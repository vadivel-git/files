<?php
    //error_reporting(E_ALL ^ E_NOTICE);
    error_reporting(0);
    header("Access-Control-Allow-Origin: *");
    $quoteInfo = array();
    include_once "lib/serverconnect.php";
    include_once "lib/common_array_price_quote.php";
    include_once "lib/functions.php";
    include_once "common_setting.php";
    $site_url   = $_REQUEST['sitename'];
    $input = trim($site_url, '/');
    // If scheme not included, prepend it
    if (!preg_match('#^http(s)?://#', $input)) {
        $input = 'http://' . $input;
    }
    $urlParts = parse_url($input);
    // remove www
    $site_name = preg_replace('/^www\./', '', $urlParts['host']);
    if (isset($_REQUEST['command'])) {
        $command = isset($_REQUEST['command']) ? strtolower($_REQUEST['command']) : '';
        if ($command == "updatefilecount") {
            $filescount = $_REQUEST['completedfilecnt'] . "/" . $_REQUEST['totalfilecnt'];
            mysql_query("UPDATE ".$quoteInfo['uptblname']." SET filescount='" . $filescount . "' WHERE  ".$quoteInfo['uptblprimarykey']."=" . $quoteInfo['quoteid']);
            mysql_query("UPDATE uploads SET upload_status = 1 WHERE created_ts >= DATE_SUB(CURDATE(),INTERVAL 1 day) AND FileName = '$_REQUEST[uploadedFile]' ");
        }
        die('cnt updated...');
    }
    $website        = $QUOTEMAILERINFO[$site_name]['name'];
    $ipaddress      = $_SERVER['REMOTE_ADDR'];
    date_default_timezone_set('America/New_York');
    $createddate    = date('Y-m-d H:i:s');
    $browserdetail  = $_SERVER['HTTP_USER_AGENT'];
   if (isset($_REQUEST['fieldinfocommand'])) {
        $commandinfo = isset($_REQUEST['fieldinfocommand']) ? strtolower($_REQUEST['fieldinfocommand']) : '';
        $valuearray=array();
        if ($commandinfo == "updatefieldinfo") {
            $valuearray=$_REQUEST['savedata'];
            $crmservice = ucfirst($valuearray['service']);
            $Fieldinfo_UniqeID = uniqid();
         
            if($valuearray["entryval"]){
                switch ($valuearray["fieldname"]) {
                    case 'paytc_qemailcrm':
                        $fieldname  = "email";
                        $fieldvalue = $valuearray["qemail"];
                        break;
                    case 'specification_pay':
                        $fieldname  = "purpose";
                        $qpurpose = $valuearray["specification_pay"];
                        $qpurposearray = explode(',', $qpurpose);
                        $purposehtml = '';
                        foreach ($qpurposearray as $purposname) {
                            $purposehtml .= $purposes[$purposname] . ',';
                        }
                        $purposehtml = rtrim($purposehtml, ',');
                        $fieldvalue = $purposehtml;
                        break;
                    case 'srclang':
                        $fieldname  = "source";
                        $fieldvalue = $language[$valuearray["srclang"]];
                        break;
                    case 'trglang':
                        $fieldname  = "target";
                        $trglang = $valuearray["trglang"];
                        $trglangarray = explode(',', $trglang);
                        $trglanghtml = '';
                        foreach ($trglangarray as $trglangname) {
                            $trglnghtml .= $language[$trglangname] . ',';
                        }
                        $trglanghtml = rtrim($trglnghtml, ',');
                        $fieldvalue = $trglanghtml;
                        break;
                    case 'prfilelength':
                        $fieldname  = "minutes";
                        $fieldvalue = $valuearray["prfilelength"];
                        break;
                    case 'expedited':
                        $fieldname  = "rush";
                        $fieldvalue = $valuearray["expedited"];
                        break;
                    case 'priceviewed':
                        $fieldname  = "priceviewed";
                        $fieldvalue = $valuearray["priceviewed"];
                        break;
                    case 'pricetotal':
                        $fieldname  = "price";
                        $fieldvalue = $valuearray["pricetotal"];
                        break;
                    case 'clicknext':
                        $fieldname  = "proceedednext";
                        $fieldvalue = $valuearray["clicknext"];
                        break;
                    case 'needtranscript':
                        $fieldname  = "needtranscript";
                        $fieldvalue = $valuearray["needtranscript"];
                        break;
                     case 'formatting':
                        $fieldname  = "format";
                        $fieldvalue = $valuearray["formatting"];
                        break;
                    case 'camethrough':
                        $fieldname  = "camethrough";
                        $fieldvalue = $valuearray["camethrough"];
                        break;
                    case 'fileupload_tat':
                        $fieldname  = "ttime";
                        $fieldvalue = $valuearray["fileupload_tat"];
                        break;
                    case 'fileuploader':
                        $fieldname  = "ufile";
                        $fieldvalue = $valuearray["filedetails"];
                        break;
                    case 'frtrial':
                        $fieldname  = "freetrial";
                        $fieldvalue = $valuearray["frtrial"];
                        break;
                    default:
                        break;
                }
                mysql_query("UPDATE enquiry_transcription_payment SET " . $fieldname . " ='" . $fieldvalue . "',modified='$createddate' WHERE entryid='" . $valuearray["entryval"]."'");
                die($valuearray["entryval"]);
            }else{
                if($website==''){
                    $website=$site_name;
                }

                $trglang = $valuearray["trglang"];
                $trglangarray = explode(',', $trglang);
                $trglanghtml = '';
                foreach ($trglangarray as $trglangname) {
                    $trglnghtml .= $language[$trglangname] . ',';
                }
                $trglanghtml = rtrim($trglnghtml, ',');

                $qpurpose = $valuearray["specification_pay"];
                $qpurposearray = explode(',', $qpurpose);
                $purposehtml = '';
                foreach ($qpurposearray as $purposname) {
                    $purposehtml .= $purposes[$purposname] . ',';
                }
                $purposehtml = rtrim($purposehtml, ',');


                mysql_query("INSERT INTO enquiry_transcription_payment(email, purpose, source, target, minutes, rush, needtranscript,camethrough,ttime, created, ip_address, website, siteurl, entryid, format, browserdetail, service, ufile, freetrial, priceviewed)
                    VALUES('".mysql_real_escape_string(htmlentities($valuearray["qemail"])) ."', '".mysql_real_escape_string(htmlentities($purposehtml)) ."',
                    '".$language[mysql_real_escape_string(htmlentities($valuearray["srclang"]))]."', '".mysql_real_escape_string(htmlentities($trglanghtml))."',
                    '".mysql_real_escape_string(htmlentities($valuearray["prfilelength"])) ."', '".mysql_real_escape_string(htmlentities($valuearray["expedited"])) ."',
                    '".mysql_real_escape_string(htmlentities($valuearray["needtrc"])) ."', '".mysql_real_escape_string(htmlentities($valuearray["camethrough"])) ."', 
                    '".mysql_real_escape_string(htmlentities($valuearray["fileupload_tat"])) ."', '$createddate', '$ipaddress', '$website', '$site_name', '$Fieldinfo_UniqeID', 
                    '".mysql_real_escape_string(htmlentities($valuearray["formatting"])) ."','$browserdetail', '$crmservice', '".mysql_real_escape_string(htmlentities($valuearray["filedetails"])) ."',
                    '".mysql_real_escape_string(htmlentities($valuearray["frtrial"]))."','".mysql_real_escape_string(htmlentities($valuearray["priceviewed"]))."')");
                    $lastinsertedid= mysql_insert_id();
                    if($lastinsertedid){
                        $entryid= $Fieldinfo_UniqeID;
                    }
                    $output = $entryid;
                die($output);
            }
        }
        if ($commandinfo == "mailnetworkerror") {
            $valuearray             =$_REQUEST['networkerrordata'];
            $crmservice             = ucfirst($valuearray["service"]);
            $networkerrflag         = $valuearray["networkerrflag"];
            $email                  = $valuearray["qemail"];
            $name                   = $valuearray["qname"];
            $country                = $valuearray["qcountrys"];
            $purpose                = $valuearray["qpurpose"];
            $acode                  = $valuearray["acode"];
            $qphone                 = $valuearray["qphone"];
            $entryval               = $valuearray["entryval"];
            $filedetails            = $valuearray["filedetails"];
            $fileuploadstatus       = $valuearray["fileuploadstatus"];
            $uploadprogress         = $valuearray["uploadprogress"];
            $crmpage                = $valuearray["crmpage"];
			$uploaderrorresponse    = $valuearray["uploaderrorresponse"];
            $uploadedfiledetails    =  $valuearray["uploadedfiledetails"];
            $to                     = 'support@vananservices.com,vananbackup@gmail.com';
            $subject                = $crmservice.' '.$QUOTEMAILERINFO[$site_name]['subject']." : Alternate Upload Options ";
            if($crmpage =="upload"){
                $subject        =  str_replace("Quote","Upload",$subject);
            }
            $foldername             = "log";
            $filename               ="networkerror";
            if (!is_dir($foldername)) {
                mkdir($foldername, 0777, true);
            }
            $date=date('d-m-Y');    
            $logdata = "<$createddate> ## <$entryval> ## <$email> ## <$filedetails> ## <$fileuploadstatus> ## <$uploadprogress> 
            ## <$uploaderrorresponse> ## <$uploadedfiledetails>";
            file_put_contents($foldername.'/'.$filename.'_'.$date.'.txt', $logdata . PHP_EOL, FILE_APPEND);
            $neterrmailreplace = array('__NETERR_SITEURL__' => $site_name.'/AlternateUpload.php');
            $fileopen               = fopen("mailer/networkerror.html", "r");
            $networkerrmail_content = fread($fileopen, filesize("mailer/networkerror.html"));
            fclose($fileopen);
            $networkerrmsg          = strtr($networkerrmail_content, $neterrmailreplace);
            if(multi_attach_mail($to, $subject, $networkerrmsg, $email, $name,1))
            {
                die("1");
            }else{
                die("0");
            }
        }
    }
if(isset($_REQUEST['coupon'])){
    $offpct = $couponcodes[$_REQUEST['coupon']];
    if($offpct == ''){
        $offpct = 0;
    }
    echo $offpct;
    die;
}
if(isset($_POST['buttonname'])) {
    date_default_timezone_set('America/New_York');
    $email              = isset($_POST['email']) ? $_POST['email'] : "";
    $qservice           = isset($_POST['service']) ? $_POST['service'] : "";
    $sourcefiletype     = isset($_POST['sourcefiletype']) ? $filetypes[$_POST['sourcefiletype']] : "";
    $prfilelength       = isset($_POST['prfilelength']) ? $_POST['prfilelength'] : "";
    $pagecount          = isset($_POST['pagecount']) ? $_POST['pagecount'] : "";
    $qtlang = $source   = isset($_POST["source"]) ? $language[$_POST["source"]] : "";   
    $target             = isset($_POST["target"]) ? $_POST["target"] : "";
    $qpurpose           = isset($_POST['specification_pay']) ? $_POST['specification_pay'] : "";
    $fileupload_tat     = isset($_POST["fileupload_tat"]) ? $_POST["fileupload_tat"] : "";
    $notacrmpay         = isset($_POST['notacrmpay']) ? $_POST['notacrmpay'] : "";
    $mailfilecrmpay     = isset($_POST['mailfilecrmpay']) ? $_POST['mailfilecrmpay'] : "";
    $mailcountry        = isset($_POST['mailcountry'])!="" ? $country[$_POST['mailcountry']] : "";
    $script_amount      = isset($_POST['script_cost']) ? $_POST['script_cost'] : "";
    $tcode_cost         = isset($_POST['tcode_cost']) ? $_POST['tcode_cost'] : "";
    $mailingaddr        = isset($_POST['mailingaddr']) ? $_POST['mailingaddr'] : "";
    $uploadat           = isset($_POST['uploadat']) ? $_POST['uploadat'] : "";
    $trgtunitcost       = isset($_POST["trgtunitcost"]) ? $_POST["trgtunitcost"] : "";
    $trgttotamt         = isset($_POST["trgttotamt"]) ? $_POST["trgttotamt"] : "";
    $nota_subamt        = isset($_POST['nota_subamt']) ? $_POST['nota_subamt'] : "";
    $notapro_subamt     = isset($_POST['notapro_subamt']) ? $_POST['notapro_subamt'] : "";
    $mfile_subamt       = isset($_POST['mfile_subamt']) ? $_POST['mfile_subamt'] : "";
    $subamttot          = isset($_POST['subamttot']) ? $_POST['subamttot'] : "";
    $transactionfee     = isset($_POST['transactionfee']) ? $_POST['transactionfee'] : "";
    $ordertotal         = isset($_POST['paymentamt']) ? $_POST['paymentamt'] : "";
//    $mini_subamt        = isset($_POST['mini_subamt']) ? $_POST['mini_subamt'] : "";
    $agent_ref          = isset($_POST["agent_ref"]) ? $_POST["agent_ref"] : "";
    $aprxtat            = isset($_POST["aprxtat"]) ? $_POST["aprxtat"] : "";
    $camethrough        = isset($_POST['camethrough']) ? $_POST['camethrough'] : "";
    $cst_db             = isset($_POST['cst_db']) ? $_POST['cst_db'] : "";
    $qtmin              = $prfilelength;
    $deliveryReq        = isset($_POST['deliveryReq']) ? $_POST['deliveryReq'] : "";
    $buttonname         = isset($_POST['buttonname']) ? $_POST['buttonname'] : "";
    $formatting         = isset($_POST["formatting"]) ? $_POST["formatting"] : "";
    $needtranscript     = isset($_POST['needtrc']) ? $_POST['needtrc'] : "";

    $fil                = isset($_POST['filena']) ? $_POST['filena'] : "";
    $fildetail          = isset($_POST['fildetail']) ? $_POST['fildetail'] : "";
    $duratnval          = isset($_POST['duratnval']) ? $_POST['duratnval'] : "";
    $filecomments       = isset($_POST['filecomments']) ? $_POST['filecomments'] : "";
    $ofpct           = isset($_POST['ofpct']) ? $_POST['ofpct'] : "";
    $offerval           = isset($_POST['offerval']) ? $_POST['offerval'] : "";
    $finalround         = isset($_POST['finalround']) ? $_POST['finalround'] : "";
    $siteprtcl          = isset($_POST['siteprtcl']) ? $_POST['siteprtcl'] : "";
    $sitename          = isset($_POST['sitename']) ? $_POST['sitename'] : "";
    $frtrial          = isset($_POST['frtrial']) ? $_POST['frtrial'] : "";

    $purposehtml = arraytoString($qpurpose,$purposes);
    $targethtml  = arraytoString($target,$language);

    $filena = '';
    $s      = explode(',', $fil);
    $fie    = '';
    $fill   = '';
    $filink = '';
    $cou    = count($s);

    for ($t = 0; $t < $cou; $t++) {
        if ($t != ($cou - 1)) {
            $fill = str_replace("\\", '/', $s[$t]);
            $fie = $fie . basename($fill) . "|,";
        } else {
            $fill = str_replace("\\", '/', $s[$t]);
            $fie = $fie . basename($fill);
        }
    }

    $filescount     = $completedfilecnt . "/" . $count;
    $fileInfo = $fileArr = array();

    if (!empty($_REQUEST['uploadedFileDetailsArr'])){
        $uploadedfilesarr = explode(",", $_REQUEST['uploadedFileDetailsArr']);
    }
    foreach ($uploadedfilesarr as $arrayval) {
        $uploadedfilearr= explode("#-#", $arrayval);
        $uploadedfilenamearr[] = substr($uploadedfilearr[0], strpos($uploadedfilearr[0], '/') + 1);
    }
    $mn=0;
    $filecontentrow='';
    $rushper='';
    if($rushopts == 3){
        $rushper = '150%';
    }else if($rushopts == 2){
        $rushper = '100%';
    }else if($rushopts == 1){
        $rushper = '50%';
    }

    $deliveryReq        = ($deliveryReq == '1') ? 'Yes' : 'No';
    $notacrmpay         = ($notacrmpay == '1') ? 'Yes' : 'No';
    $mailfilecrmpay     = ($mailfilecrmpay == '1') ? 'Yes' : 'No';
    $nativespkr         = ($nativespkr == '1') ? 'Yes' : 'No';
    $needtranscript     = ($needtranscript == '1') ? 'Yes' : 'No';
    $frtrial             = ($frtrial == '1') ? 'Yes' : 'No';

    $channelno = 11;
    if ($buttonname == "Proceed to Payment") {
        $channelno = 10;
    } elseif ($buttonname == "Get Quote") {
        $channelno = 11;
    } elseif ($buttonname == "Email Quote") {
        $channelno = 19;
    }

    $channelno   = ($cst_db == '1') ? 9 : $channelno;
    $hiddenservice = $servicelist[ucfirst($qservice)];
    $sitechannel = "abchidFS" . encrypt('__sitename_' . $site_name . '__ __channel_' . $channelno . '__ __service_' . $hiddenservice . '__ __cstemail_' . $email . '__ __ipaddress_' . $ipaddress . '__', 'vanancrm*encrypt') . "abchidFE";

    if(!in_array($sitename,$notcommonfootersites)) {
        $subjecthtml = "Vanan Online Services";
        $footerhtml = '<tr style="text-align: center;background: #006dce;border: solid 1px #006DCE;border-bottom-right-radius: 4px; border-bottom-left-radius: 4px;">
                <td style="padding: 16px 22px;"> <a href="https://vananservices.com/"><img src="https://vananservices.com/img/as-logo.png"></a>
                    <br>
                    <p style="color: #fff;font-size: 13px;margin: 8px 0 0 0;line-height: 30px;letter-spacing: 0.9px; text-align: center;"> Transcription | Translation |  Captioning/Subtitling  | Voice Over| Video Services |  Writing |  Typing |  Dictation</p>
                </td>
            </tr>

            <tr style="background:#f1f8fc;text-align: center;border: solid 1px #006DCE;border-bottom-right-radius: 4px; border-bottom-left-radius: 4px;">
                <td>
                    <p style="color: #333;font-size: 12px;font-weight: bold;margin: 0;line-height: 30px;letter-spacing: 0.9px;">  Toll-Free : &nbsp;<span style="color: #006dce;">US</span> : 1-888-535-5668 &nbsp; <span style="color: #006dce;">UK</span> : +44-80-8238-0078 &nbsp; <span style="color: #006dce;">AUS</span> : +44-80-8238-0078 </p>
                </td>
            </tr>';
    }else{
        $subjecthtml = "Helplancers";
        $footerhtml='<tr style="text-align: center;background: #006dce;border: solid 1px #006DCE;border-bottom-right-radius: 4px; border-bottom-left-radius: 4px;">
                <td style="padding: 16px 22px;">
                    <p style="color: #fff;font-size: 13px;margin: 8px 0 0 0;line-height: 30px;letter-spacing: 0.9px; text-align: center;"> Transcription | Translation |  Captioning/Subtitling  | Voice Over| Video Services |  Writing |  Typing |  Dictation</p>
                </td>
            </tr>

            <tr style="background:#f1f8fc;text-align: center;border: solid 1px #006DCE;border-bottom-right-radius: 4px; border-bottom-left-radius: 4px;">
                <td>
                    <p style="color: #333;font-size: 12px;font-weight: bold;margin: 0;line-height: 30px;letter-spacing: 0.9px;">  Toll-Free : &nbsp;<span style="color: #006dce;">US</span> : 1-888-422-2268 </p>
                </td>
            </tr>';
    }
    /*----------------------------FREE QUOTE START -------------------------*/
    if ($buttonname == "Get Quote") {
        $QUOTESERVICE = 'Captioning';
        $updateTableName = 'tickets_transcription_payment';
        $updateTablePrimaryKey = 'id';
        /*---------------MAIL CONTENT START---------------*/
        $mailngaddr = '';
        $mailngcntry = '';
        $mailfilehtml = '';
             $formathtml = '';
        if ($formatting != '') {
            $formathtml = '<tr class="unread">
                    <td align="center" style="border-right: 1px solid #ddd;font-size: 15px;width: 161px;text-align: left;padding:12px 10px;border-bottom: 1px solid #ddd;"><b style="font-weight: bold;color: #3f3d3d;">Format </b></td>
                    <td align="center" style="padding: 8px;font-size: 15px;border-bottom: 1px solid #ddd; text-align: left;">' . $formatting . '</td>
                </tr>';
        }
        $minuteshtml = '<tr class="unread">
                <td align="center" style="border-right: 1px solid #ddd;border-bottom: 1px solid #ddd;font-size: 15px;width: 161px;text-align: left;padding:12px 10px;"><b style="font-weight: bold;color: #3f3d3d;">Minutes</b></td>
                <td align="center" style="padding: 8px;font-size: 15px;border-bottom: 1px solid #ddd; text-align: left;">' . $qtmin . '</td>
            </tr>';

        $needtrchtml = '';
        if($needtranscript == 'Yes'){
            $trclabel = (strtolower($source) == strtolower($targethtml))?"Transcription is available":"Translation is available";

            $needtrchtml = ' <tr class="unread">
                <td align="center" style="border-right: 1px solid #ddd;font-size: 15px;width: 161px;text-align: left;padding:12px 10px;border-bottom: 1px solid #ddd;"><b style="font-weight: bold;color: #3f3d3d;">'.$trclabel.'</b></td>
                <td align="center" style="padding: 8px;font-size: 15px;border-bottom: 1px solid #ddd; text-align: left;">' . $needtranscript . '</td>
            </tr>';
        }
        
        $expeditedhtml = '';
        if ($deliveryReq == "Yes") {
            $expeditedhtml = ' <tr class="unread">
                <td align="center" style="border-right: 1px solid #ddd;font-size: 15px;width: 161px;text-align: left;padding:12px 10px;border-bottom: 1px solid #ddd;"><b style="font-weight: bold;color: #3f3d3d;">Expedited Service</b></td>
                <td align="center" style="padding: 8px;font-size: 15px;border-bottom: 1px solid #ddd; text-align: left;">' . $deliveryReq . '</td>
            </tr>';
        }


        $fileupload_tathtml = '';
        if ($fileupload_tat != "" ) {
            $fileupload_tathtml = ' <tr class="unread">
                <td align="center" style="border-right: 1px solid #ddd;font-size: 15px;width: 161px;text-align: left;padding:12px 10px;border-bottom: 1px solid #ddd;"><b style="font-weight: bold;color: #3f3d3d;">Turnaround Time</b></td>
                <td align="center" style="padding: 8px;font-size: 15px;border-bottom: 1px solid #ddd; text-align: left;">' . $fileupload_tat . '</td>
            </tr>';
        }
        $tathtml = '';
        if ($aprxtat != "") {
            $tathtml = '<tr class="unread">
                <td align="center" style="border-right: 1px solid #ddd;font-size: 15px;width: 161px;text-align: left;padding:12px 10px;border-bottom: 1px solid #ddd;"><b style="font-weight: bold;color: #3f3d3d;">Turnaround Time</b></td>
                <td align="center" style="padding: 8px;font-size: 15px;border-bottom: 1px solid #ddd; text-align: left;">' . $aprxtat . '</td>
            </tr>';
        }
        $frtrialhtml = '';
        if ($frtrial == "Yes") {
            $frtrialhtml = '<tr class="unread">
                <td align="center" style="border-right: 1px solid #ddd;font-size: 15px;width: 161px;text-align: left;padding:12px 10px;border-bottom: 1px solid #ddd;"><b style="font-weight: bold;color: #3f3d3d;">Free trial</b></td>
                <td align="center" style="padding: 8px;font-size: 15px;border-bottom: 1px solid #ddd; text-align: left;">' . $frtrial . '</td>
            </tr>';
        }

        /*---------------MAIL CONTENT END---------------*/

        //if ($SEND_QUOTE == 0) {
        if ($website == '') {
            $website = 'Sitename not given';
        }
        $neworderId = '';
        if ($QUOTESERVICE == 'Captioning') {
             mysql_query("INSERT INTO tickets_transcription_payment(id,minutes,email,ttime,tat,fileformat,servicetype,language,  website, camethrough, ipaddress,createddate,browserdetail,purpose,service,paymentamt,notary,mailing,mailingcountry,mailingaddress,sourcefiletype,pagecount,source_lang,target_lang, format,agentid,buttonname, needtranscription)"
                ."VALUES('','$qtmin','$email','$aprxtat','$fileupload_tat','$qtformat','$qservice','$qtlang','$website','$camethrough','$ipaddress','$createddate','$browserdetail','".mysql_real_escape_string(htmlentities($purposehtml))."','$QUOTESERVICE','$ordertotal','$notacrmpay','$mailfilecrmpay','$mailcountry','$mailingaddr','$sourcefiletype','$pagecount','$source','$targethtml','$formatting','$agent_ref','$buttonname','$needtranscript')");
            $lastinsertedid = mysql_insert_id();
            $todayDate = date('Y-m-d');
            $ordId = mysql_query("SELECT COUNT( * ) as total FROM  `tickets_transcription_payment` WHERE DATE(createddate) = '$todayDate' AND id < $lastinsertedid AND servicetype ='captioning' AND orderno !=''");
            $data = mysql_fetch_assoc($ordId);
            $ordId = $data['total'];
            $ordId++;
            $neworderId = "TP" . date("dmy") . $ordId;
            $neworderIdhtml = "Your confirmation ID is $neworderId.";
            mysql_query("UPDATE tickets_transcription_payment SET orderno ='$neworderId'  WHERE id=$lastinsertedid");
        }
        $sno = $lastinsertedid;

        if (!empty($fil)){
            $fileArr = explode(",", $fil);
            $duratnArr = explode(",", $duratnval);
            foreach ($fileArr as $val) {
                $UniqeID                = uniqid();
                $duratn                 = $duratnArr[$mn];
                $infoArr                = explode("#-#", $val);
                $param                  = array();
                $param['fileid']        = $UniqeID;
                $param['filename']      = substr($infoArr[0], strpos($infoArr[0], '/') + 1);
                $param['filesize']      = $infoArr[1];
                $param['fileduration']  = $duratn;
                $param['transfee']      = $transactionfee;
                $param['ordertotal']    = $ordertotal;
                $status                 = (in_array($param['filename'], $uploadedfilenamearr)) ? 1 :0;
                $fileInfo[]             = $param;
                //echo "INSERT INTO uploads (Id, OrderId, TableCode, FileName,FileFormat,FileSize,FileId,upload_status) values ('','$sno', '$tbleCodeStr', '$infoArr[0]','$infoArr[2]','$infoArr[1]', '$UniqeID',$status) ";
                mysql_query("INSERT INTO uploads (Id, OrderId, TableCode, FileName,FileFormat,FileSize,FileId,upload_status) values ('','$neworderId', '$tbleCodeStr', '$infoArr[0]','$infoArr[2]','$infoArr[1]', '$UniqeID',$status) ");
                $mn++;
            }
        }
        $filink = $filesizeinfo = '';
        $j = 1;

        $fileDonwloadurl = $CRMSERVERPATH.'filedownload.php?FileId=';

        foreach($fileInfo as $val){
            $filduro = $val['fileduration'];
            $indcost = $val['indcost'];

            //$filedpnames = explode("xx_", $val['filename']);
            $dispName = substr($val['filename'], strpos($val['filename'], '_') + 1);
            $filink ='<a data-download="' . $val['filename'] . '" style="color:blue;" href="' . $fileDonwloadurl . $val['fileid'] . '">Download</a><br/>';
            $filecontentrow .='<tr>
                                    <td align="left" style="border-right: 1px solid #e7e7e7;font-size: 13px;border-bottom: 1px solid #e7e7e7;">'.$dispName.'</td>
                                    <td align="left" style="border-bottom: 1px solid #e7e7e7;font-size: 13px;">'.$filink.' </td></tr>';
        }
        $filerowhtml='';
        if(!empty($fileInfo)) {
            $filerowhtml = '<tr>
                                </tr>
                                <tr>
                                    <td colspan="6" align="center" style="border-bottom: 1px solid #e7e7e7;font-weight: 600;"> File details</td>
                                </tr>
                                <tr>
                                    <td align="left" style="border-right: 1px solid #e7e7e7;border-bottom: 1px solid #e7e7e7;font-weight: 600;"> File name</td>
                                    <td align="left" style="border-bottom: 1px solid #e7e7e7;font-weight: 600;"> Link</td>
                                </tr>
                                                       
                            ' . $filecontentrow;
        }

        $filecommentshtml ='';
        if(!empty($fileInfo) && $filecomments != '') {
            $filecommentshtml = '<tr class="unread">
                <td align="center" style="border-right: 1px solid #ddd;font-size: 15px;width: 161px;text-align: left;padding:12px 10px;border-bottom: 1px solid #ddd;"><b style="font-weight: bold;color: #3f3d3d;">Special words</b></td>
                <td align="center" style="padding: 8px;font-size: 15px;border-bottom: 1px solid #ddd; text-align: left;">' . $filecomments . '</td>
            </tr>';
        }
        if ($sno) {
            mysql_query("UPDATE enquiry_transcription_payment SET flag ='1'  WHERE entryid='" . $_POST['recordkey'] . "'");
        }
        $secondfold = $formathtml.$minuteshtml . $needtrchtml . $expeditedhtml. $fileupload_tathtml . $tathtml.$frtrialhtml. $filerowhtml. $filecommentshtml;
        $param = $neworderId . '|<>|' . $sno;
        $param = encrypt_decrypt('encrypt', $param);

        $service_name = $QUOTESERVICE . ' Services - Quote'; //'Translation Services - Quote';
        $logo = rtrim($siteprtcl.$site_url, '/') . '/img/DS-logo.png';
        $mailreplace = array('__SITELOGOIMG__' => $logo,
                            '__NAME__' => $name,
                            '__EMAIL__' => $email,
                            '__PHONE__' => $phone,
                            '__HEADERIMG__' => $logo,
                            '__TRANSACFEE__' => $transactionfee,
                            '__ORDERTOTAL__' => $ordertotal,
                            '__FILEROW__' => html_entity_decode($filerowhtml),
                            '__ORDERID__' => $neworderIdhtml,
                            '__COSTPERPAGE__' => $trgtunitcost,
                            '__TLCOST__' => $trgttotamt,
                            '__TRCHTM__' => $trcHtml,
                            '__TRLHTM__' => $needtrlsHtml,
                            '__NATIVECOST__' => $nativeavail,
                            '__SUBTOTALCOST__' => $subamttot,
                            '__INPUTFILEFORMAT__' => $qtformat,
                            '__TRANSCRIPTION__' => $qtlang,
                            '__SOURCE__' => $source,
                            '__TARGET__' => $targethtml,
                            '__NOTE__' => $qnote,
                            '__GMAILCONTENT__' => $qmail,
                            '__GMAILCONTENTDISP__' => empty($qmail)?"none":"",
                            '__TATIME__' => $aprxtat,
                            '__PURPOSE__' => $purposehtml,
                            '__COMMENT__' => nl2br(stripslashes($comment)),
                            '__SERVICENAME__' => $service_name,
                            '__SITEURL__' => $site_url,
                            '__SERVICETYPE__' => $qservice,
                            '__HFSERVICE__' => $paytc_hfc,
                            '__NOOFPAGES__' => $nopageshtml,
                            '__FORMAT__' => $formatting,
                            '__FORMATTING__' => $formathtml,
                            '__SUBJECT__' => $subjectcrm,
                            '__CAPTIONING__' => $captioningcrm,
                            '__NEEDTRANSCRIPTION__' => $needtranscriptioncrm,
                            '__VIDEOLENGTH__' => $videolengthcrm,
                            '__NEEDTRANSLATION__' => $needtranslationcrm,
                            '__SOURCEVOICEOVER__' => $sourcevoiceover,
                            '__SOURCEVOICEOVERDISP__' => (empty($needtranslationcrm) || $needtranslationcrm == 'No')?"none":"" ,
                            '__SCRIPTCRM__' => $scriptcrm,
                            '__COMMENTVOICEOVER__' => $commentvoiceover,
                            '__PURPOSEVOICEOVER__' => $purposevoiceover,
                            '__VOICECOUNTCRM__' => $voicecountcrm,
                            '__GENDERAGECRM__' => $genderage,
                            '__GENDERAGECRMDISP__' => empty($voicecountcrm)?"none":"",
                            '__SCRIPTVOICEOVER__' => $scriptcrm,
                            '__SCRIPTVOICEOVERDISP__' => (empty($scriptcrm) || $scriptcrm == 'No')?"none":"",
                            '__SITENAME__' => $site_name,
                            '__MINIMUM__' =>$minimumhtml,
                            '__HARDCOPYREQ__' =>$hardcopyhtml,
                            '__NOTARY__' =>$notaryhtml,
                            '__MAILED__' => $mfilehtml,
                            '__MAILADDR__' => $mailingaddrhtml,
                            '__MINORDER__' =>"",
                            '__FILETYPE__' => $sourcefiletype,
                            '__SITECHANNEL__' => $sitechannel,
                            '__SECFOLD__' => $secondfold,
                            '__MAILCOUNTRYHTML__' => $mailingfulladdr,
                            '__TATTIMEHTML__' => $tathtml,
                            '__SITESUB__' => $subjecthtml,
                            '__FOOTER__' => $footerhtml,
                            '__FILESIZEINFO__' => html_entity_decode($filesizeinfo)

                            );

       // }
        $quoteInfo = array('quoteservice'=>$QUOTESERVICE,'mailarray'=>$mailreplace);

        $service_name = $quoteInfo['quoteservice'] . ' Services - Quote'; //'Translation Services - Quote';
        $subject = $quoteInfo['quoteservice'] . $QUOTEMAILERINFO[$site_name]['subject'];//.$site_name;
        if ($crmpage == "upload") {
            $service_name = str_replace("Quote", "Upload", $service_name);
            $subject = str_replace("Quote", "Upload", $subject);
        }

        //$mailreplace = $quoteInfo["mailarray"];
        $quotemailerarray = array(
            '__SERVICESUBJECT__' => $subject,
            '__SERVICENAME__' => $service_name);
        $mailreplacenew = array_merge($mailreplace, $quotemailerarray);
//        echo $MAILERCODE[$QUOTESERVICE];
        $file = fopen("mailer/" . $MAILERCODE[$QUOTESERVICE], "r");
        $htmlmail_content = fread($file, filesize("mailer/" . $MAILERCODE[$QUOTESERVICE]));
        fclose($file);
        $html_content = strtr($htmlmail_content, $mailreplacenew);
        $to = $email;
        multi_attach_mail($to, $subject, $html_content, $email, $sitename);
        if (isset($_COOKIE['uploadtest'])) {
            echo "===>Success...";
        }
        $output = json_encode(array('type' => 'message', 'text' => 'Your request has been sent successfully and you will receive an email from us shortly. Thank you!', 'param' => $param));
        die($output);
        /*----------------------------FREE QUOTE END -------------------------*/
    }
    else if($buttonname !=''){
    /*----------------------------PAYMENT QUOTE START -------------------------*/

    /* $minimumhtml = '';
    if (($mini_subamt > $subamttot)) {
        $minimumhtml .= '<tr>
                    <td colspan="6" align="right" style="border-right: 1px solid #e7e7e7;border-top: 1px solid #e7e7e7;padding-right: 10px;">  <p style="color: #302e2e;font-size: 13px;"> Minimum order cost</p></td>
                    <td align="right" style="border-top: 1px solid #e7e7e7;width: 20%;">  <p style="color: #302e2e;font-size: 13px;">$' . $mini_subamt .'</p> </td>
                    </tr>';
    }*/

    $needtrchtml = '';
    $trclabel = 'Transcription';
    if($source != $targethtml){
        $trclabel = 'Translation';
    }
//    if($needtranscript == 'No' && $tcode_cost > 0 && ($source != "English" && $target != "English")){
    if($needtranscript == 'No' && $script_amount > 0 ){
    $needtrchtml = '<tr>
                <td colspan="6" align="right" style="border-right: 1px solid #e7e7e7;border-top: 1px solid #e7e7e7;padding-right: 10px;">  <p style="color: #302e2e;font-size: 13px;">'.$trclabel.' fee</p></td>
                <td align="right" style="border-top: 1px solid #e7e7e7;width: 20%;">  <p style="color: #302e2e;font-size: 13px;">$' . $script_amount . '</p> </td>
                </tr>';
    }
    $tcodehtml ='';
    if($tcode_cost > 0){
        $tcodehtml = '<tr>        
            <td colspan="6" align="right" style="border-right: 1px solid #e7e7e7;border-top: 1px solid #e7e7e7;padding-right: 10px;">  <p style="color: #302e2e;font-size: 13px;">Timecode fee</p></td>
            <td align="right" style="border-top: 1px solid #e7e7e7;width: 20%;">  <p style="color: #302e2e;font-size: 13px;">$' . $tcode_cost . '</p> </td>
        </tr>';
    }

        $offervalhtml ='';
        if($offerval > 0){
            $offervalhtml = '<tr>
            <td colspan="6" align="right" style="border-right: 1px solid #e7e7e7;border-top: 1px solid #e7e7e7;padding-right: 10px;">  <p style="color: #302e2e;font-size: 13px;"> Coupon discount (-'.$ofpct.')</p></td>
            <td align="right" style="border-top: 1px solid #e7e7e7;width: 20%;">  <p style="color: #302e2e;font-size: 13px;">$' . $offerval . '</p> </td>
        </tr>';
        }
        $finalroundhtml ='';
        if($finalround > 0) {
            $finalroundhtml = '<tr>
        <td colspan="6" align="right" style="border-right: 1px solid #e7e7e7;border-top: 1px solid #e7e7e7;padding-right: 10px;">  <p style="color: #302e2e;font-size: 13px;"> Offer price</p></td>
        <td align="right" style="border-top: 1px solid #e7e7e7;width: 20%;">  <p style="color: #302e2e;font-size: 13px;">$' . $finalround . '</p> </td>
    </tr>';
        }
    $frtrialhtml = '';
    if($frtrial == "Yes"){
        $frtrialhtml ='<tr><td colspan="7" align="center" style="border-top: 1px solid #e7e7e7;">
            <p style="color: #302e2e;font-size: 12px;">Our agent will get in touch with you regarding the free trial.</p>
        </td></tr>';
    }
    $secondfolds = $needtrchtml.$tcodehtml;
    $QUOTESERVICE   = 'Captioningpay';
    $QUOTESERVICEdb = $QUOTESERVICE;
    if ($buttonname == "Email Quote") {
        $QUOTESERVICEdb = 'Captioningpayquote';
    }


    $updateTableName = 'tickets_transcription_payment';
    $updateTablePrimaryKey = 'id';

    if ($website == '') {
        $website = 'Sitename not given';
    }
    if ($QUOTESERVICE == 'Captioningpay') {
        $neworderIdhtml = '';
        $neworderId = '';
       mysql_query("INSERT INTO tickets_transcription_payment(id,email,minutes,format,tat,ttime,servicetype,language,website,ipaddress,createddate,browserdetail,service,paymentamt,notary,mailing,mailingcountry,mailingaddress,sourcefiletype,pagecount,source_lang,target_lang,agentid,buttonname,rush,camethrough,needtranscription,native,purpose) "
            . "VALUES('','$email','$qtmin','$formatting','$fileupload_tat','$aprxtat','$qservice','$qtlang','$website','$ipaddress','$createddate','$browserdetail','$QUOTESERVICEdb','$ordertotal','$notacrmpay','$mailfilecrmpay','$mailcountry','$mailingaddr','$sourcefiletype','$pagecount','$source','$targethtml','$agent_ref','$buttonname','$deliveryReq','$camethrough','$needtranscript','$nativespkr','".mysql_real_escape_string(htmlentities($purposehtml))."')");
        $tbleCodeStr = $TABLECODE['tickets_transcription_payment'];
        $lastinsertedid = mysql_insert_id();
        $todayDate = date('Y-m-d');
        $ordId = mysql_query("SELECT COUNT( * ) as total FROM  `tickets_transcription_payment` WHERE DATE(createddate) = '$todayDate' AND id < $lastinsertedid AND servicetype ='captioning' AND orderno !=''");        
        $data = mysql_fetch_assoc($ordId);
        $ordId = $data['total'];
        $ordId++;
        $neworderId = "TP" . date("dmy") . $ordId;
        $neworderIdhtml = "Your confirmation ID is $neworderId.";
        mysql_query("UPDATE tickets_transcription_payment SET orderno ='$neworderId'  WHERE id=$lastinsertedid");
    }
    $sno = $lastinsertedid;
        if (!empty($fil)){
            $fileArr = explode(",", $fil);
            $duratnArr = explode(",", $duratnval);
            foreach ($fileArr as $val) {
                $UniqeID                = uniqid();
                $duratn                 = $duratnArr[$mn];
                $infoArr                = explode("#-#", $val);
                $param                  = array();
                $param['fileid']        = $UniqeID;
                $param['filename']      = substr($infoArr[0], strpos($infoArr[0], '/') + 1);
                $param['filesize']      = $infoArr[1];
                $param['fileduration']  = $duratn;
                $param['transfee']      = $transactionfee;
                $param['ordertotal']    = $ordertotal;
                $status                 = (in_array($param['filename'], $uploadedfilenamearr)) ? 1 :0;
                $fileInfo[]             = $param;
                //echo "INSERT INTO uploads (Id, OrderId, TableCode, FileName,FileFormat,FileSize,FileId,upload_status) values ('','$sno', '$tbleCodeStr', '$infoArr[0]','$infoArr[2]','$infoArr[1]', '$UniqeID',$status) ";
                mysql_query("INSERT INTO uploads (Id, OrderId, TableCode, FileName,FileFormat,FileSize,FileId,upload_status) values ('','$neworderId', '$tbleCodeStr', '$infoArr[0]','$infoArr[2]','$infoArr[1]', '$UniqeID',$status) ");
                $mn++;
            }
        }
        $filink = $filesizeinfo = '';
        $j = 1;
        $fileDonwloadurl = $CRMSERVERPATH.'filedownload.php?FileId=';
        foreach($fileInfo as $val){
            $filduro = $val['fileduration'];
            $indcost = $val['indcost'];

            //$filedpnames = explode("xx_", $val['filename']);
            $dispName = substr($val['filename'], strpos($val['filename'], '_') + 1);
            $filink ='<a data-download="' . $val['filename'] . '" style="color:blue;" href="' . $fileDonwloadurl . $val['fileid'] . '">Download</a><br/>';
            $filecontentrow .='<tr>
                            <td colspan="4" align="center" style="border-right: 1px solid #e7e7e7;font-size: 13px;border-bottom: 1px solid #e7e7e7;">'.$dispName.'</td>
                            <td colspan="3" align="center" style="border-bottom: 1px solid #e7e7e7;font-size: 13px;">'.$filink.' </td></tr>';
        }
        $filerowhtml='';
        if(!empty($fileInfo)) {
            $filerowhtml = '
                   <tr>
                        </tr>
                        <tr>
                            <td colspan="7" align="center" style="border-top: 1px solid #e7e7e7;border-bottom: 1px solid #e7e7e7;font-weight: 600;"> File details</td>
                        </tr>
                        <tr>
                            <td colspan="4" align="center" style="border-right: 1px solid #e7e7e7;border-bottom: 1px solid #e7e7e7;font-weight: 600;"> File name</td>
                            <td colspan="3" align="center" style="border-bottom: 1px solid #e7e7e7;font-weight: 600;"> Link</td>
                        </tr>
                                               
                    ' . $filecontentrow;
        }
        $filecommentshtml ='';
        if(!empty($fileInfo) && $filecomments != '') {
            $filecommentshtml = ' <tr>
                            <td colspan="7" align="left" style="font-size: 13px;"><strong>Special words : </strong>'.$filecomments.'</td>
                        </tr>';
        }
    if ($sno) {
        mysql_query("UPDATE enquiry_transcription_payment SET flag ='1'  WHERE entryid='" . $_POST['recordkey'] . "'");
    }

    $service_name = $QUOTESERVICE . ' Services - Quote'; //'Translation Services - Quote';
    if ($crmpage == "upload") {
        $service_name = str_replace("Quote", "Upload", $service_name);
    }

    $logo = rtrim($siteprtcl.$site_url, '/') . '/img/DS-logo.png';
    $payicon = $CRMSERVERPATH . 'img/pay.png';
    $emailheaderimg = rtrim($site_url, '/') . '/img/Email.png';




    $url_param = "$neworderId|^|$ordertotal|^|captioning|^|$site_name";
    //TRC02052017|^|60|^|transcription|^|rajkumar@vananservices.com
    $encrypted_param = encrypt_decrypt('encrypt', $url_param);
    $paymentlink = $CRMSERVERPATH . 'paypal/payment_v2.0.php?van=' . $encrypted_param;

    $param = $neworderId . '|<>|' . $sno;
    $param = encrypt_decrypt('encrypt', $param);
    $fileuploadurl = "http://" . $site_url . "/additional-information.php?id=" . $param;
        $fileuploadurl='';
        if(empty($fileInfo)) {
            $fileuploadlink = "http://" . $site_url . "/additional-information.php?id=" . $param;
            $fileuploadurl ='<tr>
        <td align="center" colspan="6">
            <p style="color:#333;font-size: 14px;font-weight: bold;">
                <a style="text-decoration:none;font-size:14px;background-color: #007ec8; box-shadow: 0 2px 4px 0 rgba(0,0,0,.23), inset 1px 1px 0 0 hsla(0,0%,100%,.2);    display: inline-block;color: #fff;padding: 12px 25px;font-size: 16px;font-weight: 400;" href="'.$fileuploadlink.'"  target="_blank">Upload Files</a>
            </p>
        </td>
    </tr>
    <tr>
        <td align="center" colspan="6">
            <span style="color:#333;font-size: 13px;">(Ignore if you have shared your files already)</span>
        </td>
    </tr>';

        }
    $paynowhtml = '<tr style="margin: 0 auto;    display: table;">
                <td>
                    <a href="' . $paymentlink . '" style="text-decoration: none;"><div class="pay-btn" style="background-color:#00c853;padding:13px 36px;color:#fff!important;margin:10px 0px;">Pay Now</div></a>
                </td>
            </tr>               
           
             <tr>
                <td align="center" colspan="7">
                    <span style="color:#333;font-size: 13px;">(Ignore if you have made the payment already)</span>
                </td>
            </tr>
             <tr style="margin: 0 auto;display: table;">
                <td><img src="' . $payicon . '" alt="payment"></td>
            </tr>';
    $mailreplace = array('__SITELOGOIMG__' => $logo,
            '__EMAIL__' => $email,
            '__HEADERIMG__' => $logo,
            '__TRANSACFEE__' => $transactionfee,
            '__ORDERTOTAL__' => $ordertotal,
            '__ORDERID__' => $neworderIdhtml,
            '__TLCOST__' => $trgttotamt,
            '__SECFOLD__' => $secondfolds,
            '__NATIVECOST__' => $nativeavail,
            '__SUBTOTALCOST__' => $subamttot,
            '__SOURCE__' => $source,
            '__TARGET__' => $targethtml,
            '__TATIME__' => $aprxtat,
            '__PURPOSE__' => $purposehtml,
            '__SITEURL__' => $site_url,
            '__MINIUTES__' => $qtmin,
            '__COSTPERMINIUTES__' => $trgtunitcost,
            '__FORMAT__' => $formatting,
            '__MINORDER__' =>"",
            '__PAYNOW__' => $paynowhtml,
            '__UPLOADHERE__' => $fileuploadurl,
            /*'__MINORD__' => $minimumhtml,*/
            '__FILEDETAILS__' => $filerowhtml,
            '__FILECOMMENT__' => $filecommentshtml,
            '__SITESUB__' => $subjecthtml,
            '__FRTRIAL__' => $frtrialhtml,
            '__FOOTER__' => $footerhtml,
            '__OFFVAL__' => $offervalhtml,
            '__FINALSUB__' => $finalroundhtml,
            '__FILESIZEINFO__' => html_entity_decode($filesizeinfo)
            );

    include_once 'lib/MailChimp.php';
    $quoteInfo = array('quoteservice' => 'Captioning', 'mailarray' => $mailreplace);

    $service_name = $quoteInfo['quoteservice'] . ' Services - Quote';
    $subject = $quoteInfo['quoteservice'] . $QUOTEMAILERINFO[$site_name]['subject'];
    if ($QUOTESERVICEdb == "Captioningpay") {
        $subject = str_replace("Quote", "Price Quote", $subject);
    }else{
        $subject = str_replace("Quote", "Email Quote", $subject);
    }
    $mailreplace = $quoteInfo["mailarray"];
    $quotemailerarray = array(
        '__SERVICESUBJECT__' => $subject,
        '__SERVICENAME__' => $service_name);

    $mailreplacenew = array_merge($mailreplace, $quotemailerarray);
    //echo $MAILERCODE[$QUOTESERVICE];die;
    $file = fopen("mailer/" . $MAILERCODE[$QUOTESERVICE], "r");
    $htmlmail_content = fread($file, filesize("mailer/" . $MAILERCODE[$QUOTESERVICE]));
    fclose($file);
    $html_content = strtr($htmlmail_content, $mailreplacenew);
        $to = $email;
        //echo $html_content;die;
    multi_attach_mail($to, $subject, $html_content, $email, $sitename);
    if (isset($_COOKIE['uploadtest'])) {
        echo "===>Success...";
    }
    $output = json_encode(array('ordsid' => $neworderId, 'type' => 'message', 'text' => 'Your request has been sent successfully and you will receive an email from us shortly. Thank you!', 'param' => $param));
    die($output);
    /*----------------------------PAYMENT QUOTE END -------------------------*/

}

} else {

    if ($_POST['uploadflag'] == "false") {
        $output = json_encode(array('type' => 'message', 'text' => 'Sorry for inconvenience, Reach us at 1-888-308-1099'));
        die($output);
    }
}
?>