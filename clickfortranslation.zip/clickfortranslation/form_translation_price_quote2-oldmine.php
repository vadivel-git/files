<?php
include_once "common_setting.php";
include_once "lib/common_array_price_quote.php";
include_once "lib/functions.php";
$page       = (isset($page)) ? $page : "quote";
$protocol   = (isset($serverdetail['HTTPS']) && $serverdetail['HTTPS'] != 'off') ? "https://" : "http://";

$RANDOMNO = rand();
$sitename           = 'localhost/projects/clickfortranslation/';
$channel_click      = "payment";
$freequote = 'show';
/*$RANDOMNO = $COMMONSETTING['RANDOMNO'];
$sitename           = $serverdetail['HTTP_HOST'];
$channel_click      = ($_POST['freequote'] == 'show') ? "free quote" : "payment";*/

$pay_email          = isset($_POST['requestvariable']['customer_email']) ? $_POST['requestvariable']['customer_email'] : "";
$pay_page_count     = isset($_POST['requestvariable']['page_count']) ? $_POST['requestvariable']['page_count'] : ""; 
$pay_audio_minutes  = isset($_POST['requestvariable']['audio_minutes']) ? $_POST['requestvariable']['audio_minutes'] : ""; 
$pay_file_selected  = isset($_POST['requestvariable']['file_type'])? $_POST['requestvariable']['file_type'] : "";
$pay_sourcelan      = isset($_POST['requestvariable']['source_lang'])?$_POST['requestvariable']['source_lang']:"";
$pay_targetlan      = isset($_POST['requestvariable']['target_lang'])?$_POST['requestvariable']['target_lang']:"";
$pay_notary         = isset($_POST['requestvariable']['pay_mailing'])?$_POST['requestvariable']['pay_mailing']:"";
$pay_mailing        = isset($_POST['requestvariable']['pay_notary'])?$_POST['requestvariable']['pay_notary']:"";
$trclang            = array('90','313','106','266','265','63','64','65','66','67','68','151','17','12','13','14','15','16','120','153','275','351');
$site_name          = preg_replace('/^www\./', '', $sitename);$sitename=trim($site_name);

$rush_scenario = array(
    "tr1" => array_merge(array(0 => ''),
        array_fill_keys(array(1,2), array('5 to 6 hours','6 to 12 hours','12 to 18 hours','1 business day')),
        array_fill_keys(array(3), array('5 to 12 hours','12 to 18 hours','1 business day','1 to 2 business days')),
        array_fill_keys(array(4,5), array('12 to 18 hours','1 business day','1 to 2 business days','2 to 3 business days')),
        array_fill_keys(array(6,7,8,9,10), array('1 business day','1 to 2 business days','2 to 3 business days','3 to 4 business days')),
        array_fill_keys(array(11,12,13,14,15), array('1 to 2 business days','2 to 3 business days','4 to 5 business days','5 to 6 business days')),
        array_fill_keys(array(16,17,18,19,20), array('1 to 2 business days','3 to 4 business days','5 to 6 business days','6 to 7 business days')),
        array_fill_keys(array(21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40), array('2 to 3 business days','4 to 5 business days','6 to 7 business days','8 to 9 business days')),
        array_fill_keys(array(41,42,43,44,45,46,47,48,49,50), array('3 to 4 business days','5 to 6 business days','7 to 8 business days','9 to 10 business days')),
        array_fill_keys(array(51,52,53,54,55,56,57,58,59,60), array('4 to 5 business days','6 to 7 business days','8 to 9 business days','10 to 12 business days'))
    ),
    "tr2" => array_merge(array(0 => ''),
        array_fill_keys(array(1,2), array('12 to 18 hours','1 business day','1 to 2 business days','1 to 2 business days')),
        array_fill_keys(array(3,4,5), array('1 business day','1 to 2 business days','2 to 3 business days','3 to 4 business days')),
        array_fill_keys(array(6,7,8,9,10), array('1 to 2 business days','2 to 3 business days','3 to 4 business days','5 to 6 business days')),
        array_fill_keys(array(11,12,13,14,15), array('2 to 3 business days','3 to 4 business days','5 to 6 business days','7 to 8 business days')),
        array_fill_keys(array(16,17,18,19,20), array('2 to 3 business days','3 to 5 business days','6 to 7 business days','8 to 10 business days')),
        array_fill_keys(array(21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40), array('3 to 4 business days','5 to 6 business days','8 to 10 business days','10 to 12 business days')),
        array_fill_keys(array(41,42,43,44,45,46,47,48,49,50), array('3 to 5 business days','6 to 8 business days','9 to 11 business days','12 to 13 business days')),
        array_fill_keys(array(51,52,53,54,55,56,57,58,59,60), array('3 to 6 business days','7 to 10 business days','10 to 12 business days','12 to 14 business days'))
    ),
    "av" => array_merge(
        array(0 => array('12 to 16 hours','16 to 20 hours','1 business day','1 to 2 business days')),
        array(1 => array('12 to 18 hours','1 business day','1 to 2 business days','2 to 3 business days')),
        array(2 => array('1 business day','1 to 2 business days','2 to 3 business days','3 to 4 business days')),
        array(3 => array('1 to 2 business days','2 to 3 business days','3 to 4 business days','4 to 5 business days')),
        array(4 => array('2 to 3 business days','3 to 4 business days','4 to 6 business days','5 to 6 business days')),
        array(5 => array('2 to 3 business days','3 to 4 business days','5 to 6 business days','7 to 8 business days')),
        array(6 => array('2 to 3 business days','4 to 5 business days','6 to 7 business days','8 to 9 business days')),
        array(7 => array('3 to 4 business days','5 to 6 business days','7 to 8 business days','8 to 9 business days')),
        array(8 => array('3 to 4 business days','5 to 6 business days','7 to 8 business days','9 to 10 business days')),
        array(9 => array('4 to 5 business days','6 to 7 business days','8 to 9 business days','10 to 12 business days'))
    )

);
//$rusharray = json_encode($rush_scenario);
date_default_timezone_set('America/New_York');
echo "<script>var folderPath='".date("dmY")."/"."'; var datetime='".date("D M d Y h:i:s")."'; </script>";
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo $CRMSERVERPATH; ?>js/sweetalert.min.js?<?php echo $COMMONSETTING['RANDOMNO'];?>"></script>
<link rel="stylesheet" type="text/css" href="<?php echo $CRMSERVERPATH; ?>css/sweetalert.css">
<link type="text/css" href="<?php echo $CRMSERVERPATH; ?>css/translation_price_quote2.css?<?php echo $RANDOMNO;?>" rel="stylesheet">
<link type="text/css" href="<?php echo $CRMSERVERPATH; ?>css/checkout.css?<?php echo $RANDOMNO;?>" rel="stylesheet">
<link type="text/css" href="<?php echo $CRMSERVERPATH; ?>css/my-styleNew.css?<?php echo $RANDOMNO;?>" rel="stylesheet">

<link type="text/css" href="<?php echo $CRMSERVERPATH; ?>css/chosen.css?<?php echo $RANDOMNO;?>" rel="stylesheet">
<script type="text/javascript" src="<?php echo $CRMSERVERPATH; ?>js/chosen.jquery.js?<?php echo $RANDOMNO;?>"></script>
<script type="text/javascript">    var jc = jQuery.noConflict();
    var language_list       = <?php echo json_encode($language); ?>;
    var country_list        = <?php echo json_encode($country); ?>;
    var tirelanguage        = <?php echo json_encode($tirelanguage); ?>;
    var serverPath          = <?php echo json_encode($CRMSERVERPATH); ?>;
    var originPath          = <?php echo json_encode($sitename); ?>;
    var channel_click       = <?php echo json_encode($channel_click); ?>;
    var tierarray           = <?php echo $tierarray; ?>;
    var expeditedarr        = <?php echo json_encode($rush_scenario); ?>;
    var trclang             = <?php echo json_encode($trclang); ?>;
    var crmRootpath         = '<?php echo $CRMSERVERPATH; ?>';
//    var successpath         = '<?php //echo $QUOTEMAILERINFO[$sitename]['successpage']; ?>//';
    var successpath         = 'localhost/projects/clickfortranslation/';
    var sitename            = '<?php echo $sitename; ?>';
    var update_url          = '<?php echo $CRMSERVERPATH; ?>crmquote_pay_update_trl.php';
    var update_quote        = '<?php echo $CRMSERVERPATH;?>trl_update_price_quote2.php';
</script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<body>
<div class="fr-container">
    <div class="col-xs-12 col-sm-8 col-md-8 col-lg-8 fr_no_padd">
        <div class="fr_title">Project Details</div>
        <?php $action = $CRMSERVERPATH."paypal/payment_v2.0.php";?>
        <form id="translationForm" action="<?php echo $action; ?>" class="" method="post"  role="form">
            <input type="hidden" id="site_namee" name="site_namee" value="<?php echo $sitename; ?>">
            <input type="hidden" id="quoteflag" name="quoteflag" value="0">
            <input type="hidden" id="quoteflagnew" name="quoteflagnew" value="0">
            <input type="hidden" id="recordkey" name="recordkey" value="">
            <input type="hidden" id="networkerrflag" name="networkerrflag" value="0">
            <input type="hidden" id="item_name_1" name="item_name_1" value="translation">
            <input type="hidden" id="item_number_1" name="item_number_1" value="">
            <input type="hidden" id="paymentamt" name="paymentamt"  value="">
            <input type="hidden" id="amount" name="amount"  value="1">
            <input type="hidden" id="totalfilelength" name="totalfilelength"  value="">
            <input type="hidden" id="filelength" name="filelength"  value="">
            <input type="hidden" id="formtype" name="formtype" value="payment">
            <input type="hidden" id="mode" name="mode" value="payment">
            <input type="hidden" id="service" name="service" value="translation">
            <input type="hidden" id="uploadat" name="uploadat" value="fileupload">
            <input type="hidden" id="version_payment" name="uploaddat" value="<?php echo $_POST['version_payment']; ?>">
            <input type="hidden" id="freequote" name="freequote" value="">
            <input type="hidden" id="camethrough" name="camethrough" value="<?php echo $channel_click; ?>">
            <?php date_default_timezone_set('America/New_York'); ?>
            <input type="hidden" name="referalsite" value="<?php echo $_SERVER['SERVER_NAME'];?>">
            <input type="hidden" id="uploadprogress" value="0">
            <input type="hidden" id="trgt_unitcost" value="0.00">
            <input type="hidden" id="trcunitcost_val" value="0.00">
            <input type="hidden" id="trgt_totamt" value="0.00">
            <input type="hidden" id="trc_totamt" value="0.00">
            <input type="hidden" id="nota_subamt" value="0.00">
            <input type="hidden" id="notapro_subamt" value="0.00">
            <input type="hidden" id="mfile_subamt" value="0.00">
            <input type="hidden" id="timecode_subamt" value="0.00">
            <input type="hidden" id="tottrl_subamt" value="0.00">
            <input type="hidden" id="mini_subamt" value="0.00">
            <input type="hidden" id="expd_subamt" value="0.00">
            <input type="hidden" id="subamttot" value="0.00">
            <input type="hidden" id="trans_price" name="trans_price" value="">
            <input type="hidden" id="agent_ref" name="agent_ref" >


            <?php
            //echo "<pre>";print_r($rush_scenario);die;
            ?>
        <div class="fr_overall">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 fr_form-group">
                    <div class="form-group plain-select">
                        <select name="sourcefiletype" data-current="" data-placeholder="Select file type *" id="sourcefiletype" class="form-control del-time capturedata">
                            <option value="" selected disabled > Select file type *</option>
                            <?php
                            foreach ($filetypes as $filetypeid=>$filetypename){
                                $selectedfiletype = ($pay_file_selected == $filetypename)?"selected":"";
                                echo '<option value="'.$filetypeid.'" '.$selectedfiletype.' >'.$filetypename.'</option>';
                            }
                            ?>
                        </select>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 fr_form-group fr_extra_form-group">
                    <div class="form-group docfile">
                        <span class="input-group" >
                            <input id="pagecount" name="pagecount" title="" class="form-control onlynumbers del-time capturedata tooltiptrigger" type="text" placeholder="Enter Page count *" data-original-title="If your file has more than 20 pages, you deserve a discounted price of $20/page" value="<?php echo $pay_page_count; ?>">
                            <span class="input-group-addon fr_input-group-addon" >
                                <div class="wrappervd">
                                    <a title="One page is defined as 250 words or less." rel="tooltip">
                                        <i class="fa fa-question-circle"></i>
                                    </a>
                                </div>
                            </span>
                        </span>
                        <span class="fr_not_secure"> Not sure?<a tabindex="-1" href="<?php echo "http://".$site_name; ?>/Translation-Send-Files.php"><span class="fr-pay-color">Get a quote</span></a></span>
                    </div>
                    <div class="form-group mediafile displaynone">
                        <span class="input-group" >
                            <input id="prfilelength" name="prfilelength" title="" class="form-control onlynumbers del-time capturedata tooltiptrigger" type="text" placeholder="Enter file length in minutes *" data-original-title="Enter your file length in minutes. Eg: for 01:20:07, the file length is 81 minutes." value="<?php echo $pay_audio_minutes; ?>" >
                            <span class="input-group-addon fr_input-group-addon" >
                                <div class="wrappervd">
                                    <a title="Enter your file length in minutes. Eg: for 01:20:07, the file length is 81 minutes." rel="tooltip">
                                        <i class="fa fa-question-circle"></i>
                                    </a>
                                </div>
                            </span>
                        </span>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 fr_form-group">
                    <div class="form-group">
                        <select name="srclang" id="srclang" data-placeholder="Select source language *" class="form-control del-time capturedata">
                            <option value="" ></option>
                            <?php
                            foreach ($language as $language_key => $language_val) {
                                $lang_selected = '';
                                if($pay_sourcelan == $language_val){$lang_selected ='selected="selected"';}
                                $srctiername = isset($tirelanguage[$language_val]) ? $tirelanguage[$language_val] : "Other";
                                echo '<option data-tier="'.$srctiername .'" value="' . $language_key . '"'.$lang_selected. '>' . $language_val . '</option>';
                            }
                            ?>
                        </select>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 fr_form-group">
                    <div class="form-group">
                        <select name="trglang" id="trglang" data-placeholder="Select target language *" class="form-control del-time capturedata">
                            <option value="" ></option>
                            <?php
                            foreach ($language as $language_key => $language_val) {
                                $lang_selected = '';
                                if($language_val == $pay_targetlan){$lang_selected ='selected="selected"';}
                                $tgtiername = isset($tirelanguage[$language_val]) ? $tirelanguage[$language_val] : "Other";
                                echo '<option data-tier="'.$tgtiername .'" value="' . $language_key . '"'.$lang_selected. '>' . $language_val . '</option>';
                            }
                            ?>
                        </select>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 fr_form-group fr_nopadding">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 fr_form-group docfile">
                        <div class="form-group plain-select select_after">
                            <span class="input-group">
                                <select name="catetype" id="catetype" class="form-control del-time capturedata">
                                  <option value="" >Select category *</option>
                                  <option value="General">General</option>
                                  <option value="Legal">Legal</option>
                                  <option value="Medical">Medical</option>
                                  <option value="Technical">Technical</option>
                                  <option value="Handwritten">Handwritten</option>
                                </select>
                                <span class="input-group-addon fr_input-group-addon">
                                    <div class="wrappervd">
                                        <a title="<b>General : </b>
        Covers academics, business, media, finance, focus groups or telephonic conversations.
        <br>
        <b>Legal : </b> Covers legal documents like case files, contracts, agreements, &amp; compliance documents.
        <br>
        <b>Medical : </b> Covers medical journals, research papers, billing, prescriptions, and documentations.
        <br>
        <b>Technical : </b> Covers offer documents, user manuals, Statement of purpose documents, etc.
        <br>
        <b>Handwritten : </b> This denotes the documents which are written by hand and not typed." rel="tooltip">
                                            <i class="fa fa-question-circle"></i>
                                        </a>
                                    </div>
                                </span>
                            </span>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 mediafile displaynone fr_form-group">
                        <div class="form-group fr_label ">
                          <label>
                              <input id="needtranscript" class="del-time capturedata" onchange="paytc_pricequoteclac();" type="checkbox"> Need Transcript
                              <!--<div class="wrappervd"><a title="tooltip" rel="tooltip"><i class="fa fa-question-circle"></i></a></div>-->
                          </label>

                            <label class="usnative-blk  mediafile displaynone">
                                <input id="nativespkr" class="del-time capturedata" onchange="paytc_pricequoteclac();" type="checkbox"> U.S. Native Transcribers
                                <div class="wrappervd"><a title="The U.S. Native transcribers are professionals with years of experience in transcribing U.S. native English to perfection. Employing them ensures detailed and flawless outputs." rel="tooltip"><i class="fa fa-question-circle"></i></a></div>
                            </label>
                        </div>
                    </div>
<!--                    <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                        <div class="form-group fr_label">                           

                        </div>
                    </div>-->
                    <!-- next -->
                </div>
                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6  pull-right">
                    <div class="col-xs-12 col-sm-6 col-md-12 col-lg-12 fr_form-group fr_nopadding">
                        <div class="form-group fr_label ">
                            <label class="timcode-blk mediafile displaynone">
                                <input id="qttcodecrm" class="del-time capturedata" onchange="paytc_pricequoteclac();" type="checkbox"> Time Coding
                                <div class="wrappervd"><a title="Time code refers to inserting the time in minutes and seconds at regular intervals. It provides a marker of where in the audio or video the text is found." rel="tooltip"><i class="fa fa-question-circle"></i></a></div>
                            </label>
                             <label>
                                <!--<input id="notacrmpay" class="del-time capturedata" onchange="eligibility();paytc_pricequoteclac();" type="checkbox"> Notarization-->
                                 <input id="notacrmpay" class="del-time capturedata" <?php if($pay_notary == 'true')echo "checked" ?> onchange="eligibility();paytc_pricequoteclac();" type="checkbox"> Notarization
                                <div class="wrappervd"><a title="Documents notarized as original documents." rel="tooltip"><i class="fa fa-question-circle"></i></a></div>
                            </label>
<!--                            <label>
                                <input id="atacert" class="del-time capturedata" type="checkbox"> ATA Certified Translator
                            </label>-->
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-12 col-lg-12 fr_nopadding">
                        <div class="form-group fr_label fr_form-group">
                            <label>
                                <!--<input id="mailfilecrmpay" class="del-time capturedata" onchange="eligibility();paytc_pricequoteclac();" type="checkbox"> Request Mailed Copies-->
                                <input id="mailfilecrmpay" class="del-time capturedata" <?php if($pay_mailing == 'true')echo "checked" ?> onchange="eligibility();paytc_pricequoteclac();" type="checkbox"> Request Mailed Copies
                                <div class="wrappervd"><a title="Hard copies mailed to your address." rel="tooltip"><i class="fa fa-question-circle"></i></a></div>
                            </label>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 fr_pad_zero">
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 fr_form-group mailedyes displaynone fr_nopadding">
                        <div class="form-group ">
                            <select name="mailcountry" id="mailcountry" class="form-control del-time chozn-select capturedata" data-placeholder="Select Country *" >
                                <option value="" ></option>
                                <?php
                                foreach ($country as $country_key => $country_val) {
                                    echo '<option value="' . $country_key . '">' . $country_val . '</option>';
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    <div class="row mailedyes displaynone">
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 fr_form-group fr_pad_zero"></div>
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 fr_form-group">
                            <textarea id="paytc_mailaddress" class="form-control capturedata" rows="4" placeholder="Door No, Street Name, \nCity, \nState, \nZipcode"></textarea>
                        </div>
                    </div>
                    <!-- next -->
                </div>
                <div class="clearfix"></div>
                <div class="uploadhere displaynone">
                    <!---------------FILE UPLOAD START--------------->
                    <div class="row " style="margin: 0 0 12px 0;">
                        <div class="col-sm-4">
                        <div onclick="addFiles();" id="fileuploader" class="DS-color-id chooser" style="float: left;cursor: pointer; height: 45px; width: 150px; ">
                            <img src="<?php echo $CRMSERVERPATH ?>img/uploadfiles.png" >
                            <input type="file" id="file" style="display:none;" multiple onChange="upload()">
                        </div>
                        </div>
                        <div class="col-sm-12 text-left">
                            <div class="sp1"></div>
                            <label class="control-label control-label-vd"><strong class="red_color">Note:</strong> You may upload multiple files at the same time.</label>
                            <div class="sp1"></div>
                        </div>
                    </div>

                    <div class="upload_error" style="color:#e0271d; font-weight:bold; padding:5px 0px; display: none;">
                        Network connection Error .. Please check your internet connection ...
                    </div>
                    <div class="col-lg-12" id="fileuploadfield">
                        <div class="panel panel-default" style="display:none;" id="info">
                            <div class="row up-head">
                                <div class="col-xs-4 col-sm-4 col-lg-4 fname">File Name</div>
                                <div class="col-xs-4 col-sm-4 col-lg-4 text-center mediafile">File Length</div>
                                <div class="col-xs-4 col-sm-4 col-lg-4 text-center">Status</div>
                            </div>
                        </div>
                    </div>
                    <div id="my-welcome-message2" class="displaynone vd-welcome">
                        <div class="modal-body no-padding vd-pad">
                            <div class="pop">
                                <img src="<?php echo $CRMSERVERPATH ?>img/vd-upload-pop.png" alt="upload" title="upload" class="vd-upload-pop">
                                <div class="vd-hilights-pop">
                                    <!--  <div style="color:#e0271d; font-weight:bold; padding:5px 0px; display: none;" class="upload_error">
                                        Network connection Error .. <br>Please check your internet connection ...
                                     </div> -->
                                    <div id="uploading_msg">
                                        Kindly don't close this window.
                                        <br><b>Uploading in Progress...</b>
                                        <div id="completedfiletext"></div>
                                    </div>
                                    <div class="upload_errmsg" style="display: none;">
                                        There seems to be a problem with your request. <br>  Here are a few other options for you.<br> <br>
                                        <div style="text-align:left">
                                            1. Upload your files <a href="AlternateUpload.php" target="_blank" style="color:blue"><u> here</u> </a> <br>
                                            2. OR Share your dropbox link to support@vananservices.com <br>
                                            3. OR Simply<span onClick="$('#open-icon').trigger('click')" style="color:blue;cursor: pointer"><u> Chat with us </u> </span> anytime.
                                        </div>
                                    </div>

                                </div>
                                <!-- Kindly don't close this page as your file(s) are being uploaded. -->
                                <img src="<?php echo $CRMSERVERPATH ?>img/loading.gif" alt="upload gif" title="loading" class="vd-up-gif">
                            </div>
                        </div>
                    </div>
                    <!---------------FILE UPLOAD END--------------->
                </div>
            </div>
                <div class="row fr_new_mar"></div>


                <div class="hardcopytat displaynone fr_txt_word_CV">
                    The mentioned TAT applies for the delivery of electronic copies via email. TAT may vary for mailing hard copies depending upon the shipping address.
                    </div>
                <div id="delivery-timeline" class="row fr_row_bg displaynone">
                    <div class="col-xs-12 col-sm-10 col-md-8 col-lg-8 fr_form-group fr_centerpage">
                        <label>
                            <p class="pull-left fr_pull-left"> <input type="radio" class="capturedata del-time form-check-input" name="deliveryReq" value="option1" checked=""> </p>
                            <p class="fr_pay-left">I agree to your standard delivery of <span id="tat-val"></span></p>
                        </label>
                    </div>
                    <div class="col-xs-12 col-sm-10 col-md-8 col-lg-8 fr_form-group fr_centerpage">
                        <label>
                            <p class="pull-left fr_pull-left"><input type="radio" id="expedited" class="capturedata del-time form-check-input" name="deliveryReq" value="option2" ></p>
                            <p class="fr_pay-left">I would like to avail "Expedited Service"</p>
                        </label>
                    </div>
                    <div class="col-xs-12 col-sm-10 col-md-8 col-lg-8 fr_form-group fr_centerpage">
                        <div class="col-xs-12 col-sm-7 col-md-7 col-lg-7 fr_form-group">
                            <input id="fileupload_tat" class="capturedata form-control expeditedblk displaynone" type="text" placeholder="Select the Date *">
                        </div>
                    </div>
                </div>
                <div id="expedited-timeline" class="row fr_row_bg displaynone">
                </div>
<!--                <div class="col-xs-12 col-sm-10 col-md-8 col-lg-8 fr_form-group fr_centerpage">-->

        </div>
    </form>
</div>
    <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4 fr_lg_col-4 pull-right fr_nopadding">
        <div class="fr_title">Your Summary</div>
        <div class="fr_sumarry no-summary">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 fr_default_txt">
                <div class="qt_msg">Enter <span id="mandat">the details</span> to get the price quote for your project</div>
                <div class="fr_CV_msg qt_mailinfo displaynone" onclick="parent.LC_API.open_chat_window()"> <i class="fa fa-comments cv-icon-blink" aria-hidden="true"></i><b>Chat with us</b></div>
                <div class="qt_mailinfo displaynone">Or</div>
                <div class="qt_mailinfo displaynone fr_fo_si">Enter your email ID to receive a quote from us.</div>
            </div>
             <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 fr_txt_word_CV"> Certificate of Translation - free of cost
             </div>
        </div>
        <div class="fr_sumarry_overall">
            <div class="order-summary displaynone">
                <div class="fr_sumarry">
                    <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8">Translation cost ($<span id="trgtunitcost_disp"></span> /<span class="docfile">page</span><span class="mediafile">min</span>)</div>
                    <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right">$<span id="trgt_tot"></span></div>
                </div>
                <div class="fr_sumarry mediafile trc-pr">
                    <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8">Transcript cost ($<span id="trcunitcost_disp"></span> /<span class="docfile">page</span><span class="mediafile">min</span>)</div>
                    <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right">$<span id="trc_tot"></span></div>
                </div>
                <div class="fr_sumarry displaynone discount-pr">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 fr_txt_word_CV">
                        As your file has more than 20 pages, you deserve a discounted price of $20/page
                    </div>
                </div>
                <div class="fr_sumarry displaynone mediafile timecode-pr">
                    <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 ">Time Code</div>
                    <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right">$<span id="timecode_sub_amt"></span></div>
                </div>
                <div class="fr_sumarry displaynone mediafile totaltrl-pr">
                    <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 ">Total Cost</div>
                    <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right">$<span id="tottrl_sub_amt"></span></div>
                </div>
                <div class="fr_sumarry displaynone minimum-pr">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 fr_txt_word_CV">
                        Minimum order cost applies to orders less than $50.
                    </div>
                </div>
                <div class="fr_sumarry displaynone mediafile minimum-pr">
                    <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 "><strong>Minimun Order Cost</strong></div>
                    <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right"><strong>$<span id="mini_sub_amt"></span></strong></div>
                </div>
                <div class="fr_sumarry displaynone expd-pr">
                    <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 ">Expedited service fee</div>
                    <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right">$<span id="expd_sub_amt"></span></div>
                </div>
                <div class="fr_sumarry displaynone notary-pr">
                    <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 ">Notary</div>
                    <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right">$<span id="nota_sub_amt"></span></div>
                </div>
                <div class="fr_sumarry displaynone notary-pr">
                    <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 ">Processing fee</div>
                    <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right">$<span id="notapro_sub_amt"></span></div>
                </div>
                <div class="fr_sumarry displaynone mailed-pr">
                    <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 ">Mailing fee</div>
                    <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right">$<span id="mfile_sub_amt"></span></div>
                </div>
                
                <div class="fr_sumarry">
                    <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 ">Subtotal</div>
                    <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right">$<span id="sub_amt"></span></div>
                </div>
                <div class="fr_sumarry">
                    <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 ">Transaction Fee
                        <div class="wrappervd">
                            <a rel="tooltip" title="Transaction fee is 5% of total order cost. This fee covers credit card, banking partners, and PayPal processing fees"> <i class="fa fa-question-circle"></i></a>
                        </div>
                    </div>
                    <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right">$<span id="trans_rate"></span></div>
                </div>
                <div class="fr_sumarry fr_sumarry_bg">
                    <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 "><b>Grand Total</b></div>
                    <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right"><b>$<span id="price_display"></span></b></div>
          
                </div>
            </div>
            <div class="order-summary displaynone">
                <div class="fr_sumarry">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 fr_txt_word_CV">Certificate of Translation - free of cost
                    </div>
                </div>
            </div>
            <div class="fr_sumarry u-email displaynone">
                <div class="col-xs-11 col-sm-11 col-md-11 col-lg-11 fr_nopadding fr_centerpage">
                    <div class="form-group fr-nomargin">
                        <input id ="paytc_qemailcrm" name="paytc_qemailcrm" value="<?php echo $pay_email; ?>" placeholder="Your Email ID *" title="" class="capturedata form-control fr-nomargin" type="text">
                    </div>
                </div>
            </div>
            <div class="order-summary displaynone">
                <div class="fr_sumarry">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 fr_txt_word_CV">If a page exceeds 250
                        words, revised invoice will be sent.
                    </div>
                </div>
            </div>
        </div>
        <div class="fr_sumarry pt displaynone">
            <?php
            $btnclass = 'col-xs-12 col-sm-12 col-md-12 col-lg-12';
            if($freequote == "show"){ $btnclass = 'col-xs-6 col-sm-6 col-md-6 col-lg-6';
            ?>
            <div id="emailquote-btn" class="col-xs-6 col-sm-6 col-md-6 col-lg-6 fr_nopadding btnhand">
                <div class="qsubmitcrm fr_email_btn" id="emailquote" value="Email Quote" >Email the Quote</div>
            </div>
            <?php } ?>
            <div id="proceedpayment-btn" class="<?php echo $btnclass; ?> text-right fr_nopadding btnhand">
                <div class="qsubmitcrm fr_email_btn fr_color" id="proceedpayment" value="Proceed to Payment" >Proceed to Payment</div>
            </div>
        </div>
        <div class="fr_sumarry qt displaynone">
            <div class="fr_nopadding btnhand">
                <div class="qsubmitcrm fr_email_btn" id="getquote" value="Get Quote" >Get Quote</div>
            </div>
        </div>
        <div class="fr_sumarry pr displaynone">
            <div class="fr_nopadding btnhand">
                <div class="processing-st" >Processing...</div>
            </div>
        </div>
    </div>

        <div class="col-xs-12 col-sm-8 col-md-8 col-lg-8 text-center pad-top15 underl ">
            <a href="<?php echo "http://".$site_name; ?>/Translation-Send-Files.php">If you're an existing customer, upload files right away by
            <span class="text-primary">clicking here</span></a>
        </div>

</div>
<link rel="stylesheet" href="<?php echo $CRMSERVERPATH; ?>css/jquery.datetimepicker.css?<?php echo $COMMONSETTING['RANDOMNO'];?>">
<script type="text/javascript" src="<?php echo $CRMSERVERPATH; ?>js/translation_price_quote2.js?<?php echo $RANDOMNO;?>"></script>
<script type="text/javascript" src="<?php echo $CRMSERVERPATH; ?>js/jquery.datetimepicker.full.js?<?php echo $COMMONSETTING['RANDOMNO'];?>"></script>
<script>
    paytc_resetVariables();
    jc('#fileupload_tat').datetimepicker({
        timepicker: false,
        format: 'Y-m-d',
        formatDate: 'Y-m-d',
        minDate: '-1970-01-01'
    });
    jc( document ).on('keydown','.onlynumbers', function(e) {
        if (e.keyCode == 46 || e.keyCode == 8 || e.keyCode == 9
            || e.keyCode == 27 || e.keyCode == 13
            || (e.keyCode == 65 && e.ctrlKey === true)
            || (e.keyCode >= 35 && e.keyCode <= 39)){
            return;
        }else {
            // If it's not a number stop the keypress
            if (e.shiftKey || (e.keyCode < 48 || e.keyCode > 57) && (e.keyCode < 96 || e.keyCode > 105 )) {
                e.preventDefault();
            }
        }
    });
    // tooltip_new_responsive
    jc(function () {
        var a = jc("[rel~=tooltip]"), b = !1, c = !1;
        a.bind("mouseenter", function () {
            if (b = jc(this), tip = b.attr("title"), c = jc('<div id="tooltipvd"></div>'), !tip || "" == tip)return !1;
            b.removeAttr("title"), c.css("opacity", 0).html(tip).appendTo("body");
            var a = function () {
                jc(window).width() < 1.5 * c.outerWidth() ? c.css("max-width", jc(window).width() / 2) : c.css("max-width", 340);
                var a = b.offset().left + b.outerWidth() / 2 - c.outerWidth() / 2, d = b.offset().top - c.outerHeight() - 20;
                if (a < 0 ? (a = b.offset().left + b.outerWidth() / 2 - 20, c.addClass("left")) : c.removeClass("left"), a + c.outerWidth() > jc(window).width() ? (a = b.offset().left - c.outerWidth() + b.outerWidth() / 2 + 20, c.addClass("right")) : c.removeClass("right"), d < 0) {
                    var d = b.offset().top + b.outerHeight();
                    c.addClass("top")
                } else c.removeClass("top");
                c.css({left: a, top: d}).animate({top: "+=10", opacity: 1}, 50)
            };
            a(), jc(window).resize(a);
            var d = function () {
                c.animate({top: "-=10", opacity: 0}, 50, function () {
                    jc(this).remove()
                }), b.attr("title", tip)
            };
            b.bind("mouseleave", d), c.bind("click", d)
        })
    });
    var textAreas = document.getElementsByTagName('textarea');

    Array.prototype.forEach.call(textAreas, function(elem) {
        elem.placeholder = elem.placeholder.replace(/\\n/g, '\n');
    });
</script>
</body>
</html>
