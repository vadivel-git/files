<?php
error_reporting(0);
include_once "common_setting.php";
include_once "lib/common_array_price_quote.php";
include_once "lib/functions.php";

$page       = (isset($page)) ? $page : "quote";
$protocol   = (isset($serverdetail['HTTPS']) && $serverdetail['HTTPS'] != 'off') ? "https://" : "http://";

$RANDOMNO       = $COMMONSETTING['RANDOMNO'];
$channel_click  = ($_POST['freequote'] == 'show') ? "free quote" : "payment";
$sitename       = $serverdetail['HTTP_HOST'];

$pay_email          = isset($_POST['requestvariable']['customer_email']) ? $_POST['requestvariable']['customer_email'] : "";
$customer_dashboard = isset($_POST['requestvariable']['customer_dashboard']) ? $_POST['requestvariable']['customer_dashboard'] : "";
$pay_file_selected  = isset($_POST['requestvariable']['file_type'])? $_POST['requestvariable']['file_type'] : "";
$pay_page_count     = isset($_POST['requestvariable']['page_count']) ? $_POST['requestvariable']['page_count'] : "";
$pay_audio_minutes  = isset($_POST['requestvariable']['audio_minutes']) ? $_POST['requestvariable']['audio_minutes'] : "";
$pay_formatting     = isset($_POST['requestvariable']['formatting'])? $_POST['requestvariable']['formatting'] : "";
$pay_sourcelan      = isset($_POST['requestvariable']['srclang'])?$_POST['requestvariable']['srclang']:"";
$pay_verbtaim       = isset($_POST['requestvariable']['pay_verbtaim'])?$_POST['requestvariable']['pay_verbtaim']:"";
$pay_category       = isset($_POST['requestvariable']['catetype'])?$_POST['requestvariable']['catetype']:"";

$trclang            = array('90','313','312','106','266','265','63','64','65','66','67','68','151','17','12','13','14','15','16','120','153','275','351');
$site_name          = preg_replace('/^www\./', '', $sitename);$sitename=trim($site_name);
date_default_timezone_set('America/New_York');
echo "<script>var folderPath='".date("dmY")."/"."'; var datetime='".date("D M d Y h:i:s")."'; </script>";
?>

<link rel="stylesheet" type="text/css" href="<?php echo $CRMSERVERPATH; ?>css/master.css">
<link rel="stylesheet" type="text/css" href="<?php echo $CRMSERVERPATH; ?>css/master-responsive.css">
<!--<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>-->

<script type="text/javascript" src="<?php echo $CRMSERVERPATH; ?>js/sweetalert.min.js?<?php echo $COMMONSETTING['RANDOMNO'];?>"></script>
<link rel="stylesheet" type="text/css" href="<?php echo $CRMSERVERPATH; ?>css/sweetalert.css">
<link type="text/css" href="<?php echo $CRMSERVERPATH; ?>css/checkout.css?<?php echo $RANDOMNO;?>" rel="stylesheet">
<link type="text/css" href="<?php echo $CRMSERVERPATH; ?>css/my-styleNew.css?<?php echo $RANDOMNO;?>" rel="stylesheet">

<script type="text/javascript">
var jc = jQuery.noConflict();
var serverPath = <?php echo json_encode($CRMSERVERPATH); ?>;
var crmRootpath = '<?php echo $CRMSERVERPATH; ?>';
var language_list = <?php echo json_encode($language); ?>;
var country_list = <?php echo json_encode($country); ?>;
var timcodeoptions      = <?php echo json_encode($timcodeoptions); ?>;
var originPath = <?php echo json_encode($sitename); ?>;
var channel_click = <?php echo json_encode($channel_click); ?>;
var trclang = <?php echo json_encode($trclang); ?>;
var successpath         = '<?php echo $QUOTEMAILERINFO[$sitename]['successpage']; ?>';
var sitename = '<?php echo $sitename; ?>';
var update_quote =
'<?php echo $CRMSERVERPATH;?>typing_update_price_quote.php';
</script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<body>
    <section class="ui-v-font">
        <div class="ui-container container">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 mas_design_bg ui_padding_00 row-eq-height">
                    <div class="col-xs-12 col-sm-7 col-md-8 col-lg-8 ui-pb">
                        <?php $action = $CRMSERVERPATH."paypal/payment_v2.0.php"; ?>
                        <form class="typingform float-label" spellcheck="false" id="translationForm" action="<?php echo $action; ?>" class="" method="post" role="form">
                            <h2 class="legend ui_hw">Project Details</h2>
                            <input type="hidden" id="site_namee" name="site_namee" value="<?php echo $sitename; ?>">
                            <input type="hidden" id="quoteflag" name="quoteflag" value="0">
                            <input type="hidden" id="quoteflagnew" name="quoteflagnew" value="0">
                            <input type="hidden" id="recordkey" name="recordkey" value="">
                            <input type="hidden" id="networkerrflag" name="networkerrflag" value="0">
                            <input type="hidden" id="item_name_1" name="item_name_1" value="typing">
                            <input type="hidden" id="item_number_1" name="item_number_1" value="">
                            <input type="hidden" id="paymentamt" name="paymentamt" value="">
                            <input type="hidden" id="amount" name="amount" value="1">
                            <input type="hidden" id="totalfilelength" name="totalfilelength" value="">
                            <input type="hidden" id="filelength" name="filelength" value="">
                            <input type="hidden" id="formtype" name="formtype" value="payment">
                            <input type="hidden" id="mode" name="mode" value="payment">
                            <input type="hidden" id="cst_db" name="cst_db" value="<?php echo $customer_dashboard; ?>">
                            <input type="hidden" id="service" name="service" value="typing">
                            <input type="hidden" id="uploadat" name="uploadat" value="fileupload">
                            <!--<input type="hidden" id="mini_subamt" name="mini_subamt" value="0.00">-->
                            <input type="hidden" id="version_payment" name="uploaddat" value="<?php echo $_POST['version_payment']; ?>">
                            <input type="hidden" id="freequote" name="freequote" value="">
                            <input type="hidden" id="camethrough" name="camethrough" value="<?php echo $channel_click; ?>">
                            <?php date_default_timezone_set('America/New_York'); ?>
                            <input type="hidden" name="referalsite" value="<?php echo $_SERVER['SERVER_NAME'];?>">
                            <input type="hidden" id="uploadprogress" value="0">
                            <input type="hidden" id="trgt_unitcost" value="0.00">
                            <input type="hidden" id="trgt_unitcostb" value="0.00">
                            <input type="hidden" id="trgt_totamtb" value="0.00">
                            <input type="hidden" id="trlverbacost" value="0.00">
                            <input type="hidden" id="trctcodecost" value="0.00">
                            <input type="hidden" id="trgt_totamt" value="0.00">
                            <input type="hidden" id="trc_totamt" value="0.00">
                            <input type="hidden" id="nota_subamt" value="0.00">
                            <input type="hidden" id="notapro_subamt" value="0.00">
                            <input type="hidden" id="mfile_subamt" value="0.00">
                            <input type="hidden" id="timecode_subamt" value="0.00">
                            <input type="hidden" id="subamttot" value="0.00">
                            <input type="hidden" id="trans_price" name="trans_price" value="">
                            <input type="hidden" id="offerpct" value="0" >
                            <input type="hidden" id="offerval" value="0" >
                            <input type="hidden" id="finalround" value="0" >
                            <input type="hidden" id="agent_ref" name="agent_ref">
                            <div class="row">
                            <!-- Select file type -->
                                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                                    <div id="first1" class="control ui-small plain-select">
                                        <select required name="sourcefiletype" data-placeholder="Select file type *" id="sourcefiletype" class="form-control ui-control del-time capturedata" id="frequencySalary">
                                            <option value="" selected disabled> Select file type *</option>
                                            <?php
                                            foreach ($filetypes as $filetypeid=>$filetypename){
                                                $selectedfiletype = ($pay_file_selected == $filetypename)?"selected":"";
                                                echo '<option value="'.$filetypeid.'" '.$selectedfiletype.' >'.$filetypename.'</option>';
                                            }
                                            ?>
                                        </select>
                                        <label class="fr-label" >File type</label>
                                    </div>
                                </div>
                                <!-- Page count -->
                                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 docfile">
                                    <div id="first2" class="control ui-re-row-sapce">
                                        <input id="pagecount" name="pagecount" value="<?php echo $pay_page_count; ?>" class="form-control ui-control form-control-success onlynumbers del-time capturedata tooltiptrigger" placeholder="Enter Page count *" type="text" required />
                                        <label class="fr-label">Page count</label>
                                        <span class="ui-ahref">Not sure?
                                            <?php $wwwurl = (in_array($sitename,$wwwwebsites))?"www.":""; ?>
                                            <a tabindex="-1" href="<?php echo $protocol.$wwwurl.$site_name; ?>/Typing-Send-Files.php">Get a quote</a>
                                        </span>
                                        <div class="wrappervd pull-right ui-wrapperd">
                                            <a rel="tooltip" title="One page is defined as 250 words or less." value="<?php echo $pay_page_count; ?>">
                                                <span class="control-label">
                                                    <div class="tooltip--questionmark">
                                                        <span class="tooltip__question">?</span>
                                                    </div>
                                                </span>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <!-- File length in minutes -->
                                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 mediafile displaynone">
                                    <div id="first3" class="control ui-re-row-sapce">
                                        <div class="displaynone offer-blk fr_manual_tooltip">Transcribe <span id="needmin"></span> minutes more and receive <span id="availoff"></span> discount.</div>
                                        <input id="prfilelength" name="prfilelength" class="form-control ui-control form-control-success onlynumbers del-time capturedata tooltiptrigger" placeholder="Enter file length in minutes *" type="text" required  value="<?php echo $pay_audio_minutes; ?>" />
                                        <!-- yes, this is not nice, in real live, do it with JS -->
                                        <label class="fr-label">File length in minutes</label>
                                        <div class="wrappervd pull-right ui-wrapperd">
                                            <a rel="tooltip" title="Enter your file length in minutes. Eg: for 01:20:07, the file length is 81 minutes." value="<?php echo $pay_audio_minutes; ?>">
                                                <span class="control-label">
                                                    <div class="tooltip--questionmark">
                                                        <span class="tooltip__question">?</span>
                                                    </div>
                                                </span>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <!-- Source Language -->
                                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                                    <div id="first4" class="control ui-small">
                                        <select name="srclang" id="srclang" data-placeholder="Select source language *" required class="form-control ui-control del-time capturedata comboselect">
                                            <option selected="" disabled="" data-placehold="Enter source language" value="">Select Source language</option>
                                            <?php
                                            $eng = array(90=>"English");
                                            unset($language[90]);
                                            $language = $eng+$language;
                                            foreach ($language as $language_key => $language_val) {
                                                $lang_selected = '';
                                                if ($pay_sourcelan == $language_val) {
                                                    $lang_selected = 'selected="selected"';
                                                }
                                                echo '<option value="' . $language_key . '"' . $lang_selected . '>' . $language_val . '</option>';
                                            }
                                            ?>
                                        </select>
                                        <label class="fr-label">Source language</label>
                                    </div>
                                </div>
                                <!-- Category -->
                                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                                    <div id="first5" class="control ui-small ui-re-row-sapce  plain-select">
                                        <select name="catetype" id="catetype" data-placeholder="Select category *" required class="form-control ui-control del-time capturedata">
                                            <option value="" selected disabled>Select category *</option>
                                            <option value="General">General</option>
                                            <option value="Legal">Legal</option>
                                        </select>
                                        <label class="fr-label">Category</label>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <!--formatting-->
                                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 ">
                                    <div id="first6" class="control ui-small docfile ui-re-row-sapce  plain-select">
                                        <select name="formatting" id="formatting" data-placeholder="Select Formatting *" required class="form-control ui-control del-time capturedata">
                                            <option value="" selected disabled>Select Formatting *</option>
                                            <option value="Yes" <?php if($pay_formatting=='With Formatting' || $pay_formatting=='Yes' )echo 'selected';?>>Yes</option>
                                            <option value="No" <?php if($pay_formatting=='Without Formatting'  || $pay_formatting=='No')echo 'selected';?> >No</option>
                                            <option value="Handwritten" <?php if($pay_formatting=='Handwritten')echo 'selected';?>>Handwritten</option>
                                        </select>
                                        <label class="fr-label">Formatting</label>
                                    </div>
                                    <div id="first14" class="control mediafile displaynone timcode-blk ui-small docfile ui-re-row-sapce  plain-select">
                                        <select name="qttcodecrm" id="qttcodecrm" data-placeholder="Select Formatting *" required class="form-control ui-control del-time capturedata">
                                            <option value="" selected disabled >Select time code</option>
                                            <?php
                                            foreach ($timcodeoptions as $timcode=>$tcodeval){
                                                echo '<option value="'.$timcode.'" >'.$tcodeval["label"].'</option>';
                                            }
                                            ?>
                                        </select>
                                        <label class="fr-label" id="qttcodecrmlbl">Time code</label>
                                    </div>
                                </div>
                                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 pull-right">
                                    <div class="cntr mr_cntr mediafile displaynone">
                                        <span class="verbtaim-blk displaynone">
                                            <input class="hidden-xs-up cbxid capturedata" <?php if($pay_verbtaim=='true')echo "checked" ?> id="qtvercrmpay" onchange="paytc_pricequoteclac();" type="checkbox">
                                            <label class="cbx" id="qtvercrmpay-lbl" tabindex="0" for="qtvercrmpay"></label>
                                            <label class="lbl" for="qtvercrmpay">Verbatim
                                                <div class="wrappervd">
                                                    <a rel="tooltip" title="Verbatim typing means word by word typing that includes the fillers uhh, umm, ah, laughing sounds etc. ( + $0.25/min)">
                                                        <span class="control-label"><div class="tooltip--questionmark"><span class="tooltip__question">?</span></div></span>
                                                    </a>
                                                </div>
                                            </label>
                                        </span>
                                        <span class="usnative-blk displaynone">
                                            <!--<input class="hidden-xs-up cbxid" <?php /*if($pay_verbtaim=='true')echo "checked" */?> id="qtvercrmpay" onchange="paytc_pricequoteclac();" type="checkbox">-->
                                            <input id="nativespkr" class="hidden-xs-up cbxid del-time capturedata" onchange="paytc_pricequoteclac();" type="checkbox">
                                            <label class="cbx" id="nativespkr-lbl" tabindex="0" for="nativespkr"></label>
                                            <label class="lbl" for="nativespkr">U.S. Native Transcribers
                                                <div class="wrappervd">
                                                    <a rel="tooltip" title="The U.S. Native transcribers are professionals with years of experience in transcribing U.S. native English to perfection. Employing them ensures detailed and flawless outputs.">
                                                        <span class="control-label"><div class="tooltip--questionmark"><span class="tooltip__question">?</span></div></span>
                                                    </a>
                                                </div>
                                            </label>
                                        </span>
                                    </div>
                                    <div class="cntr mr_cntr notary-blk displaynone">
                                        <span>
                                            <input class="hidden-xs-up cbxid del-time capturedata" id="notacrmpay" type="checkbox" onchange="eligibility();paytc_pricequoteclac();">
                                            <label class="cbx" id="notacrmpay-lbl" tabindex="0" for="notacrmpay"></label>
                                            <label class="lbl" for="notacrmpay">Notarization</label>
                                        </span>
                                        <span>
                                            <input class="hidden-xs-up cbxid  del-time capturedata" id="mailfilecrmpay" type="checkbox" onchange="eligibility();paytc_pricequoteclac();">
                                            <label class="cbx" tabindex="0" for="mailfilecrmpay"></label>
                                            <label class="lbl" for="mailfilecrmpay">Request Mailed Copies</label>
                                        </span>
                                    </div>
                                    <div id="first7" class="ui-radio-space control ui-small mailedyes displaynone">
                                        <select required name="mailcountry" id="mailcountry" data-placeholder="Select Country *"  class="form-control ui-control del-time capturedata comboselect">
                                            <option value="" selected disabled>Select Country</option>
                                            <?php
                                            foreach ($country as $country_key => $country_val) {
                                                echo '<option value="' . $country_key . '">' . $country_val . '</option>';
                                            }
                                            ?>
                                        </select>
                                        <label class="fr-label">Country</label>
                                    </div>
                                    <div class="ui-radio-space control mailedyes displaynone">
                                        <textarea id="paytc_mailaddress" class="form-control ui-control capturedata" rows="2" placeholder="Door No, Street Name,City,State,Zipcode" required=""></textarea>
                                        <label class="fr-label">Door No, Street Name,City,State,Zipcode</label>
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                                <div class="uploadhere displaynone">
                                    <div class="row">
                                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                            <div class="ui-upolad" onclick="addFiles();">
                                                <img src="<?php echo $CRMSERVERPATH ?>img/addfiles.png" alt="addfiles" class="img-responsive center-block" width="40" style="margin: 0 auto 14px auto;">
                                                <input type="file" id="file" style="display:none;" multiple onChange="upload()">
                                                Add files
                                                <p style="padding-top: 12px;" class="text-center ui-p"><strong>Note : </strong>You may upload multiple files at the same time.</p>
                                                <p class="text-center ui-p">You may also upload your files later.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="upload_error" style="color:#e0271d; font-weight:bold; padding:5px 0px; display: none;">Network connection Error .. Please check your internet connection ...</div>
                                    <div class="col-lg-12 dv_nopad" id="fileuploadfield">
                                        <div class="panel panel-default" style="display:none;" id="info">
                                            <div class="row ui-up-head">
                                                <div class="col-xs-4 col-sm-4 col-lg-4 fname">File Name</div>
                                                <div class="col-xs-4 col-sm-4 col-lg-4 text-center mediafile">File Length</div>
                                                <div class="col-xs-4 col-sm-4 col-lg-4 text-center pull-right">Status</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="my-welcome-message2" class="displaynone vd-welcome">
                                        <div class="modal-body no-padding vd-pad">
                                            <div class="pop">
                                                <img src="<?php echo $CRMSERVERPATH ?>img/vd-upload-pop.png" alt="upload" title="upload" class="vd-upload-pop">
                                                <div class="vd-hilights-pop">
                                                    <div id="uploading_msg">Kindly don't close this window.<br><b>Uploading in Progress...</b>
                                                        <div id="completedfiletext"></div>
                                                    </div>
                                                    <div class="upload_errmsg" style="display: none;">
                                                        There seems to be a problem with your request.
                                                        <br> Here are a few other options for you.<br><br>
                                                        <div style="text-align:left">1. Upload your files
                                                            <a href="AlternateUpload.php" target="_blank" style="color:blue"><u> here</u> </a>
                                                            <br> 2. OR Share your dropbox link to support@vananservices.com
                                                            <br> 3. OR Simply
                                                            <span onClick="$('#open-icon').trigger('click')" style="color:blue;cursor: pointer"><u> Chat with us </u> </span> anytime.
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- Kindly don't close this page as your file(s) are being uploaded. -->
                                                <img src="<?php echo $CRMSERVERPATH ?>img/loading.gif" alt="upload gif" title="loading" class="vd-up-gif">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="filecomment displaynone">
                                    <div class="form-group form-modifier col-lg-12 dv_nopad">
                                        <textarea name="filecomments" id="filecomments" class="form-control ui-control textarea-modifier" rows="3" placeholder="Please enter spelling of names, locations, addresses and any additional information / notes (including handwritten or illegible text) that can help us accurately translate your specific requests."></textarea>
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                                <div class="row">
                                    <div class="col-xs-12 col-sm-11 col-md-8 col-lg-10 hardcopytat displaynone fr_txt_word_CV ui-centerpage text-center ui-p ui-tat">
                                        The mentioned TAT applies for the delivery of electronic copies via email. TAT may vary for mailing hard copies depending upon the shipping address.
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                    <div class="ui-radiobox displaynone ui-last-radio" id="delivery-timeline">
                                        <b class="ui-turn">Turnaround time</b>
                                        <div class="clearfix"></div>
                                        <div class="col-xs-12 col-sm-12 col-md-7 col-lg-7">
                                            <label class="custom-control custom-radio">
                                                <input id="radio1" type="radio" class="capturedata form-check-input del-time custom-control-input" onclick="paytc_pricequoteclac();" name="deliveryReq" value="option1" checked="">
                                                <span class="custom-control-indicator"></span>
                                                <span class="lbl ui_lbl_radio custom-control-description">Standard delivery <span id="tat-val"></span></span>
                                            </label>
                                        </div>
                                        <div class="col-xs-12 col-sm-12 col-md-5 col-lg-5">
                                            <label class="custom-control custom-radio">
                                                <input id="expedited" onclick="paytc_pricequoteclac();" name="deliveryReq" value="option2" type="radio" class="capturedata form-check-input del-time custom-control-input">
                                                <span class="custom-control-indicator"></span>
                                                <span class="lbl ui_lbl_radio custom-control-description">Expedited Services</span>
                                            </label>
                                        </div>
                                        <div class="col-xs-12 col-sm-10 col-md-8 col-lg-10 expeditedblk displaynone">
                                            <div class="col-xs-7 col-sm-7 col-md-7 col-lg-7">
                                                <div id="first11" class="control ui-first11">
                                                    <input class="form-control ui-control capturedata" id="fileupload_tat" name="minutes" placeholder="Select the Date *"  required />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="ui_summary col-xs-12 col-sm-5 col-md-4 col-lg-4 ui_padding_0">
                        <div class="">
                            <h2 class="legend text-center">Quote Summary</h2>
                            <div class="fr_sumarry no-summary ">
                                <div class="qt_msg ui-msg">Enter the details to get the price quote for your project</div>
                                <div class="clearfix"></div>
                                <div class="row text-center ui-email">
                                    <div class="fr_CV_msg qt_mailinfo displaynone ui-chat" onclick="parent.LC_API.open_chat_window()"><i class="fa fa-comments cv-icon-blink" aria-hidden="true"></i><b>Chat with us</b></div>
                                    <div class="qt_mailinfo displaynone">Or</div>
                                    <div class="qt_mailinfo displaynone fr_fo_si">Enter your email ID to receive a quote from us.</div>
                                </div>
                            </div>
                            <div class="ui-summarry">
                                <div class="order-summary displaynone">
                                    <div class="ui_fr_sumarry">
                                        <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 ui-pad-r0">Typing cost ($<span id="trgtunitcost_disp"></span>/<span class="docfile">page</span><span class="mediafile">min</span>)</div>
                                        <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right">$<span id="trgt_tot"></span></div>
                                    </div>
                                    <div class="ui_fr_sumarry displaynone availedoff">
                                        <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 ui-pad-r0">Discounted price ($<span id="tpprice_disp"></span>/min)</div>
                                        <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right">$<span id="tpcost_disp"></span></div>
                                    </div>
                                    <!--<div class="availedoff fr_txt_word_CV"></div>-->
                                    <div class="ui_fr_sumarry displaynone availedoff">
                                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 fr_txt_word_CV">
                                            <span class="offval">You save $<span id="offprice"></span></span>
                                        </div>
                                    </div>
                                    <div class="ui_fr_sumarry timecode-pr" style="display: none;">
                                        <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 ui-pad-r0">Time Code</div>
                                        <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right">$<span id="trctcodecost_disp">0.00</span></div>
                                    </div>
                                    <div class="ui_fr_sumarry trlverbatime-pr trlsum">
                                        <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 ui-pad-r0">Verbatim</div>
                                        <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right">$<span id="trlverbacost_disp"></span></div>
                                    </div>
                                  <!--  <div class="ui_fr_sumarry displaynone minimum-pr">
                                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 minimumcost ui-col-r">
                                            Minimum order cost applies to orders less than $50.
                                        </div>
                                    </div>
                                    <div class="ui_fr_sumarry displaynone mediafile minimum-pr">
                                        <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 ui-pad-r0">Minimum Order Cost</div>
                                        <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right">$<span id="mini_sub_amt"></span></div>
                                    </div>-->
                                    <div class="ui_fr_sumarry displaynone notary-pr">
                                        <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 ui-pad-r0">Notary</div>
                                        <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right">$<span id="nota_sub_amt"></span></div>
                                    </div>
                                    <div class="ui_fr_sumarry displaynone notary-pr">
                                        <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 ui-pad-r0">Processing fee</div>
                                        <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right">$<span id="notapro_sub_amt"></span></div>
                                    </div>
                                    <div class="ui_fr_sumarry displaynone mailed-pr">
                                        <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 ui-pad-r0">Mailing fee</div>
                                        <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right">$<span id="mfile_sub_amt"></span></div>
                                    </div>
                                    <div class="ui_fr_sumarry">
                                        <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 ui-pad-r0">Subtotal</div>
                                        <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right">$<span id="sub_amt"></span></div>
                                    </div>
                                    <div class="ui_fr_sumarry displaynone coupval-pr">
                                        <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 ui-pad-r0">Coupon discount (-<span id="ofpct"></span>)</div>
                                        <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right">$<span id="offerval_value"></span></div>
                                    </div>
                                    <div class="ui_fr_sumarry displaynone coupval-pr">
                                        <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 ui-pad-r0">Offer price</div>
                                        <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right">$<span id="sub_total"></span></div>
                                    </div>
                                    <div class="ui_fr_sumarry">
                                        <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 ui-pad-r0">Transaction Fee
                                            <div class="wrappervd">
                                                <a rel="tooltip" title="Transaction fee is 5% of total order cost. This fee covers credit card, banking partners, and PayPal processing fees">
                                                    <span class="control-label"><div class="tooltip--questionmark"><span class="tooltip__question">?</span></div></span>
                                                </a>
                                            </div>
                                        </div>
                                        <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right">$<span id="trans_rate"></span></div>
                                    </div>
                                    <div class="ui_fr_sumarry fr_sumarry_bg">
                                        <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 ui-pad-r0"><b>Grand Total</b></div>
                                        <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right"><b>$<span id="price_display"></span></b></div>
                                    </div>
                                    <?php if(in_array($sitename,$couponcodesites)){ ?>
                                    <div class="col-lg-12 float-label">
                                        <div class="coupon-blk">
                                            <div class="control">
                                                <div class="input-group">
                                                    <input id="couponcode" name="couponcode" class="form-control ui-control form-control-success capturedata" placeholder="Coupon code" >
                                                    <span class="input-group-addon" id="applycoupon">apply</span>
                                                </div>
                                            </div>
                                            <span id="couponmsg"></span>
                                        </div>
                                    </div>
                                    <?php  } ?>
                                </div>

                                <div class="col-lg-12 float-label">
                                    <div>
                                        <div id="first2" class="control">
                                            <input id="paytc_qemailcrm" name="paytc_qemailcrm" value="<?php echo $pay_email; ?>" class="form-control ui-control form-control-success del-time capturedata" placeholder="Your Email ID *" required />
                                            <!-- <label for="title">Email</label> -->
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="pagecounthelp displaynone">
                                        <div class="ui_fr_sumarry">
                                            <div class="text-center ui-col-r">
                                                <i class="fa fa-info-circle" aria-hidden="true"></i> If a page exceeds 250 words, revised invoice will be sent.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="ui_fr_sumarry pt displaynone">
                                    <?php
//                                    ui-quote-btn-joint, ui-pay-btn-joint
                                    $qtbutton ='ui-quote-btn';
                                    $ptbutton = 'ui-pay-btn';
                                    $twobutton = '';
                                    $btnclass = 'col-xs-12 col-sm-12 col-md-12 col-lg-12';
                                    if($freequote == "show"){
                                        $btnclass = 'col-xs-6 col-sm-12 col-md-12 col-lg-6';
                                        $qtbutton ='ui-quote-btn-joint';
                                        $ptbutton = 'ui-pay-btn-joint';
                                        $twobutton = 'ui-joint-btn';
                                    ?>
                                    <div id="emailquote-btn" class="col-xs-6 col-sm-12 col-md-12 col-lg-6 fr_nopadding btnhand ui-btn-quote <?php echo $twobutton; ?>">
                                        <div class="qsubmitcrm fr_email_btn <?php echo $qtbutton; ?>" tabindex="0" id="emailquote" value="Email Quote">Email me the Quote</div>
                                    </div>
                                    <?php } ?>
                                    <div id="proceedpayment-btn" class="<?php echo $btnclass; ?> text-right fr_nopadding btnhand ui-btn-quote <?php echo $twobutton; ?>">
                                        <div class="qsubmitcrm fr_email_btn fr_color <?php echo $ptbutton; ?>" tabindex="0" id="proceedpayment" value="Proceed to Payment">Proceed to Payment</div>
                                    </div>
                                    <p class="fr_vvv"> <i class="fa fa-lock" aria-hidden="true"></i> Safe &amp; Secure Payment </p>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="fr_sumarry qt displaynone">
                                    <div class="fr_nopadding btnhand">
                                        <div class="qsubmitcrm fr_email_btn ui-quote-btn" tabindex="0" id="getquote" value="Get Quote">Get Quote</div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="fr_sumarry up displaynone">
                                    <div class="fr_nopadding btnhand">
                                        <div class="qsubmitcrm fr_email_btn ui-quote-btn">Uploading...</div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="fr_sumarry pr displaynone">
                                    <div class="fr_nopadding btnhand">
                                        <div class="qsubmitcrm fr_email_btn ui-col-green">Processing...</div>
                                    </div>
                                </div>
                            </div>
                            <!-- <div class="ui_bottom">
                                <div class="ui-line"></div>
                                <div class="ui-contact">US : 1-888-535-5668 <br> support@vananservices.com</div>
                            </div> -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <div class="fr-container">
        <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8 fr_no_padd">
            <span id="timespendingid" class="displaynone"></span>
            <?php if($customer_dashboard == ''){ ?>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 text-center pad-top15 ui-underl ">
                <a href="<?php echo $protocol.$wwwurl.$site_name; ?>/Typing-Send-Files.php">If you're an existing customer, upload files right away by
                    <span class="text-primary ui-primary">clicking here</span>
                </a>
            </div>
            <?php } ?>
        </div>
    <link rel="stylesheet" href="<?php echo $CRMSERVERPATH; ?>css/jquery.datetimepicker.css?<?php echo $COMMONSETTING['RANDOMNO'];?>">
    <script type="text/javascript" src="<?php echo $CRMSERVERPATH; ?>js/typing_price_quote.js?<?php echo $RANDOMNO;?>"></script>
    <script type="text/javascript" src="<?php echo $CRMSERVERPATH; ?>js/jquery.datetimepicker.full.js?<?php echo $COMMONSETTING['RANDOMNO'];?>"></script>
    <script>
    var catetype = "<?php echo $pay_category; ?>";
    jc('#catetype').val(catetype);
    paytc_resetVariables();
    jc('#fileupload_tat').datetimepicker({
        timepicker: false,
        format: 'm-d-Y',
        formatDate: 'm-d-Y',
        minDate: '-1970-01-01',
        scrollMonth : false,
        scrollInput : false
    });
    jc(document).on('keydown', '.onlynumbers', function(e) {
        if (e.keyCode == 46 || e.keyCode == 8 || e.keyCode == 9 ||
            e.keyCode == 27 || e.keyCode == 13 ||
            (e.keyCode == 65 && e.ctrlKey === true) ||
            (e.keyCode >= 35 && e.keyCode <= 39)) {
                return;
        } else {
        // If it's not a number stop the keypress
            if (e.shiftKey || (e.keyCode < 48 || e.keyCode > 57) && (e.keyCode <
                96 || e.keyCode > 105)) {
                    e.preventDefault();
            }
      }
    });
    // tooltip_new_responsive
    jc(function() {
      var a = jc("[rel~=tooltip]"),
        b = !1,
        c = !1;
      a.bind("mouseenter", function() {
        if (b = jc(this), tip = b.attr("title"), c = jc(
            '<div id="tooltipvd"></div>'), !tip || "" == tip) return !1;
        b.removeAttr("title"), c.css("opacity", 0).html(tip).appendTo(
          "body");
        var a = function() {
          jc(window).width() < 1.5 * c.outerWidth() ? c.css(
            "max-width", jc(window).width() / 2) : c.css(
            "max-width", 340);
          var a = b.offset().left + b.outerWidth() / 2 - c.outerWidth() /
            2,
            d = b.offset().top - c.outerHeight() - 20;
          if (a < 0 ? (a = b.offset().left + b.outerWidth() / 2 - 20,
              c.addClass("left")) : c.removeClass("left"), a + c.outerWidth() >
            jc(window).width() ? (a = b.offset().left - c.outerWidth() +
              b.outerWidth() / 2 + 20, c.addClass("right")) : c.removeClass(
              "right"), d < 0) {
            var d = b.offset().top + b.outerHeight();
            c.addClass("top")
          } else c.removeClass("top");
          c.css({
            left: a,
            top: d
          }).animate({
            top: "+=10",
            opacity: 1
          }, 50)
        };
        a(), jc(window).resize(a);
        var d = function() {
          c.animate({
            top: "-=10",
            opacity: 0
          }, 50, function() {
            jc(this).remove()
          }), b.attr("title", tip)
        };
        b.bind("mouseleave", d), c.bind("click", d)
      })
    });

    var textAreas = document.getElementsByTagName('textarea');
    Array.prototype.forEach.call(textAreas, function(elem) {
      elem.placeholder = elem.placeholder.replace(/\\n/g, '\n');
    });
    </script>
    <!-- Link to the javascript file we will create -->
<!--    <script src="http://vdtm.in/uiform/js/scripts.js"></script>-->
    <!-- <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script> -->
        <script src="<?php echo $CRMSERVERPATH; ?>js/jquery.combo.select.js"></script>
        <script>
            jc(function() {
                jc('.comboselect').comboSelect();
                jc('.js-select').change(function(e, v) {
                    jc('.idx').text(e.target.selectedIndex)
                    jc('.val').text(e.target.value)
                });
                jc('.combo-input').change(function(event) {
                    var selectid = jc(this).parent().parent().attr('id');
                    var thisvalue = jc('.float-label #' + selectid + ' select option:selected').val();
                    if(thisvalue == '') {
                        jc('.float-label #' + selectid + ' .combo-input').val('');
                    }
                });
                jc(".option-item").hover(function() {
                    jc(".option-item").removeClass("option-hover");
                    jc(this).addClass("newhover");
                });

                jc('.comboselect').change(function(event) {
                    var selectid = jc(this).parent().parent().attr('id');
                    if (event.target.value != "") {
                        jc(".float-label #" + selectid + " label").addClass("selected-label");
                    } else {
                        jc(".float-label #" + selectid + " label").removeClass("selected-label");
                    }
                })

                /**
                 * Open select
                 */

                jc('.js-select-open').click(function(e) {
                    jc('.js-select').focus()
                    e.preventDefault();
                })
                /**
                 * Open select
                 */

                jc('.js-select-close').click(function(e) {
                    jc('.js-select').trigger('comboselect:close')
                    e.preventDefault();
                })

                /**
                 * Add new options
                 */
                var $select = jc('.js-select-3');
                jc('.js-select-add').click(function() {
                    $select.prepend(jc('<option>', {
                        text: 'A new option: ' + Math.floor(Math.random() * 10) +1
                    })).trigger('comboselect:update')
                    return false;
                })
            })
        </script>
  </body>
  </html>
