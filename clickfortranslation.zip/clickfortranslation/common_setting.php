<?php

$COMMONSETTING = array('RANDOMNO' => '0103301754621' );

$pathInfo = pathinfo(dirname(__FILE__));
//sample http://vananhost.com/vanancrm/
//$CRMSERVERPATH = "http://".$_SERVER['HTTP_HOST']."/".$pathInfo['basename']."/";
$CRMSERVERPATH = "https://".$_SERVER['HTTP_HOST']."/".$pathInfo['basename']."/";
$CRMSERVERPATH = "http://localhost/div/sites/2017/10th/10th/clickfortranslation/";
//$CRMSERVERPATH = "http://vdtm.in/payv/";

// echo json_encode($arr);
$live_email = 'salescs@vananservices.com,vananbackup@gmail.com';
?>
