 <style>
.loader {
  border: 16px solid #f3f3f3;
  border-radius: 50%;
  border-top: 16px solid #3498db;
  width: 120px;
  height: 120px;
  margin-left: 550px;
  margin-top: 250px;
  -webkit-animation: spin 2s linear infinite;
  animation: spin 2s linear infinite;
}
@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}
@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
</style>
<div class="loader"></div>
<?php
include_once "../common_setting.php"; //$COMMONSETTING, $CRMSERVERPATH
include_once "../lib/common_array.php";
include_once "../lib/functions.php";
if(isset($_REQUEST['van'])){
    $decrypted_param = encrypt_decrypt('decrypt', $_REQUEST['van']);
    $decrypted_array = explode('|^|',$decrypted_param);
    //"$neworderId|^|$ordertotal|^|translation|^|$email|^|$site_name";
    $item_number_1  = $decrypted_array[0];
    $amount         = $decrypted_array[1];;
    $item_name_1    = $decrypted_array[2];
    $site_namee     = $decrypted_array[3];;
}else{
    $item_name_1    = $_POST['item_name_1'];
    $item_number_1  = $_POST['item_number_1'];
    $amount         = $_POST['amount'];
    $site_namee     = $_POST['site_namee'];
}
//    $paymentemail = "vijayakumar-facilitator@vananservices.com";
//    $action ="https://sandbox.paypal.com/cgi-bin/webscr";
    $paymentemail = "payment@vananservices.com";
    $action = "https://www.paypal.com/cgi-bin/webscr";
    
    echo '<form action="'. $action.'" method="post" name="paypal">
    <input type="hidden" name="METHOD" value="DoDirectPayment ">
    <input type="hidden" name="cmd" value="_cart">
    <input type="hidden" name="upload" value="1">
    <input type="hidden" name="method" value="DoDirectPayment">
    <input type="hidden" name="business" value="'. $paymentemail.'">
    <input type="hidden" name="item_name_1" value="'.$item_name_1.'">
    <input type="hidden" name="item_number_1" value="'. $item_number_1.'">
    <input type="hidden" name="amount_1" value="'.$amount.'">
    <input type="hidden" name="quantity_1" value="1">
    <input type="hidden" name="custom" value="'.$site_namee.'">
    <input type="hidden" name="return" value="'.$CRMSERVERPATH.'paypal/success_v2.0.php">
    <input type="hidden" name="notify_url" value="'.$CRMSERVERPATH.'paypal/payment_notification.php">  
    <input type="hidden" name="rm" value="2">
    <input type="hidden" name="cbt" value="Return to The Store">
    <input type="hidden" name="cancel_return" value="'.$CRMSERVERPATH.'paypal/cancel.php">
    <input type="hidden" name="lc" value="US">
    <input type="hidden" name="currency_code" value="USD">       
</form>';
?>
<script>
   document.paypal.submit();
</script>
