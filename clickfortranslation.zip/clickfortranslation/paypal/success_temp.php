<?php
include_once "../common_setting.php"; //$COMMONSETTING, $CRMSERVERPATH
include_once "../lib/common_array_price_quote.php";
include("../lib/serverconnect.php");
include("../lib/functions.php");

//echo "<pre>";print_r($_POST);die;
/*$product_id     =   $_POST['item_number1'];
$product_name   =   $_POST['item_name1'];
$sid            =   $_POST['txn_id'];
$key            =   $_POST['payer_id'];
$first_name     =   $_POST['first_name'];
$last_name      =   $_POST['last_name'];
$card_holder_name =   $_POST['first_name'];
$email          =   $_POST['payer_email'];
$order_number   =   $_POST['order_number'];
$currency_code  =   $_POST['address_country_code'];
$invoice_id     =   $_POST['payer_id'];
$price          =   $_POST['mc_gross_1'];
$total          =   $_POST['payment_gross'];
$credit_card_processed    =   $_POST['credit_card_processed'];
$street_address =   $_POST['address_street'];
$street_address2=   $_POST['address_name'];
$city           =   $_POST['address_city'];
$state          =   $_POST['address_state'];
$country        =   $_POST['address_country'];
$ip_country     =   $_POST['address_country_code'];
$zip            =   $_POST['address_zip'];
$phone          =   $_POST['phone'];
$demo           =   $_POST['business'];
$pay_method     =   $_POST['payment_type'];
$x_receipt_link_url =   $_POST['x_receipt_link_url'];
$payment_date   = $_POST['payment_date'];
$payment_status = $_POST['payment_status'];
$payment_fee    = $_POST['payment_fee'];
$receiver_id    = $_POST['receiver_id'];
$sitename       = $_POST['custom'];
$payment_type   = "paypal"; 
$data           = mysql_real_escape_string(json_encode($_POST));
$sql = "INSERT INTO `payment`(`product_id`,`product_name`, `sid`, `key`, `first_name`, `last_name`, `card_holder_name`, `email`, `order_number`, `currency_code`, `invoice_id`, `price`, `total`, `credit_card_processed`, `street_address`, `street_address2`, `city`, `state`, `country`, `ip_country`, `zip`, `phone`, `demo`, `pay_method`, `x_receipt_link_url`,`payment_date`,`payment_status`,`payment_fee`,`receiver_id`,`payment_type`,`data`) VALUES ('$product_id','$product_name','$sid','$key','$first_name','$last_name','$card_holder_name','$email','$order_number','$currency_code','$invoice_id','$price','$total','$credit_card_processed','$street_address','$street_address2','$city','$state','$country','$ip_country','$zip','$phone','$demo','$pay_method','$x_receipt_link_url','$payment_date','$payment_status','$payment_fee','$receiver_id','$payment_type','$data')";
mysql_query($sql);

// For creating additional info page URL
$sql_customer = mysql_query("SELECT * FROM `tickets_transcription_payment` WHERE orderno = '$product_id'");
$customer_data = mysql_fetch_assoc($sql_customer);
$sno     = $customer_data['id'];
$param = $product_id.'|<>|'.$sno;
$param = encrypt_decrypt('encrypt', $param);
$fileuploadurl = 'http://'.$QUOTEMAILERINFO[$sitename]['successpage']."/additional-information.php?id=".$param;
// End

//if($product_id != ""){
$sql_updated = mysql_query("SELECT * FROM `tickets_transcription_payment` WHERE orderno = '$product_id' AND suceess_mail = '1'");
$number_of_rows = mysql_num_rows($sql_updated);
//if($number_of_rows < 1){
    $sql_updated1 = mysql_query("SELECT * FROM `tickets_transcription_payment` WHERE orderno = '$product_id'");
    $prdorder= mysql_fetch_assoc($sql_updated1);
 //$sql = "update tickets_transcription_payment set payment_status = '1', suceess_mail = '1' where orderno = '$product_id' ";
 mysql_query($sql);
 */

        
        $customerName = $customer_data['name'];
        $customeremail= $customer_data['email'];
        $service      = $customer_data['service'];
        $service_type = $customer_data['servicetype'];
        $sourcefiletype = $customer_data['sourcefiletype'];
        $customerName = $customer_data['name'];
        $verb         = $customer_data['verbatim'];
        $timecode     = $customer_data['tcode'];
        $pagecount = $customer_data['pagecount'];
        $files        = $customer_data['ufile'];
       

        $fileName     = explode(",",$files);      
        $filenames    = "";
        foreach ($fileName as $value) {
            $data = str_replace("xx_","",strstr($value,"xx_"));
            $fil   = explode("#-#",$data);           
            if($filenames == ""){
                $filenames .= preg_replace('/\\.[^.\\s]{3,4}$/', '', $fil[0]);;
            }else{
                $filenames .= ", ".preg_replace('/\\.[^.\\s]{3,4}$/', '', $fil[0]);
            }            
        }

        if($service = "Transcription"){
            $order_tect = "transcribed";
        }           
        
        $len_minutes = $prdorder['minutes'];
        $orderId = $prdorder['orderno'];
        $ttime = $prdorder['tat'];
        //$logo = 'http://vananservices.com/img/DS-logo.png';
        $logo = 'http://'.$QUOTEMAILERINFO[$sitename]['successpage'].'/img/DS-logo.png';
        //$param = $product_id.'-'.md5($sno);   

        if($sourcefiletype == 'Document'){
            $servicetype = ucfirst($servicetype);
            $headertitle = "Number of pages";
            $len_minutes = ($customer_data['pagecount'] == 1)?$customer_data['pagecount']." page":$customer_data['pagecount']." pages";
        }else if($service != 'Translationpay'){
            $servicetype = "Transcription";
            $headertitle = "Total File Lenth";
            $len_minutes = $customer_data['minutes']." mins";
        }
$sitename ="helplancers.com";
if(!in_array($sitename,$notcommonfootersites)) {
    $subjecthtml = "Vanan Online Services";
    $footerhtml = '<tr style="text-align: center;background: #006dce;border: solid 1px #006DCE;border-bottom-right-radius: 4px; border-bottom-left-radius: 4px;">
                <td style="padding: 16px 22px;"> <a href="https://vananservices.com/"><img src="https://vananservices.com/img/as-logo.png"></a>
                    <br>
                    <p style="color: #fff;font-size: 13px;margin: 8px 0 0 0;line-height: 30px;letter-spacing: 0.9px; text-align: center;"> Transcription | Translation |  Captioning/Subtitling  | Voice Over| Video Services |  Writing |  Typing |  Dictation</p>
                </td>
            </tr>

            <tr style="background:#f1f8fc;text-align: center;border: solid 1px #006DCE;border-bottom-right-radius: 4px; border-bottom-left-radius: 4px;">
                <td>
                    <p style="color: #333;font-size: 12px;font-weight: bold;margin: 0;line-height: 30px;letter-spacing: 0.9px;">  Toll-Free : &nbsp;<span style="color: #006dce;">US</span> : 1-888-535-5668 &nbsp; <span style="color: #006dce;">UK</span> : +44-80-8238-0078 &nbsp; <span style="color: #006dce;">AUS</span> : +44-80-8238-0078 </p>
                </td>
            </tr>';
}else{
    $subjecthtml = "Helplancers";
    $footerhtml='<tr style="text-align: center;background: #006dce;border: solid 1px #006DCE;border-bottom-right-radius: 4px; border-bottom-left-radius: 4px;">
                <td style="padding: 16px 22px;">
                    <p style="color: #fff;font-size: 13px;margin: 8px 0 0 0;line-height: 30px;letter-spacing: 0.9px; text-align: center;"> Transcription | Translation |  Captioning/Subtitling  | Voice Over| Video Services |  Writing |  Typing |  Dictation</p>
                </td>
            </tr>

            <tr style="background:#f1f8fc;text-align: center;border: solid 1px #006DCE;border-bottom-right-radius: 4px; border-bottom-left-radius: 4px;">
                <td>
                    <p style="color: #333;font-size: 12px;font-weight: bold;margin: 0;line-height: 30px;letter-spacing: 0.9px;">  Toll-Free : &nbsp;<span style="color: #006dce;">US</span> : 1-888-422-2268 </p>
                </td>
            </tr>';
}
    $invoice ='<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8"> </head>
<body style="width: 630px; margin: 60px auto 0 auto; padding:0 !important; -webkit-text-size-adjust:none; -ms-text-size-adjust:none; background-color:#FFFFFF;border: 1px solid #a0a0a0;max-width: 100%;font-family:\'Raleway\', \'Helvetica Neue\', Helvetica, Arial, sans-serif">
    <table style="width: 100%;">
        <tbody>
            <tr>
                <table style="width: 100%;">
                    <tbody>
                        <tr>
                            <td align="center" style="border-bottom: 1px solid #e7e7e7;padding-top:18px;padding-bottom:8px;background-color: #f1f8fc;"> <img src="'.$logo.'" width="220px" alt="img"> </td>
                        </tr>
                        <tr>
                            <td>
                                <p style="margin-left: 12px;color:#424242;padding-bottom: 8px; font-weight: bold;">Hello!</p>
                                <p style="margin-left: 12px;color:#424242;padding-bottom: 13px; line-height: 28px;">
                                    Thanks for your order. We\'ll start working on it right away.                                 
                                </p>
                            </td>
                        </tr>
                        <tr>
                            <td align="center">
                                <p style="color:#333;font-size: 14px;font-weight: bold;">
                                    <a href="'.$fileuploadurl.'" style="text-decoration:none;font-size:14px;background-color: #00c853; box-shadow: 0 2px 4px 0 rgba(0,0,0,.23), inset 1px 1px 0 0 hsla(0,0%,100%,.2);    display: inline-block;color: #fff;padding: 12px 25px;font-size: 16px;border-radius: 4px;-moz-border-radius: 4px;-webkit-border-radius: 4px;font-weight: 400;" target="_blank">Upload Files</a>
                                </p>
                            </td>
                        </tr>                        
                        <tr>
                            <td align="center">
                                <span style="color:#333;font-size: 13px;">(Ignore if you have shared your files already)</span>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </tr>
            <tr>
                <div class="table-responsive">
                    <table style="border: 1px solid #e7e7e7;width: 100%;">
                        <tbody>
                            <tr class="unread" style="background-color:#f5f5f5;border-top:1px solid #e7e7e7">
                                <td align="center" colspan="8" style="font-size:18px;padding: 10px;text-align: center;font-weight: bold;color: #3f3d3d;"><b>Order Information</b></td>
                            </tr>                        
                            <tr class="unread" style="border-top:1px solid #e7e7e7">
                                <td align="center" colspan="8" style="padding: 10px;text-align: center;font-weight: bold;color: #3f3d3d;"><b>Order ID : '.$orderId.'</b></td>
                            </tr>
                            
                            <tr class="unread">
                                <td align="center" style="border-top: 1px solid #ddd;adding: 8px;font-size: 15px;"><b style="font-weight: bold;color: #3f3d3d;">'.$headertitle.'</b></td>
                                <td align="center" style="border-top: 1px solid #ddd;padding: 8px;font-size: 15px;"> <b style="font-weight: bold;color: #3f3d3d;">Grand Total</b></td>
                                <td align="center" style="border-top: 1px solid #ddd;padding: 8px;font-size: 15px;"> <b style="font-weight: bold;color: #3f3d3d;">Turnaround Time</b></td>
                            </tr>
                            <tr class="unread">
                                <td align="center" style="border-top: 1px solid #ddd;padding: 8px;font-size: 15px;">'.$len_minutes.'</td>
                                <td align="center" style="border-top: 1px solid #ddd;padding: 8px;font-size: 15px;">$'.$total.'</td>
                                <td align="center" style="border-top: 1px solid #ddd;padding: 8px;font-size: 15px;">'.$ttime.'</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </tr>
            <tr>
                <table style="width: 100%;border-bottom: 1px solid #c5c1c1;margin-top: 50px;">
                    <tr>
                        <td></td>
                        <td></td>
                    </tr>
                </table>
            </tr>
            <tr>
                <table style="width: 100%;background-color: #f1f8fc;">
                    '.$footerhtml.'
                </table>
            </tr>
        </tbody>
    </table>
</body>

</html>';

//        $to ="salescs@vananservices.com,vananbackup@gmail.com";
        $to ="rajkumar@vananservices.com";
        $subject = ucfirst($service_type)." Order Confirmation";
        $replyto = $to;
        $message=$invoice;
        $email = $to;
echo $message;
    multi_attach_maile($to, $subject, $message, $replyto, $sitename);
    function multi_attach_maile($to, $subject, $message, $replyto, $sitename){
        $from_mail = 'support@vananservices.com';
        $to = 'rajkumar@vananservices.com';
        if($sitename == 'helplancers.com'){
            $from_mail = "reachus@helplancers.com";
            $to = 'rajkumar@vananservices.com';
        }
        $headers = "From: $from_mail" . "\r\n";
        $headers .= "Reply-to: $email" . "\r\n";
        $headers .= "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type: text/html; charset=iso-8859-1" . "\r\n";
        @mail($to, $subject, wordwrap($message), $headers);
    }



/*$headers = "From: support@vananservices.com" . "\r\n";
$headers .= "Reply-to: $replyto" . "\r\n";
$headers .= "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type: text/html; charset=iso-8859-1" . "\r\n";
@mail($to, $subject, $message, $headers);*/
/*        header("Location: ".$fileuploadurl);
}
}
header("Location: ".$fileuploadurl);*/


?>
