<?php
    error_reporting(0);
    header("Access-Control-Allow-Origin: *");
    $quoteInfo = array();
    include_once "lib/serverconnect.php";
    include_once "lib/common_array_price_quote.php";
    include_once "lib/functions.php";
    include_once "common_setting.php";
    $site_url   = $_REQUEST['sitename'];
    $input = trim($site_url, '/');
    // If scheme not included, prepend it
    if (!preg_match('#^http(s)?://#', $input)) {
        $input = 'http://' . $input;
    }
    $urlParts = parse_url($input);
    // remove www
    $site_name = preg_replace('/^www\./', '', $urlParts['host']);
    if (isset($_REQUEST['command'])) {
        $command = isset($_REQUEST['command']) ? strtolower($_REQUEST['command']) : '';
        if ($command == "updatefilecount") {
            $filescount = $_REQUEST['completedfilecnt'] . "/" . $_REQUEST['totalfilecnt'];
            mysql_query("UPDATE ".$quoteInfo['uptblname']." SET filescount='" . $filescount . "' WHERE  ".$quoteInfo['uptblprimarykey']."=" . $quoteInfo['quoteid']);
            mysql_query("UPDATE uploads SET upload_status = 1 WHERE created_ts >= DATE_SUB(CURDATE(),INTERVAL 1 day) AND FileName = '$_REQUEST[uploadedFile]' ");
        }
        die('cnt updated...');
    }
    $website        = $QUOTEMAILERINFO[$site_name]['name'];
    $ipaddress      = $_SERVER['REMOTE_ADDR'];
    date_default_timezone_set('America/New_York');
    $createddate    = date('Y-m-d H:i:s');
    $browserdetail  = $_SERVER['HTTP_USER_AGENT'];

   if (isset($_REQUEST['fieldinfocommand'])) {
        $commandinfo = isset($_REQUEST['fieldinfocommand']) ? strtolower($_REQUEST['fieldinfocommand']) : '';
        $valuearray=array();
        if ($commandinfo == "updatefieldinfo") {
            $valuearray=$_REQUEST['savedata'];
            $crmservice = ucfirst($valuearray['service']);
            $Fieldinfo_UniqeID = uniqid();
            if($valuearray["entryval"]){
                switch ($valuearray["fieldname"]) {
                    case 'paytc_qemailcrm':
                        $fieldname  = "email";
                        $fieldvalue = $valuearray["qemail"];
                        break;
                    case 'sourcefiletype':
                        $fieldname  = "filetype";
                        $fieldvalue = $filetypes[$valuearray["sourcefiletype"]];
                        break;
                    case 'catetype':
                        $fieldname  = "purpose";
                        $fieldvalue = $valuearray["catetype"];
                        break;
                    case 'srclang':
                        $fieldname  = "source";
                        $fieldvalue = $language[$valuearray["srclang"]];
                        break;
                    case 'pagecount':
                        $fieldname  = "pagecount";
                        $fieldvalue = $valuearray["pagecount"];
                        break;
                    case 'prfilelength':
                        $fieldname  = "minutes";
                        $fieldvalue = $valuearray["prfilelength"];
                        break;
                    case 'expedited':
                        $fieldname  = "rush";
                        $fieldvalue = $valuearray["expedited"];
                        break;
                    case 'clicknext':
                        $fieldname  = "proceedednext";
                        $fieldvalue = $valuearray["clicknext"];
                        break;
                    case 'qttcodecrm':
                        $fieldname  = "timecode";
                        $fieldvalue = $valuearray["qttcodecrm"];
                        break;
                    case 'qtvercrmpay':
                        $fieldname  = "verbatime";
                        $fieldvalue = $valuearray["qtvercrmpay"];
                        break;
                    case 'notacrmpay':
                        $fieldname  = "notary";
                        $fieldvalue = $valuearray["notary"];
                        break;
                    case 'mailfilecrmpay':
                        $fieldname  = "mailed";
                        $fieldvalue = $valuearray["mailed"];
                        break;
                    case 'mailcountry':
                        $fieldname  = "mailingcountry";
                        $fieldvalue = $country[$valuearray["mailcountry"]];
                        break;
                    case 'paytc_mailaddress':
                        $fieldname  = "mailingaddress";
                        $fieldvalue = $valuearray["mailaddress"];
                        break;
                    case 'needtranscript':
                        $fieldname  = "needtranscript";
                        $fieldvalue = $valuearray["needtranscript"];
                        break;
                     case 'nativespkr':
                        $fieldname  = "nativespeaker";
                        $fieldvalue = $valuearray["nativespkr"];
                        break;
                     case 'formatting':
                        $fieldname  = "format";
                        $fieldvalue = $valuearray["formatting"];
                        break;
                    case 'camethrough':
                        $fieldname  = "camethrough";
                        $fieldvalue = $valuearray["camethrough"];
                        break;
                    case 'fileupload_tat':
                        $fieldname  = "ttime";
                        $fieldvalue = $valuearray["fileupload_tat"];
                        break;
                    case 'fileuploader':
                        $fieldname  = "ufile";
                        $fieldvalue = $valuearray["filedetails"];
                        break;
                    case 'priceviewed':
                        $fieldname  = "priceviewed";
                        $fieldvalue = $valuearray["priceviewed"];
                        break;
                    case 'pricetotal':
                        $fieldname  = "price";
                        $fieldvalue = $valuearray["pricetotal"];
                        break;
                    default:
                        break;
                }
                mysql_query("UPDATE enquiry_transcription_payment SET " . $fieldname . " ='" . $fieldvalue . "',modified='$createddate' WHERE entryid='" . $valuearray["entryval"]."'");
                die($valuearray["entryval"]);
            }else{
                    if($website==''){
                        $website=$site_name;
                    }
          mysql_query("INSERT INTO enquiry_transcription_payment(email, filetype, purpose, source, pagecount, minutes, rush, notary, mailed, mailingcountry, mailingaddress, timecode,needtranscript,nativespeaker,camethrough,ttime, created, ip_address, website, siteurl, entryid, format, browserdetail, service, ufile, priceviewed )
                                                                           VALUES('".mysql_real_escape_string(htmlentities($valuearray["qemail"])) ."', '".$filetypes[mysql_real_escape_string(htmlentities($valuearray["sourcefiletype"]))]."', '".mysql_real_escape_string(htmlentities($valuearray["catetype"])) ."',
                                                                           '".$language[mysql_real_escape_string(htmlentities($valuearray["srclang"]))]."', '".mysql_real_escape_string(htmlentities($valuearray["pagecount"])) ."',
                                                                           '".mysql_real_escape_string(htmlentities($valuearray["prfilelength"])) ."', '".mysql_real_escape_string(htmlentities($valuearray["expedited"])) ."', '".mysql_real_escape_string(htmlentities($valuearray["notary"])) ."',
                                                                           '".mysql_real_escape_string(htmlentities($valuearray["mailed"])) ."', '".$country[mysql_real_escape_string(htmlentities($valuearray["mailcountry"]))]."', '".mysql_real_escape_string(htmlentities($valuearray["mailaddress"])) ."',
                                                                           '".mysql_real_escape_string(htmlentities($valuearray["qttcodecrm"])) ."','".mysql_real_escape_string(htmlentities($valuearray["needtranscript"])) ."','".mysql_real_escape_string(htmlentities($valuearray["nativespkr"])) ."', '".mysql_real_escape_string(htmlentities($valuearray["camethrough"])) ."', '".mysql_real_escape_string(htmlentities($valuearray["fileupload_tat"])) ."', '$createddate', '$ipaddress', '$website', '$site_name', '$Fieldinfo_UniqeID', '".mysql_real_escape_string(htmlentities($valuearray["formatting"])) ."', 
                                                                           '$browserdetail', '$crmservice', '".mysql_real_escape_string(htmlentities($valuearray["filedetails"])) ."' ,'".mysql_real_escape_string(htmlentities($valuearray["priceviewed"])) ."' )");
                    $lastinsertedid= mysql_insert_id();
                    if($lastinsertedid){
                        $entryid= $Fieldinfo_UniqeID;
                    }
                    $output = $entryid;
                die($output);
            }
        }
        if ($commandinfo == "mailnetworkerror") {
            
            $valuearray=$_REQUEST['networkerrordata'];
            $crmservice = ucfirst($valuearray["service"]);
            $networkerrflag = $valuearray["networkerrflag"];
            $email = $valuearray["qemail"];
            $name = $valuearray["qname"];
            $country = $valuearray["qcountrys"];
            $purpose = $valuearray["qpurpose"];
            $acode = $valuearray["acode"];
            $qphone = $valuearray["qphone"];
            $entryval = $valuearray["entryval"];
            $filedetails = $valuearray["filedetails"];
            $fileuploadstatus = $valuearray["fileuploadstatus"];
            $uploadprogress = $valuearray["uploadprogress"];
            $crmpage = $valuearray["crmpage"];
			$uploaderrorresponse = $valuearray["uploaderrorresponse"];
            $uploadedfiledetails = $valuearray["uploadedfiledetails"];
            $to = 'support@vananservices.com,vananbackup@gmail.com';
            $subject        = $crmservice.' '.$QUOTEMAILERINFO[$site_name]['subject']." : Alternate Upload Options ";
            if($crmpage =="upload"){
                $subject        =  str_replace("Quote","Upload",$subject);
            }
            $foldername = "log";
            $filename ="networkerror";
            if (!is_dir($foldername)) {
                mkdir($foldername, 0777, true);
            }
            $date=date('d-m-Y');    
            $logdata = "<$createddate> ## <$entryval> ## <$email> ## <$filedetails> ## <$fileuploadstatus> ## <$uploadprogress> 
            ## <$uploaderrorresponse> ## <$uploadedfiledetails>";
            file_put_contents($foldername.'/'.$filename.'_'.$date.'.txt', $logdata . PHP_EOL, FILE_APPEND);
            $neterrmailreplace = array('__NETERR_SITEURL__' => $site_name.'/AlternateUpload.php'
                           );
            $fileopen             = fopen("mailer/networkerror.html", "r");
            $networkerrmail_content = fread($fileopen, filesize("mailer/networkerror.html"));
            fclose($fileopen);
            $networkerrmsg    = strtr($networkerrmail_content, $neterrmailreplace);

            if(multi_attach_mail($to, $subject, $networkerrmsg, $email, $sitename,1))
            {
                die("1");
            }else{
                die("0");
            }
        }
    }
if(isset($_REQUEST['coupon'])){
    $offpct = $couponcodes[$_REQUEST['coupon']];
    if($offpct == ''){
        $offpct = 0;
    }
    echo $offpct;
    die;
}
if(isset($_POST['buttonname'])) {
    date_default_timezone_set('America/New_York');
    $email              = isset($_POST['email']) ? $_POST['email'] : "";
    $qservice           = isset($_POST['service']) ? $_POST['service'] : "";
    $sitename           = isset($_POST['sitename']) ? $_POST['sitename'] : "";
    $sourcefiletype     = isset($_POST['sourcefiletype']) ? $filetypes[$_POST['sourcefiletype']] : "";
    $prfilelength       = isset($_POST['prfilelength']) ? $_POST['prfilelength'] : "";
    $pagecount          = isset($_POST['pagecount']) ? $_POST['pagecount'] : "";
    $qtlang = $source   = isset($_POST["source"]) ? $language[$_POST["source"]] : "";    
    $catetype           = $qpurpose = $purpose = isset($_POST['catetype']) ? $_POST['catetype'] : "";
    $fileupload_tat     = isset($_POST["fileupload_tat"]) ? $_POST["fileupload_tat"] : "";
    $notacrmpay         = isset($_POST['notacrmpay']) ? $_POST['notacrmpay'] : "";
    $nativespkr         = isset($_POST['nativespkr']) ? $_POST['nativespkr'] : "";
    $mailfilecrmpay     = isset($_POST['mailfilecrmpay']) ? $_POST['mailfilecrmpay'] : "";
    $mailcountry        = isset($_POST['mailcountry'])!="" ? $country[$_POST['mailcountry']] : "";
    
    $mailingaddr        = isset($_POST['mailingaddr']) ? $_POST['mailingaddr'] : "";
    $uploadat           = isset($_POST['uploadat']) ? $_POST['uploadat'] : "";
    $trgtunitcost       = isset($_POST["trgtunitcost"]) ? $_POST["trgtunitcost"] : "";
    $trlverbacost       = isset($_POST["trlverbacost"]) ? $_POST["trlverbacost"] : "";
    $trctcodecost       = isset($_POST["trctcodecost"]) ? $_POST["trctcodecost"] : "";
    $trgttotamt         = isset($_POST["trgttotamt"]) ? $_POST["trgttotamt"] : "";
    $nota_subamt        = isset($_POST['nota_subamt']) ? $_POST['nota_subamt'] : "";
    $notapro_subamt     = isset($_POST['notapro_subamt']) ? $_POST['notapro_subamt'] : "";
    $mfile_subamt       = isset($_POST['mfile_subamt']) ? $_POST['mfile_subamt'] : "";
    $subamttot          = isset($_POST['subamttot']) ? $_POST['subamttot'] : "";
    $transactionfee     = isset($_POST['transactionfee']) ? $_POST['transactionfee'] : "";
    $ordertotal         = isset($_POST['paymentamt']) ? $_POST['paymentamt'] : "";
//    $mini_subamt         = isset($_POST['mini_subamt']) ? $_POST['mini_subamt'] : "";
    $agent_ref          = isset($_POST["agent_ref"]) ? $_POST["agent_ref"] : "";
    $aprxtat            = isset($_POST["aprxtat"]) ? $_POST["aprxtat"] : "";
    $camethrough        = isset($_POST['camethrough']) ? $_POST['camethrough'] : "";
    $qtmin              = $prfilelength;
    $deliveryReq        = isset($_POST['deliveryReq']) ? $_POST['deliveryReq'] : "";
    $buttonname         = isset($_POST['buttonname']) ? $_POST['buttonname'] : "";
    $formatting         = isset($_POST["formatting"]) ? $_POST["formatting"] : "";

    $qttcode            = isset($_POST['qttcode']) ? $_POST['qttcode'] : "";
    $spkrchange         = isset($_POST['spkrchange']) ? $_POST['spkrchange'] : "";
    $howoftn            = isset($_POST['howoftn']) ? $_POST['howoftn'] : "";
    $oftnmtd            = isset($_POST['oftnmtd']) ? $_POST['oftnmtd'] : "";
    $qtvercrmpay            = isset($_POST['qtvercrmpay']) ? $_POST['qtvercrmpay'] : "";
    $cst_db             = isset($_POST['cst_db']) ? $_POST['cst_db'] : "";


    $fil                = isset($_POST['filena']) ? $_POST['filena'] : "";
    $fildetail          = isset($_POST['fildetail']) ? $_POST['fildetail'] : "";
    $duratnval          = isset($_POST['duratnval']) ? $_POST['duratnval'] : "";
    $filecomments       = isset($_POST['filecomments']) ? $_POST['filecomments'] : "";

    $trgt_unitcostb     = isset($_POST['trgt_unitcostb']) ? $_POST['trgt_unitcostb'] : "";
    $trgt_totamtb       = isset($_POST['trgt_totamtb']) ? $_POST['trgt_totamtb'] : "";
    $ofpct           = isset($_POST['ofpct']) ? $_POST['ofpct'] : "";
    $offerval           = isset($_POST['offerval']) ? $_POST['offerval'] : "";
    $finalround         = isset($_POST['finalround']) ? $_POST['finalround'] : "";


    $filena = '';
    $s      = explode(',', $fil);
    $fie    = '';
    $fill   = '';
    $filink = '';
    $cou    = count($s);

    for ($t = 0; $t < $cou; $t++) {
        if ($t != ($cou - 1)) {
            $fill = str_replace("\\", '/', $s[$t]);
            $fie = $fie . basename($fill) . "|,";
        } else {
            $fill = str_replace("\\", '/', $s[$t]);
            $fie = $fie . basename($fill);
        }
    }
    $filescount     = $completedfilecnt . "/" . $count;


    $fileInfo = $fileArr = array();

    if (!empty($_REQUEST['uploadedFileDetailsArr'])){
        $uploadedfilesarr = explode(",", $_REQUEST['uploadedFileDetailsArr']);
    }
    foreach ($uploadedfilesarr as $arrayval) {
        $uploadedfilearr= explode("#-#", $arrayval);
        $uploadedfilenamearr[] = substr($uploadedfilearr[0], strpos($uploadedfilearr[0], '/') + 1);
    }
    $mn=0;
    $filecontentrow='';

    $qttcode = $timcodeoptions[$qttcode]['label'];

    $deliveryReq        = ($deliveryReq == '1') ? 'Yes' : 'No';
    $notacrmpay         = ($notacrmpay == '1') ? 'Yes' : 'No';
    $mailfilecrmpay     = ($mailfilecrmpay == '1') ? 'Yes' : 'No';
    $qtvercrmpay            = ($qtvercrmpay == '1') ? 'Yes' : 'No';

    $needtranscript     = ($needtranscript == '1') ? 'Yes' : 'No';
    $nativespkr         = ($nativespkr == '1') ? 'Yes' : 'No';


    if($sourcefiletype == 'Document'){
        $srctype = 'Number of page(s)';
        $costlabel = 'Cost per page';
        $nosrc = $pagecount;
        $catheader = 'Formatting';
        $catvalue = $formatting;
    }else{
        $srctype = 'Minutes';
        $costlabel = 'Cost per minute';
        $nosrc = $qtmin;

        $catheader = 'Verbatim';
        $catvalue = $qtvercrmpay;
    }


    $channelno = 11;
    if ($buttonname == "Proceed to Payment") {
        $channelno = 10;
    } elseif ($buttonname == "Get Quote") {
        $channelno = 11;
    } elseif ($buttonname == "Email Quote") {
        $channelno = 19;
    }
    
    $channelno   = ($cst_db == '1') ? 9 : $channelno;
    $hiddenservice = $servicelist[ucfirst($qservice)];
    $sitechannel = "abchidFS" . encrypt('__sitename_' . $site_name . '__ __channel_' . $channelno . '__ __service_' . $hiddenservice . '__ __cstemail_' . $email . '__ __ipaddress_' . $ipaddress . '__', 'vanancrm*encrypt') . "abchidFE";
    if(!in_array($sitename,$notcommonfootersites)) {
        $subjecthtml = "Vanan Online Services";
        $footerhtml = '<tr style="text-align: center;background: #006dce;border: solid 1px #006DCE;border-bottom-right-radius: 4px; border-bottom-left-radius: 4px;">
                <td style="padding: 16px 22px;"> <a href="https://vananservices.com/"><img src="https://vananservices.com/img/as-logo.png"></a>
                    <br>
                    <p style="color: #fff;font-size: 13px;margin: 8px 0 0 0;line-height: 30px;letter-spacing: 0.9px; text-align: center;"> Transcription | Translation |  Captioning/Subtitling  | Voice Over| Video Services |  Writing |  Typing |  Dictation</p>
                </td>
            </tr>

            <tr style="background:#f1f8fc;text-align: center;border: solid 1px #006DCE;border-bottom-right-radius: 4px; border-bottom-left-radius: 4px;">
                <td>
                    <p style="color: #333;font-size: 12px;font-weight: bold;margin: 0;line-height: 30px;letter-spacing: 0.9px;">  Toll-Free : &nbsp;<span style="color: #006dce;">US</span> : 1-888-535-5668 &nbsp; <span style="color: #006dce;">UK</span> : +44-80-8238-0078 &nbsp; <span style="color: #006dce;">AUS</span> : +44-80-8238-0078 </p>
                </td>
            </tr>';
    }else{
        $subjecthtml = "Helplancers";
        $footerhtml='<tr style="text-align: center;background: #006dce;border: solid 1px #006DCE;border-bottom-right-radius: 4px; border-bottom-left-radius: 4px;">
                <td style="padding: 16px 22px;">
                    <p style="color: #fff;font-size: 13px;margin: 8px 0 0 0;line-height: 30px;letter-spacing: 0.9px; text-align: center;"> Transcription | Translation |  Captioning/Subtitling  | Voice Over| Video Services |  Writing |  Typing |  Dictation</p>
                </td>
            </tr>

            <tr style="background:#f1f8fc;text-align: center;border: solid 1px #006DCE;border-bottom-right-radius: 4px; border-bottom-left-radius: 4px;">
                <td>
                    <p style="color: #333;font-size: 12px;font-weight: bold;margin: 0;line-height: 30px;letter-spacing: 0.9px;">  Toll-Free : &nbsp;<span style="color: #006dce;">US</span> : 1-888-422-2268 </p>
                </td>
            </tr>';
    }
    /*----------------------------FREE QUOTE START -------------------------*/
    if ($buttonname == "Get Quote") {
        $QUOTESERVICE = 'Typing';
        $updateTableName = 'tickets_transcription_payment';
        $updateTablePrimaryKey = 'id';
        /*---------------MAIL CONTENT START---------------*/
        $mailngaddr = '';
        $mailngcntry = '';
        $mailfilehtml = '';
        $formathtml = '';
        $timecodehtml = '';
        if($formatting != ''){
            $formathtml = '<tr class="unread">
                <td align="center" style="border-right: 1px solid #ddd;font-size: 15px;width: 161px;text-align: left;padding:12px 10px;border-bottom: 1px solid #ddd;"><b style="font-weight: bold;color: #3f3d3d;">Format </b></td>
                <td align="center" style="padding: 8px;font-size: 15px;border-bottom: 1px solid #ddd; text-align: left;">' . $formatting . '</td>
            </tr>';
        }
        $tcodeval = '';
        if($qttcode != ''){
            $timecodehtml = '<tr class="unread">
                <td align="center" style="border-right: 1px solid #ddd;font-size: 15px;width: 161px;text-align: left;padding:12px 10px;border-bottom: 1px solid #ddd;"><b style="font-weight: bold;color: #3f3d3d;"> Time Code</b></td>
                <td align="center" style="padding: 8px;font-size: 15px;border-bottom: 1px solid #ddd; text-align: left;">' . $qttcode . '</td>
            </tr>';
        }

        $nopageshtml = '<tr class="unread">
                    <td align="center" style="border-right: 1px solid #ddd;font-size: 15px;width: 161px;text-align: left;padding:12px 10px;border-bottom: 1px solid #ddd;"><b style="font-weight: bold;color: #3f3d3d;">No of pages </b></td>
                    <td align="center" style="padding: 8px;font-size: 15px;border-bottom: 1px solid #ddd; text-align: left;">' . $pagecount . '</td>
                </tr>';

        $notaryhtml = '<tr class="unread">
                    <td align="center" style="border-right: 1px solid #ddd;font-size: 15px;width: 161px;text-align: left;padding:12px 10px;border-bottom: 1px solid #ddd;"><b style="font-weight: bold;color: #3f3d3d;">Notarized</b></td>
                    <td align="center" style="padding: 8px;font-size: 15px;border-bottom: 1px solid #ddd; text-align: left;">' . $notacrmpay . '</td>
                </tr>';

        $minuteshtml = '<tr class="unread">
                <td align="center" style="border-right: 1px solid #ddd;border-bottom: 1px solid #ddd;font-size: 15px;width: 161px;text-align: left;padding:12px 10px;"><b style="font-weight: bold;color: #3f3d3d;">Minutes</b></td>
                <td align="center" style="padding: 8px;font-size: 15px;border-bottom: 1px solid #ddd; text-align: left;">' . $qtmin . '</td>
            </tr>';

        $needtrchtml = '';
        if($needtranscript == 'Yes'){
        $needtrchtml = ' <tr class="unread">
                <td align="center" style="border-right: 1px solid #ddd;font-size: 15px;width: 161px;text-align: left;padding:12px 10px;border-bottom: 1px solid #ddd;"><b style="font-weight: bold;color: #3f3d3d;">Need Transcript</b></td>
                <td align="center" style="padding: 8px;font-size: 15px;border-bottom: 1px solid #ddd; text-align: left;">' . $needtranscript . '</td>
            </tr>';
        }
        $nativehtml = '';
        if($nativespkr == 'Yes') {
            $nativehtml = ' <tr class="unread">
                <td align="center" style="border-right: 1px solid #ddd;font-size: 15px;width: 161px;text-align: left;padding:12px 10px;border-bottom: 1px solid #ddd;"><b style="font-weight: bold;color: #3f3d3d;">U.S Native Speaker</b></td>
                <td align="center" style="padding: 8px;font-size: 15px;border-bottom: 1px solid #ddd; text-align: left;">' . $nativespkr . '</td>
            </tr>';
        }
        $qtvercrmhtml = '';
        if($qtvercrmpay == 'Yes') {
            $qtvercrmhtml = ' <tr class="unread">
                <td align="center" style="border-right: 1px solid #ddd;font-size: 15px;width: 161px;text-align: left;padding:12px 10px;border-bottom: 1px solid #ddd;"><b style="font-weight: bold;color: #3f3d3d;">Verbatim</b></td>
                <td align="center" style="padding: 8px;font-size: 15px;border-bottom: 1px solid #ddd; text-align: left;">' . $qtvercrmpay . '</td>
            </tr>';
        }
        $expeditedhtml = '';
        if ($deliveryReq == "Yes") {
        $expeditedhtml = ' <tr class="unread">
                <td align="center" style="border-right: 1px solid #ddd;font-size: 15px;width: 161px;text-align: left;padding:12px 10px;border-bottom: 1px solid #ddd;"><b style="font-weight: bold;color: #3f3d3d;">Expedited Service</b></td>
                <td align="center" style="padding: 8px;font-size: 15px;border-bottom: 1px solid #ddd; text-align: left;">' . $deliveryReq . '</td>
            </tr>';
        }
        $fileupload_tathtml = '';
        if ($fileupload_tat != "" ) {
            $fileupload_tathtml = ' <tr class="unread">
                <td align="center" style="border-right: 1px solid #ddd;font-size: 15px;width: 161px;text-align: left;padding:12px 10px;border-bottom: 1px solid #ddd;"><b style="font-weight: bold;color: #3f3d3d;">Turnaround Time</b></td>
                <td align="center" style="padding: 8px;font-size: 15px;border-bottom: 1px solid #ddd; text-align: left;">' . $fileupload_tat . '</td>
            </tr>';
        }
    if ($mailfilecrmpay == 'Yes') {
        if($mailcountry != 'United States')
        {
          $fileupload_tathtml = ''; 
          $expeditedhtml = '';
        }
            $mailngaddr = '<tr class="unread">
                        <td align="center" style="border-right: 1px solid #ddd;border-bottom: 1px solid #ddd;font-size: 15px;width: 161px;text-align: left;padding:12px 10px;"><b style="font-weight: bold;color: #3f3d3d;">Physical address</b></td>
                        <td align="center" style="padding: 8px;font-size: 15px;border-bottom: 1px solid #ddd;text-align: left;">' . $mailingaddr . '</td>
                    </tr>';
            $mailngcntry = ' <tr class="unread">
                        <td align="center" style="border-right: 1px solid #ddd;font-size: 15px;width: 161px;text-align: left;padding:12px 10px;border-bottom: 1px solid #ddd;"> <b style="font-weight: bold;color: #3f3d3d;">Mailing country</b> </td>
                        <td align="center" style="padding: 8px;font-size: 15px;border-bottom: 1px solid #ddd; text-align: left;"> ' . $mailcountry . '</td>
                    </tr>';
        } else {
            $mailfilehtml = '<tr class="unread">
                        <td align="center" style="border-right: 1px solid #ddd;border-bottom: 1px solid #ddd;font-size: 15px;width: 161px;text-align: left;padding:12px 10px;"><b style="font-weight: bold;color: #3f3d3d;">Mailed</b></td>
                        <td align="center" style="padding: 8px;font-size: 15px;border-bottom: 1px solid #ddd;text-align: left;">' . $mailfilecrmpay . '</td>
                    </tr>';
        }
        $tathtml = '';
        if ($aprxtat != "") {
            $tathtml = '<tr class="unread">
                <td align="center" style="border-right: 1px solid #ddd;font-size: 15px;width: 161px;text-align: left;padding:12px 10px;border-bottom: 1px solid #ddd;"><b style="font-weight: bold;color: #3f3d3d;">Turnaround Time</b></td>
                <td align="center" style="padding: 8px;font-size: 15px;border-bottom: 1px solid #ddd; text-align: left;">' . $aprxtat . '</td>
            </tr>';
        }

        /*---------------MAIL CONTENT END---------------*/



        //if ($SEND_QUOTE == 0) {
            if ($website == '') {
                $website = 'Sitename not given';
            }
            $neworderId = '';
            if ($QUOTESERVICE == 'Typing') {
                 mysql_query("INSERT INTO tickets_transcription_payment(id,minutes,email,ttime,tat,tcode,fileformat,servicetype,language,  website, camethrough, ipaddress,createddate,browserdetail,purpose,service,paymentamt,notary,mailing,mailingcountry,mailingaddress,sourcefiletype,pagecount,source_lang,format,agentid,buttonname,rush,filecomment)"
                    ."VALUES('','$qtmin','$email','$fileupload_tat','$aprxtat','$qttcode','$qtformat','$qservice','$qtlang','$website','$camethrough','$ipaddress','$createddate','$browserdetail','$qpurpose','$QUOTESERVICE','$ordertotal','$notacrmpay','$mailfilecrmpay','$mailcountry','$mailingaddr','$sourcefiletype','$pagecount','$source','$formatting','$agent_ref','$buttonname','$deliveryReq','".mysql_real_escape_string(htmlentities($filecomments))."')");
                $lastinsertedid = mysql_insert_id();
                $todayDate = date('Y-m-d');
                $ordId = mysql_query("SELECT COUNT( * ) as total FROM  `tickets_transcription_payment` WHERE DATE(createddate) = '$todayDate' AND id < $lastinsertedid AND servicetype ='typing' AND orderno !=''");
                $data = mysql_fetch_assoc($ordId);
                $ordId = $data['total'];
                $ordId++;
                $neworderId = "TP" . date("dmy") . $ordId.rand(10,99);
                $neworderIdhtml = "Your confirmation ID is $neworderId.";
                mysql_query("UPDATE tickets_transcription_payment SET orderno ='$neworderId'  WHERE id=$lastinsertedid");
            }
            $sno = $lastinsertedid;
        if (!empty($fil)){
            $fileArr = explode(",", $fil);
            $duratnArr = explode(",", $duratnval);
            foreach ($fileArr as $val) {
                $UniqeID                = uniqid();
                $duratn                 = $duratnArr[$mn];
                $infoArr                = explode("#-#", $val);
                $param                  = array();
                $param['fileid']        = $UniqeID;
                $param['filename']      = substr($infoArr[0], strpos($infoArr[0], '/') + 1);
                $param['filesize']      = $infoArr[1];
                $param['fileduration']  = $duratn;
                $param['transfee']      = $transactionfee;
                $param['ordertotal']    = $ordertotal;
                $status                 = (in_array($param['filename'], $uploadedfilenamearr)) ? 1 :0;
                $fileInfo[]             = $param;
                //echo "INSERT INTO uploads (Id, OrderId, TableCode, FileName,FileFormat,FileSize,FileId,upload_status) values ('','$sno', '$tbleCodeStr', '$infoArr[0]','$infoArr[2]','$infoArr[1]', '$UniqeID',$status) ";
                mysql_query("INSERT INTO uploads (Id, OrderId, TableCode, FileName,FileFormat,FileSize,FileId,upload_status) values ('','$neworderId', '$tbleCodeStr', '$infoArr[0]','$infoArr[2]','$infoArr[1]', '$UniqeID',$status) ");
                $mn++;
            }
        }
        $filink = '';
        $j = 1;
        $fileDonwloadurl = $CRMSERVERPATH.'filedownload.php?FileId=';
        foreach($fileInfo as $val){
            $filduro = $val['fileduration'];
            $indcost = $val['indcost'];
            $dispName = substr($val['filename'], strpos($val['filename'], '_') + 1);
            $filink ='<a data-download="' . $val['filename'] . '" style="color:blue;" href="' . $fileDonwloadurl . $val['fileid'] . '">Download</a><br/>';
            $filecontentrow .='<tr>
                                <td align="left" style="border-right: 1px solid #e7e7e7;font-size: 13px;border-bottom: 1px solid #e7e7e7;">'.$dispName.'</td>
                                <td align="left" style="border-bottom: 1px solid #e7e7e7;font-size: 13px;">'.$filink.' </td></tr>';
        }
        $filerowhtml='';
        if(!empty($fileInfo)) {
            $filerowhtml = '<tr>
                </tr>
                <tr>
                    <td colspan="6" align="center" style="border-bottom: 1px solid #e7e7e7;font-weight: 600;"> File Details</td>
                </tr>
                <tr>
                    <td align="left" style="border-right: 1px solid #e7e7e7;border-bottom: 1px solid #e7e7e7;font-weight: 600;"> File Name</td>
                    <td align="left" style="border-bottom: 1px solid #e7e7e7;font-weight: 600;"> Link</td>
                </tr>
                                       
            ' . $filecontentrow;
        }
        $filecommentshtml='';
        if($filecomments != '' && !empty($fileInfo)){
            $filecommentshtml = '<tr class="unread">
                <td align="center" style="border-right: 1px solid #ddd;font-size: 15px;width: 161px;text-align: left;padding:12px 10px;border-bottom: 1px solid #ddd;"><b style="font-weight: bold;color: #3f3d3d;">Comments</b></td>
                <td align="center" style="padding: 8px;font-size: 15px;border-bottom: 1px solid #ddd; text-align: left;">' . $filecomments . '</td>
            </tr>';
        }

//        $needtranscript     = isset($_POST['needtranscript']) ? $_POST['needtranscript'] : "";
//        $nativespkr         = isset($_POST['nativespkr']) ? $_POST['nativespkr'] : "";

        if ($sourcefiletype == 'Document') {
            $secondfold = $nopageshtml .$formathtml. $expeditedhtml . $fileupload_tathtml . $notaryhtml . $mailfilehtml . $mailngcntry . $mailngaddr.$filecommentshtml;
        } else {
            $secondfold = $minuteshtml . $expeditedhtml . $fileupload_tathtml. $timecodehtml . $qtvercrmhtml .$nativehtml . $notaryhtml . $mailfilehtml . $mailngcntry . $mailngaddr.$filecommentshtml;
        }
            //echo "UPDATE enquiry_transcription_payment SET flag ='1'  WHERE entryid='" . $_POST['recordkey']."'";
            if ($sno) {
                mysql_query("UPDATE enquiry_transcription_payment SET flag ='1'  WHERE entryid='" . $_POST['recordkey'] . "'");
            }

            $param = $neworderId . '|<>|' . $sno;
            $param = encrypt_decrypt('encrypt', $param);
            //$fileuploadurl = "http://".$site_url."/additional-information.php?id=".$param;
            $service_name = $QUOTESERVICE . ' Services - Quote'; //'Translation Services - Quote';
/*            if ($crmpage == "upload") {
                $service_name = str_replace("Quote", "Upload", $service_name);

            }*/

            $logo = rtrim($site_url, '/') . '/img/DS-logo.png';
            $mailreplace = array('__SITELOGOIMG__' => $logo,
                            '__NAME__' => $name,
                            '__EMAIL__' => $email,
                            '__PHONE__' => $phone,
                            '__HEADERIMG__' => $logo,
                            '__TRANSACFEE__' => $transactionfee,
                            '__ORDERTOTAL__' => $ordertotal,
                            '__FILEROW__' => html_entity_decode($filerowhtml),
                            '__ORDERID__' => $neworderIdhtml,
                            '__COSTPERPAGE__' => $trgtunitcost,
                            '__TLCOST__' => $trgttotamt,
                            '__TRCHTM__' => $trcHtml,
                            '__TRLHTM__' => $needtrlsHtml,
                            '__NATIVECOST__' => $nativeavail,
                            '__SUBTOTALCOST__' => $subamttot,
                            '__INPUTFILEFORMAT__' => $qtformat,
                            '__TRANSCRIPTION__' => $qtlang,
                            '__SOURCE__' => $source,
                            '__NOTE__' => $qnote,
                            '__GMAILCONTENT__' => $qmail,
                            '__GMAILCONTENTDISP__' => empty($qmail)?"none":"",
                            '__TATIME__' => $aprxtat,
                            '__PURPOSE__' => $qpurpose,
                            '__COMMENT__' => nl2br(stripslashes($comment)),
                            '__SERVICENAME__' => $service_name,
                            '__SITEURL__' => $site_url,
                            '__SERVICETYPE__' => $qservice,
                            '__HFSERVICE__' => $paytc_hfc,
                            '__NOOFPAGES__' => $nopageshtml,
                            '__FORMAT__' => $formatting,
                            '__FORMATTING__' => $formathtml,
                            '__SUBJECT__' => $subjectcrm,
                            '__CAPTIONING__' => $captioningcrm,
                            '__NEEDTRANSCRIPTION__' => $needtranscriptioncrm,
                            '__VIDEOLENGTH__' => $videolengthcrm,
                            '__NEEDTRANSLATION__' => $needtranslationcrm,
                            '__SOURCEVOICEOVER__' => $sourcevoiceover,
                            '__SOURCEVOICEOVERDISP__' => (empty($needtranslationcrm) || $needtranslationcrm == 'No')?"none":"" ,
                            '__SCRIPTCRM__' => $scriptcrm,
                            '__COMMENTVOICEOVER__' => $commentvoiceover,
                            '__PURPOSEVOICEOVER__' => $purposevoiceover,
                            '__VOICECOUNTCRM__' => $voicecountcrm,
                            '__GENDERAGECRM__' => $genderage,
                            '__GENDERAGECRMDISP__' => empty($voicecountcrm)?"none":"",
                            '__SCRIPTVOICEOVER__' => $scriptcrm,
                            '__SCRIPTVOICEOVERDISP__' => (empty($scriptcrm) || $scriptcrm == 'No')?"none":"",
                            '__SITENAME__' => $site_name,
                            '__MINIMUM__' =>$minimumhtml,
                            '__HARDCOPYREQ__' =>$hardcopyhtml,
                            '__NOTARY__' =>$notaryhtml,
                            '__MAILED__' => $mfilehtml,
                            '__MAILADDR__' => $mailingaddrhtml,
                            '__MINORDER__' =>$minordercost,
                            '__FILETYPE__' => $sourcefiletype,
                            '__SITECHANNEL__' => $sitechannel,
                            '__SECFOLD__' => $secondfold,
                            '__FILEDETAILS__' => $filerowhtml,
                            '__MAILCOUNTRYHTML__' => $mailingfulladdr,
                            '__TATTIMEHTML__' => $tathtml,
                            '__SITESUB__' => $subjecthtml,
                            '__FOOTER__' => $footerhtml,
                            '__FILESIZEINFO__' => html_entity_decode($filesizeinfo)

                            );

       // }
        $quoteInfo = array('quoteservice'=>$QUOTESERVICE,'mailarray'=>$mailreplace);

        $service_name = $quoteInfo['quoteservice'] . ' Services - Quote'; //'Translation Services - Quote';
        $subject = $quoteInfo['quoteservice'] . $QUOTEMAILERINFO[$site_name]['subject'];//.$site_name;
        if ($crmpage == "upload") {
            $service_name = str_replace("Quote", "Upload", $service_name);
            $subject = str_replace("Quote", "Upload", $subject);
        }

        //$mailreplace = $quoteInfo["mailarray"];
        $quotemailerarray = array(
            '__SERVICESUBJECT__' => $subject,
            '__SERVICENAME__' => $service_name);
        $mailreplacenew = array_merge($mailreplace, $quotemailerarray);
        $file = fopen("mailer/" . $MAILERCODE[$QUOTESERVICE], "r");
        $htmlmail_content = fread($file, filesize("mailer/" . $MAILERCODE[$QUOTESERVICE]));
        fclose($file);
        $html_content = strtr($htmlmail_content, $mailreplacenew);
        $to = $email;
        multi_attach_mail($to, $subject, $html_content, $email, $sitename);
        if (isset($_COOKIE['uploadtest'])) {
            echo "===>Success...";
        }
        $output = json_encode(array('type' => 'message', 'text' => 'Your request has been sent successfully and you will receive an email from us shortly. Thank you!', 'param' => $param));
        die($output);
        /*----------------------------FREE QUOTE END -------------------------*/
    }
    else if($buttonname !=''){
    /*----------------------------PAYMENT QUOTE START -------------------------*/
    $notaryhtml = '';
    if ($notacrmpay == 'Yes') {
        $notaryhtml .= '<tr>
                    <td colspan="5" align="right" style="border-right: 1px solid #e7e7e7;border-top: 1px solid #e7e7e7;padding-right: 10px;">  <p style="color: #302e2e;font-size: 13px;"> Notary</p></td>
                    <td align="right" style="border-top: 1px solid #e7e7e7;width: 20%;">  <p style="color: #302e2e;font-size: 13px;">$' . $nota_subamt . '</p> </td>
                    </tr>
                    <tr>
                    <td colspan="5" align="right" style="border-right: 1px solid #e7e7e7;border-top: 1px solid #e7e7e7;padding-right: 10px;">  <p style="color: #302e2e;font-size: 13px;"> Processing fee</p></td>
                    <td align="right" style="border-top: 1px solid #e7e7e7;width: 20%;">  <p style="color: #302e2e;font-size: 13px;">$' . $notapro_subamt . '</p> </td>
                    </tr>';
    }

/*    $discounthtml='';
    if($trgt_totamtb > 0){
        $discounthtml = '<tr>
            <td colspan="5" align="right" style="border-right: 1px solid #e7e7e7;border-top: 1px solid #e7e7e7;padding-right: 10px;">  <p style="color: #302e2e;font-size: 13px;"> Discounted price ('.$trgt_unitcostb.'/min)</p></td>
            <td align="right" style="border-top: 1px solid #e7e7e7;width: 20%;">  <p style="color: #302e2e;font-size: 13px;">$' . $trgt_totamtb . '</p> </td>
            </tr>';
    }*/

    $timecodehtml='';
    $timecodedesc='';
    if($qttcode != ''){
        $timecodehtml = '<tr>
                <td colspan="5" align="right" style="border-right: 1px solid #e7e7e7;border-top: 1px solid #e7e7e7;padding-right: 10px;">  <p style="color: #302e2e;font-size: 13px;"> Time code</p></td>
                <td align="right" style="border-top: 1px solid #e7e7e7;width: 20%;">  <p style="color: #302e2e;font-size: 13px;">$' . $trctcodecost . '</p> </td>
                </tr>';
        $timecodedesc = '<tr>
                <td colspan="6" align="center" style="color: #302e2e;font-size: 12px;border-top: 1px solid #e7e7e7;">
                Time code will be perform at '.strtolower($qttcode).'.
                </td>
                </tr>';
    }

    $verbahtml='';
    if($qtvercrmpay == 'Yes'){
        $verbahtml = '<tr>
                <td colspan="5" align="right" style="border-right: 1px solid #e7e7e7;border-top: 1px solid #e7e7e7;padding-right: 10px;">  <p style="color: #302e2e;font-size: 13px;"> Verbatim</p></td>
                <td align="right" style="border-top: 1px solid #e7e7e7;width: 20%;">  <p style="color: #302e2e;font-size: 13px;">$' . $trlverbacost . '</p> </td>
                </tr>';
    }

     /*$minimumhtml = '';
    if (($mini_subamt > $trgttotamt)) {
        $minimumhtml .= '<tr>
                    <td colspan="5" align="right" style="border-right: 1px solid #e7e7e7;border-top: 1px solid #e7e7e7;padding-right: 10px;">  <p style="color: #302e2e;font-size: 13px;"> Minimum order</p></td>
                    <td align="right" style="border-top: 1px solid #e7e7e7;width: 20%;">  <p style="color: #302e2e;font-size: 13px;">$' . $mini_subamt . '</p> </td>
                    </tr>';
    }*/

    $mfilehtml = '';
    $hardcopyhtml = '';
    if ($mailfilecrmpay == 'Yes' && $mailcountry == "United States") {
        $mfilehtml .= '<tr>
                    <td colspan="5" align="right" style="border-right: 1px solid #e7e7e7;border-top: 1px solid #e7e7e7;padding-right: 10px;">  <p style="color: #302e2e;font-size: 13px;"> Mailing</p></td>
                    <td align="right" style="border-top: 1px solid #e7e7e7;width: 20%;">  <p style="color: #302e2e;font-size: 13px;">$' . $mfile_subamt . '</p> </td>
                    </tr>';
        $hardcopyhtml = 'The mentioned TAT applies for the delivery of electronic copies via email. TAT may vary for mailing hard copies depending upon the shipping address.';
    }

    $offervalhtml ='';
    if($offerval > 0){
        $offervalhtml = '<tr>
        <td colspan="5" align="right" style="border-right: 1px solid #e7e7e7;border-top: 1px solid #e7e7e7;padding-right: 10px;">  <p style="color: #302e2e;font-size: 13px;"> Coupon discount (-'.$ofpct.')</p></td>
        <td align="right" style="border-top: 1px solid #e7e7e7;width: 20%;">  <p style="color: #302e2e;font-size: 13px;">$' . $offerval . '</p> </td>
    </tr>';
    }
    $finalroundhtml ='';
    if($offerval > 0) {
        $finalroundhtml = '<tr>
        <td colspan="5" align="right" style="border-right: 1px solid #e7e7e7;border-top: 1px solid #e7e7e7;padding-right: 10px;">  <p style="color: #302e2e;font-size: 13px;"> Offer price</p></td>
        <td align="right" style="border-top: 1px solid #e7e7e7;width: 20%;">  <p style="color: #302e2e;font-size: 13px;">$' . $finalround . '</p> </td>
    </tr>';
    }
    if($nativespkr == 'Yes' && $source == 'English'){
        $nativeavail = "You have availed U.S. native transcribers for your project that costs $1.75 per minute.";
    }

    $QUOTESERVICE   = 'Typingpay';
    $QUOTESERVICEdb = $QUOTESERVICE;
    if ($buttonname == "Email Quote") {
        $QUOTESERVICEdb = 'Typingpayquote';
    }


    $updateTableName = 'tickets_transcription_payment';
    $updateTablePrimaryKey = 'id';

    if ($website == '') {
        $website = 'Sitename not given';
    }
    if ($QUOTESERVICE == 'Typingpay') {
        $neworderIdhtml = '';
        $neworderId = '';
       mysql_query("INSERT INTO tickets_transcription_payment(id,email,minutes,format,ttime,tat,tcode,servicetype,language,website,ipaddress,createddate,browserdetail,purpose,service,paymentamt,notary,mailing,mailingcountry,mailingaddress,sourcefiletype,pagecount,source_lang,buttonname,rush,camethrough,needtranscription,native,filecomment) "
            . "VALUES('','$email','$qtmin','$formatting','$fileupload_tat','$aprxtat','$qttcode','$qservice','$qtlang','$website','$ipaddress','$createddate','$browserdetail','$qpurpose','$QUOTESERVICEdb','$ordertotal','$notacrmpay','$mailfilecrmpay','$mailcountry','$mailingaddr','$sourcefiletype','$pagecount','$source','$buttonname','$deliveryReq','$camethrough','$needtranscript','$nativespkr','".mysql_real_escape_string(htmlentities($filecomments))."')");
        $tbleCodeStr = $TABLECODE['tickets_transcription_payment'];
        $lastinsertedid = mysql_insert_id();
        $todayDate = date('Y-m-d');
        $ordId = mysql_query("SELECT COUNT( * ) as total FROM  `tickets_transcription_payment` WHERE DATE(createddate) = '$todayDate' AND id < $lastinsertedid AND servicetype ='typing' AND orderno !=''");        
        $data = mysql_fetch_assoc($ordId);
        $ordId = $data['total'];
        $ordId++;
        $neworderId = "TP" . date("dmy") . $ordId.rand(10,99);
        $neworderIdhtml = "Your confirmation ID is $neworderId.";
        mysql_query("UPDATE tickets_transcription_payment SET orderno ='$neworderId'  WHERE id=$lastinsertedid");
    }
    $sno = $lastinsertedid;
        if (!empty($fil)){
            $fileArr = explode(",", $fil);
            $duratnArr = explode(",", $duratnval);
            foreach ($fileArr as $val) {
                $UniqeID                = uniqid();
                $duratn                 = $duratnArr[$mn];
                $infoArr                = explode("#-#", $val);
                $param                  = array();
                $param['fileid']        = $UniqeID;
                $param['filename']      = substr($infoArr[0], strpos($infoArr[0], '/') + 1);
                $param['filesize']      = $infoArr[1];
                $param['fileduration']  = $duratn;
                $param['transfee']      = $transactionfee;
                $param['ordertotal']    = $ordertotal;
                $status                 = (in_array($param['filename'], $uploadedfilenamearr)) ? 1 :0;
                $fileInfo[]             = $param;
                //echo "INSERT INTO uploads (Id, OrderId, TableCode, FileName,FileFormat,FileSize,FileId,upload_status) values ('','$sno', '$tbleCodeStr', '$infoArr[0]','$infoArr[2]','$infoArr[1]', '$UniqeID',$status) ";
                mysql_query("INSERT INTO uploads (Id, OrderId, TableCode, FileName,FileFormat,FileSize,FileId,upload_status) values ('','$neworderId', '$tbleCodeStr', '$infoArr[0]','$infoArr[2]','$infoArr[1]', '$UniqeID',$status) ");
                $mn++;
            }
        }
        $filink = '';
        $j = 1;
        $fileDonwloadurl = $CRMSERVERPATH.'filedownload.php?FileId=';
        foreach($fileInfo as $val){
            $filduro = $val['fileduration'];
            $indcost = $val['indcost'];
            $dispName = substr($val['filename'], strpos($val['filename'], '_') + 1);
            $filink ='<a data-download="' . $val['filename'] . '" style="color:blue;" href="' . $fileDonwloadurl . $val['fileid'] . '">Download</a><br/>';
            $filecontentrow .='<tr>
                                <td colspan="3" align="left" style="border-right: 1px solid #e7e7e7;font-size: 13px;border-bottom: 1px solid #e7e7e7;">'.$dispName.'</td>
                                <td colspan="3" align="left" style="border-bottom: 1px solid #e7e7e7;font-size: 13px;">'.$filink.' </td></tr>';
        }
        $filerowhtml='';
        if(!empty($fileInfo)) {
            $filerowhtml = '<tr>
                </tr>
                <tr>
                    <td colspan="6" align="center" style="border-bottom: 1px solid #e7e7e7;font-weight: 600;"> File Details</td>
                </tr>
                <tr>
                    <td colspan="3" align="left" style="border-right: 1px solid #e7e7e7;border-bottom: 1px solid #e7e7e7;font-weight: 600;"> File Name</td>
                    <td colspan="3" align="left" style="border-bottom: 1px solid #e7e7e7;font-weight: 600;"> Link</td>
                </tr>
                                       
            ' . $filecontentrow;
        }

    if ($sno) {
        mysql_query("UPDATE enquiry_transcription_payment SET flag ='1'  WHERE entryid='" . $_POST['recordkey'] . "'");
    }

    $service_name = $QUOTESERVICE . ' Services - Quote'; //'Translation Services - Quote';
    if ($crmpage == "upload") {
        $service_name = str_replace("Quote", "Upload", $service_name);
    }

    $logo = rtrim($site_url, '/') . '/img/DS-logo.png';
    $payicon = $CRMSERVERPATH . 'img/pay.png';
    $emailheaderimg = rtrim($site_url, '/') . '/img/Email.png';


    $mailingaddrhtml = '';
    $hardcopytathtml = '';
    if ($mailfilecrmpay == 'Yes') {
        $hardcopytathtml = 'The mentioned TAT applies for the delivery of electronic copies via email. TAT may vary for mailing hard copies depending upon the shipping address.';
        $mailingaddrhtml = '                    
                <tr><td colspan="6" align="center" style="padding-left: 22px;">
                    <span style="color: #302e2e;font-size: 12px;max-height: 120px;overflow-x: scroll;"><strong>Physical address: </strong><br>' . $mailingaddr . '</span>                
                </td>                    
                </tr>
                ';
    }
    $filecommentshtml ='';
    if(!empty($fileInfo) && $filecomments != '') {
        $filecommentshtml = ' <tr>
            <td colspan="6" align="left" style="font-size: 13px;border-bottom: 1px solid #e7e7e7;"><strong>Comments : </strong>'.$filecomments.'</td>
        </tr>';
    }

    $url_param = "$neworderId|^|$ordertotal|^|typing|^|$site_name";
    //TRC02052017|^|60|^|transcription|^|rajkumar@vananservices.com
    $encrypted_param = encrypt_decrypt('encrypt', $url_param);
    $paymentlink = $CRMSERVERPATH . 'paypal/payment_v2.0.php?van=' . $encrypted_param;

    $param = $neworderId . '|<>|' . $sno;
    $param = encrypt_decrypt('encrypt', $param);


        $fileuploadurl='';
    if(empty($fileInfo)) {
        $fileuploadlink = "http://" . $site_url . "/additional-information.php?id=" . $param;
        $fileuploadurl ='<tr>
        <td align="center" colspan="6">
            <p style="color:#333;font-size: 14px;font-weight: bold;">
                <a style="text-decoration:none;font-size:14px;background-color: #007ec8; box-shadow: 0 2px 4px 0 rgba(0,0,0,.23), inset 1px 1px 0 0 hsla(0,0%,100%,.2);    display: inline-block;color: #fff;padding: 12px 25px;font-size: 16px;font-weight: 400;" href="'.$fileuploadlink.'"  target="_blank">Upload Files</a>
            </p>
        </td>
    </tr>
    <tr>
        <td align="center" colspan="6">
            <span style="color:#333;font-size: 13px;">(Ignore if you have shared your files already)</span>
        </td>
    </tr>';

    }
    $paynowhtml = '<tr style="margin: 0 auto;    display: table;">
                <td>
                    <a href="' . $paymentlink . '" style="text-decoration: none;"><div class="pay-btn" style="background-color:#00c853;padding:13px 36px;color:#fff!important;margin:10px 0px;">Pay Now</div></a>
                </td>
            </tr>               
           
             <tr>
                <td align="center" colspan="6">
                    <span style="color:#333;font-size: 13px;">(Ignore if you have made the payment already)</span>
                </td>
            </tr>
             <tr style="margin: 0 auto;display: table;">
                <td><img src="' . $payicon . '" alt="payment"></td>
            </tr>';
 $mailreplace = array('__SITELOGOIMG__' => $logo,
                            '__SRCLABEL__' => $srctype,
                            '__COSTLBL__' => $costlabel,
                            '__FILELENGTH__' => $nosrc,
                            '__CATHEADER__' => $catheader,
                            '__CATVAL__' => $catvalue,
                            '__NAME__' => $name,
                            '__EMAIL__' => $email,
                            '__PHONE__' => $phone,
                            '__HEADERIMG__' => $logo,
                            '__TRANSACFEE__' => $transactionfee,
                            '__ORDERTOTAL__' => $ordertotal,
                            '__FILEROW__' => html_entity_decode($filerowhtml),
                            '__ORDERID__' => $neworderIdhtml,
                            '__COSTPERPAGE__' => $trgtunitcost,
                            '__TLCOST__' => $trgttotamt,
                            '__TRCHTM__' => $trcHtml,
                            '__TRLHTM__' => $needtrlsHtml,
                            '__NATIVECOST__' => $nativeavail,
                            '__SUBTOTALCOST__' => $subamttot,
                            '__INPUTFILEFORMAT__' => $qtformat,
                            '__TRANSCRIPTION__' => $qtlang,
                            '__SOURCE__' => $source,
                            '__NOTE__' => $qnote,
                            '__GMAILCONTENT__' => $qmail,
                            '__GMAILCONTENTDISP__' => empty($qmail)?"none":"",
                            '__TATIME__' => $aprxtat,
                            '__PURPOSE__' => $qpurpose,
                            '__COMMENT__' => nl2br(stripslashes($comment)),
                            '__SERVICENAME__' => $service_name,
                            '__SITEURL__' => $site_url,
                            '__SERVICETYPE__' => $qservice,
                            '__HFSERVICE__' => $paytc_hfc,
                            '__NOOFPAGES__' => $pagecount,
                            '__FORMAT__' => $formatting,
                            '__SUBJECT__' => $subjectcrm,
                            '__CAPTIONING__' => $captioningcrm,
                            '__NEEDTRANSCRIPTION__' => $needtranscriptioncrm,
                            '__VIDEOLENGTH__' => $videolengthcrm,
                            '__NEEDTRANSLATION__' => $needtranslationcrm,
                            '__SOURCEVOICEOVER__' => $sourcevoiceover,
                            '__SOURCEVOICEOVERDISP__' => (empty($needtranslationcrm) || $needtranslationcrm == 'No')?"none":"" ,
                            '__SCRIPTCRM__' => $scriptcrm,
                            '__COMMENTVOICEOVER__' => $commentvoiceover,
                            '__PURPOSEVOICEOVER__' => $purposevoiceover,
                            '__VOICECOUNTCRM__' => $voicecountcrm,
                            '__GENDERAGECRM__' => $genderage,
                            '__GENDERAGECRMDISP__' => empty($voicecountcrm)?"none":"",
                            '__SCRIPTVOICEOVER__' => $scriptcrm,
                            '__SCRIPTVOICEOVERDISP__' => (empty($scriptcrm) || $scriptcrm == 'No')?"none":"",
                            '__SITENAME__' => $site_name,
                            '__DISCOUNTED__' =>$discounthtml,
                            '__TCOST__' =>$timecodehtml,
                            '__VERBCOST__' =>$verbahtml,
                            /*'__MINIMUM__' =>$minimumhtml,*/
                            '__HARDCOPYREQ__' =>$hardcopyhtml,
                            '__NOTARY__' =>$notaryhtml,
                            '__MAILED__' => $mfilehtml,
                            '__MAILADDR__' => $mailingaddrhtml,
                            '__MINORDER__' =>$minordercost,
                            '__TCODEDESC__' => $timecodedesc,
                            '__PAYNOW__' => $paynowhtml,
                            '__OFFVAL__' => $offervalhtml,
                            '__FINALSUB__' => $finalroundhtml,
                            '__FILEDETAILS__' => $filerowhtml,
                            '__UPLOADHERE__' => $fileuploadurl,
                            '__FILECOMMENT__' => $filecommentshtml,
                            '__SITESUB__' => $subjecthtml,
                            '__FOOTER__' => $footerhtml,
                            '__FILESIZEINFO__' => html_entity_decode($filesizeinfo)

                            );
//    $mailreplace = array('__SITELOGOIMG__' => $logo,
//        '__EMAIL__' => $email,
//        '__HEADERIMG__' => $logo,
//        '__TRANSACFEE__' => $transactionfee,
//        '__ORDERTOTAL__' => $ordertotal,
//        '__COSTPERPAGE__' => $trgtunitcost,
//        '__TLCOST__' => $trgttotamt,
//        '__SUBTOTALCOST__' => $subamttot,
//        '__TRANSCRIPTION__' => $qtlang,
//        '__ORDERID__' => $neworderIdhtml,
//        '__SOURCE__' => $source,
//        '__TARGET__' => $target,
//        '__TATIME__' => $aprxtat,
//        '__PURPOSE__' => $qpurpose,
//        '__SERVICENAME__' => $service_name,
//        '__SITEURL__' => $site_url,
//        '__SITECHANNEL__' => $sitechannel,
//        '__SERVICETYPE__' => $qservice,
//        '__NOOFPAGES__' => $pagecount,
//        '__FORMAT__' => $format,
//        '__SITENAME__' => $site_name,
//        '__NOTARY__' => $notaryhtml,
//        '__MAILED__' => $mfilehtml,
//        '__MAILEDTAT__' => $hardcopytathtml,
//        '__MAILADDR__' => $mailingaddrhtml,
//        '__PAYNOW__' => $paynowhtml,
//        '__UPLOADHERE__' => $fileuploadurl,
//        '__FILESIZEINFO__' => html_entity_decode($filesizeinfo)
//    );



    include_once 'lib/MailChimp.php';
    $quoteInfo = array('quoteservice' => 'Typing', 'mailarray' => $mailreplace);

    $service_name = $quoteInfo['quoteservice'] . ' Services - Quote';
    $subject = $quoteInfo['quoteservice'] . $QUOTEMAILERINFO[$site_name]['subject'];
    if ($QUOTESERVICEdb == "Typingpay") {
        $subject = str_replace("Quote", "Price Quote", $subject);
    }else{
        $subject = str_replace("Quote", "Email Quote", $subject);
    }
    $mailreplace = $quoteInfo["mailarray"];
    $quotemailerarray = array(
        '__SERVICESUBJECT__' => $subject,
        '__SERVICENAME__' => $service_name);

    $mailreplacenew = array_merge($mailreplace, $quotemailerarray);
    //echo $MAILERCODE[$QUOTESERVICE];die;
    $file = fopen("mailer/" . $MAILERCODE[$QUOTESERVICE], "r");
    $htmlmail_content = fread($file, filesize("mailer/" . $MAILERCODE[$QUOTESERVICE]));
    fclose($file);
    $html_content = strtr($htmlmail_content, $mailreplacenew);
        $to = $email;
    multi_attach_mail($to, $subject, $html_content, $email, $sitename);
    if (isset($_COOKIE['uploadtest'])) {
        echo "===>Success...";
    }


    $output = json_encode(array('ordsid' => $neworderId, 'type' => 'message', 'text' => 'Your request has been sent successfully and you will receive an email from us shortly. Thank you!', 'param' => $param));
    die($output);
    /*----------------------------PAYMENT QUOTE END -------------------------*/

}

} else {

    if ($_POST['uploadflag'] == "false") {
        $output = json_encode(array('type' => 'message', 'text' => 'Sorry for inconvenience, Reach us at 1-888-308-1099'));
        die($output);
    }
}
?>