<?php
header("Access-Control-Allow-Origin: *");

require_once 'CommonUtil.php';

$action = $_POST['action'];
        
if(isset( $action )) {
    
    $obj = new CommonUtil();
    
    switch($action){
        
        case "getuploadPartSize":
            $result = $obj->getUploadPartSize();
            break;
        
        default:
            $result = "Function not found";
            break;
    }
    
    echo $result;
}

