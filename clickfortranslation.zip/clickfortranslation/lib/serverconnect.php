<?php

 // $link = mysql_connect('localhost', 'vananhos_pricequ', 'pricequ@789'); // Remote server
// $link = mysql_connect('35.164.159.47', 'vananhos_pricequ', 'pricequ@789'); // Remote server

$link = mysql_connect('localhost', 'root', ''); // local server
if (!$link) {
    die('Could not connect: ' . mysql_error());
}
mysql_select_db("vananhos_pricequotecalc");



?>