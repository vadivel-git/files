<?php
header("Access-Control-Allow-Origin: *"); 
include_once "../../common_setting.php";   
?>
<style>
div{
    -webkit-user-select:none;
    -moz-user-select:none;
    user-select:none;
}
</style>
<div class = "modal-header">
    <button type = "button" class = "close" data-dismiss = "modal">&times;</button>
    <div class = "modal-title text-center">Time Stamped</div>
</div>
<div class = "modal-body as-popup-h">    
    <div class="row">
         <div class="col-md-12">
<!--            <p>[Music] [0:00:19]</p>
            <p><b>Kathy &nbsp;   :</b>    Welcome to World Wide Business I'm Kathy Ireland.  Despite the ubiquity of audio and video, today's need for the typed word is more important than ever and no one answers this growing need better than Vanan Services.  CEO Saravanan Nagaraj and Vice-President Priya Nagaraj are here to explain how their attention to detail reliability and quality has turned the transcription industry upside down.  Welcome, to you both.  </p>
            <p><b>Saravanan &nbsp;   :</b>    Thank you Kathy. It's great to have us here and we're delighted to share our experience.  </p>
            <p><b>Kathy &nbsp;   :</b>    Thank you.  Priya:  Thank you for having us here.  I'm really excited about this. [0:01:00] Kathy:  Well we are too and Saravanan, What are some of the challenges that companies face with transcription outsourcing?  </p>
            <p><b>Saravanan &nbsp;   :</b>    It's; mostly online transcription services are provided by individual transcribers.   </p>
            <p><b>Kathy &nbsp;   :</b>    Uh-hum. </p>
            <p><b>Saravanan  &nbsp;   :</b>  So, customer cannot expect 98% accuracy, on time delivery and they do not know even the audio file. </p>
            <p><b>Kathy &nbsp;   :</b>    Uh-huh. </p>
            <p><b>Saravanan &nbsp;  :</b>  :  Which is; it could be a personal information, perhaps very sensitive information, you do not know who is handling your information. </p>
            <p><b>Kathy &nbsp;   :</b>    Sure.  </p>
            <p><b>Saravanan  &nbsp;   :</b> what is their level of education.   </p>
            <p><b>Kathy &nbsp;   :</b>    Priya, how does your company address these challenges? </p>
            <p><b>Priya &nbsp;   :</b>    Vanan Services recognize these challenges to businesses and put together a team that is devoted to detail and quality on a level that ensures, I mean, that allows what other companies cannot.  A process of transcription, proof reading and finally a quality check assures that customer's final product meets and exceeds the highest expectations.  [0:02:00] David:  We chose Vanan Services, uh, because basically the nature of our business began to evolve. Um, our clients and our customers, uh, began needed, needing more, uh, services that at the time we really couldn't provide.  </p>
            <p><b>Greg &nbsp;   :</b>    In my business we're all about deadlines and so sometimes I will throw to them a 48 turn, hour turnaround, sometimes I will throw to them a 24 hour turnaround and almost every time no matter what the situation is they come through with flying colors and, and exceed our expectations.  I would absolutely, positively recommend Vanan Services.  Why?  Because they get it right every time.  </p>
            <p><b>Kathy &nbsp;   :</b>    Saravanan can you please tell us about your flagship service Vanan Services?  What is it?</p>
            <p><b>Saravanan  &nbsp;   :</b>   The transcription services what we offer comes with the great features such as 98% accuracy, free trial and 24/7 support basically.   </p>
            <p><b>Kathy &nbsp;   :</b>    Wow!  That's wonderful and Priya what kinds of organizations utilize Vanan Services [0:03:00] and what are their needs?  Priya:  We serve, for example law firms, students, faculty of universities, media and broadcasting organizations, for call centers, you know, for coaching purposes; to name a few.  From transcription services to translation, closed captioning, voice over; the variety of our services guarantees that we can serve, you know, several organizations under one custom solutions.  </p>
            <p><b>Kathy &nbsp;   :</b>    In an industry where reliability and quality play such an integral role it is clear that Vanan Services has set its bar very high.  Congratulations to both of you.  I wish you continued success.</p>
            <p><b>Saravanan &nbsp;   :</b>    Thank you very much Kathy.  </p>
            <p><b>Priya &nbsp;   :</b>    Thank you for having us here.  </p>
            <p><b>Kathy &nbsp;   :</b>    Thank you. </p>
            <p>[Music] [0:03:46] [0:04:00]</p>-->
            <img src="<?php echo $CRMSERVERPATH; ?>lib/transcription_samples/time-stamp.png"  class="img-responsive hidden-xs" />
            <img src="<?php echo $CRMSERVERPATH; ?>lib/transcription_samples/time-mobile.png"  class="img-responsive hidden-lg hidden-sm hidden-md" />
        </div>
    </div>
</div>
