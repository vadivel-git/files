<?php
//
//Created By   :  Veeravel Karthikeyan
//
//Created Date :  16-09-2016
//
//Comments     :  common functions for all modules
//Modifed by Rohini R on 19/09/2016 to add logdetails functionality
//
function getwebsitedetails($site){
    $where = "";
    if($site != ""){
        $where = "WHERE website = '$site'" ;
    }
    $websiteData = mysql_query("SELEct * FROM website $where");
    return $website = mysql_fetch_array($websiteData);
}
function logdetails($filename,$serverdetail =NULL){

    $requesturl = $_SERVER[REQUEST_URI];
    $parts = parse_url($requesturl);
    parse_str($parts['query'],$query);
    $sitename=$query['sitename'];
    $command=$query['command'];
    if(!$sitename){
        $sitename = $serverdetail['HTTP_HOST'];
    }
    $foldername = "log";
    if (!is_dir($foldername)) {
        mkdir($foldername, 0777, true);
    }
    date_default_timezone_set('America/New_York');
    $currentdate    = date('Y-m-d H:i:s');
    $date=date('d-m-Y');
    if($filename =="server"){
        $requesturl = $_SERVER[HTTP_REFERER];
        $logdata = "<$currentdate> ## <$requesturl> ## <$_SERVER[REMOTE_ADDR]> ## <$_SERVER[HTTP_USER_AGENT]> ## <$command>";
        file_put_contents('../'.$foldername.'/'.$filename.'_'.$date.'.txt', $logdata . PHP_EOL, FILE_APPEND);
    }elseif($filename =="filedownload"){
        $logdata = "<$currentdate> ## <$requesturl> ## <$_SERVER[REMOTE_ADDR]> ## <$_SERVER[HTTP_USER_AGENT]>";
        file_put_contents($foldername.'/'.$filename.'_'.$date.'.txt', $logdata . PHP_EOL, FILE_APPEND);
    }else{
        $logdata = "<$currentdate> ## <$serverdetail[REQUEST_URI]> ## <$serverdetail[HTTP_REFERER]> ## <$serverdetail[REMOTE_ADDR]>  ## <$serverdetail[HTTP_HOST]> ## <$serverdetail[HTTP_USER_AGENT]> ## <$filename>";
        file_put_contents($foldername.'/'.$filename.'_'.$date.'.txt', $logdata . PHP_EOL, FILE_APPEND);
    }
}

function sendMail($to = 'veeravel.vanan@gmail.com', $subject = 'Test Msg', $message = 'Test Sample Msg', $replyto = '', $ccmail = '', $attachment, $parameters = '') {

    require_once 'PHPMailer/PHPMailerAutoload.php';
    $mail = new PHPMailer;
    $mail->isSMTP(true);
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'supports@vananservices.com';
    $mail->Password = 'EUitgh%^^&35$';
    $mail->SMTPSecure = 'TLS';
    $mail->Port = 587;
    $mail->From = 'support@vananservices.com';
    $mail->FromName = 'Vanan Online Services';
    $mail->Sender="support@vananservices.com";

    //For Adding cc mail
    $ccmail_addr = explode(',', $ccmail);
    foreach ($ccmail_addr as $ccaddr) {
        $mail->AddCC($ccaddr,$ccaddr);
    }

    // For Multiple Receipient
    $to_addr = explode(',', $to);
    foreach ($to_addr as $addr) {
        $mail->addAddress($addr);
    }

    $mail->addReplyTo($replyto, $replyto);
    $mail->WordWrap = 50;
    $mail->isHTML(true);

    // For attchment
    foreach ($attachment as $attach) {
        $mail->AddAttachment($attach, basename($attach));
    }

    $mail->Subject = $subject;
    $mail->Body = $message;

    if (!$mail->send()) {
        echo 'Message could not be sent.';
        echo 'Mailer Error: ' . $mail->ErrorInfo;
        return 0;
    }
    return 1;
}

function multi_attach_mail($to, $subject, $message, $email, $sitename ,$response=null) {
    //$to = 'salescs@vananservices.com,vananbackup@gmail.com';
    $headers = "From: support@vananservices.com" . "\r\n";
    $headers .= "Reply-to: $email" . "\r\n";
    $headers .= "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type: text/html; charset=iso-8859-1" . "\r\n";
    //$to ='rajkumar@vananservices.com,veeravel@vananservices.com';
    //@mail($to, $subject, wordwrap($message), $headers);
    sendMail($to, $subject, wordwrap($message), $email,"","","");
}
function encrypt_decrypt($action, $string) {
    $output = false;
    $encrypt_method = "AES-256-CBC";
    $secret_key = 'vANaN';
    $secret_iv = 'VanAn';

    // hash
    $key = hash('sha256', $secret_key);

    // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
    $iv = substr(hash('sha256', $secret_iv), 0, 16);

    if( $action == 'encrypt' ) {
        $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
        $output = base64_encode($output);
    }
    else if( $action == 'decrypt' ){
        $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    }

    return $output;
}
function encrypt_decryptCRM($action, $string) {
    $output = false;
    $encrypt_method = "AES-256-CBC";
    $secret_key = 'vanancrm*encrypt';
    $secret_iv = 'VanAn';

    // hash
    $key = hash('sha256', $secret_key);

    // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
    $iv = substr(hash('sha256', $secret_iv), 0, 16);

    if( $action == 'encrypt' ) {
        $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
        $output = base64_encode($output);
    }
    else if( $action == 'decrypt' ){
        $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    }

    return $output;
}
function safe_b64encode($string) {
    $data = base64_encode($string);
    $data = str_replace(array('+','/','='),array('-','_',''),$data);
    return $data;
}
function encrypt($value,$skey){
    if(!$value || $value ==''){return false;}
    $text       = $value;
    $iv_size    = mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB);
    $iv         = mcrypt_create_iv($iv_size, MCRYPT_RAND);
    $crypttext  = mcrypt_encrypt(MCRYPT_RIJNDAEL_256, $skey, $text, MCRYPT_MODE_ECB, $iv);
    return trim(safe_b64encode($crypttext));
}

function arraytoString($sourcestr,$strarray){
    $sourcearray = explode(',', $sourcestr);
    $sourcehtml = '';
    foreach ($sourcearray as $sourcename) {
        $sourcehtml .= $strarray[$sourcename] . ',';
    }
    return $sourcehtml = rtrim($sourcehtml, ',');
}

?>
