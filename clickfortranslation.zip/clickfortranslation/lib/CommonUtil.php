<?php

Class CommonUtil{
    
    public static function getUploadPartSize(){
        
        $json       = file_get_contents("http://ip-api.com/json/".$_SERVER['REMOTE_ADDR']);
        $details    = json_decode($json, true);
        $country_code = isset($details['countryCode']) ? $details['countryCode'] : 'IN' ;
        switch($country_code){
            case "IN":
                $partSizeSpeed = 5 * 1024 * 1024;
                break;
            case "US":
                $partSizeSpeed = 50 * 1024 * 1024;
                break;
            case "GB":
            case "AU":
            case "UK":
                $partSizeSpeed = 20 * 1024 * 1024;
                break;
            default :
                $partSizeSpeed = 5 * 1024 * 1024;
                break;
        }
        
        return $partSizeSpeed;
    }
    
}