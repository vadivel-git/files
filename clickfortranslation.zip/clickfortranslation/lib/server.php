<?php
/* **************************************************************************************************
* File        : server.php
* Author      : Ravichandran P  
* Date        : 10-06-2016
****************************************************************************************************
* Version   Date            Author                            Remarks
****************************************************************************************************
* 1.0      10-06-2016    Ravichandran P                             Initial Version
*1.1       19-09-2016    Rohini R                           To implement log functionality
* **************************************************************************************************
* Description : Ajax actions for file upload
* ************************************************************************************************** */
header("Access-Control-Allow-Origin: *");

//ini_set('display_errors', 1);
//error_reporting('E_ALL');


function sendJson($arr)
{
	header('Content-Type: application/json');
    die(json_encode($arr));
}

$command = isset($_GET['command']) ? strtolower($_GET['command']) : '';

$DOCUMENTROOTPATH = $_SERVER['DOCUMENT_ROOT']."/crmform/";

require_once $DOCUMENTROOTPATH.'vendor/autoload.php';
require_once $DOCUMENTROOTPATH.'lib/config.php';
require_once $DOCUMENTROOTPATH."lib/common_array.php";
require_once $DOCUMENTROOTPATH."lib/functions.php";
   
use Aws\Common\Enum\DateFormat;
use Aws\S3\Model\MultipartUpload\UploadId;
use Aws\S3\S3Client;


//Modifed by Rohini R on 10/06/2016 to configure region
$client = S3Client::factory(array(
		'region' => AWS_REGION,
		'key' => AWS_KEY,
        'secret' => AWS_SECRET
    ));
	
// echo "<pre>";
  // print_r($client); die('here');

$filename= "server";
logdetails($filename);

function isAllowed()
{
//wow, what a validator :P
//WARNING: this is just a demonstration, convert it to your own need
    return ($_REQUEST['otherInfo']['user'] == 'user' && $_REQUEST['otherInfo']['pass'] == 'pass');
}



function checkValidSite(){
    global $QUOTEMAILERINFO;
        $site_url   = $_SERVER['HTTP_ORIGIN'];
        if($site_url==''){
            $requesturl = $_SERVER[REQUEST_URI];
            $parts = parse_url($requesturl);
            parse_str($parts['query'],$query);
            $site_url=$query['sitename'];
        }
        $input = trim($site_url, '/');

        // If scheme not included, prepend it
        if (!preg_match('#^http(s)?://#', $input)) {
            $input = 'http://' . $input;
        }
        $urlParts = parse_url($input);
        // remove www
        $site_name = preg_replace('/^www\./', '', $urlParts['host']);   

    if(!($QUOTEMAILERINFO[$site_name]) && $site_name !='localhost'){
            date_default_timezone_set('America/New_York');
            $createddate    = date('Y-m-d H:i:s');
            // $json       = file_get_contents("http://ip-api.com/json/".$_SERVER['REMOTE_ADDR']);
            // $details    = json_decode($json, true);
            // $country_code = isset($details['countryCode']) ? $details['countryCode'] : 'IN' ;
            //<p>Country  : '.$country_code.' </p>
            $message = '<html>
            <head>
              <title>Details</title>
            </head>
            <body>
            <br><br />
               <p>Date & time : '.$createddate.' </p>
               <p>Site URL : '.$site_url.' </p>
               <p>IP Address : '.$_SERVER[REMOTE_ADDR].' </p>
               <p>Browser Details : '.$_SERVER[HTTP_USER_AGENT].' </p>
              <br>
            <br><br />
            </body>
            </html>';
            $headers  = 'MIME-Version: 1.0' . "\r\n";
            $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
            $headers .= 'From: confirmation@vananservices.com'. "\r\n";

            $to="rohini.r@vananservices.com";
            $subject ="File upload from other website";
            mail($to,$subject,$message,$headers); 
        }
} 
function getbucketname($filename){
    global $BUCKETLIST;
    preg_match_all('/^[0-9]+\/[a-zA-Z0-9]+([a-z]{2})/',$filename,$matches);
    $bucketcode = $matches[1][0];
    $arr        = array_combine(array_column($BUCKETLIST, 'bucket_code'), array_column($BUCKETLIST, 'bucket_name'));
    $bucketname = $arr[$bucketcode];
    $bucket     = isset($bucketname) ? $bucketname :BUCKET_NAME;
    return $bucket;
}           
switch ($command) {
    case 'createmultipartupload': {
            
            checkValidSite();
         
            if (!isAllowed()) {
                header(' ', true, 403);
                die('You are not authorized');
            }
             
            /* @var $multipartUploadModel UploadId */
            $model = $client->createMultipartUpload(array(
                'Bucket' => getbucketname($_REQUEST['fileInfo']['name']),
                'Key' => $_REQUEST['fileInfo']['name'],
                'ContentType' => $_REQUEST['fileInfo']['type'],
                'Metadata' => $_REQUEST['fileInfo']
            ));

            sendJson(array(
                'uploadId' => $model->get('UploadId'),
                'key' => $model->get('Key'),
            ));
            break;
        }
    case 'signuploadpart': {
            $command = $client->getCommand('UploadPart',
                array(
                'Bucket' => getbucketname($_REQUEST['sendBackData']['key']),
                'Key' => $_REQUEST['sendBackData']['key'],
                'UploadId' => $_REQUEST['sendBackData']['uploadId'],
                'PartNumber' => $_REQUEST['partNumber'],
                'ContentLength' => $_REQUEST['contentLength']
            ));
            $request = $command->prepare();
            // This dispatch commands wasted a lot of my times :'(
            $client->dispatch('command.before_send', array('command' => $command));
            $request->removeHeader('User-Agent');
            $request->setHeader('x-amz-date', gmdate(DateFormat::RFC2822));
            // This dispatch commands wasted a lot of my times :'(
            $client->dispatch('request.before_send', array('request' => $request));

            sendJson(array(
                'url' => $request->getUrl(),
                'authHeader' => (string) $request->getHeader('Authorization'),
                'dateHeader' => (string) $request->getHeader('x-amz-date'),
            ));
            break;
        }
    case 'completemultipartupload': {
            $partsModel = $client->listParts(array(
                'Bucket' => getbucketname($_REQUEST['sendBackData']['key']),
                'Key' => $_REQUEST['sendBackData']['key'],
                'UploadId' => $_REQUEST['sendBackData']['uploadId'],
            ));

            $model = $client->completeMultipartUpload(array(
                'Bucket' => getbucketname($_REQUEST['sendBackData']['key']),
                'Key' => $_REQUEST['sendBackData']['key'],
                'UploadId' => $_REQUEST['sendBackData']['uploadId'],
                'Parts' => $partsModel['Parts'],
            ));

            sendJson(array(
                'success' => true
            ));
          
            
            break;
        }
    case 'abortmultipartupload': {
            $model = $client->abortMultipartUpload(array(
                'Bucket' => getbucketname($_REQUEST['sendBackData']['key']),
                'Key' => $_REQUEST['sendBackData']['key'],
                'UploadId' => $_REQUEST['sendBackData']['uploadId']
            ));

            sendJson(array(
                'success' => true
            ));
            break;
        }
	//Added by Rohini R on 09/06/2016 to display Files in bucket 
	case 'displaybuckets': {
			$result = $client->listBuckets();
			
			foreach ($result['Buckets'] as $bucket) {
				// Each Bucket value will contain a Name and CreationDate
				echo "&nbsp;&nbsp;{$bucket['Name']} - {$bucket['CreationDate']}\n"."</br>";
				$bucketname= $bucket['Name'];
				
				$BucketLocation = $client->getBucketLocation(array(
					// Bucket is required
					'Bucket' => $bucketname
				));
				echo '&nbsp;&nbsp;<b style="color:red">'.$BLocation = $BucketLocation['Location'].'</b>'."</br>";
						
				$iterator = $client->getIterator('ListObjects', array(
					'Bucket' => $bucketname
				));
				
				if($BucketLocation['Location'] =='ap-southeast-1'){
					foreach ($iterator as $object) {
						echo '<a onclick="downloadfile(\''.$object['Key'].'\')">'.$object['Key'].'</a>' .'<a onclick="deletefile(\''.$object['Key'].'\')">&nbsp;&nbsp;&nbsp;Delete</a>'. '<br>';
						
					}
				}
			}
		   
            break;
        }
	//Added by Rohini R on 09/06/2016 to download Files from bucket 
	case 'downloadfile': {
			$key =  $_REQUEST['Filename'];
			$bucket = getbucketname($_REQUEST['Filename']);

           // To download customer's file name without prefix we added
            $command = $client->getCommand('GetObject', array(
                'Bucket' => $bucket,
                'Key' => $key,
                'ResponseContentDisposition' => 'attachment; filename="'.substr($key, strpos($key, '_')+1).'"'
            ));


            echo $signedUrl = $command->createPresignedUrl('+10 minutes');

	        break;
    }

    case 'playfile': {
            $key =  $_REQUEST['Filename'];
            $bucket = getbucketname($_REQUEST['Filename']);
            $url = "{$bucket}/{$key}";
            // get() returns a Guzzle\Http\Message\Request object
            $request = $client->get($url);
            // Create a signed URL from a completely custom HTTP request that
            // will last for 10 minutes from the current time
            echo $signedUrl = $client->createPresignedUrl($request, '+10 minutes');

            break;
    }
	//Added by Rohini R on 10/06/2016 to delete Files from bucket 
	case 'deletefile': {
			$key =  $_REQUEST['Filename'];
			$bucket = getbucketname($_REQUEST['Filename']);
			$result = $client->deleteObject(array(
			'Bucket' => $bucket,
			'Key'    => $key
			)); 
            break;
			
    }
	//Added by Rohini R on 13/06/2016 to create folder in bucket
	case 'createfolder': {
			//$key =  $_REQUEST['Filename'];
			$bucket = BUCKET_NAME;
			$client->putObject(array( 
			   'Bucket'       => BUCKET_NAME, // Defines name of Bucket
			   'Key'          => "Rohini/", //Defines Folder name
			   'Body'       => "",
			   'ACL'          => 'public-read' // Defines Permission to that folder
			)); 
            break;
    }
	//Added by Rohini R on 13/06/2016 to create bucket
	case 'createbucket': {
			$bucket=  'my.vanan.bucket2';
			$result = $client->createBucket(array(
				'Bucket'             =>$bucket,
				'LocationConstraint' => 'ap-southeast-1'
			));
			break;
    }	
	//Added by Rohini R on 13/06/2016 to delete bucket
	case 'deletebucket': {
			$bucket=  'my.vanan.bucket2';
			//echo $result['Location'] . "\n";
			$client->deleteBucket(array('Bucket' => $bucket));
			break;
    }	
		
    default: {
            header(' ', true, 404);
            die('Command not understood');
            break;
        }
}
?>
