<?php


// aws s3 config

define('AWS_REGION', 'us-east-1');
define('AWS_KEY', 'AKIAILYQBDZCIQUDSJFQ');
define('AWS_SECRET', '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');
define('BUCKET_NAME', 'securedatalive');








