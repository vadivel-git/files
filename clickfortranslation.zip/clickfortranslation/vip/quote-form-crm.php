<div class="col-xs-12 col-md-8">
              <h3 class="DS-text-bold DS-center DS-center1"></h3>
              <div class="DS-clrar-10"></div>
			  
			  
              <?php  if($FILEUPLOADMSG === 1 ){ ?>
              <!--h2 class="chat-link chat-header"> Order now and get 10% offer on all your orders. </h2-->
              
              <h2 class="chat-link">We are a company that never sleeps, we are available <a id="full-view-button" href="javascript:void(null)" onclick="parent.LC_API.open_chat_window()"><span id="open-icon"></span><span id="open-label">24/7 online chat </span></a>  connect with us through online chat or fill up the details in our online form and upload your files safe and secure.</h2>
              <?php  } else { ?>
              <!--h2 class="chat-link chat-header"> Ask for a quote — Get 10% offer on all your orders. </h2-->
              <h2 class="chat-link">To accommodate your immediate order, contact us through our <a id="full-view-button" href="javascript:void(null)" onclick="parent.LC_API.open_chat_window()"><span id="open-icon"></span><span id="open-label">24/7 online chat </span></a>  service or <br>just fill out the required information below.</h2>
              <?php } ?>
         
		 
		 
		 
		 
		 <!--h2  class="chat-link">To accommodate your immediate order, contact us though our <a id="full-view-button" href="javascript:void(null)" onclick="parent.LC_API.open_chat_window()"><span id="open-icon"></span><span id="open-label">24/7 online chat</span></a> services.</p></h2-->
                <!-- form-start -->
                <div class="DS-clrar-20"></div>
                <!-- <form role="form" novalidate="novalidate"> -->
                  <!-- row-block1 -->
                  <div class="row DS-row-reduse">
                    <!-- block1 -->
                    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js?<?php echo $RANDOMNO ?>"></script>
                    <script type="text/javascript" src="js/jquery.MultiFile.js?<?php echo $RANDOMNO ?>"></script>
                  <div class="form-group DS-contact-left">
                    <label class="control-label">Full Name<span class="DS-star">*</span></label>
                    <div class="controls">
                        <div class="input-group">
                      <span class="input-group-addon"><i class="fa fa-user"></i></span>
                        <input class="form-control" name="name" id="qname" placeholder="Your Full Name" type="text" data-placement="bottom">
                        <!-- tooltip -->
                        <div class="tooltip-con">
                        <div class="tooltip" id="toolname"></div></div>
                        <!-- tooltip -->
                      </div>
                    </div>
                  </div>
                  <!-- block2 -->
                  <div class="form-group DS-contact-right">
                    <label class="control-label">Email ID<span class="DS-star">*</span></label>
                    <div class="controls">
                        <div class="input-group">
                      <span class="input-group-addon"><i class="fa fa-envelope-o"></i></span>
                        <input class="form-control" name="Email" id="qemail" placeholder="Your Email ID" type="text" data-placement="bottom">
                        <!-- tooltip -->
                        <div class="tooltip-con">
                        <div class="tooltip" id="toolemail"></div></div>
                        <!-- tooltip -->
                      </div>
                    </div>
                  </div>
                </div>
                <!-- row-block2 -->
                <div class="DS-clrar-20"></div>
                  <div class="row DS-row-reduse">
                    <!-- block1 -->
                  <div class="form-group DS-contact-left">
                    <label class="control-label">Country<span class="DS-star"></span></label>
                    <div class="controls">
                        <div class="input-group">
                      <span class="input-group-addon"><i class="fa fa-flag-o"></i></span>
                        <select name="country" id="qcountrys" class="form-control" data-placement="bottom">
                              <option value="">Select Country</option>
                              <option value="United States">United States</option>
                              <option value="Afghanistan">Afghanistan</option>
                              <option value="Albania">Albania</option>
                              <option value="Algeria">Algeria</option>
                              <option value="American Samoa">American Samoa</option>
                              <option value="Andorra">Andorra</option>
                              <option value="Angola">Angola</option>
                              <option value="Anguilla">Anguilla</option>
                              <option value="Antarctica">Antarctica</option>
                              <option value="Antigua and Barbuda">Antigua and Barbuda</option>
                              <option value="Argentina">Argentina</option>
                              <option value="Armenia">Armenia</option>
                              <option value="Aruba">Aruba</option>
                              <option value="Australia">Australia</option>
                              <option value="Austria">Austria</option>
                              <option value="Azerbaijan">Azerbaijan</option>
                              <option value="Bahamas">Bahamas</option>
                              <option value="Bahrain">Bahrain</option>
                              <option value="Bangladesh">Bangladesh</option>
                              <option value="Barbados">Barbados</option>
                              <option value="Belarus">Belarus</option>
                              <option value="Belgium">Belgium</option>
                              <option value="Belize">Belize</option>
                              <option value="Benin">Benin</option>
                              <option value="Bermuda">Bermuda</option>
                              <option value="Bhutan">Bhutan</option>
                              <option value="Bolivia">Bolivia</option>
                              <option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option>
                              <option value="Botswana">Botswana</option>
                              <option value="Brazil">Brazil</option>
                              <option value="British Indian Ocean Territory">British Indian Ocean Territory</option>
                              <option value="British Virgin Islands">British Virgin Islands</option>
                              <option value="Brunei">Brunei</option>
                              <option value="Bulgaria">Bulgaria</option>
                              <option value="Burkina Faso">Burkina Faso</option>
                              <option value="Burma (Myanmar)">Burma (Myanmar)</option>
                              <option value="Burundi">Burundi</option>
                              <option value="Cambodia">Cambodia</option>
                              <option value="Cameroon">Cameroon</option>
                              <option value="Canada">Canada</option>
                              <option value="Cape Verde">Cape Verde</option>
                              <option value="Cayman Islands">Cayman IslanSD</option>
                              <option value="Central African Republic">Central African Republic</option>
                              <option value="Chad">Chad</option>
                              <option value="Chile">Chile</option>
                              <option value="China">China</option>
                              <option value="Christmas Island">Christmas Island</option>
                              <option value="Cocos (Keeling) Islands">Cocos (Keeling) Islands</option>
                              <option value="Colombia">Colombia</option>
                              <option value="Comoros">Comoros</option>
                              <option value="Cook Islands">Cook Islands</option>
                              <option value="Costa Rica">Costa Rica</option>
                              <option value="Croatia">Croatia</option>
                              <option value="Cuba">Cuba</option>
                              <option value="Cyprus">Cyprus</option>
                              <option value="Czech Republic">Czech Republic</option>
                              <option value="Democratic Republic of the Congo">Democratic Republic of the Congo</option>
                              <option value="Denmark">Denmark</option>
                              <option value="Djibouti">Djibouti</option>
                              <option value="Dominica">Dominica</option>
                              <option value="Dominican Republic">Dominican Republic</option>
                              <option value="Ecuador">Ecuador</option>
                              <option value="Egypt">Egypt</option>
                              <option value="El Salvador">El Salvador</option>
                              <option value="Equatorial Guinea">Equatorial Guinea</option>
                              <option value="Eritrea">Eritrea</option>
                              <option value="Estonia">Estonia</option>
                              <option value="Ethiopia">Ethiopia</option>
                              <option value="Falkland Islands">Falkland Islands</option>
                              <option value="Faroe IslanSD">Faroe Islands</option>
                              <option value="Fiji">Fiji</option>
                              <option value="Finland">Finland</option>
                              <option value="France">France</option>
                              <option value="French Polynesia">French Polynesia</option>
                              <option value="Gabon">Gabon</option>
                              <option value="Gambia">Gambia</option>
                              <option value="Gaza Strip">Gaza Strip</option>
                              <option value="Georgia">Georgia</option>
                              <option value="Germany">Germany</option>
                              <option value="Ghana">Ghana</option>
                              <option value="Gibraltar">Gibraltar</option>
                              <option value="Greece">Greece</option>
                              <option value="Greenland">Greenland</option>
                              <option value="Grenada">Grenada</option>
                              <option value="Guam">Guam</option>
                              <option value="Guatemala">Guatemala</option>
                              <option value="Guinea">Guinea</option>
                              <option value="Guinea-Bissau">Guinea-Bissau</option>
                              <option value="Guyana">Guyana</option>
                              <option value="Haiti">Haiti</option>
                              <option value="Holy See (Vatican City)">Holy See (Vatican City)</option>
                              <option value="Honduras">Honduras</option>
                              <option value="Hong Kong">Hong Kong</option>
                              <option value="Hungary">Hungary</option>
                              <option value="Iceland">Iceland</option>
                              <option value="India">India</option>
                              <option value="Indonesia">Indonesia</option>
                              <option value="Iran">Iran</option>
                              <option value="Iraq">Iraq</option>
                              <option value="Ireland">Ireland</option>
                              <option value="Isle of Man">Isle of Man</option>
                              <option value="Israel">Israel</option>
                              <option value="Italy">Italy</option>
                              <option value="Ivory Coast">Ivory Coast</option>
                              <option value="Jamaica">Jamaica</option>
                              <option value="Japan">Japan</option>
                              <option value="Jersey">Jersey</option>
                              <option value="Jordan">Jordan</option>
                              <option value="Kazakhstan">Kazakhstan</option>
                              <option value="Kenya">Kenya</option>
                              <option value="Kiribati">Kiribati</option>
                              <option value="Kosovo">Kosovo</option>
                              <option value="Kuwait">Kuwait</option>
                              <option value="Kyrgyzstan">Kyrgyzstan</option>
                              <option value="Laos">Laos</option>
                              <option value="Latvia">Latvia</option>
                              <option value="Lebanon">Lebanon</option>
                              <option value="Lesotho">Lesotho</option>
                              <option value="Liberia">Liberia</option>
                              <option value="Libya">Libya</option>
                              <option value="Liechtenstein">Liechtenstein</option>
                              <option value="Lithuania">Lithuania</option>
                              <option value="Luxembourg">Luxembourg</option>
                              <option value="Macau">Macau</option>
                              <option value="Macedonia">Macedonia</option>
                              <option value="Madagascar">Madagascar</option>
                              <option value="Malawi">Malawi</option>
                              <option value="Malaysia">Malaysia</option>
                              <option value="Maldives">Maldives</option>
                              <option value="Mali">Mali</option>
                              <option value="Malta">Malta</option>
                              <option value="Marshall Islands">Marshall Islands</option>
                              <option value="Mauritania">Mauritania</option>
                              <option value="Mauritius">Mauritius</option>
                              <option value="Mayotte">Mayotte</option>
                              <option value="Mexico">Mexico</option>
                              <option value="Micronesia">Micronesia</option>
                              <option value="Moldova">Moldova</option>
                              <option value="Monaco">Monaco</option>
                              <option value="Mongolia">Mongolia</option>
                              <option value="Montenegro">Montenegro</option>
                              <option value="Montserrat">Montserrat</option>
                              <option value="Morocco">Morocco</option>
                              <option value="Mozambique">Mozambique</option>
                              <option value="Namibia">Namibia</option>
                              <option value="Nauru">Nauru</option>
                              <option value="Nepal">Nepal</option>
                              <option value="Netherlands">Netherlands</option>
                              <option value="Netherlands Antilles">Netherlands Antilles</option>
                              <option value="New Caledonia">New Caledonia</option>
                              <option value="New Zealand">New Zealand</option>
                              <option value="Nicaragua">Nicaragua</option>
                              <option value="Niger">Niger</option>
                              <option value="Nigeria">Nigeria</option>
                              <option value="Niue">Niue</option>
                              <option value="Norfolk Island">Norfolk Island</option>
                              <option value="North Korea">North Korea</option>
                              <option value="Northern Mariana Islands">Northern Mariana Islands</option>
                              <option value="Norway">Norway</option>
                              <option value="Oman">Oman</option>
                              <option value="Pakistan">Pakistan</option>
                              <option value="Palau">Palau</option>
                              <option value="Panama">Panama</option>
                              <option value="Papua New Guinea">Papua New Guinea</option>
                              <option value="Paraguay">Paraguay</option>
                              <option value="Peru">Peru</option>
                              <option value="Philippines">Philippines</option>
                              <option value="Pitcairn Islands">Pitcairn Islands</option>
                              <option value="Poland">Poland</option>
                              <option value="Portugal">Portugal</option>
                              <option value="Puerto Rico">Puerto Rico</option>
                              <option value="Qatar">Qatar</option>
                              <option value="Republic of the Congo">Republic of the Congo</option>
                              <option value="Romania">Romania</option>
                              <option value="Russia">Russia</option>
                              <option value="Rwanda">Rwanda</option>
                              <option value="Saint Barthelemy">Saint Barthelemy</option>
                              <option value="Saint Helena">Saint Helena</option>
                              <option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option>
                              <option value="Saint Lucia">Saint Lucia</option>
                              <option value="Saint Martin">Saint Martin</option>
                              <option value="Saint Pierre and Miquelon">Saint Pierre and Miquelon</option>
                              <option value="Saint Vincent and the Grenadines">Saint Vincent and the Grenadines</option>
                              <option value="Samoa">Samoa</option>
                              <option value="San Marino">San Marino</option>
                              <option value="Sao Tome and Principe">Sao Tome and Principe</option>
                              <option value="Saudi Arabia">Saudi Arabia</option>
                              <option value="Senegal">Senegal</option>
                              <option value="Serbia">Serbia</option>
                              <option value="Seychelles">Seychelles</option>
                              <option value="Sierra Leone">Sierra Leone</option>
                              <option value="Singapore">Singapore</option>
                              <option value="Slovakia">Slovakia</option>
                              <option value="Slovenia">Slovenia</option>
                              <option value="Solomon IslanSD">Solomon IslanSD</option>
                              <option value="Somalia">Somalia</option>
                              <option value="South Africa">South Africa</option>
                              <option value="South Korea">South Korea</option>
                              <option value="Spain">Spain</option>
                              <option value="Sri Lanka">Sri Lanka</option>
                              <option value="Sudan">Sudan</option>
                              <option value="Suriname">Suriname</option>
                              <option value="Svalbard">Svalbard</option>
                              <option value="Swaziland">Swaziland</option>
                              <option value="Sweden">Sweden</option>
                              <option value="Switzerland">Switzerland</option>
                              <option value="Syria">Syria</option>
                              <option value="Taiwan">Taiwan</option>
                              <option value="Tajikistan">Tajikistan</option>
                              <option value="Tanzania">Tanzania</option>
                              <option value="Thailand">Thailand</option>
                              <option value="Timor-Leste">Timor-Leste</option>
                              <option value="Togo">Togo</option>
                              <option value="Tokelau">Tokelau</option>
                              <option value="Tonga">Tonga</option>
                              <option value="Trinidad and Tobago">Trinidad and Tobago</option>
                              <option value="Tunisia">Tunisia</option>
                              <option value="Turkey">Turkey</option>
                              <option value="Turkmenistan">Turkmenistan</option>
                              <option value="Turks and Caicos Islands">Turks and Caicos Islands</option>
                              <option value="Tuvalu">Tuvalu</option>
                              <option value="Uganda">Uganda</option>
                              <option value="Ukraine">Ukraine</option>
                              <option value="United Arab Emirates">United Arab Emirates</option>
                              <option value="United Kingdom">United Kingdom</option>
                              <option value="Uruguay">Uruguay</option>
                              <option value="US Virgin Islands">US Virgin Islands</option>
                              <option value="Uzbekistan">Uzbekistan</option>
                              <option value="Vanuatu">Vanuatu</option>
                              <option value="Venezuela">Venezuela</option>
                              <option value="Vietnam">Vietnam</option>
                              <option value="Wallis and Futuna">Wallis and Futuna</option>
                              <option value="West Bank">West Bank</option>
                              <option value="Western Sahara">Western Sahara</option>
                              <option value="Yemen">Yemen</option>
                              <option value="Zambia">Zambia</option>
                              <option value="Zimbabwe">Zimbabwe</option>
                              </select>
                              <!-- tooltip -->
                        <div class="tooltip-con">
                        <div class="tooltip" id="toolcountry"></div></div>
                        <!-- tooltip -->
                      </div>
                    </div>
                  </div>
                  <!-- block2 -->
              <!--     <div class="form-group DS-contact-right">
                    <label class="control-label">Area Code<span class="DS-star"></span></label>
                    <div class="controls">
                        <div class="input-group">
                      <span class="input-group-addon"><i class="fa fa-code"></i></span>
                        <input class="form-control" id="qacode" onkeypress="return isNumberKeyq(event);" name="Area Code" placeholder="Area Code" type="text" data-placement="bottom">
                    
                        <div class="tooltip-con">
                        <div class="tooltip" id="toolarea"></div></div>
                    
                    </div>
                  </div>
                  </div> -->
      <div class="form-group DS-contact-right">
					<div class="row">
					<div class="col-sm-5">
					<label class="control-label">Area code<span class="DS-star"></span></label>
						<div class="controls">
							<div class="input-group">
						  <span class="input-group-addon"><i class="fa fa-code"></i></span>
							<input class="form-control" name="areacode" id="acode" placeholder="Ex: 3322" type="text" data-placement="bottom">
							<!-- tooltip -->
							<div class="tooltip-con">
							<div class="tooltip" id="#"></div></div>
							<!-- tooltip -->
						  </div>
						</div>
					</div>
					<div class="col-sm-7">
					<label class="control-label">Phone No<span class="DS-star"></span></label>
					<div class="controls">
                        <div class="input-group">
                      <span class="input-group-addon"><i class="fa fa-mobile"></i></span>
                        <input class="form-control" name="Phone" id="qphone" onkeypress="return isNumberKeyq(event);" placeholder="Your Phone Number" type="text" data-placement="bottom">
                        <!-- tooltip -->
                        <div class="tooltip-con">
                        <div class="tooltip" id="toolphone"></div></div>
                        <!-- tooltip -->
                      </div>
                    </div>
					</div>
					
					</div>
                    
                    
                  </div>
                </div>
                <!-- row-block3 -->
                <div class="DS-clrar-20"></div>
                  <div class="row DS-row-reduse">
                    <!-- block1 -->
            
                  <!-- block2 -->
                  <div class="form-group DS-contact-left">
 <div class="DS-clrar-10"></div>
                    <label class="control-label">Translate From <span class="DS-star">*</span></label>
                    <div class="controls">
                        <div class="input-group">
                      <span class="input-group-addon"><i class="fa fa-language"></i></span>
                        <select class="form-control DS-form-width DS-size DS-q DS-wrapper" id="qsource" data-placement="bottom">
                            <option value="">Select Source Language</option>
                                <option value="Abkhazian">Abkhazian</option>
								
								<option value="Acholi">Acholi</option>
                                  <option value="Afar">Afar</option>
                                  <option value="Afrikaans">Afrikaans</option>
								   
								   <option value="Akan">Akan</option>
								  
                                  <option value="Albanian">Albanian</option>
                                  <option value="Amharic">Amharic</option>
                                  <option value="Arabic">Arabic</option>
                                  <option value="Armenian">Armenian</option>
								  
								  <option value="Ashanti">Ashanti</option>
                                  <option value="Assamese">Assamese</option>
								 
								 <option value="Assyrian">Assyrian</option>
                                  <option value="Aymara">Aymara</option>
                                  <option value="Azerbaijani">Azerbaijani</option>   
                                  
								  <option value="Bahasa">Bahasa</option>
                                  <option value="Bashkir">Bashkir</option> 
                                  <option value="Basque">Basque</option>
                                  <option value="Bengali">Bengali</option>
                                  <option value="Bhutani">Bhutani</option>
                                  <option value="Bihari">Bihari</option>
                                  <option value="Bislama">Bislama</option>
                                  <option value="Bosnian">Bosnian</option>
                                  <option value="Breton">Breton</option>
                                  <option value="Bulgarian">Bulgarian</option>
                                  <option value="Burmese">Burmese</option>
                                  <option value="Byelorussian">Byelorussian</option>
                                  
								  <option value="Cambodian">Cambodian</option>
								   
								   <option value="Cantonese">Cantonese</option>
								   
								   <option value="Cape">Cape</option>
								   
                                 <option value="Cebuano">Cebuano</option>
								  
								  <option value="Chamorro">Chamorro</option>
								  
                                  <option value="Cherokee">Cherokee</option>
                                  <option value="Chewa">Chewa</option> 
								  
								  <option value="Chinese">Chinese</option>  
								 
                                  <option value="Chinese Simplified">Chinese Simplified</option>
                                  <option value="Chinese Traditional">Chinese Traditional</option>
                                   
								   <option value="Chuukese">Chuukese</option>
								   
								  
                                  <option value="Corsican">Corsican</option>
                                  <option value="Croatian">Croatian</option>
                                  <option value="Czech">Czech</option>
                                  
								  <option value="Danish">Danish</option>
								  
								  <option value="Dari">Dari</option>
                                 
								 <option value="Divehi">Divehi</option>
								   
								   <option value="Dinka">Dinka</option>
								   
								   <option value="Dutch">Dutch </option>
								  
								  <option value="Dzongkha">Dzongkha</option>
								   
								    
								   
                                  
								  <option value="Edo">Edo</option>
								   <option value="Efik">Efik</option>
                                                                                                         
                                  <option value="English">English</option>
                                  <option value="Esperanto">Esperanto</option>
                                  <option value="Estonian">Estonian</option>
								   <option value="Ethiopian">Ethiopian</option>
                                  <option value="Ewé">Ewé</option>
								  
								  
                                  <option value="Faeroese">Faeroese</option>
                                  <option value="Farsi">Farsi</option>
                                  <option value="Fiji">Fiji</option>
                                  <option value="Finnish">Finnish</option>
                                  <option value="Flemish">Flemish</option>
                                  <option value="French">French</option>
                                  <option value="Frisian">Frisian</option>
                                  <option value="Fulfulde">Fulfulde</option>
								  <option value="Fula">Fula</option>
								  <option value="Fulani">Fulani</option>
								  
                                  <option value="Ga">Ga</option>
								   <option value="Gaelic">Gaelic</option>
								  
                                  <option value="Gaelic Manx">Gaelic Manx</option>
                                  <option value="Gaelic Scot">Gaelic Scot</option>
                                  <option value="Galician">Galician</option>
                                  <option value="Georgian">Georgian</option>
                                  <option value="German">German</option>
                                  <option value="Greek">Greek</option>
                                  <option value="Greenlandic">Greenlandic</option>
                                  <option value="Guarani">Guarani</option>
                                  <option value="Gujarati">Gujarati</option>
								  
                                  <option value="Haitian Creole">Haitian Creole</option>
                                  <option value="Hausa">Hausa</option>
								  
								    
                                  <option value="Hawaiian">Hawaiian</option>
                                  <option value="he, iw*">he, iw*</option>
                                  <option value="Hebrew">Hebrew</option>
                                  <option value="Hindi">Hindi</option>
                                  <option value="Hmong">Hmong</option>
								  <option value="Ho">Ho</option>
								  
                                  <option value="Hungarian">Hungarian</option>
                                  
								  <option value="Ibibio">Ibibio</option>
								  
                                  <option value="Icelandic">Icelandic</option>
                                  <option value="id, in*">id, in*</option>
                                  <option value="Igbo">Igbo</option>
									<option value="Ilocano">Ilocano</option>
                                  <option value="Indonesian">Indonesian</option>
                                  <option value="Interlingua">Interlingua</option>
                                  <option value="Interlingue">Interlingue</option>
                                  <option value="Inuktitut">Inuktitut</option>
                                  <option value="Inupiak">Inupiak</option>
                                  <option value="Irish">Irish</option>
                                  <option value="Italian">Italian</option>
                                  
								  <option value="Japanese">Japanese</option>
                                  <option value="Javanese">Javanese</option>
                                 
								 <option value="Kannada">Kannada</option>
                                  <option value="Kanuri">Kanuri</option>
                                  <option value="Kashmiri">Kashmiri</option>
                                  <option value="Kazakh">Kazakh</option>
                                  <option value="Khmer">Khmer</option>
                                  <option value="Kinyarwanda">Kinyarwanda</option>
                                  <option value="Kirghiz">Kirghiz</option>
                                  <option value="Kirundi">Kirundi</option>
                                  <option value="Konkani">Konkani</option>
                                  <option value="Korean">Korean</option>
                                  <option value="Kurdish">Kurdish</option>
                                  <option value="Laothian">Laothian</option>
                                 
								 <option value="Latin">Latin</option>
                                  <option value="Latvian">Latvian</option>
								  <option value="Lebanese">Lebanese</option>
								  <option value="Luganda">Luganda</option>
                                  <option value="Lingala">Lingala</option>
                                  <option value="Lithuanian">Lithuanian</option>
                                  
								  <option value="Macedonian">Macedonian</option>
								  <option value="Mam">Mam</option>
								  <option value="Mandarin">Mandarin</option>
								  <option value="Mandingo">Mandingo</option>
								  <option value="Mandinka">Mandinka</option>
								  <option value="Marshallese">Marshallese</option>
                                  <option value="Malagasy">Malagasy</option>
                                  <option value="Malay">Malay</option>
                                  <option value="Malayalam">Malayalam</option>
                                  <option value="Maltese">Maltese</option>
								  
                                  <option value="Maori">Maori</option>
                                  <option value="Marathi">Marathi</option>
								  <option value="Mien">Mien</option>
								  <option value="Mina">Mina</option>
								  
								  
								  
								  
								  
								  
								  
								  
								  
                                  <option value="Moldavian">Moldavian</option> 
								  <option value="Moroccan">Moroccan</option>
                                  <option value="Mongolian">Mongolian</option>
                                  
								  <option value="Nauru">Nauru</option>
                                  <option value="Nepali">Nepali</option>
                                  <option value="Norwegian">Norwegian</option>
                                   <option value="Nuer">Nuer</option>
                                 
								 <option value="Occitan">Occitan</option>
                                  <option value="Oriya">Oriya</option>
                                  <option value="Oromo">Oromo</option>
                                  
								  <option value="Papiamentu">Papiamentu</option>
                                  <option value="Pashto">Pashto</option>
                                  <option value="Philipine">Philipine</option>
                                  <option value="Polish">Polish</option>
                                  <option value="Portuguese">Portuguese</option>
                                  <option value="Punjabi">Punjabi</option>
								   <option value="Pulaar">Pulaar</option>
                                  
								  <option value="Quechua">Quechua</option>
								  <option value="Quiche">Quiche</option>
                                  <option value="Rhaeto-Roman">Rhaeto-Roman</option>
                                  <option value="Romanian">Romanian</option>
                                  <option value="Russian">Russian</option>
                                  
								  <option value="Sami">Sami</option>
                                  <option value="Samoan">Samoan</option>
                                  <option value="Sangro">Sangro</option>
                                  <option value="Sanskrit">Sanskrit</option>
								  <option value="Sara">Sara</option>
                                  <option value="Serbian">Serbian</option>
                                  <option value="Serbo">Serbo</option>
                                  <option value="Sesotho">Sesotho</option>
                                  <option value="Shanghainese">Shanghainese</option>
								  <option value="Sicilian">Sicilian</option> 
								  <option value="Sinhala">Sinhala</option>
								  
							
                                  <option value="Shona">Shona</option>
                                  <option value="Sindhi">Sindhi</option>
                                  <option value="Sinhalese">Sinhalese</option>
                                  <option value="Siswati">Siswati</option>
                                  <option value="Slovak">Slovak</option>
                                  <option value="Slovenian">Slovenian</option>
                                  <option value="Soninke">Soninke</option> 
								  <option value="Sorani">Sorani</option> 
								  <option value="Sotho">Sotho</option> 
								 
								  
								  
                                  <option value="Spanish">Spanish</option>
                                  <option value="Sundanese">Sundanese</option>
                                  <option value="Swahili">Swahili</option>
                                  <option value="Swedish">Swedish</option>
                                  <option value="Syriac">Syriac</option>
                                 
								 <option value="Tagalog">Tagalog</option>
                                  <option value="Tajik">Tajik</option>
								  <option value="Tahitian">Tahitian
</option>
								  
                                  <option value="Tamazight">Tamazight</option>
								  
								  <option value="Taiwanese">Taiwanese</option>
								  
								  
                                  <option value="Tamil">Tamil</option>
                                  <option value="Tatar">Tatar</option>
                                  <option value="Telugu">Telugu</option>
								  <option value="Teochew">Teochew</option>
                                  <option value="Tetun">Tetun</option>
                                  <option value="Thai">Thai</option>
                                  <option value="Tibetan">Tibetan</option>
                                  <option value="Tigrinya">Tigrinya</option>
                                  <option value="Tonga">Tonga</option>
								    <option value="Tshiluba">Tshiluba</option>
                                  <option value="Tsonga">Tsonga</option>
                                  <option value="Turkish">Turkish</option>
                                  <option value="Turkmen">Turkmen</option>
                                  <option value="Twi">Twi</option>
                                 
								 <option value="Uighur">Uighur</option>
                                  <option value="Ukrainian">Ukrainian</option>
                                  <option value="Urdu">Urdu</option>
								  
                                  <option value="Uzbek">Uzbek</option>
                                  
								  <option value="Venda">Venda</option>
                                  <option value="Vietnamese">Vietnamese</option>
								  <option value="Visayan">Visayan</option>
                                  <option value="Volapük">Volapük</option>
                                  
								  <option value="Welsh">Welsh</option>
                                  <option value="Wolof">Wolof</option>
                                  
								  <option value="Xhosa">Xhosa</option>
                                  <option value="yi, ji*">yi, ji*</option>
                                  <option value="Yiddish">Yiddish</option>
                                  <option value="Yoruba">Yoruba</option>
                                  <option value="Zulu">Zulu</option>
                                  <option value="Other">Other Source Language</option>
                          </select>
			                    </div>
                    </div>
                  </div>
                   <div class="form-group DS-contact-right">
                <div class="DS-clrar-10"></div>
                                    <label class="control-label">Translate To <span class="DS-star">*</span></label>
                                    <div class="controls">
                                        <div class="input-group">
                                      <span class="input-group-addon"><i class="fa fa-language"></i></span>
                                      <select  name="qtarget"  id="qtarget" multiple="multiple" data-placement="bottom"  class="form-control DS-form-width DS-size DS-q DS-wrapper">
                                           <!--  <option value="">Select Target Language</option> -->
                                                <option value="Abkhazian">Abkhazian</option>
                                                  <option value="Afar">Afar</option>
                                                  <option value="Afrikaans">Afrikaans</option>
                                                  <option value="Albanian">Albanian</option>
                                                  <option value="Amharic">Amharic</option>
                                                  <option value="Arabic">Arabic</option>
                                                  <option value="Armenian">Armenian</option>
                                                  <option value="Assamese">Assamese</option>
                                                  <option value="Aymara">Aymara</option>
                                                  <option value="Azerbaijani">Azerbaijani</option>
                                                  <option value="Bahasa">Bahasa</option>
                                                  <option value="Bashkir">Bashkir</option>
                                                  <option value="Basque">Basque</option>
                                                  <option value="Bengali">Bengali</option>
                                                  <option value="Bhutani">Bhutani</option>
                                                  <option value="Bihari">Bihari</option>
                                                  <option value="Bislama">Bislama</option>
                                                  <option value="Bosnian">Bosnian</option>
                                                  <option value="Breton">Breton</option>
                                                  <option value="Bulgarian">Bulgarian</option>
                                                  <option value="Burmese">Burmese</option>
                                                  <option value="Byelorussian">Byelorussian</option>
                                                  <option value="Cambodian">Cambodian</option>
                                                  <option value="Catalan">Catalan</option>
                                                  <option value="Cherokee">Cherokee</option>
                                                  <option value="Chewa">Chewa</option>
                                                  <option value="Chinese Simplified">Chinese Simplified</option>
                                                  <option value="Chinese Traditional">Chinese Traditional</option>
                                                  <option value="Chuukese">Chuukese</option>
                                                  <option value="Corsican">Corsican</option>
                                                  <option value="Croatian">Croatian</option>
                                                  <option value="Czech">Czech</option>
                                                  <option value="Danish">Danish</option>
                                                  <option value="Divehi">Divehi</option>
                                                  <option value="Dutch">Dutch</option>
                                                  <option value="Edo">Edo</option>
                                                  <option value="English">English</option>
                                                  <option value="Esperanto">Esperanto</option>
                                                  <option value="Estonian">Estonian</option>
                                                  <option value="Ewé">Ewé</option>
                                                  <option value="Faeroese">Faeroese</option>
                                                  <option value="Farsi">Farsi</option>
                                                  <option value="Fiji">Fiji</option>
                                                  <option value="Finnish">Finnish</option>
                                                  <option value="Flemish">Flemish</option>
                                                  <option value="French">French</option>
                                                  <option value="Frisian">Frisian</option>
                                                  <option value="Fulfulde">Fulfulde</option>
                                                  <option value="Gaelic Manx">Gaelic Manx</option>
                                                  <option value="Gaelic Scot">Gaelic Scot</option>
                                                  <option value="Galician">Galician</option>
                                                  <option value="Georgian">Georgian</option>
                                                  <option value="German">German</option>
                                                  <option value="Greek">Greek</option>
                                                  <option value="Greenlandic">Greenlandic</option>
                                                  <option value="Guarani">Guarani</option>
                                                  <option value="Gujarati">Gujarati</option>
                                                  <option value="Haitian Creole">Haitian Creole</option>
                                                  <option value="Hausa">Hausa</option>
                                                  <option value="Hawaiian">Hawaiian</option>
                                                  <option value="he, iw*">he, iw*</option>
                                                  <option value="Hebrew">Hebrew</option>
                                                  <option value="Hindi">Hindi</option>
                                                  <option value="Hmong">Hmong</option>
                                                  <option value="Hungarian">Hungarian</option>
                                                  <option value="Ibibio">Ibibio</option>
                                                  <option value="Icelandic">Icelandic</option>
                                                  <option value="id, in*">id, in*</option>
                                                  <option value="Igbo">Igbo</option>
                                                  <option value="Indonesian">Indonesian</option>
                                                  <option value="Interlingua">Interlingua</option>
                                                  <option value="Interlingue">Interlingue</option>
                                                  <option value="Inuktitut">Inuktitut</option>
                                                  <option value="Inupiak">Inupiak</option>
                                                  <option value="Irish">Irish</option>
                                                  <option value="Italian">Italian</option>
                                                  <option value="Japanese">Japanese</option>
                                                  <option value="Javanese">Javanese</option>
                                                  <option value="Kannada">Kannada</option>
                                                  <option value="Kanuri">Kanuri</option>
                                                  <option value="Kashmiri">Kashmiri</option>
                                                  <option value="Kazakh">Kazakh</option>
                                                  <option value="Khmer">Khmer</option>
                                                  <option value="Kinyarwanda">Kinyarwanda</option>
                                                  <option value="Kirghiz">Kirghiz</option>
                                                  <option value="Kirundi">Kirundi</option>
                                                  <option value="Konkani">Konkani</option>
                                                  <option value="Korean">Korean</option>
                                                  <option value="Kurdish">Kurdish</option>
                                                  <option value="Laothian">Laothian</option>
                                                  <option value="Latin">Latin</option>
                                                  <option value="Latvian">Latvian</option>
                                                  <option value="Lingala">Lingala</option>
                                                  <option value="Lithuanian">Lithuanian</option>
                                                  <option value="Macedonian">Macedonian</option>
                                                  <option value="Malagasy">Malagasy</option>
                                                  <option value="Malay">Malay</option>
                                                  <option value="Malayalam">Malayalam</option>
                                                  <option value="Maltese">Maltese</option>
                                                  <option value="Maori">Maori</option>
                                                  <option value="Marathi">Marathi</option>
                                                  <option value="Moldavian">Moldavian</option>
                                                  <option value="Mongolian">Mongolian</option>
                                                  <option value="Nauru">Nauru</option>
                                                  <option value="Nepali">Nepali</option>
                                                  <option value="Norwegian">Norwegian</option>
                                                  <option value="Occitan">Occitan</option>
                                                  <option value="Oriya">Oriya</option>
                                                  <option value="Oromo">Oromo</option>
                                                  <option value="Papiamentu">Papiamentu</option>
                                                  <option value="Pashto">Pashto</option>
                                                  <option value="Philipine">Philipine</option>
                                                  <option value="Polish">Polish</option>
                                                  <option value="Portuguese">Portuguese</option>
                                                  <option value="Punjabi">Punjabi</option>
                                                  <option value="Quechua">Quechua</option>
                                                  <option value="Rhaeto-Roman">Rhaeto-Roman</option>
                                                  <option value="Romanian">Romanian</option>
                                                  <option value="Russian">Russian</option>
                                                  <option value="Sami">Sami</option>
                                                  <option value="Samoan">Samoan</option>
                                                  <option value="Sangro">Sangro</option>
                                                  <option value="Sanskrit">Sanskrit</option>
                                                  <option value="Serbian">Serbian</option>
                                                  <option value="Serbian">Serbian</option>
                                                  <option value="Sesotho">Sesotho</option>
                                                  <option value="Setswana">Setswana</option>
                                                  <option value="Shona">Shona</option>
                                                  <option value="Sindhi">Sindhi</option>
                                                  <option value="Sinhalese">Sinhalese</option>
                                                  <option value="Siswati">Siswati</option>
                                                  <option value="Slovak">Slovak</option>
                                                  <option value="Slovenian">Slovenian</option>
                                                  <option value="Somali">Somali</option>
                                                  <option value="Spanish">Spanish</option>
                                                  <option value="Sundanese">Sundanese</option>
                                                  <option value="Swahili">Swahili</option>
                                                  <option value="Swedish">Swedish</option>
                                                  <option value="Syriac">Syriac</option>
                                                  <option value="Tagalog">Tagalog</option>
                                                  <option value="Tajik">Tajik</option>
                                                  <option value="Tamazight">Tamazight</option>
                                                  <option value="Tamil">Tamil</option>
                                                  <option value="Tatar">Tatar</option>
                                                  <option value="Telugu">Telugu</option>
                                                  <option value="Tetun">Tetun</option>
                                                  <option value="Thai">Thai</option>
                                                  <option value="Tibetan">Tibetan</option>
                                                  <option value="Tigrinya">Tigrinya</option>
                                                  <option value="Tonga">Tonga</option>
                                                  <option value="Tsonga">Tsonga</option>
                                                  <option value="Turkish">Turkish</option>
                                                  <option value="Turkmen">Turkmen</option>
                                                  <option value="Twi">Twi</option>
                                                  <option value="Uighur">Uighur</option>
                                                  <option value="Ukrainian">Ukrainian</option>
                                                  <option value="Urdu">Urdu</option>
                                                  <option value="Uzbek">Uzbek</option>
                                                  <option value="Venda">Venda</option>
                                                  <option value="Vietnamese">Vietnamese</option>
                                                  <option value="Volapük">Volapük</option>
                                                  <option value="Welsh">Welsh</option>
                                                  <option value="Wolof">Wolof</option>
                                                  <option value="Xhosa">Xhosa</option>
                                                  <option value="yi, ji*">yi, ji*</option>
                                                  <option value="Yiddish">Yiddish</option>
                                                  <option value="Yoruba">Yoruba</option>
                                                  <option value="Zulu">Zulu</option>
                                                  <option value="Other">Other Target Languages</option>
                          </select>
<!--<span class="input-group-btn"><button type="button" class="btn VD-plus btn-add">+</button></span>-->
                            <!-- tooltip -->
                        <div class="tooltip-con">
                        <div class="tooltip" id="tooltl"></div></div>
                        <!-- tooltip -->
                      </div>
                    </div>
                  </div>
                </div>
                
                <div class="row DS-row-reduse">
                           <div class="form-group DS-contact-left" id="other" style="margin-top: 21px;">
                    <label class="control-label">Other Source Language<span class="DS-star"></span></label>
<div class="controls">
<div class="input-group">
                      <span class="input-group-addon"><i class="fa fa-mobile"></i></span>
                        <input class="form-control" name="otherlang" id="otherlang" placeholder="Enter Your Language" type="text" data-placement="bottom">
                       
                      </div>
</div>
</div>
<div class="form-group DS-contact-right" id="other1" style="margin-top: 21px;">
                    <label class="control-label">Other target Language<span class="DS-star"></span></label>
                    <div class="controls">
                        <div class="input-group">
                      <span class="input-group-addon"><i class="fa fa-mobile"></i></span>
                        <input class="form-control" name="otherlang1" id="otherlang1" placeholder="Enter Your Language" type="text" data-placement="bottom">
                       
                      </div>
                    </div>
                  </div>     
                </div>
                <!-- row-block3 -->
                <div class="DS-clrar-20"></div>
      <div class="row DS-row-reduse">
      <div class="form-group col-sm-12">
<!-- <div class="wrapper" style="float:left">-->
  
                <!-- multipart upload start-->
                <?php 
                  date_default_timezone_set('America/New_York'); 
                  echo "<script>var folderPath='".date("dmY")."/"."'; datetime='".date("D M d Y h:i:s")."' </script>";
                  $CRMSERVERPATH = "http://vananhost.com/vanancrm/";
                  $COMMONSETTINGJSON = file_get_contents($CRMSERVERPATH."common_setting.php");
                  $COMMONSETTING = json_decode($COMMONSETTINGJSON, true);
              ?>
              <link rel="stylesheet" type="text/css" href="<?php echo $CRMSERVERPATH;?>/css/checkout.css?<?php echo $COMMONSETTING['RANDOMNO'] ?>">
              <link href="<?php echo $CRMSERVERPATH;?>/css/my-styleNew.css?<?php echo $COMMONSETTING['RANDOMNO'] ?>" rel="stylesheet" type="text/css">
            <?php 
              if(isset($_COOKIE['devtest'])){
                
                echo "<script> var update_url = 'http://vananhost.com/vanancrm/quote_translation_crmdev.php' </script>";
            ?>
              
              <script type="text/javascript" src="<?php echo $CRMSERVERPATH;?>js/crm-upload2.js?<?php echo $COMMONSETTING['RANDOMNO'] ?>"></script>
              <?php 
              }else{
               
               echo "<script> var update_url = 'http://vananhost.com/vanancrm/quote_translation_crm.php' </script>";
            ?>
            <script type="text/javascript" src="<?php echo $CRMSERVERPATH;?>js/crm-upload.js?<?php echo $COMMONSETTING['RANDOMNO'] ?>"></script>
             <?php 
              }
               
            ?>
                  <div onclick="addFiles();" id="fileuploader" class="DS-color-id chooser" style="cursor: pointer; height: 45px; width: 150px; ">
                      <input type="file" id="file" style="display:none;" multiple onChange="upload()"> 
                  </div>
                  
                  <div id="upload_error" style="color:#e0271d; font-weight:bold; padding:5px 0px; display: none;">
                      Network connection Error .. Please check your internet connection ...
                  </div>
                  <input type="hidden" id="recordkey" name="recordkey" value="">  
                  <input type="hidden" name="referalsite" value="<?php echo $_SERVER['SERVER_NAME'];?>"></input>
                  <input type="hidden" id="uploadprogress" value="0"></input>
                  <div class="col-lg-12" id="fileuploadfield">
                      <div class="panel panel-default" style="display:none;" id="info">
                          <div class="row up-head">
                              <div class="col-xs-8 col-sm-8 col-lg-8">File Name/URL</div>
                              <div class="col-xs-4 col-sm-4 col-lg-4">Status</div>
                          </div>
                      </div>
                  </div>
                <!-- multipart upload end -->
                
<!--<div class="tooltip">The process of notary is where every legal document or papers are certified to be complete and accurate with the notary as witness. This is very important especially if you will be taking your documents to different countries around the globe.</div>
</div>-->
  </div>
</div>
                  <div class="row DS-row-reduse">
                    <!-- block1 -->
          
                    <!-- block1 -->
               
<div class="form-group col-sm-12">
<div class="DS-clrar-20"></div>
<label class="control-label"></label>
<div class="DS-question1 DS-question">
<label><input class="check1 DS-tick2" type="checkbox" id="qnote"><span> I would like to have <strong>'Notarization Certificate'</strong> for my files.</label>
<!-- <div class="DS-Qust">
<div class="wrapper">
<i class="fa fa-question-circle"></i>
<div class="tooltip">The process of notary is where every legal document or papers are certified to be complete and accurate with the notary as witness. This is very important especially if you will be taking your documents to different countries around the globe.</div>
</div>
</div> -->
</div>
                </div>
<div class="form-group col-sm-12">
<label class="control-label"></label>
<div class="DS-question1 DS-question">
<label><input class="check1 DS-tick2" type="checkbox" id="qmail"> I would like you to <strong>mail the files</strong> to my Doorsteps.</label>
<!-- <div class="DS-Qust">
<div class="wrapper">
<i class="fa fa-question-circle"></i>
<div class="tooltip">We provide Fast, Convenient, and Affordable Mailing Services For US Customers At $15 Via USPS. Turnaround timeframe is within 2 to 3 business days.Please also take note that we also offer Express delivery services, feel free to contact us if you are interested in availing these services.</div>
                </div>
</div> -->
                </div>
                </div>
                </div>
            <!-- block2 -->
                  <!-- block2 -->
                 
                
                  <!-- text-box -->
                <!--   <div class="form-group DS-contact-right">
                    <label class="control-label">File</label>
                    <div class="controls">
                        <div class="input-group">
                      <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                        <input type="text" class="form-control" name="File" placeholder="File">
                      </div>
                    </div>
                  </div> -->
                  
                  <div class="row DS-row-reduse">
<div class="form-group DS-contact-left">
                        <textarea name="msg"  id="qmailmsg" rows="5" cols="60" placeholder="* Door_Number,\nStreet_Name,\nCity,State,\nZip Code,\nCountry.
"></textarea>
                        <!-- tooltip -->
                        <div class="tooltip-con" style="top: 512px;">
                        <div class="tooltip" id="tooladdr"></div></div>
                        <!-- tooltip -->
  
                      </div>
                      
<!--                   <div class="form-group DS-contact-left">
                   
                    <div class="controls">
                        <div class="input-group" id="upload-file-container">
                        <input id="qupfile" name="qupfile[]"  class="multi with-preview" style="width: 132px; height:35px;cursor:pointer" type="file">
                        <input id="qupfile" type="file" name="qupfile[]" class="multi with-preview" style="color:#444;">
                      </div>
                    </div>
                    <label class="control-label"> (Maximum size: 25 MB If exceeds, go to <span class="DS-color-id"><a data-di-id="di-id-b9416155-f37094d3" href="http://clickfortranslation.com/Translation-Quote.php">upload page</a></span> after filling this form.)</label>
                  </div> -->
                  
                      </div>
<div class="row DS-row-reduse">
  
<div class="form-group col-sm-12">
<div class="accordion_container" style="border:none">
              <div class="accordion_head"> <span class="plusminus">+</span> Need your Files Soon? Tell us some additional information.</div>
                  <div class="accordion_body"  style="display: none;" >
<div class="row DS-row-reduse">
<div class="DS-clrar-20"></div>
<div class="form-group DS-contact-left">
    <label class="control-label">Turnaround Time</label>
    <div class="controls">
        <div class="input-group">
            <span class="input-group-addon"><i class="fa fa-clock-o"></i></span>
            <div id="datetimepicker1">
                <span class="add-on">
<input data-format="dd/MM/yyyy" id="qtat" placeholder="Pick the Date" class="" style="margin-bottom:0px; width: 100%; padding: 6px 12px;" type="text"></span>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    $(function () {
        $('#datetimepicker1').datetimepicker({
    		  startDate: new Date(datetime) ,
        }).on('changeDate', function(e){
            $(this).datetimepicker('hide');
        });
   
    $('#qtat').click(function(){
    		var headerHeight = $('#fileuploadfield').css( 'height' );
        headerHeight = (parseInt(headerHeight)-20)+'px';
			$('.dropdown-menu').css("margin-top",headerHeight);
			
		});
    });
    $("#datetimepicker").data('datetimepicker').setLocalDate(new Date(year, month, day, 00, 01));
</script>
<style type="text/css">
#my-welcome-message2{
     display: none;
     z-index: 1001;
     position: fixed;
     left: 38%;
     top: 40%;
     padding: 0;
     width: auto;
     height: auto;
     overflow: auto;
     border: 2px solid #999;
     background-size: cover;
     background: #d8d8d8;
 }
.vd-welcome {
    width: 30% !important;
    
}
.vd-hilights-pop {
    font-size: 19px;
    width: auto;
    height: auto;
    padding: 10px 15px;
    color: #333;
    text-align: center;
    line-height: 32px;
    font-family: Ruda, arial, sans-serif;
}
.vd-upload-pop{
    width: 95px;
    float: left;
}
.vd-pad{
    padding: 18px 0 0 20px !important;
}
.vd-up-gif {
    width: 111px;
    float: right;
    padding: 0;
}
.accordion_body { background-color: #fff; }
.accordion_head { box-shadow: none; background: #fff; font-weight:normal;color: #126AA2; }
.plusminus {     line-height: 20px; float: left; margin: 0px 10px; border-radius: 50%; background: #579F37; color: White; font-size: 14px; height: 20px;
text-align: center;width: 20px;font-weight: bold;
}
.mail-cnt { margin-top:9px; }
 
.DS-Qust{
margin: 10px 6px 0 3px;
}
.tooltip { margin-left: 78px; }
#textAreaWrap {
    position: relative;
    background-color: white;
}
#textArea {
    position: relative;
    z-index: 1;
    width: 350px;
    height: 100px;
    min-height: 100px;
    padding: 6px 12px;
    resize: vertical;
    background-color: transparent;
    /* When set background-color: transparent - Firefox  displays
    unpleasant textarea border. Set border style to fix it.*/
    border: 1px solid #a5a5a5;
}
#placeholderDiv {
    position: absolute;
    top: 0;
    padding: 6px 13px;
    color: #a5a5a5;
}
</style>
                <div class="form-group DS-contact-right">
<!-- block1 -->
                  <div class="form-group">
                    <label class="control-label">Purpose</label>
                    <div class="controls">
                        <div class="input-group">
                    <!--   <span class="input-group-addon"><i class="fa fa-question-circle"></i></span> -->
  <span class="input-group-addon">
<div class="wrapper">
<i class="fa fa-question-circle"></i>
<div class="tooltip"> Choose the purpose of translation for(eg).Academic,Certificate,immigration,Major needs etc..</div>
</div>
</span>
            <input class="form-control" id="qpurpose" placeholder="Eg: Immigration, Legal, etc." type="text">
					   <!-- Select -->
						<!--select id="qservice" class="form-control">
                             <option value="">Select</option>
							 <option value="Audio/Video">Audio/Video</option>
                            <option value="Book">Book</option>
                            <option value="Certified">Certified</option>
							<option value="Certificate">Certificate</option>
							<option value="Document">Document</option>
							
							
							<option value="Immigration">Immigration</option>
							<option value="Others">Others</option>
                        </select-->
                        <!-- Select -->
                      </div>
                    </div>
                  </div>
                </div>
              </div>
<div class="DS-clrar-20"></div>              
                <div class="DS-clrar-20"></div>
                <div class="form-group ">
                      <label class="control-label">Comment</label>
                  <div class="controls">
                      <div class="input-group">
                    <span class="input-group-addon"><i class="glyphicon glyphicon-pencil"></i></span>
                      <textarea name="msg" class="form-control " id="qcomment" rows="4" cols="78" placeholder="Enter your Comment here"></textarea>
                    </div>
                  </div>
                </div>
</div>
             </div>
</div>
</div>
                <div class="DS-clrar-20"></div>
                <div class="DS-quote-form-bottom-text ">
                      <p class="DS-quote-msg-bottom">✓ 100% privacy we will never spam you</p>
                      <p class="DS-quote-msg-bottom"><input id="qcopy" type="checkbox">&nbsp; Subscribe to receive latest updates</p>
                    </div>
                    <div class="DS-clrar-20"></div>
<div class="DS-clrar-20"></div>
                    <div class="DS-aligncenter DS-row-reduse"><!-- <a href="#"> --><div  id="qsubmit" class="quotebtn DS-h-btn2 cta hvr-float-shadow">Get A Quote</div>
					<input type="hidden" id="quoteflag" name="quoteflag" value="0">
  <div  id="progress" style="display:none;width:200px" class="progressbtn DS-h-btn">Upload progressing...</div>
  
  <!-- </a> --></div>
                    <div class="DS-quote-fmsg" name="qfmsg" id="qfmsg"></div>
                    <div class="DS-res-clear-25"></div>
					<div id="my-welcome-message2" class="vd-welcome">
						<div class="modal-body no-padding vd-pad">
							<div class="pop">
							   <img src="img/vd-upload-pop.png" alt="upload" class="vd-upload-pop">
							   <div class="vd-hilights-pop"><!-- <font color="green">Quote has been sent successfully.</font> <br>--> Your file is being sent!
                  <br>Kindly don't close this window.</div>
                  <!-- Kindly don't close this page as your file(s) are being uploaded. -->
							   <img src="img/loading.gif" alt="upload gif" class="vd-up-gif">
							</div>
						</div>
					</div>
<script>
$(document).ready(function() {
$('#picture1').mouseover(function() {
$('.pic1desc').show();
});
//When the Image is hovered away from, hide the div using Mouseout
$('#picture1').mouseout(function() {
$('.pic1desc').hide();
});
});
</script>
                    <script type="text/javascript" src="js/jquery-1.8.2.min.js?<?php echo $RANDOMNO ?>"></script>
                    <script type="text/javascript" src="js/quote_translation_crm.js?<?php echo $RANDOMNO ?>"></script>
                  <script type="text/javascript">
                      // Allowed only hyphen,number
                      function isNumberKeyq(evt)
                      {
                        var charCode = (evt.which) ? evt.which : event.keyCode;
                        console.log(charCode);
                        if (charCode != 45 && charCode > 31 && (charCode < 48 || charCode > 57))
                           return false;
                        return true;
                      }
                    </script>
                  </div>
                   <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js?<?php echo $RANDOMNO ?>"></script>
                  
                  <script src="js/bootstrap.min.js?<?php echo $RANDOMNO ?>"></script>
                  
<script type="text/javascript">
                                            $(document).ready(function() {
                                                $('#qtarget').multiselect({
                                                    maxHeight: 200
                                                });
                                            });
											
											
											var textAreas = document.getElementsByTagName('textarea');
											Array.prototype.forEach.call(textAreas, function(elem) {
												elem.placeholder = elem.placeholder.replace(/\\n/g, '\n');
											});
                                        </script>
										