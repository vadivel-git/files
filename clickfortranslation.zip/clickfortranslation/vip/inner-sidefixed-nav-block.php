<div class="DS-sidefixed-nav1">
<script type="text/javascript" src="js/jquery-min.js?<?php echo $RANDOMNO ?>"></script>
<script type="text/javascript" src="js/call.js?<?php echo $RANDOMNO ?>"></script>
<script type="text/javascript">

            // Allowed only hyphen,number
            function isNumberKeycc(evt)
            {
                  var charCode = (evt.which) ? evt.which : event.keyCode;
                  console.log(charCode);
                  if (charCode != 45 && charCode > 31 && (charCode < 48 || charCode > 57))
                              return false;
                  return true;
            }

      </script> 
<!-- /.modal -->
         <!-- popup-form-start -->
<div class="modal fade" id="myModal-d" tabindex="-1" role="dialog" 
   aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog" style="width: 365px;">
      <div class="modal-content">
         <div class="modal-header" style="padding: 0;">
            <button type="button" class="close" 
               data-dismiss="modal" aria-hidden="true" style="margin: 4px 15px 0 0;">
                  &times;
            </button>
            <h4 class="modal-title DS-popup-form" id="myModalLabel"><i class="fa fa-users" style="font-size: 21px;margin: 0 8px 0 0;"></i>Leave a feedback</h4>
         </div>
         <!-- form-start -->
     
          <div class="DS-form-txt">
            <label class="DS-form-name">Name<span class="DS-star">*</span></label>
            <input class="DS-input" id="fname" type="text">
          </div>

          <div class="DS-form-txt">
            <label class="DS-form-name">Email id<span class="DS-star">*</span></label>
            <input  class="DS-input" id="femail" type="text">
          </div>

          <div class="DS-form-txt">
            <label class="DS-form-name">feedback <span class="DS-star">*</span></label>
            <textarea class="form-control DS-for-commend" id="fcomment" name="inputMessage" placeholder="Give a feedback" rows="4"></textarea>
          </div>
          
          
         <!-- form-end -->
         <div class="modal-footer">
            <button type="button" id="fsubmit" class="btn btn-primary DS-upbtn DS-form-txt-bt">
               Submit
            </button>
            <div id="femsg" style="color: #000;text-align: center;margin: 6px 0 0 0;"></div>
         </div>
         

      </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<!-- popup-form-end -->

      </div>
<script type="text/javascript" src="js/jquery-min.js?<?php echo $RANDOMNO ?>"></script>
<script type="text/javascript" src="js/feed_back.js?<?php echo $RANDOMNO ?>"></script>



      