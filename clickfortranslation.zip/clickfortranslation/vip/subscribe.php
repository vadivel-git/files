<p class="alert-success"></p>
<p class="alert-warning"></p>
<!-- subscribe-form -->
<form action="//clickfortranslation.us11.list-manage.com/subscribe/post?u=3e35a4526e9878683f384cc34&amp;id=b207fdf956" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="newsletter-signup validate" target="_blank" novalidate="">
<input type="email" value="" name="EMAIL" placeholder="Enter your email id" class="form-control-home input-box" id="mce-EMAIL">

<input type="submit" value="Keep In Touch" name="subscribe" id="mc-embedded-subscribe" class="DS-h-btn1 cta hvr-float-shadow DS-signup">
</form>
