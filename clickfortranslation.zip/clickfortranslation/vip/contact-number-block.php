<!-- contact-number-block -->
      <section class="DS-shadow">
        <div class="DS-clrar-9"></div>
        <div class="container">
          <div class="row">
		  <div class="desk-contact-show">
            <p class="DS-contact"><i class="fa fa-mobile"></i>&nbsp;&nbsp;US : 1-888-535-5668 &nbsp;&nbsp;&nbsp;UK : +44-80-8238-0078&nbsp;&nbsp;&nbsp;AUS : +61-1-8003-57380</p>
			</div>
			 <div class="mobile-contact-show">
			<p class="DS-contact"><i class="fa fa-mobile"></i>&nbsp;&nbsp;US : 1-888-535-5668 &nbsp;&nbsp;&nbsp;UK : +44-80-8238-0078</p>
			
			<p class="DS-contact">&nbsp;&nbsp;&nbsp;AUS : +61-1-8003-57380</p>
			</div>


          </div><!-- numdre-row-end -->
        </div><!-- numdre-container-end -->
        <div class="DS-clrar-9"></div>
      </section>