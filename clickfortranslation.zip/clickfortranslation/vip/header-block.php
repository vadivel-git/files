<!-- <div id="my-welcome-message">
    <div class="modal-body no-padding">

      <div class="pop">
       <div class="col-md-4 bg_1st">
       <div class="span1">Silver</div><br>
       <div class="span2">offer</div><br>
       <div class="span3">save up to</div><br>
       <div class="span4">10% <span class="span5">off</span></div>
       <div class="height-1"></div>
       <div class="divider"></div>
       <div class="span6">15 to 25 pages</div>
        <div class="height-1"></div>
        <div class="divider"></div>
        <div class="get_btn"><a href="http://clickfortranslation.com/Translation-Quote.php" id="id1">get my 10% off</a></div>
       </div>

       <div class="col-md-4 bg_2nd">
       <div class="span1">Golden</div><br>
       <div class="span2">offer</div><br>
       <div class="span3">save up to</div><br>
       <div class="span4">15% <span class="span5">off</span></div>
       <div class="height-1"></div>
       <div class="divider"></div>
       <div class="span6">26 to 50 Pages</div>
        <div class="height-1"></div>
        <div class="divider"></div>
        <div class="get_btn get2"><a href="http://clickfortranslation.com/Translation-Quote.php" id="id1">get my 15% off</a></div>
       </div>

       <div class="col-md-4 bg_3rd">
       <div class="span1">Platinum</div><br>
       <div class="span2">offer</div><br>
       <div class="span3">Get Off</div><br>
       <div class="span4">$15<span class="span5">/ page</span></div>
       <div class="height-1"></div>
       <div class="divider"></div>
       <div class="span6">More than 50 Pages</div>
        <div class="height-1"></div>
        <div class="divider"></div>
        <div class="get_btn"><a href="http://clickfortranslation.com/Translation-Quote.php" id="id1">get my $5/page off</a></div>
       </div>

    </div>
    </div>
</div> -->

<header class="DS-header">
    
    <nav class="navbar navbar-default" role="navigation">
        <div class="container res_head">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="http://clickfortranslation.com/"><img src="img/DS-logo.png" class="DS-logo" alt="Logo"></a>
            </div>
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav DS-menu">
                    <a href="http://clickfortranslation.com/">
                        <div class="menu"><i class="fa fa-home" style="font-size:24px;color:#222;line-height:19px"></i></div>
                    </a>


<!-- sub drop menu -->
      
<ul class="nav navbar-nav">
    <li class="dropdown">
        <a href="#" class="dropdown dropdown-toggle menu" data-toggle="dropdown">SERVICES 
            <b class="caret"></b>
        </a>
        <ul class="dropdown-menu ">
            <li>                  
			
			                    <li><a href="http://clickfortranslation.com/Book-Translation-Services.php">Book Translation </a></li>
                                <li><a href="http://clickfortranslation.com/translation-services.php">Translation Services </a></li>
                                <li><a href="http://clickfortranslation.com/Certified-Translation-Services.php">Certified Translation </a></li>
								<li><a href="http://clickfortranslation.com/Document-Translation-Services.php">Document Translation </a></li>
								
                                
                            
                                <li><a href="http://clickfortranslation.com/Birth-Certificate-Translation-Services.php">Birth Certificate Translation </a></li>
                                <li><a href="http://clickfortranslation.com/major-translation-services.php">Many More </a></li>
                            </li>
        </ul>
    </li>
</ul>
<!-- sub drop menu end -->
                    <!-- <li class="dropdown">
                        <a href="#" class="dropdown-toggle menu">SERVICES</a>
                        <ul class="dropdown-menu">
                            <li>
                                <li><a href="http://clickfortranslation.com/translation-services.php">Translation Services </a></li>
                                <li><a href="http://clickfortranslation.com/Certified-Translation-Services.php">Certified Translation </a></li>
                                <li class="divider"></li>



                                <li class="dropdown-submenu">
                                <a href="http://clickfortranslation.com/language-translation-services.php">Language Translation </a>
                               

                <ul class="dropdown-menu">
                  <li><a href="#">Second level</a></li> 
                  <li><a href="#">Second level</a></li>
                  <li><a href="#">Second level</a></li>
                </ul>
 </li>

                                 <li class="divider"></li>
                                <li><a href="http://clickfortranslation.com/Document-Translation-Services.php">Document Translation </a></li>
                                <li><a href="http://clickfortranslation.com/Birth-Certificate-Translation-Services.php">Birth Certificate Translation </a></li>
                                <li><a href="http://clickfortranslation.com/major-translation-services.php">Many More </a></li>
                            </li>
                        </ul>
                    </li> -->
                    <li class="dropdown">
                        <!--a href="http://clickfortranslation.com/translation-services-rates.php" class="dropdown-toggle menu">Rates</a-->
						<a href="#" class="dropdown dropdown-toggle menu" data-toggle="dropdown">LANGUAGES 
                        <b class="caret"></b>
						</a>
						
						
                                
                               

                <ul class="dropdown-menu">
                  <li><a  href="http://clickfortranslation.com/Arabic-Translation-Services.php">Arabic Translation</a></li> 
                  <li><a  href="http://clickfortranslation.com/Italian-Translation-Services.php">Italian Translation</a></li>
                  <li><a  href="http://clickfortranslation.com/French-Translation-Services.php">French Translation</a></li>
				  
				  <li><a  href="http://clickfortranslation.com/Spanish-Translation-Services.php">Spanish Translation</a></li>
				<li><a  href="http://clickfortranslation.com/Japanese-Translation-Services.php">Japanese Translation</a><a  href="http://clickfortranslation.com/language-translation-services.php">Many More</a></li>
				  
                </ul>
                     
                    </li>
                    <li class="dropdown">
                        <a href="http://clickfortranslation.com/translation-services-rates.php" class="dropdown-toggle menu">Rates</a>
                        <!--ul class="dropdown-menu">
                            <li>
                                <li><a href="http://clickfortranslation.com/discounts-and-offers.php#bulk">Bulk order offer</a></li>
                                <li><a href="http://clickfortranslation.com/discounts-and-offers.php#academic"> 10% Offer for students</a></li>
                                <li><a href="http://clickfortranslation.com/discounts-and-offers.php#refer">10% Offer for refer a friend</a></li>
                                <li><a href="http://clickfortranslation.com/discounts-and-offers.php#second">10% Offer on your second order</a></li>
                               
                                <li><a href="http://clickfortranslation.com/discounts-and-offers.php">More Offers</a></li>
                            </li>
                        </ul-->
                    </li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle menu">Support</a>
                        <ul class="dropdown-menu">
                            <li>
                                <li><a href="http://clickfortranslation.com/FAQ.php">FAQ </a></li>
                                <li><a href="http://clickfortranslation.com/Translation-Employee-Form.php">Career</a></li>
                                <li><a href="http://clickfortranslation.com/Contact-us.php">Contact</a></li>
                            </li>
                        </ul>
                    </li>
					<li class="dropdown">
                        <a href="http://clickfortranslation.com/how-it-works.php" class="dropdown-toggle menu">How it works?</a>
                    </li>
					
                    <!--li class="dropdown">
                        <a href="http://clickfortranslation.com/how-it-works.php" class="dropdown-toggle menu-last VD-ICOn">
						<i class="fa fa-language" aria-hidden="true"></i></a>
						<ul class="dropdown-menu">
                            <li>
                                <li><a  href="http://clickfortranslation.com/Arabic-Translation-Services.php">Arabic Translation</a></li>
                                <li><a  href="http://clickfortranslation.com/Italian-Translation-Services.php">Italian Translation</a></li>
                                <li><a href="http://clickfortranslation.com/Contact-us.php">Contact</a></li>
                            </li>
                        </ul>
                    </li-->
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <div class="DS-clrar-20"></div>
                    <div class="DS-clrar-5"></div>
                    <a href="http://clickfortranslation.com/Translation-Quote.php">
                        <div class="DS-upbtn-l">Free Quote</div>
                    </a>
                    <div class="DS-round">OR</div> 
                    <a href="http://clickfortranslation.com/Upload-Files.php">
                        <div class="DS-upbtn">Translate now</div>
                    </a>
                </ul>

<!--search-->
<div class="vdd-clear"></div><div class="vd-ad-search"><form action='search.php' id="custom-search-form" class="pull-right"><input type="text" name='search' class="search-query" placeholder="Search"><button type="submit" class="btn"><i class="fa fa-search"></i></button></form></div>
<!--search-->

            </div>
        </div>
    </nav>
    <script>
        /*<![CDATA[*/
        function addBookmark() {
            if (window.sidebar) {
                window.sidebar.addPanel(location.href, document.title, "")
            } else {
                if (document.all) {
                    window.external.AddFavorite(location.href, document.title)
                } else {
                    if (window.opera && window.print) {
                        alert("Press ctrl+D to bookmark (Command+D for macs) after you click Ok")
                    } else {
                        if (window.chrome) {
                            alert("Press ctrl+D to bookmark (Command+D for macs) after you click Ok")
                        } else {
                            alert("Press ctrl+D to bookmark (Command+D for macs) after you click Ok")
                        }
                    }
                }
            }
        }; /*]]>*/
    </script>
	
 <img class="center-block img-responsive" onclick="parent.LC_API.open_chat_window()" src="img/24-call.png" width="320" style="cursor:pointer;">
</header>