<?php

$link = mysql_connect('192.163.251.68', 'vananhos_tracker', 'DFwHzpG)Ll41'); // Remote server

 //$link = mysql_connect('localhost', 'root', ''); // local server



if (!$link) {

    die('Could not connect: ' . mysql_error());

}
else{
	echo 'cnnnt';
}

mysql_select_db("vananhos_hourtlv7");



?>