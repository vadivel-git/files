
<script type="text/javascript">



window.__lc = window.__lc || {};
window.__lc.license = 3112802;
(function() {
  var lc = document.createElement('script'); lc.type = 'text/javascript'; lc.async = true;
  lc.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + 'cdn.livechatinc.com/tracking.js';
  var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(lc, s);
})();


</script>







<!--script type="text/javascript">



function wsa_include_js(){



var wsa_host = (("https:" == document.location.protocol) ? "https://" : "http://");



var js = document.createElement('script');



js.setAttribute('language', 'javascript');



js.setAttribute('type', 'text/javascript');



js.setAttribute('src',wsa_host + 'tracking.websitealive.com/vTracker_v2.asp?objectref=c1&websiteid=0&groupid=3169');



document.getElementsByTagName('head').item(0).appendChild(js);



}







if (window.attachEvent) {window.attachEvent('onload', wsa_include_js);}



else if (window.addEventListener) {window.addEventListener('load', wsa_include_js, false);}



else {document.addEventListener('load', wsa_include_js, false);}



</script-->

<!-- google rich snippet bread crumb, not displayed on the page, just by google -->

<div id="brd-crumbs" xmlns:v="http://rdf.data-vocabulary.org/#" style="display: none">



</div>



<!-- Google Tag Manager -->
<noscript><iframe src="//www.googletagmanager.com/ns.html?id=GTM-T3VMDF"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-T3VMDF');</script>
<!-- End Google Tag Manager -->







