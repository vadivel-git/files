<section>
         <div class="DS-clrar-50"></div>
         <div class="container DS-max-width">
          <div class="row DS-margin">
            <h2 class="DS-heade2"><a href="http://clickfortranslation.com/discounts-and-offers.php" target="_blank">Attractive offers</h2>
            <div class="DS-h-msg-slogen">Enjoy our offers for translation services!</div>
          </div>
          <div class="DS-clrar-20"></div>
          <div class="row">
            <a href="http://clickfortranslation.com/discounts-and-offers.php#academic" target="_blank"><div class="col-xs-6 col-sm-3">
              <img src="img/DS-freetrial.png" class="DS-why-img" alt="">
              <p class="DS-why-text">10% Offer for <br>Students</p>
              <a href="http://clickfortranslation.com/discounts-and-offers.php#academic"><div class="DS-inner-icons"></div></a>
            </div></a>

            <a href="http://clickfortranslation.com/discounts-and-offers.php#second" target="_blank"><div class="col-xs-6 col-sm-3">
              <img src="img/offer.png" class="DS-why-img" alt="">
              <p class="DS-why-text">10% Offer on your<br> second order</p>
              <a href="http://clickfortranslation.com/discounts-and-offers.php#second"><div class="DS-inner-icons"></div></a>
            </div></a>
			
			 <!--a href="http://clickfortranslation.com/discounts-and-offers.php#tomato" target="_blank"><div class="col-xs-6 col-sm-3">
              <img src="img/offer.png" class="DS-why-img" alt="">
              <p class="DS-why-text">La Tomatina<br> Offer</p>
              <a href="http://clickfortranslation.com/discounts-and-offers.php#tomato"><div class="DS-inner-icons"></div></a>
            </div></a-->

            <a href="http://clickfortranslation.com/discounts-and-offers.php#bulk" target="_blank"><div class="col-xs-6 col-sm-3">
              <img src="img/DS-Bo.png" class="DS-why-img" alt="">
              <p class="DS-why-text">Bulk order <br>offer</p>
              <a href="http://clickfortranslation.com/discounts-and-offers.php#bulk"><div class="DS-inner-icons"></div></a>
            </div></a>

            <a href="http://clickfortranslation.com/discounts-and-offers.php#refer" target="_blank"><div class="col-xs-6 col-sm-3">
              <img src="img/DS-customer.png" class="DS-why-img" alt="">
              <p class="DS-why-text">10% Offer for refer <br>a friend</p>
              <a href="http://clickfortranslation.com/discounts-and-offers.php#refer"><div class="DS-inner-icons"></i></div></a>
            </div></a>

          </div>

         </div>
          <div class="DS-clrar-50"></div>
      </section>