<!-- <div id="my-welcome-message1">
    <div class="modal-body pad_pop">
        <div class="col-lg-6 col-sm-8 col-xs-8 pp_up">
            <h3 class="pop_h3">Give Details About Your Project!</h3>
            <p class="pop_p">Using the <strong>Message box</strong>, tell us what service do you need including the mandatory <strong>source and target language</strong>. Just fill to get Certified, Notarized and Mailed translation service quickly. You'll get impressive outputs instantly.</p>
            <div class="clearfx">
            </div>
        </div>
    </div>
</div> -->
<!-- <div id="my-welcome-message">
    <div class="modal-body no-padding">

      <div class="pop">
       <div class="col-md-4 bg_1st">
       <div class="span1">Silver</div><br>
       <div class="span2">offer</div><br>
       <div class="span3">save up to</div><br>
       <div class="span4">10% <span class="span5">off</span></div>
       <div class="height-1"></div>
       <div class="divider"></div>
       <div class="span6">15 to 25 pages</div>
        <div class="height-1"></div>
        <div class="divider"></div>
        <div class="get_btn"><a href="http://clickfortranslation.com/Translation-Quote.php" id="id1">get my 10% off</a></div>
       </div>

       <div class="col-md-4 bg_2nd">
       <div class="span1">Golden</div><br>
       <div class="span2">offer</div><br>
       <div class="span3">save up to</div><br>
       <div class="span4">15% <span class="span5">off</span></div>
       <div class="height-1"></div>
       <div class="divider"></div>
       <div class="span6">26 to 50 Pages</div>
        <div class="height-1"></div>
        <div class="divider"></div>
        <div class="get_btn get2"><a href="http://clickfortranslation.com/Translation-Quote.php" id="id1">get my 15% off</a></div>
       </div>

       <div class="col-md-4 bg_3rd">
       <div class="span1">Platinum</div><br>
       <div class="span2">offer</div><br>
       <div class="span3">Get Off</div><br>
       <div class="span4">$15<span class="span5">/ page</span></div>
       <div class="height-1"></div>
       <div class="divider"></div>
       <div class="span6">More than 50 Pages</div>
        <div class="height-1"></div>
        <div class="divider"></div>
        <div class="get_btn"><a href="http://clickfortranslation.com/Translation-Quote.php" id="id1">get my $5/page off</a></div>
       </div>

    </div>
    </div>
</div> -->

</div>

</div>

<header class="DS-header">

    

    <nav class="navbar navbar-default" role="navigation">

        <div class="container res_head">

            <div class="navbar-header">

                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">

                    <span class="sr-only">Toggle navigation</span>

                    <span class="icon-bar"></span>

                    <span class="icon-bar"></span>

                    <span class="icon-bar"></span>

                </button>

                <a class="navbar-brand" href="http://clickfortranslation.com/"><img src="img/DS-logo.png" class="DS-logo" alt="Logo"></a>

            </div>

            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

                <ul class="nav navbar-nav DS-menu">
                    <a href="http://clickfortranslation.com/" data-di-id="di-id-d7889415-893d8a3b" style="">
                        <div class="menu"><i class="fa fa-home" style="font-size:24px;color:#222;line-height:19px"></i></div>
                    </a>


<!-- sub drop menu -->
      
<ul class="nav navbar-nav">
    <li class="dropdown">
        <a href="#" class="dropdown dropdown-toggle menu" data-toggle="dropdown" data-di-id="di-id-a5e8b1b9-8d921925">SERVICES 
            <b class="caret"></b>
        </a>
        <ul class="dropdown-menu ">
            <li>
                                </li><li><a href="http://clickfortranslation.com/translation-services.php" data-di-id="di-id-265265fe-74c6ab9f">Translation Services </a></li>
                                <li><a href="http://clickfortranslation.com/Certified-Translation-Services.php" data-di-id="di-id-16cfee81-b3e1bddf">Certified Translation </a></li>
                                 <!-- sub menu -->
            <!--li href="http://clickfortranslation.com/language-translation-services.php" class="dropdown-submenu">
                
				<a  class="dropdown-toggle" data-toggle="dropdown">Language Translation</a>
                <ul class="dropdown-menu">
                    <li>
                       <a  href="http://clickfortranslation.com/Arabic-Translation-Services.php">Arabic Translation</a>
			
				<a  href="http://clickfortranslation.com/Italian-Translation-Services.php">Italian Translation</a>
				<a  href="http://clickfortranslation.com/French-Translation-Services.php">French Translation</a>
			<a  href="http://clickfortranslation.com/Spanish-Translation-Services.php">Spanish Translation</a>
				<a  href="http://clickfortranslation.com/Japanese-Translation-Services.php">Japanese Translation</a><a  href="http://clickfortranslation.com/language-translation-services.php">Many More</a>
					
				
                    </li>
                </ul>
            </li -->
            <!-- sub menu -->
                                <li><a href="http://clickfortranslation.com/Document-Translation-Services.php" data-di-id="di-id-ac4bb491-f9c08378">Document Translation </a></li>
                                <li><a href="http://clickfortranslation.com/Birth-Certificate-Translation-Services.php" data-di-id="di-id-31fdda3b-af42847a">Birth Certificate Translation </a></li>
                                <li><a href="http://clickfortranslation.com/major-translation-services.php" data-di-id="di-id-f827a12f-e2e2c400">Many More </a></li>
                            
        </ul>
    </li>
</ul>
<!-- sub drop menu end -->
                    <!-- <li class="dropdown">
                        <a href="#" class="dropdown-toggle menu">SERVICES</a>
                        <ul class="dropdown-menu">
                            <li>
                                <li><a href="http://clickfortranslation.com/translation-services.php">Translation Services </a></li>
                                <li><a href="http://clickfortranslation.com/Certified-Translation-Services.php">Certified Translation </a></li>
                                <li class="divider"></li>



                                <li class="dropdown-submenu">
                                <a href="http://clickfortranslation.com/language-translation-services.php">Language Translation </a>
                               

                <ul class="dropdown-menu">
                  <li><a href="#">Second level</a></li> 
                  <li><a href="#">Second level</a></li>
                  <li><a href="#">Second level</a></li>
                </ul>
 </li>

                                 <li class="divider"></li>
                                <li><a href="http://clickfortranslation.com/Document-Translation-Services.php">Document Translation </a></li>
                                <li><a href="http://clickfortranslation.com/Birth-Certificate-Translation-Services.php">Birth Certificate Translation </a></li>
                                <li><a href="http://clickfortranslation.com/major-translation-services.php">Many More </a></li>
                            </li>
                        </ul>
                    </li> -->
                    <li class="dropdown">
                        <!--a href="http://clickfortranslation.com/translation-services-rates.php" class="dropdown-toggle menu">Rates</a-->
						<a href="#" class="dropdown dropdown-toggle menu" data-toggle="dropdown" data-di-id="di-id-fc72497a-79f8ca98">LANGUAGES 
                        <b class="caret"></b>
						</a>
						
						
                                
                               

                <ul class="dropdown-menu">
                  <li><a href="http://clickfortranslation.com/Arabic-Translation-Services.php" data-di-id="di-id-c48c9d33-7789ff21">Arabic Translation</a></li> 
                  <li><a href="http://clickfortranslation.com/Italian-Translation-Services.php" data-di-id="di-id-c48c9d33-2901c174">Italian Translation</a></li>
                  <li><a href="http://clickfortranslation.com/French-Translation-Services.php" data-di-id="di-id-c48c9d33-629ca4b8">French Translation</a></li>
				  
				  <li><a href="http://clickfortranslation.com/Spanish-Translation-Services.php" data-di-id="di-id-c48c9d33-39ae5627">Spanish Translation</a></li>
				<li><a href="http://clickfortranslation.com/Japanese-Translation-Services.php" data-di-id="di-id-3a7eb723-1354c213">Japanese Translation</a><a href="http://clickfortranslation.com/language-translation-services.php" data-di-id="di-id-3a7eb723-e2c49efe">Many More</a></li>
				  
                </ul>
                     
                    </li>
                    <li class="dropdown">
                        <a href="http://clickfortranslation.com/translation-services-rates.php" class="dropdown-toggle menu" data-di-id="di-id-cd5b3053-8a8ca800">Rates</a>
                        <!--ul class="dropdown-menu">
                            <li>
                                <li><a href="http://clickfortranslation.com/discounts-and-offers.php#bulk">Bulk order offer</a></li>
                                <li><a href="http://clickfortranslation.com/discounts-and-offers.php#academic"> 10% Offer for students</a></li>
                                <li><a href="http://clickfortranslation.com/discounts-and-offers.php#refer">10% Offer for refer a friend</a></li>
                                <li><a href="http://clickfortranslation.com/discounts-and-offers.php#second">10% Offer on your second order</a></li>
                               
                                <li><a href="http://clickfortranslation.com/discounts-and-offers.php">More Offers</a></li>
                            </li>
                        </ul-->
                    
                    </li><li class="dropdown">
                        <a href="#" class="dropdown-toggle menu" data-di-id="di-id-fc72497a-79f8ca98">Support</a>
                        <ul class="dropdown-menu">
                            <li>
                                </li><li><a href="http://clickfortranslation.com/FAQ.php" data-di-id="di-id-bfef8c56-8b34662b">FAQ </a></li>
                                <li><a href="http://clickfortranslation.com/Translation-Employee-Form.php" data-di-id="di-id-e2bdfbab-e250e19d">Career</a></li>
                                <li><a href="http://clickfortranslation.com/Contact-us.php" data-di-id="di-id-b1371ef7-a4247f9d">Contact</a></li>
                            
                        </ul>
                    </li>
					<li class="dropdown">
                        <a href="http://clickfortranslation.com/how-it-works.php" class="dropdown-toggle menu" data-di-id="di-id-e39079bc-fc9f3c28">How it works?</a>
                    </li>
					
                    <!--li class="dropdown">
                        <a href="http://clickfortranslation.com/how-it-works.php" class="dropdown-toggle menu-last VD-ICOn">
						<i class="fa fa-language" aria-hidden="true"></i></a>
						<ul class="dropdown-menu">
                            <li>
                                <li><a  href="http://clickfortranslation.com/Arabic-Translation-Services.php">Arabic Translation</a></li>
                                <li><a  href="http://clickfortranslation.com/Italian-Translation-Services.php">Italian Translation</a></li>
                                <li><a href="http://clickfortranslation.com/Contact-us.php">Contact</a></li>
                            </li>
                        </ul>
                    </li-->
                </ul>

                <ul class="nav navbar-nav navbar-right">

                    <div class="DS-clrar-20"></div>

                    <div class="DS-clrar-5"></div>

                    <a href="http://clickfortranslation.com/Translation-Quote.php" target="_blank">

                        <div class="DS-upbtn-l">Free Quote</div>

                    </a>

                    <div class="DS-round">OR</div>

                    <a href="http://clickfortranslation.com/Upload-Files.php">
                        <div class="DS-upbtn">Translate now</div>
                    </a>

                </ul>

<!--search-->
<div class="vdd-clear"></div><div class="vd-ad-search"><form action='search.php' id="custom-search-form" class="pull-right"><input type="text" name='search' class="search-query" placeholder="Search"><button type="submit" class="btn"><i class="fa fa-search"></i></button></form></div>
<!--search-->

            </div>

        </div>

    </nav>

    <script>

        /*<![CDATA[*/

        function addBookmark() {

            if (window.sidebar) {

                window.sidebar.addPanel(location.href, document.title, "")

            } else {

                if (document.all) {

                    window.external.AddFavorite(location.href, document.title)

                } else {

                    if (window.opera && window.print) {

                        alert("Press ctrl+D to bookmark (Command+D for macs) after you click Ok")

                    } else {

                        if (window.chrome) {

                            alert("Press ctrl+D to bookmark (Command+D for macs) after you click Ok")

                        } else {

                            alert("Press ctrl+D to bookmark (Command+D for macs) after you click Ok")

                        }

                    }

                }

            }

        }; /*]]>*/

    </script>
	 <img class="center-block img-responsive" onclick="parent.LC_API.open_chat_window()" src="img/24-call.png" width="320" style="cursor:pointer;">

</header>
<div class="DS-clrar-20"></div>
<div class="DS-clrar-20"></div>