<section>
        <div class="container DS-max-width">
          <div class="DS-clrar-50 DS-space-reduce-320"></div>
          <div class="row DS-margin">
             <h4 class="DS-heade4"><!--a href="#" target="_blank"-->Your business goal is our objective</h4>
            <div class="DS-h-msg-slogen">Share your visions with us and we'll turn them into reality</div>
            <div class="DS-clrar-50 DS-space-reduce-320"></div>
            <div class="DS-res-clear-25"></div>
             <div class="row DS-margin">
              <!-- vertical-style-start-->
              <div class="col-sm-4 xs-box2 DS-footer-convey-box">
                <div class="DS-footer-icons">
                  <img src="img/DS-quote.png" class="DS-why-img" alt="" style="float: left;   max-height: 60px; margin:2px 0 0 14px;">
                </div>
                <div class="DS-footer-msg">
                  <a href="http://clickfortranslation.com/Translation-Quote.php"><h4>Free Quote</h4></a>
                  <a href="http://clickfortranslation.com/Translation-Quote.php"><div class="DS-footer-cnv-box-1 hvr-float-shadow " > Get a Quote</div>
                </div></a>
              </div>

              <div class="col-sm-4 xs-box2 DS-footer-convey-box">
                <div class="DS-footer-icons">
                  <img src="img/DS-upload.png" class="DS-why-img" alt="" style="float: left;   max-height: 60px; margin:2px 0 0 14px;">
                </div>
                <div class="DS-footer-msg">
                  <a href="http://clickfortranslation.com/upload-file.php"><h4>Upload Now</h4></a>
                  <a href="http://clickfortranslation.com/upload-file.php"><div class="DS-footer-cnv-box-2 hvr-float-shadow" >Let's Start Here</div></a>
                </div>
              </div>

              <div class="col-sm-4 xs-box2 DS-footer-convey-box">
                <div class="DS-footer-icons">
                  <img src="img/DS-call.png" class="DS-why-img" alt="" style="float: left;   max-height: 60px; margin:2px 0 0 14px;">
                </div>
                <div class="DS-footer-msg">
                  <a href="http://clickfortranslation.com/Contact-us.php"><h4>Contact Us</h4></a>
                  <a href="http://clickfortranslation.com/Contact-us.php"><div class="DS-footer-cnv-box-3 hvr-float-shadow">Connect With Us</div></a>
                </div>
              </div>


              <!-- vertical-style-end-->

          </div> 
          </div>
          <div class="DS-clrar-50 DS-space-reduce-320"></div>
          <div class="DS-clrar-20 "></div>
        </div>
      </section>