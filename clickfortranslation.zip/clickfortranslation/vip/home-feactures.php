<section class="DS-home-bottom">
        <div class="DS-clrar-50 DS-space-reduce-320"></div>
        <div class="DS-clrar-20"></div>
        <div class="container DS-home-bottom-msg DS-max-width">
          <div class="row" style="margin-right: 0; margin-left: 0;">            <div class="col-xs-6 DS-line-r DS-line-b DS-line-t DS-line-l">
              <div class="DS-clrar-20 DS-space-reduce-320"></div>
              <div class="DS-clrar-10"></div>
              <div class="DS-small-head">Featured Clients</div>
              <p class="DS-h-small-text">We are globally trusted and wanted by first class businesses.
                </p>
              <div class="DS-aligncenter"><a href="http://clickfortranslation.com/client.php"><div class="DS-h-btn1 cta hvr-float-shadow">Take a look</div></a></div>
            </div>            <div class="col-xs-6 DS-line-b DS-line-t DS-line-r">
              <div class="DS-clrar-20 DS-space-reduce-320"></div>
              <div class="DS-clrar-10"></div>
              <div class="DS-small-head">Client Reviews</div>
              <p class="DS-h-small-text">Listen to the majority. It’s their words that matter the most. 
                       </p>
             <div class="DS-aligncenter"><a href="http://clickfortranslation.com/client-review.php"><div class="DS-h-btn1 cta hvr-float-shadow">View Reviews</div></a></div>
            </div>          </div>          <div class="row" style="margin-right: 0; margin-left: 0;">
            <div class="col-xs-6 DS-line-r DS-line-l DS-line-b">
              <div class="DS-clrar-20 DS-space-reduce-320"></div>
              <div class="DS-clrar-10"></div>
              <div class="DS-small-head">Other Services </div>
              <p class="DS-h-small-text">Additional services are created for more convenience and satisfaction. 
                       </p>
              <div class="DS-aligncenter"><a href="http://clickfortranslation.com/our-services.php"><div class="DS-h-btn1 cta hvr-float-shadow">Our Services</div></a></div>
            </div>            <div class="col-xs-6 DS-line-r DS-line-b">
              <div class="DS-clrar-20 DS-space-reduce-320"></div>
              <div class="DS-clrar-10"></div>
              <div class="DS-small-head">Leave a Feedback</div>
              <p class="DS-h-small-text"> Your comments are important to us so keep them coming. 
                        </p>
              <div class="DS-aligncenter"><a href="#"><div class="DS-h-btn1 cta hvr-float-shadow" data-toggle="modal" 
   data-target="#myModal-d">Drop us a line</div></a>
   <!-- popup-form-start -->
<div class="modal fade" id="myModal-d" tabindex="-1" role="dialog" 
   aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog" style="width: 365px;">
      <div class="modal-content">
         <div class="modal-header" style="padding: 0;">
            <button type="button" class="close" 
               data-dismiss="modal" aria-hidden="true" style="margin: 0 15px 0 0;">
                  &times;
            </button>
            <h4 class="modal-title DS-popup-form" id="myModalLabel">Leave a feedback</h4>
         </div>
         <!-- form-start -->
     
          <div class="DS-form-txt">
            <label class="DS-form-name">Full Name<span class="DS-star">*</span></label>
            <input id="" class="DS-input" name="Name" id="fname" type="text">
          </div>          <div class="DS-form-txt">
            <label class="DS-form-name">Email ID<span class="DS-star">*</span></label>
            <input id="" class="DS-input" name="Email id" id="femail" type="text">
          </div>          <div class="DS-form-txt">
            <label class="DS-form-name">feedback <span class="DS-star">*</span></label>
            <textarea class="form-control DS-for-commend" id="inputMessage" id="fcomment" name="inputMessage" placeholder="Give a feedback" rows="4"></textarea>
          </div>          
         <!-- form-end -->
         <div class="modal-footer">
            <button type="button" id="fsubmit" class="btn btn-primary DS-upbtn DS-form-txt-bt">
               Submit
            </button>
             <div id="femsg" style="color: #000;text-align: center;margin: 6px 0 0 0;"></div>
         </div>
      </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<!-- popup-form-end -->
<script type="text/javascript" src="js/jquery-min.js"></script>
<script type="text/javascript" src="js/feed_back.js"></script>
 </div>
            </div>          </div>        </div>
        <div class="DS-clrar-50 DS-space-reduce-320"></div>
        <div class="DS-clrar-20"></div>
      </section>