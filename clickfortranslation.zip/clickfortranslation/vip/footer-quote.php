      <!-- footer-block -->

      <footer>

        <div class="DS-clrar-20"></div>

        <div class="DS-clrar-20"></div>

        <div class="container DS-max-width">

          <div class="row">

             <!-- section1 -->
            <div class="col-md-3 col-sm-3">
              <img src="img/vanan_logo.png" class="vanan_logo">
              <p class="vanan_para">
Clickfortranslation has a professional team of talented and experienced professionals. Our rates are fairly priced and affordable.</p>
            </div>
             <!-- section1 -->

			

            <div class="col-md-4 col-sm-4">

              <div class="DS-widget">

                <h5 class="DS-left DS-footer-heading"><a href="http://clickfortranslation.com/About-us.php" style="color:#fff;"><strong>About</strong></a></h5><h5>Support</h5>

                <hr>

                <div class="row">

                  <!-- section1 -->

                  <div class="col-md-6 col-sm-6 col-xs-6">

                    <ul class="DS-list-unstyled">

                        

                        <li><a href="http://clickfortranslation.com/client.php">Clients</a></li>

                        <li><a href="http://clickfortranslation.com/client-review.php">Client reviews</a></li>

                        <li><a href="http://clickfortranslation.com/testimonial.php">Testimonial</a></li>

						<li><a href="http://clickfortranslation.com/blog">Blog</a></li>

                    </ul>

                  </div>

                  <div class="col-md-6 col-sm-6 col-xs-6">

                    <ul class="DS-list-unstyled">

					<li><a href="http://clickfortranslation.com/FAQ.php">Faq</a></li>

                        <li><a href="http://clickfortranslation.com/Translation-Employee-Form.php">Career</a></li>

                        <li><a href="http://clickfortranslation.com/Contact-us.php">Contact</a></li>

                           <li><a href="http://clickfortranslation.com/how-it-works.php">How it Works?</a></li>

                    </ul>

                  </div>

                </div>

              </div>

            </div>

            <!-- section2 -->

            <div class="col-md-3 col-sm-3">

              <div class="DS-widget">

                <h5>Services</h5>

                <hr>

                <div class="row">

                  <!-- section1 -->

                  <div class="col-md-6 col-sm-6 col-xs-6 DS-footer1">

                    <ul class="DS-list-unstyled">

                        

                        

						 

						 <!--li><a href="http://clickfortranslation.com/Certified-Translation-Services.php">Certified Translation </a></li-->
						 
						 <li><a href="http://clickfortranslation.com/Book-Translation-Services.php">Book Translation </a></li>

						  

						  <li><a href="http://clickfortranslation.com/Translation-Agency.php">Translation Agency</a></li> 
						  <li><a href="http://clickfortranslation.com/Certified-Translation-Services.php">Certified Translation </a></li>
						  
						  
						  <li><a href="http://clickfortranslation.com/Document-Translation-Services.php">Document Translation </a></li>
						  
						  <li><a href="http://clickfortranslation.com/Birth-Certificate-Translation-Services.php">Birth Certificate Translation </a></li>

                        

						
						
						
						

						

                    </ul>

                  </div>

                  <!--div class="col-md-6 col-sm-6 col-xs-6">

                    <ul class="DS-list-unstyled">

                        <li><a href="#">Account</a></li>

                        <li><a href="#">History</a></li>

                        <li><a href="#">Profile</a></li>

                        <li><a href="#">Wish-list</a></li>

                    </ul>

                  </div-->

                </div>

              </div>

            </div>

            <!-- section3 -->

            <div class="col-md-2 col-sm-2">

              <div class="DS-widget" style="font-size: 12px;">

            

                <div class="DS-payment">

                  <img class="DS-img-responsive" src="img/DS-pay.png" alt="Payment">

                  <hr>

                  <div class="DS-social">

                    <h5>Follow Us</h5>

                  <hr>

                  <!-- <a href="#" class="DS-facebook"><i class="fa fa-facebook"></i></a>

                  <a href="#" class="DS-google-plus"><i class="fa fa-google-plus"></i></a>

                  <a href="#" class="DS-twitter"><i class="fa fa-twitter"></i></a> -->



                  <ul class="social-nav DS-model-2 clearfix">

                    <li><a href="https://www.facebook.com/Click-For-Translation-252223405159880/
" target="_blank" class="facebook"> <i class="fa fa-facebook"></i></a></li>

                    <li><a href="https://twitter.com/Clickfortransla/
" target="_blank" class="twitter"><i class="fa fa-twitter"></i></a></li>

                    <li><a href="https://plus.google.com/+Clickfortranslations/posts

" target="_blank" class="google-plus"><i class="fa fa-google-plus"></i></a></li>

                  </ul>



                </div>

                </div>                

              </div>

            </div>

          </div>

          <hr>

          <p class="DS-copy">Copyright © 2016 <a href="http://clickfortranslation.com/">Clickfortranslation.com</a><!--a href="#" style="letter-spacing: 0.4px;">privacy policy</a--> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="http://clickfortranslation.com/terms-condition.php" style="letter-spacing: 0.4px;">Terms and conditions</a></p>

        </div>

      </footer>



    </div>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins v1.11.3) -->

    <script src="js/smooth-scroll.js?<?php echo $RANDOMNO ?>"></script>

    <!-- Include all compiled plugins (below), or include individual files as needed -->

    <script src="js/jquery-min.js?<?php echo $RANDOMNO ?>"></script>

    <script src="js/bootstrap.min.js?<?php echo $RANDOMNO ?>"></script>

    <script src="js/jquery-scrollToTop.js?<?php echo $RANDOMNO ?>"></script>

    <script type="text/javascript">

        $(document).ready(function($) {

            $('body').scrollToTop({skin: 'cycle'});

            $('#myContent').hide();

            $('#togg').dblclick(function(){

            $('#myContent').toggle();

            });

            $('#myContent1').hide();

            $('#togg1').dblclick(function(){

            $('#myContent1').toggle();

            });

    

    });

    </script>



    <script type="text/javascript">

jQuery(document).ready(function($) { 



  // Find the toggles and hide their content

  $('.toggle').each(function(){

    $(this).find('.toggle-content').hide();

  });

  

  // When a toggle is clicked (activated) show their content

  $('.toggle a.toggle-trigger').click(function(){

    var el = $(this), parent = el.closest('.toggle');

    

    if( el.hasClass('active') )

    {

      parent.find('.toggle-content').slideToggle();

      el.removeClass('active');

    }

    else

    {

      parent.find('.toggle-content').slideToggle();

      el.addClass('active');

    }

    return false;

  });

  

});  //End



</script>

  <script type="text/javascript">

      $(function () {

  $('[data-toggle="tooltip"]').tooltip()

})

      </script>


  <?php include'vip/chat_option.php';?>
 <script src="js/jquery-min.js" type="text/javascript"></script>
<script src="js/accordion.js?<?php echo $RANDOMNO ?>" type="text/javascript"></script>

<!-- php (firstVisitPopup-jquery-script) -->
    <!--<script src="js/firstVisitPopup.js?<?php echo $RANDOMNO ?>"></script>-->
    
     <!-- jQuery (page load popup script) -->
        <!--<script>
      $(function () {
                setTimeout(function(){ $('#my-welcome-message, #my-welcome-message1').firstVisitPopup({
          cookieName : 'homepage',
          showAgainSelector: '#show-message'
        }); }, 5000);

      });
    </script>-->

  </body>

</html>



     