<div class="DS-res-clear-50"></div>

<div class="col-xs-6 col-md-4 DS-res-rightbox-width">

              <div class="DS-inner-right-box">

                <a href="http://clickfortranslation.com/features.php"><img src="img/DS-like.png" class="DS-right-img" alt="offer"></a>

                <!-- step1 -->

                <div class="DS-inner-right-heading DS-text-bold">Features</div>

                <div class="DS-inner-right-list">

                  <ul>

				  <!--li><a href="http://clickfortranslation.com/discounts-and-offers.php#tomato">✓ La Tomatina Offer</a></li-->
				  

                    <li><a href="http://clickfortranslation.com/why-choose-us.php#iso">✓ ISO Certified Company</a></li>

                    <!--li><a href="http://clickfortranslation.com/discounts-and-offers.php#season">✓ Seasonal Offers</a></li-->

                    <li><a href="http://clickfortranslation.com/why-choose-us.php#24/7">✓ 24/7 Customer Support</a></li>

					    <li><a href="http://clickfortranslation.com/why-choose-us.php#happy">✓ Fast and easy order</a></li>

                    <li><a href="http://clickfortranslation.com/why-choose-us.php#trans">✓ 100% Security </a></li>
					
					
					

                  </ul>

                </div>

                <!-- step2 -->

                <div class="DS-clrar-10"></div>

                <div class="DS-inner-right-heading DS-text-bold">Translation Service Rates</div>

               <div class="DS-inner-right-list">
                   <ul>
                    <table class="table table-striped">
                        <thead class="thead">
                            <tr>
                                <td class="thlength"><strong style="font-size: 14px; color: #E9281D;">Specifications</strong></td>
                                <td class="thlength"><strong style="font-size: 14px; color: #E9281D;">Cost & Turnaround</strong></td>
                            </tr>
                        </thead>
                        
                        <tbody class="DS-rates-all-table">
                              <tr>
                                <td class="DS-rates-table table-pad"><strong>Translation Rate </strong></td>
                                <td>$25/page </td>
                              </tr>

                              <tr>
                                <td class="DS-rates-table table-pad"><strong>Audio Translation Rate</strong></td>
                                <td>$7/min</td>
                              </tr>

                 <tr>
				 
                                <td class="DS-rates-table"><strong>Turnaround Time</strong><br>&nbsp; ✓ 1 to 2 Pages<br>&nbsp; ✓ 3 to 5 Pages<br>&nbsp; ✓ 6 to 10 Pages<div class="DS-qust_emplye">
                           
                            </div></td>
                                <td>  <div class="wrapper" style="float:left">
                             
                              <i class="fa fa-question-circle" ></i> 
                              <div class="tooltip">Normal TAT for these languages:Arabic, French, German, Italian, Chinese(Mandarin), Chinese(Simplified), Japanese, Spanish, Portuguese. </div>
                            </div> <br>&nbsp;  ✓ 24 - 48 Hours<br>&nbsp; ✓ 3 Business days<br>&nbsp; ✓ 6 to 7 Business days   </td>
                              </tr>
                              
                              
                              <tr>
                                <td class="DS-rates-table table-pad"><strong>Rush Turnaround Time</strong></td>
                                <td>4 hours onwards</td>
                              </tr>
                              
                              
                        </tbody>
                  
                    </table>
                    </ul>
                </div>

                <!-- step3 -->

                 <div class="DS-clrar-10"></div>

                <div class="DS-inner-right-heading DS-text-bold">We also provide</div>

                <div class="DS-inner-right-list">

                  <ul>

                    <li><a href="http://clickfortranslation.com/our-services.php#transcription">✓ Transcription</a></li>

                    <li><a href="http://clickfortranslation.com/our-services.php#voice">✓ Voice Over</a></li>

                    <li><a href="http://clickfortranslation.com/our-services.php#caption">✓ Closed Captioning / Subtitling</a></li>

                    <li><a href="http://clickfortranslation.com/our-services.php#typing">✓ Typing</a></li>

                    <li><a href="http://clickfortranslation.com/our-services.php#video">✓ Video Services</a></li>

                  </ul>

                </div>                <!-- image-block -->

                <div class="DS-clrar-20"></div>

                <div class="row" style="margin-left: 0px;">                <a href="http://clickfortranslation.com/translation-services-rates.php" target="_blank"><div class="DS-inneright">

                  <div class="DS-baner-icons"><i class="fa fa-usd DS-baner-icons-img DS-inner-of-img"></i>

                  </div>

                  <p class="DS-baner-img-text-inner">Pricing at $25/page  </p>

              </div></a>              <!--a href="#" target="_blank"--><div class="DS-inneright">

                <div class="DS-baner-icons"><i class="fa fa-shield DS-baner-icons-img1" ></i>

                </div>

                <p class="DS-baner-img-text-inner">Secure and Confidential</p>

              </div></a>              <!--a href="" target="_blank"--><div class="DS-inneright">

                <div class="DS-baner-icons"><i class="fa fa-star-half-o DS-baner-icons-img3"></i>

                </div>

                <p class="DS-baner-img-text-inner">Rated 4.7 out of 5</p>

              </div></a>

              </div>              <!-- testmonial-start -->

              <div class="DS-clrar-50"></div>

               <div class="DS-inner-right-heading DS-text-bold">Client Testimonials</div>

               <div class="DS-clrar-20"></div>

               <div id="carousel-testimonial" class="carousel slide text-center" data-ride="carousel">

                        <!-- Wrapper for slides -->

                        <div class="carousel-inner" role="listbox">

                            <div class="item">

                                <p><img class="img-circle img-thumbnail" src="img/client.jpg" alt=""></p>

                                <h4 class="DS-testmonial-head DS-text-bold">Montgomery</h4>

                             <!--    <small>Treatment, storage, and disposal (TSD) worker</small> -->

                                <p class="DS-inner-para">Excellent translation services with the fastest delivery timeframes. The results were truly amazing and I couldn’t ask for more. Kudos for the excellent translation service! </p>

                            </div>

                            <div class="item active">

                                <p><img class="img-circle img-thumbnail" src="img/client2.jpg" alt=""></p>

                                <h4 class="DS-testmonial-head DS-text-bold">Margaret Thompson</h4>

                                <p class="DS-inner-para">We were thrilled to know when they offered us a huge discount with our high volume orders. We will definitely order again. </p>

                            </div>

                            <div class="item">

                                <p><img class="img-circle img-thumbnail" src="img/client3.jpg" alt=""></p>

                                <h4 class="DS-testmonial-head DS-text-bold">Sheila Adams</h4>

                             <!--    <small>Treatment, storage, and disposal (TSD) worker</small> -->

                                <p class="DS-inner-para">As an e-learning and development company, we constantly need translation services for our videos and audio. We had the pleasure of collaborating with Click For Translation and the whole experience was really enjoyable. </p>

                            </div>

                        </div>                        <!--testmonial-Controls -->

                        <div class="btns">

                            <a class="btn btn-primary btn-sm" href="#carousel-testimonial" role="button" data-slide="prev" style="background-color: #596267; color: #fff;">

                                <span class="fa fa-angle-left" aria-hidden="true"></span>

                                <span class="sr-only">Previous</span>

                            </a>

                            <a class="btn btn-primary btn-sm" href="#carousel-testimonial" role="button" data-slide="next"style="background-color: #596267; color: #fff;">

                                <span class="fa fa-angle-right" aria-hidden="true"></span>

                                <span class="sr-only">Next</span>

                            </a>

                        </div>

                        <!-- testmonial-end -->

                    </div>                    <!-- Subscribe-start -->

              <div class="DS-clrar-50"></div>

              <div class="DS-inner-right-heading DS-text-bold">Subscribe for special offers</div>

              <div class="DS-clrar-20"></div>

              <!-- subscribe-embed-form-start-->

                <?php include 'vip/subscribe.php'; ?>

              <p class="DS-h-small-text-inner"> Don't worry. We don't spam :)</p>

               <!-- Subscribe-end -->              </div>

            </div>