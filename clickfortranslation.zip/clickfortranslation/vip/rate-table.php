<table class="table table-striped rt table-responsive">
<thead class="thead">
<tr>
<td class="thlength"><strong style="font-size: 16px; color: #E9281D;">Specifications</strong></td>
<td class="thlength"><strong style="font-size: 16px; color: #E9281D;">Rates & TAT</strong></td>
</tr>
</thead>
<tbody class="DS-rates-all-table">

<tr>
<td class="DS-rates-table" ><strong class="rtp">Translation Rate</strong>
<div class="DS-qust_emplye">                      
</div>
</td>
<td class="rtp">$25/page
<br><strong style="color: #E9281D;">Note:</strong> Rates vary for rare languages.</td></td>
</tr>
<tr>
<td class="DS-rates-table"><strong class="rtp">Audio Translation Rate  </strong>
<div class="DS-qust_emplye">
</div>
</td>
<td class="rtp"> $7/min
<br><strong style="color: #E9281D;">Note:</strong> Rates differs for rare languages.</td>
</tr>
<tr>
<td class="DS-rates-table"><strong class="rtp">Turnaround Time</strong>
<div class="DS-qust_emplye">
</div>
</td>
<td class="rtp">24hours onwards</td>
</tr>
<tr>
<td class="DS-rates-table"><strong class="rtp">Rush Turnaround Time</strong>
<div class="DS-qust_emplye">
</div>
</td>
<td class="rtp">4 hours onwards</td>
</tr>
 <tr>
				 
                                <td class="DS-rates-table"><strong class="rtp">Normal TAT</strong><br>&nbsp; ✓ 1 to 2 Pages<br>&nbsp; ✓ 3 to 5 Pages<br>&nbsp; ✓ 6 to 10 Pages<div class="DS-qust_emplye">
                           
                            </div></td>
                                <td>  <div class="wrapper" style="float:left">
                             
                              <i class="fa fa-question-circle" ></i> 
                              <div class="tooltip">Normal TAT for these languages:Arabic, French, German, Italian, Chinese(Mandarin), Chinese(Simplified), Japanese, Spanish, Portuguese. </div>
                            </div> <br>&nbsp;  ✓ 24 - 48 Hours<br>&nbsp; ✓ 3 Business days<br>&nbsp; ✓ 6 to 7 Business days   </td>
                              </tr>

</tbody>
</table>