
<!-- type="button" data-toggle="collapse" data-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample" -->


<div class="row"> 
                    <div class="DS-clrar-20"></div>
                    <div id="togg">Translation Services USA, UK, CANADA, AUSTRALIA & More. </div>
                  <div id="myContent">
                    <div class="well">
                      <!--table-start-->
                    
                        <div class="row-fluid show-grid">
                          <div class="DS-hide-content-msg">
                            <p class="DS-inner-para1">Philadelphia, Pennsylvania</p>
                            <p class="DS-inner-para1">Houston, Texas</p>
                            <p class="DS-inner-para1">New York, NY </p>
                            <p class="DS-inner-para1">Dallas, Texas </p>
                            <p class="DS-inner-para1">Detroit, Michigan </p>
                            <p class="DS-inner-para1">Los Angeles, California</p>
                            <p class="DS-inner-para1">Chicago, Illinois</p>
                            <p class="DS-inner-para1">Phoenix, Arizona</p>
                            <p class="DS-inner-para1">San Diego, California</p>
                            <p class="DS-inner-para1">San Antonio, Texass</p>
                          </div>

                          <div class="DS-hide-content-msg1">
                            <p class="DS-inner-para1">San Francisco, California</p>
                            <p class="DS-inner-para1">Columbus, Ohio</p>
                            <p class="DS-inner-para1">San Jose, California </p>
                            <p class="DS-inner-para1">Indianapolis, Indiana </p>
                            <p class="DS-inner-para1">Jacksonville, Florida</p>
                            <p class="DS-inner-para1">Charlotte, North Carolina</p>
                            <p class="DS-inner-para1">Fort Worth, Texas</p>
                            <p class="DS-inner-para1">Austin, Texas</p>
                            <p class="DS-inner-para1">Memphis, Tennessee</p>
                            <p class="DS-inner-para1">Baltimore, Maryland</p>
                          </div>

                          <div class="DS-hide-content-msg1">
                            <p class="DS-inner-para1">Washington, Columbia</p>
                            <p class="DS-inner-para1">Nashville, Tennessee</p>
                            <p class="DS-inner-para1">Boston, Massachusetts </p>
                            <p class="DS-inner-para1">Milwaukee, Wisconsin </p>
                            <p class="DS-inner-para1">El Paso, Texas</p>
                            <p class="DS-inner-para1">Portland, Oregon</p>
                            <p class="DS-inner-para1">Oklahoma City, Oklahoma</p>
                            <p class="DS-inner-para1">Seattle, Washington</p>
                            <p class="DS-inner-para1">Denver, Colorado</p>
                            <p class="DS-inner-para1">Las Vegas, Nevada</p>
                          </div>

                          <div class="DS-hide-content-msg2">
                            <p class="DS-inner-para1">Long Beach, California</p>
                            <p class="DS-inner-para1">Kansas City, Missouri</p>
                            <p class="DS-inner-para1">Tucson, Arizona </p>
                            <p class="DS-inner-para1">Albuquerque, New Mexico </p>
                            <p class="DS-inner-para1">Atlanta, Georgia</p>
                            <p class="DS-inner-para1">Sacramento, California</p>
                            <p class="DS-inner-para1">Mesa, Arizona</p>
                            <p class="DS-inner-para1">Fresno, California</p>
                            <p class="DS-inner-para1">New Orleans, Louisiana</p>
                            <p class="DS-inner-para1">Cleveland, Ohio</p>
                          </div>
                        </div>
                        <!--table-end-->
                        <div class="DS-area-space"></div>
                    </div>
                  </div>
                  </div>
