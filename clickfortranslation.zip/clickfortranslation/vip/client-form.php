<h2><center> Share Your Views On Our Service</center></h2><div class="DS-clrar-20"></div>


						<!-- div class="DS-inner-right-heading DS-text-bold DS-feacture-head" id="flip">Add Your Reviews</div -->
						<div class="DS-clrar-20"></div>
						<div class="row DS-row-reduse">
							<!-- block1 -->
							<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
							<script type="text/javascript" src="js/jquery.MultiFile.js"></script>
							<script src="js/bootstrap.min.js"></script>
							<div class="form-group DS-contact-left">
								<label class="control-label">Full Name<span class="DS-star">*</span>
								</label>
								<div class="controls">
									<div class="input-group"> <span class="input-group-addon"><i class="fa fa-user"></i></span>
										<input class="form-control" name="name" id="qname1" placeholder="Your Full Name" type="text" data-placement="bottom">
									</div>
								</div>
							</div>
							<!-- block2 -->
							<div class="form-group DS-contact-right">
								<label class="control-label">Email ID<span class="DS-star">*</span>
								</label>
								<div class="controls">
									<div class="input-group"> <span class="input-group-addon"><i class="fa fa-envelope-o"></i></span>
										<input class="form-control" name="ticket" id="qemail1" placeholder="Your Mail ID" type="text" data-placement="bottom">
									</div>
								</div>
							</div>
						</div>
						<div class="DS-clrar-20"></div>
						<div class="row DS-row-reduse">
							<!-- block1 -->
							<div class="form-group DS-contact-left">
								<label class="control-label">Review Title<span class="DS-star">*</span>
								</label>
								<div class="controls">
									<div class="input-group"> <span class="input-group-addon"><i class="glyphicon glyphicon-pencil"></i></span>
										<input class="form-control" name="title" id="qcountrys1" placeholder="For Eg. Great Work " type="text" data-placement="bottom">
									</div>
								</div>
								<!--div class="controls">
									<div class="input-group"> <span class="input-group-addon"><i class="fa fa-flag-o"></i></span>
										<select name="country" id="qcountrys1" class="form-control" data-placement="bottom">
											<option value="">Select</option>
											<option value="Transcription">Excellent Work !</option>
											<option value="Translation">Great Work</option>
											<option value="Closed Captioning">Worst for this time</option>
											<option value="Voice Over">verage</option>
											<option value="Subtitling">Fast and accurate</option>
											<option value="Typing">Good Stuff!</option>
											
										</select>
									</div>
								</div-->
							</div>
							<!-- block2 -->
							<div class="form-group DS-contact-right">
								<label class="control-label">Rating<span class="DS-star">*</span>
								</label>
								<div class="controls">
									<div class="input-group">
										<div class="stars" style="margin-left:1px;">
											<input name="star1" value="1" class="star-1" id="star-1" type="radio" data-placement="bottom">
											<label class="star1" for="star-1">1</label>
											<input name="star1" value="2" class="star-2" id="star-2" type="radio">
											<label class="star" for="star-2">2</label>
											<input name="star1" value="3" class="star-3" id="star-3" type="radio">
											<label class="star" for="star-3">3</label>
											<input name="star1" value="4" class="star-4" id="star-4" type="radio">
											<label class="star" for="star-4">4</label>
											<input name="star1" value="5" class="star-5" id="star-5" type="radio">
											<label class="star1" for="star-5">5</label> <span></span>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="DS-clrar-20"></div>
						<div class="form-group ">
							<label class="control-label">Review</label>
							<div class="controls">
								<div class="input-group"> <span class="input-group-addon"><i class="glyphicon glyphicon-pencil"></i></span>
									<textarea name="msg" class="form-control " id="qcomment1" rows="4" cols="78" placeholder="Enter your Review " data-placement="bottom"></textarea>
								</div>
							</div>
						</div>
						<div class="DS-clrar-20"></div>
						<div class="DS-aligncenter DS-row-reduse">
							<!-- <a href="#"> -->
							<div class="DS-h-btn2 cta hvr-float-shadow" id="qsubmit1">Comment Us</div>
							<!-- </a> -->
							<div id="msg"></div>
						</div>
						<div class="DS-aligncenter DS-row-reduse" style="display:none;">
							<div class="DS-h-btn2 cta hvr-float-shadow" id="test" data-toggle="modal" data-target="#myModal-d1">Test</div>
						</div>
						<!-- popup-form-start -->
						<div class="modal fade" id="myModal-d1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
							<div class="modal-dialog" style="width: 524px;">
								<div class="modal-content">
									<div class="modal-header" style="padding: 0;"></div>
									<!-- form-start -->
									<div class="DS-form-txt text-new">
										<div>
											<p>Thank you! your review has been posted successfully.</p>
										</div>
									</div>
									<!-- form-end -->
									<div class="modal-footer">
										<button type="button" class="btn btn-primary DS-upbtn DS-form-txt-bt" data-dismiss="modal" aria-hidden="true" style="margin: 4px 15px 0 0;">Ok</button>
										<div id="femsg" style="color: #000;text-align: center;margin: 6px 0 0 0;"></div>
									</div>
								</div>
								<!-- /.modal-content -->
							</div>
							<!-- /.modal-dialog -->
						</div>