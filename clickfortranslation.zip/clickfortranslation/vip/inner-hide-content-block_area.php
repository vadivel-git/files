<?php
if($sitcon=='city')
{
$con = 'Our topnotch transcriptions in '.$csccity.''.$cscstate.''.$csccountry.' deliver world-class quality, that’s in demand from universities, to media and business establishments. Our clients needing audio and video transcription solutions from '.$csccity.''.$cscstate.''.$csccountry.', rely on our affordable rates from $0.75/minute, flexible formats, fast turnaround. We guarantee a responsive 24/7 customer support, and ironclad security and confidentiality in '.$csccity.''.$cscstate.''.$csccountry.'.';
}
if($sitcon=='state')
{
$con = 'Quality transcriptions in '.$cscstate.''.$csccountry.' are abundant due to high-demand from business establishments and private firms. But world-class transcription are often exorbitant, which starting businesses cannot fit for their budget. We dominate the transcription business in '.$cscstate.''.$csccountry.' with efficient and affordable packages starting from $0.75/minute. With over 60,000 successful transcriptions, and a trustedteam of multilingual transcribers, we guarantee fast turnaround, risk-free price evaluation, and bulk savings for transcriptions in '.$cscstate.''.$csccountry.'.';
}
if($sitcon=='country')
{
$con = ''.$csccountry.' is one among the world countries that has high expenditure on education. A huge percentage of adults living in '.$csccountry.' are literate which gives an opportunity for the growth of writing industry. People of '.$csccountry.' can benefit in a big way by availing our writing services.';
}
if($sitcon=='')
{
$con = '';
}

   echo '
    <div class="row" style="'.$show.'"> 
    <div class="DS-clrar-20"></div>
    <div id="togg">Transcription Service in '.$csccity.''.$cscstate.''.$csccountry.'</div>
    <div id="myContent">
    <div class="well">
    '.$con.'  
    </div>
    </div> 
    </div>
    ';
    ?>
