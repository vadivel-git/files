<?php include'vip/doctype.php';?>

<link rel="canonical" href="http://clickfortranslation.com/About-us.php">

    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <title>About us | Translation services ($25/page)</title>

	

	 <meta name="description" content="Translation service company, click for translation is the leading service provider offering quick services in the industry. Our translation services are affordable to all ($25/page)."/>

	 

    <meta name="keywords" content="Translation Service Company, Translation Providers, Online Translation"/>

   

    <?php include'vip/site_verification.php';?>

    <?php include'vip/All-links.php';?>

  <body>

     <!-- side-nav -->

      <?php include'vip/inner-sidefixed-nav-block.php';?>

    <div class="DS-wrapper">

      <!-- header-Block -->

      <?php include'vip/header-block.php';?>



      <!-- baner-Block -->

      <section class="DS-inner-baner">

        <div class="container">

          <!-- inner-sub-nav-End -->
 
<div class="DS-clrar-20 "></div>
          <div class="DS-clrar-20 "></div>

          <div class="col-md-8">

            <div class="row">

              <h1 class="DS-head1">ABOUT US</h1>

			     <span class="DS-small-word">"60,000+ Happy Customers!"</span>

            </div>

            <!-- list -->

			

            <div class="DS-clrar-20"></div>

            <div class="row">

			   <p class="DS-baner-list">✓ <strong>800+</strong> native experts</p>
 <p class="DS-baner-list"> ✓ <strong>98%</strong> Accuracy</p>
             

            </div>



            <div class="DS-clrar-10"></div>

            <div class="row">

	   <a href="http://clickfortranslation.com/translation-services-rates.php#turn">  <p class="DS-baner-list">✓ 24 Hours turnaround</p></a>

			 <p class="DS-baner-list"> ✓ High Quality</p>

			 

       

              

            </div>

            <!-- baner-offers -->

            <div class="DS-clrar-20"></div>

              <div class="row">



                <a href="http://clickfortranslation.com/translation-services-rates.php" target="_blank"><div class="DS-inner-con">

                  <div class="DS-baner-icons"><i class="fa fa-usd DS-baner-icons-img DS-inner-of-img"></i>

                  </div>

                 <p class="DS-baner-img-text">Pricing at <span class="rate_change">$25</span>/page </p>

                </div></a>



                <!--a href="#" target="_blank"--><div class="DS-inner-con">

                  <div class="DS-baner-icons"><i class="fa fa-thumbs-o-up DS-baner-icons-img DS-inner-of-img1"></i>

                  </div>

                  <p class="DS-baner-img-text">Satisfaction Guarantee</p>

                </div></a>



             <a href="http://clickfortranslation.com/FAQ.php#secure" target="_blank"><div class="DS-inner-con">

                <div class="DS-baner-icons"><i class="fa fa-shield DS-baner-icons-img DS-inner-of-img2"></i>

                </div>

                <p class="DS-baner-img-text">Secure and Confidential</p>

              </div></a>



              <!--a href="#" target="_blank"--><div class="DS-inner-con">

                <div class="DS-baner-icons"><i class="fa fa-star-half-o DS-baner-icons-img DS-inner-of-img3"></i>

                </div>

                <p class="DS-baner-img-text">Rated 4.7 out of 5</p>

              </div></a>

                 

              </div>

            <!-- button -->

            <?php include'vip/video.php';?>



          </div><!-- baner-col-md-8-end -->

        </div><!-- baner-container-end -->

      </section><!-- baner-section-end -->

      <!-- contact-number -->

      <?php include'vip/contact-number-block.php';?>

      <!-- best-offers -->

      <?php include'vip/best-offers-block.php';?>

      <!-- upload-steps -->

      <?php include'vip/uploadsteps-block.php';?>

      <!-- inner-msg-box -->

      <section>

        <div class="DS-clrar-50"></div>

        <div class="container DS-container-width">

          <div class="row">

            <!-- left-side-block -->

            <div class="col-xs-12 col-md-8">

             <h3 class="DS-text-bold">Translation Service Company</h3>

             <div class="DS-clrar-10"></div>

             <p class="DS-inner-para">We offer professional and affordable translation services.Within a short period of our establishment</br> in the translation industry, we have achieved a huge reputation from our clients. </p><p class="DS-inner-para"><a href="http://clickfortranslation.com">Click for translation</a> is the <a href="http://clickfortranslation.com/ISO-Certified.php">ISO certified</a> <strong>translation service company</strong> offers language translation services to our clients from around the world.
    Our client base is increasing every day that has gained has many new and repeated clients to our company.</p>
	<p class="DS-inner-para">We pride in offering competitive services to our clients from all sectors including education, legal, corporate and more. If you are looking for a vibrant team of translators who could offer exceptional quality services, then we will be your choice of translation service provider online. </p>

			

			

			 <div class="DS-clrar-10"></div>

			 



             <h4 class="DS-text-bold">Translation Providers in US</h4>

             <div class="DS-clrar-10"></div>

             <p class="DS-inner-para">We are one of the renowned <strong>translation providers in US</strong> striving to offer high quality services with fast turnaround.  We provide <a href="http://clickfortranslation.com/Translation-Quote.php">free quotes</a> to our clients. </p>   
			 <p class="DS-inner-para">we are confident in serving our clients with the highest quality services.  We make the process of <a href="http://clickfortranslation.com/Translation-Quote.php">uploading the files</a> easier with just a click. </p>
 <p class="DS-inner-para">Call us to our Toll Free: <strong>1-888-535-5668</strong>, for more information.  </p>

			

			

             <div class="DS-clrar-10"></div>

             <!-- inner features-block-start -->

                        <section class="DS-home-bottom DS-innermsg-feacture">

                          <h4 class="DS-innermsg-head">Features</h4>

                        <div class="DS-clrar-20"></div>

                        <div class="row">

                          <div class="DS-innermsg-box">

                            <div class="DS-inner-left">

                              <div class="DS-innermsg-list">✓ Pricing at $25/page</div>

                              <div class="DS-innermsg-list">✓ <a href="http://clickfortranslation.com/Contact-us.php">24/7 Customer support</a></div>

                              <div class="DS-innermsg-list">✓ <a href="http://clickfortranslation.com/ISO-Certified-Transcription-Company.php">ISO Certified Company</a></div>

                              <div class="DS-innermsg-list">✓ High Accuracy</div>

                            </div>



                            <div class="DS-inner-right">

                              <div class="DS-innermsg-list">✓ Supports all file formats</div>

                              <div class="DS-innermsg-list"><a href="http://clickfortranslation.com/features.php#notary">✓ Provide company & Notary certificate</a></div>

                              <div class="DS-innermsg-list">✓ <a href="http://clickfortranslation.com/why-choose-us.php#nda">NDA Can provide</a></div>

                              <div class="DS-innermsg-list">✓ Fast Turn around time</div>

                            </div>



                          </div>

                        </div>

                        



                        <div class="DS-clrar-20"></div>

                        <div class="DS-aligncenter"><a href="http://clickfortranslation.com/translation-services-rates.php"></a><a class="button cta hvr-float-shadow"style="  border: solid 2px #fff; color: #fff;" href="http://clickfortranslation.com/translation-services-rates.php"><i class="fa fa-usd" style="padding: 0 7px 0 0;font-size: 18px;position: relative;top: -2px;"></i>Translation Pricing</a></div>

                        </section>

                        <div class="DS-clrar-20"></div>

                        <div class="DS-clrar-20"></div>

                        <!-- inner features-block-end -->

             <h4 class="DS-text-bold">Our Featured Services</h4>

             <div class="DS-clrar-10"></div>

			<p class="DS-inner-para">We in addition to offering a money back guarantee, also provide the services with fast turnaround time. </p>

        <p class="DS-inner-para">We provide <a href="http://clickfortranslation.com/Translation-Quote.php">free quotes</a> for our clients. We also provide free trials to our new clients. Call us to our Toll Free: <strong>1-888-535-5668</strong>, to know more about our services.  </p>

				 <!--h4 class="DS-text-bold">Fast  transcription services faq</h4>

			 <div class="DS-clrar-10"></div>

			 <p class="DS-inner-para">1. Where can I get professional and fast transcription services?</p>

           <p class="DS-inner-para">2. Where can I find companies that provide fast transcription services?</p>

           <p class="DS-inner-para">3. Where can I find fast transcription services at affordable rates?</p>

           <p class="DS-inner-para">4. Where can I find a fast online transcription service?</p>

           <p class="DS-inner-para">5. How can I find fast transcription services that are confidential? </p>

			<h4 class="DS-text-bold">Recent Articles</h4>

			 <div class="DS-clrar-10"></div>

			 	 <p class="DS-inner-para">1. <a href="http://clickfortranslation.com/blog/where-can-i-find-services-that-provide-quality-transcription/" rel="bookmark">Where can I find services that provide quality transcription?</a></p-->



			

             <!--ul class="DS-ul">

               <li class="DS-innermsgs-list">✓  Where can I get academic interview transcription?</li>

               <li class="DS-innermsgs-list">✓  Where can I get academic interview transcription?</li>

               <li class="DS-innermsgs-list">✓  Where can I get academic interview transcription?</li>

             </ul--	>





            <?php include'vip/inner-hide-content.php';?>

            <!-- inner-area-block-end -->

            </div>

            <!-- right-side-block -->

             <?php include'vip/inner-rightside-box-block.php';?>



          </div>

        </div>

        <div class="DS-clrar-50"></div>

      </section>

      <!-- conversion-button -->

      <?php include'vip/footer-conversion-block.php';?>

      <!-- conversion-button -->

      <?php include'vip/footer-block.php';?>

