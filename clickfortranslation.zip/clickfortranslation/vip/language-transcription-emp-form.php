<div class="col-xs-12 col-md-8">
              <h3 class="DS-text-bold DS-center DS-center1"></h3>
              <div class="DS-clrar-10"></div>
              <p class="DS-inner-para DS-center DS-center1"></p>
                <!-- form-start -->
                <div class="DS-clrar-20"></div>
                
                  <!-- row-block1 -->
                  <div class="row DS-row-reduse">
                    <!-- block1 -->
                  <div class="form-group DS-contact-left">
                    <label class="control-label">Name<span class="DS-star">*</span></label>
                    <div class="controls">
                        <div class="input-group">
                      <span class="input-group-addon"><i class="fa fa-user"></i></span>
                        <input type="text" class="form-control" id="name" placeholder="Your Name">
                      </div>
                    </div>
                  </div>
                  <!-- block2 -->
                  <div class="form-group DS-contact-right">
                    <label class="control-label">Phone<span class="DS-star">*</span></label>
                    <div class="controls">
                        <div class="input-group">
                      <span class="input-group-addon"><i class="fa fa-mobile"></i></span>
                        <input type="text" class="form-control" id="phone" placeholder="Your Phone No">
                      </div>
                    </div>
                  </div>

                </div>

                <!-- row-block-2 -->
                <div class="DS-clrar-20"></div>
                <div class="row DS-row-reduse">
                    <!-- block1 -->
                  <div class="form-group DS-contact-left">
                    <label class="control-label">Cell No<span class="DS-star">*</span></label>
                    <div class="controls">
                        <div class="input-group">
                      <span class="input-group-addon"><i class="fa fa-phone"></i></span>
                        <input type="text" class="form-control" id="cell" placeholder="Cell Phone No">
                      </div>
                    </div>
                  </div>
                  <!-- block2 -->
                  <div class="form-group DS-contact-right">
                    <label class="control-label">Email<span class="DS-star">*</span></label>
                    <div class="controls">
                        <div class="input-group">
                      <span class="input-group-addon"><i class="fa fa-envelope-o"></i></span>
                        <input type="text" class="form-control" id="email" placeholder="Your Email Id">
                      </div>
                    </div>
                  </div>

                </div>

                <!-- row-block-3 -->
                <div class="DS-clrar-20"></div>
                <div class="row DS-row-reduse">
                    <!-- block1 -->
                  <div class="form-group DS-contact-left">
                    <label class="control-label">Skype</label>
                    <div class="controls">
                        <div class="input-group">
                      <span class="input-group-addon"><i class="fa fa-skype"></i></span>
                        <input type="text" class="form-control" id="skype" placeholder="Skype">
                      </div>
                    </div>
                  </div>
                  <!-- block2 -->
                  <div class="form-group DS-contact-right">
                    <label class="control-label">Language<span class="DS-star">*</span></label>
                    <div class="controls">
                        <div class="input-group">
                      <span class="input-group-addon"><i class="fa fa-language"></i></span>
                        <input type="text" class="form-control" id="lang" placeholder="Language">
                      </div>
                    </div>
                  </div>

                </div>


                <!-- row-block-4 -->
                <div class="DS-clrar-20"></div>
                <div class="row DS-row-reduse">
                    <!-- block1 -->
                  <div class="form-group DS-contact-left">
                    <label class="control-label">Do You Translate Audio/Video <span class="DS-star">*</span></label>
                    <div class="controls">
                        <div class="input-group">
                      <span class="input-group-addon"><i class="fa fa-file-audio-o"></i></span>
                        <select name="Do you translate audio/video" id="translate" class="form-control">
                            <option value="">Select</option>
                            <option value="Yes">Yes</option>
                            <option value="No">No</option>
                        </select>
                      </div>
                    </div>
                  </div>
                  <!-- block2 -->
                  <div class="form-group DS-contact-right">
                    <label class="control-label">Source Language<span class="DS-star">*</span></label>
                    <div class="controls">
                        <div class="input-group">
                      <span class="input-group-addon"><i class="fa fa-language"></i></span>
                        <select name="source_lang" id="sourcelang" class="form-control">
<option value="" selected="selected">Select Language </option>
<option value="Abkhazian">Abkhazian</option>
<option value="Afar">Afar</option <option value="Afrikaans">Afrikaans</option>
<option value="Albanian">Albanian</option>
<option value="Amharic">Amharic</option>
<option value="Arabic">Arabic</option>
<option value="Armenian">Armenian</option>
<option value="Assamese">Assamese</option>
<option value="Aymara">Aymara</option>
<option value="Azerbaijani">Azerbaijani</option>
<option value="Bahasa">Bahasa</option>
<option value="Bashkir">Bashkir</option>
<option value="Basque">Basque</option>
<option value="Bengali">Bengali</option>
<option value="Bhutani">Bhutani</option>
<option value="Bihari">Bihari</option>
<option value="Bislama">Bislama</option>
<option value="Bosnian">Bosnian</option>
<option value="Breton">Breton</option>
<option value="Bulgarian">Bulgarian</option>
<option value="Burmese">Burmese</option>
<option value="Byelorussian">Byelorussian</option>
<option value="Cambodian">Cambodian</option>
<option value="Catalan">Catalan</option>
<option value="Cherokee">Cherokee</option>
<option value="Chewa">Chewa</option>
<option value="Chinese Simplified">Chinese Simplified</option>
<option value="Chinese Traditional">Chinese Traditional</option>
<option value="Chuukese">Chuukese</option>
<option value="Corsican">Corsican</option>
<option value="Croatian">Croatian</option>
<option value="Czech">Czech</option>
<option value="Danish">Danish</option>
<option value="Divehi">Divehi</option>
<option value="Dutch">Dutch</option>
<option value="Edo">Edo</option>
<option value="English">English</option>
<option value="Esperanto">Esperanto</option>
<option value="Estonian">Estonian</option>
<option value="Ewé">Ewé</option>
<option value="Faeroese">Faeroese</option>
<option value="Farsi">Farsi</option>
<option value="Fiji">Fiji</option>
<option value="Finnish">Finnish</option>
<option value="Flemish">Flemish</option>
<option value="French">French</option>
<option value="Frisian">Frisian</option>
<option value="Fulfulde">Fulfulde</option>
<option value="Gaelic Manx">Gaelic Manx</option>
<option value="Gaelic Scot">Gaelic Scot</option>
<option value="Galician">Galician</option>
<option value="Georgian">Georgian</option>
<option value="German">German</option>
<option value="Greek">Greek</option>
<option value="Greenlandic">Greenlandic</option>
<option value="Guarani">Guarani</option>
<option value="Gujarati">Gujarati</option>
<option value="Haitian Creole">Haitian Creole</option>
<option value="Hausa">Hausa</option>
<option value="Hawaiian">Hawaiian</option>
<option value="he, iw*">he, iw*</option>
<option value="Hebrew">Hebrew</option>
<option value="Hindi">Hindi</option>
<option value="Hmong">Hmong</option>
<option value="Hungarian">Hungarian</option>
<option value="Ibibio">Ibibio</option>
<option value="Icelandic">Icelandic</option>
<option value="id, in*">id, in*</option>
<option value="Igbo">Igbo</option>
<option value="Indonesian">Indonesian</option>
<option value="Interlingua">Interlingua</option>
<option value="Interlingue">Interlingue</option>
<option value="Inuktitut">Inuktitut</option>
<option value="Inupiak">Inupiak</option>
<option value="Irish">Irish</option>
<option value="Italian">Italian</option>
<option value="Japanese">Japanese</option>
<option value="Javanese">Javanese</option>
<option value="Kannada">Kannada</option>
<option value="Kanuri">Kanuri</option>
<option value="Kashmiri">Kashmiri</option>
<option value="Kazakh">Kazakh</option>
<option value="Khmer">Khmer</option>
<option value="Kinyarwanda">Kinyarwanda</option>
<option value="Kirghiz">Kirghiz</option>
<option value="Kirundi">Kirundi</option>
<option value="Konkani">Konkani</option>
<option value="Korean">Korean</option>
<option value="Kurdish">Kurdish</option>
<option value="Laothian">Laothian</option>
<option value="Latin">Latin</option>
<option value="Latvian">Latvian</option>
<option value="Lingala">Lingala</option>
<option value="Lithuanian">Lithuanian</option>
<option value="Macedonian">Macedonian</option>
<option value="Malagasy">Malagasy</option>
<option value="Malay">Malay</option>
<option value="Malayalam">Malayalam</option>
<option value="Maltese">Maltese</option>
<option value="Maori">Maori</option>
<option value="Marathi">Marathi</option>
<option value="Moldavian">Moldavian</option>
<option value="Mongolian">Mongolian</option>
<option value="Nauru">Nauru</option>
<option value="Nepali">Nepali</option>
<option value="Norwegian">Norwegian</option>
<option value="Occitan">Occitan</option>
<option value="Oriya">Oriya</option>
<option value="Oromo">Oromo</option>
<option value="Papiamentu">Papiamentu</option>
<option value="Pashto">Pashto</option>
<option value="Philipine">Philipine</option>
<option value="Polish">Polish</option>
<option value="Portuguese">Portuguese</option>
<option value="Punjabi">Punjabi</option>
<option value="Quechua">Quechua</option>
<option value="Rhaeto-Roman">Rhaeto-Roman</option>
<option value="Romanian">Romanian</option>
<option value="Russian">Russian</option>
<option value="Sami">Sami</option>
<option value="Samoan">Samoan</option>
<option value="Sangro">Sangro</option>
<option value="Sanskrit">Sanskrit</option>
<option value="Serbian">Serbian</option>
<option value="Serbian">Serbian</option>
<option value="Sesotho">Sesotho</option>
<option value="Setswana">Setswana</option>
<option value="Shona">Shona</option>
<option value="Sindhi">Sindhi</option>
<option value="Sinhalese">Sinhalese</option>
<option value="Siswati">Siswati</option>
<option value="Slovak">Slovak</option>
<option value="Slovenian">Slovenian</option>
<option value="Somali">Somali</option>
<option value="Spanish">Spanish</option>
<option value="Sundanese">Sundanese</option>
<option value="Swahili">Swahili</option>
<option value="Swedish">Swedish</option>
<option value="Syriac">Syriac</option>
<option value="Tagalog">Tagalog</option>
<option value="Tajik">Tajik</option>
<option value="Tamazight">Tamazight</option>
<option value="Tamil">Tamil</option>
<option value="Tatar">Tatar</option>
<option value="Telugu">Telugu</option>
<option value="Tetun">Tetun</option>
<option value="Thai">Thai</option>
<option value="Tibetan">Tibetan</option>
<option value="Tigrinya">Tigrinya</option>
<option value="Tonga">Tonga</option>
<option value="Tsonga">Tsonga</option>
<option value="Turkish">Turkish</option>
<option value="Turkmen">Turkmen</option>
<option value="Twi">Twi</option>
<option value="Uighur">Uighur</option>
<option value="Ukrainian">Ukrainian</option>
<option value="Urdu">Urdu</option>
<option value="Uzbek">Uzbek</option>
<option value="Venda">Venda</option>
<option value="Vietnamese">Vietnamese</option>
<option value="Volapük">Volapük</option>
<option value="Welsh">Welsh</option>
<option value="Wolof">Wolof</option>
<option value="Xhosa">Xhosa</option>
<option value="yi, ji*">yi, ji*</option>
<option value="Yiddish">Yiddish</option>
<option value="Yoruba">Yoruba</option>
<option value="Zulu">Zulu</option>
</select>
                      </div>
                    </div>
                  </div>

                </div>


                <!-- row-block-5 -->
                <div class="DS-clrar-20"></div>
                <div class="row DS-row-reduse">
                    <!-- block1 -->
                  <div class="form-group DS-contact-left">
                    <label class="control-label">Target Language<span class="DS-star">*</span></label>
                    <div class="controls">
                        <div class="input-group">
                      <span class="input-group-addon"><i class="fa fa-globe"></i></span>
                        <select name="source_lang" id="targetlang" class="form-control">
<option value="" selected="selected">Select Language </option>
<option value="Abkhazian">Abkhazian</option>
<option value="Afar">Afar</option <option value="Afrikaans">Afrikaans</option>
<option value="Albanian">Albanian</option>
<option value="Amharic">Amharic</option>
<option value="Arabic">Arabic</option>
<option value="Armenian">Armenian</option>
<option value="Assamese">Assamese</option>
<option value="Aymara">Aymara</option>
<option value="Azerbaijani">Azerbaijani</option>
<option value="Bahasa">Bahasa</option>
<option value="Bashkir">Bashkir</option>
<option value="Basque">Basque</option>
<option value="Bengali">Bengali</option>
<option value="Bhutani">Bhutani</option>
<option value="Bihari">Bihari</option>
<option value="Bislama">Bislama</option>
<option value="Bosnian">Bosnian</option>
<option value="Breton">Breton</option>
<option value="Bulgarian">Bulgarian</option>
<option value="Burmese">Burmese</option>
<option value="Byelorussian">Byelorussian</option>
<option value="Cambodian">Cambodian</option>
<option value="Catalan">Catalan</option>
<option value="Cherokee">Cherokee</option>
<option value="Chewa">Chewa</option>
<option value="Chinese Simplified">Chinese Simplified</option>
<option value="Chinese Traditional">Chinese Traditional</option>
<option value="Chuukese">Chuukese</option>
<option value="Corsican">Corsican</option>
<option value="Croatian">Croatian</option>
<option value="Czech">Czech</option>
<option value="Danish">Danish</option>
<option value="Divehi">Divehi</option>
<option value="Dutch">Dutch</option>
<option value="Edo">Edo</option>
<option value="English">English</option>
<option value="Esperanto">Esperanto</option>
<option value="Estonian">Estonian</option>
<option value="Ewé">Ewé</option>
<option value="Faeroese">Faeroese</option>
<option value="Farsi">Farsi</option>
<option value="Fiji">Fiji</option>
<option value="Finnish">Finnish</option>
<option value="Flemish">Flemish</option>
<option value="French">French</option>
<option value="Frisian">Frisian</option>
<option value="Fulfulde">Fulfulde</option>
<option value="Gaelic Manx">Gaelic Manx</option>
<option value="Gaelic Scot">Gaelic Scot</option>
<option value="Galician">Galician</option>
<option value="Georgian">Georgian</option>
<option value="German">German</option>
<option value="Greek">Greek</option>
<option value="Greenlandic">Greenlandic</option>
<option value="Guarani">Guarani</option>
<option value="Gujarati">Gujarati</option>
<option value="Haitian Creole">Haitian Creole</option>
<option value="Hausa">Hausa</option>
<option value="Hawaiian">Hawaiian</option>
<option value="he, iw*">he, iw*</option>
<option value="Hebrew">Hebrew</option>
<option value="Hindi">Hindi</option>
<option value="Hmong">Hmong</option>
<option value="Hungarian">Hungarian</option>
<option value="Ibibio">Ibibio</option>
<option value="Icelandic">Icelandic</option>
<option value="id, in*">id, in*</option>
<option value="Igbo">Igbo</option>
<option value="Indonesian">Indonesian</option>
<option value="Interlingua">Interlingua</option>
<option value="Interlingue">Interlingue</option>
<option value="Inuktitut">Inuktitut</option>
<option value="Inupiak">Inupiak</option>
<option value="Irish">Irish</option>
<option value="Italian">Italian</option>
<option value="Japanese">Japanese</option>
<option value="Javanese">Javanese</option>
<option value="Kannada">Kannada</option>
<option value="Kanuri">Kanuri</option>
<option value="Kashmiri">Kashmiri</option>
<option value="Kazakh">Kazakh</option>
<option value="Khmer">Khmer</option>
<option value="Kinyarwanda">Kinyarwanda</option>
<option value="Kirghiz">Kirghiz</option>
<option value="Kirundi">Kirundi</option>
<option value="Konkani">Konkani</option>
<option value="Korean">Korean</option>
<option value="Kurdish">Kurdish</option>
<option value="Laothian">Laothian</option>
<option value="Latin">Latin</option>
<option value="Latvian">Latvian</option>
<option value="Lingala">Lingala</option>
<option value="Lithuanian">Lithuanian</option>
<option value="Macedonian">Macedonian</option>
<option value="Malagasy">Malagasy</option>
<option value="Malay">Malay</option>
<option value="Malayalam">Malayalam</option>
<option value="Maltese">Maltese</option>
<option value="Maori">Maori</option>
<option value="Marathi">Marathi</option>
<option value="Moldavian">Moldavian</option>
<option value="Mongolian">Mongolian</option>
<option value="Nauru">Nauru</option>
<option value="Nepali">Nepali</option>
<option value="Norwegian">Norwegian</option>
<option value="Occitan">Occitan</option>
<option value="Oriya">Oriya</option>
<option value="Oromo">Oromo</option>
<option value="Papiamentu">Papiamentu</option>
<option value="Pashto">Pashto</option>
<option value="Philipine">Philipine</option>
<option value="Polish">Polish</option>
<option value="Portuguese">Portuguese</option>
<option value="Punjabi">Punjabi</option>
<option value="Quechua">Quechua</option>
<option value="Rhaeto-Roman">Rhaeto-Roman</option>
<option value="Romanian">Romanian</option>
<option value="Russian">Russian</option>
<option value="Sami">Sami</option>
<option value="Samoan">Samoan</option>
<option value="Sangro">Sangro</option>
<option value="Sanskrit">Sanskrit</option>
<option value="Serbian">Serbian</option>
<option value="Serbian">Serbian</option>
<option value="Sesotho">Sesotho</option>
<option value="Setswana">Setswana</option>
<option value="Shona">Shona</option>
<option value="Sindhi">Sindhi</option>
<option value="Sinhalese">Sinhalese</option>
<option value="Siswati">Siswati</option>
<option value="Slovak">Slovak</option>
<option value="Slovenian">Slovenian</option>
<option value="Somali">Somali</option>
<option value="Spanish">Spanish</option>
<option value="Sundanese">Sundanese</option>
<option value="Swahili">Swahili</option>
<option value="Swedish">Swedish</option>
<option value="Syriac">Syriac</option>
<option value="Tagalog">Tagalog</option>
<option value="Tajik">Tajik</option>
<option value="Tamazight">Tamazight</option>
<option value="Tamil">Tamil</option>
<option value="Tatar">Tatar</option>
<option value="Telugu">Telugu</option>
<option value="Tetun">Tetun</option>
<option value="Thai">Thai</option>
<option value="Tibetan">Tibetan</option>
<option value="Tigrinya">Tigrinya</option>
<option value="Tonga">Tonga</option>
<option value="Tsonga">Tsonga</option>
<option value="Turkish">Turkish</option>
<option value="Turkmen">Turkmen</option>
<option value="Twi">Twi</option>
<option value="Uighur">Uighur</option>
<option value="Ukrainian">Ukrainian</option>
<option value="Urdu">Urdu</option>
<option value="Uzbek">Uzbek</option>
<option value="Venda">Venda</option>
<option value="Vietnamese">Vietnamese</option>
<option value="Volapük">Volapük</option>
<option value="Welsh">Welsh</option>
<option value="Wolof">Wolof</option>
<option value="Xhosa">Xhosa</option>
<option value="yi, ji*">yi, ji*</option>
<option value="Yiddish">Yiddish</option>
<option value="Yoruba">Yoruba</option>
<option value="Zulu">Zulu</option>
</select>
                      </div>
                    </div>
                  </div>
                  <!-- block2 -->
                  <div class="form-group DS-contact-right">
                    <label class="control-label">Language Combination</label>
                    <div class="controls">
                        <div class="input-group">
                      <span class="input-group-addon"><i class="fa fa-language"></i></span>
                        <input type="text" class="form-control" id="langcomb" placeholder="Language Combination ">
                      </div>
                    </div>
                  </div>

                </div>


                <!-- row-block-6 -->
                <div class="DS-clrar-20"></div>
                <div class="row DS-row-reduse">
                    <!-- block1 -->
                  <div class="form-group DS-contact-left">
                    <label class="control-label">Rate Per Hour <span class="DS-star">*</span></label>
                    <div class="controls">
                        <div class="input-group">
                      <span class="input-group-addon"><i class="fa fa-usd"></i></span>
                        <input type="text" class="form-control" id="rate" placeholder="Rate per Hour ">
                      </div>
                    </div>
                  </div>
                  <!-- block2 -->
                  <div class="form-group DS-contact-right">
                    <label class="control-label">Experience<span class="DS-star">*</span></label>
                    <div class="controls">
                        <div class="input-group">
                      <span class="input-group-addon"><i class="fa fa-database"></i></span>
                        <input type="text" class="form-control" id="experience" placeholder="Experience ">
                      </div>
                    </div>
                  </div>

                </div>


                 <!-- row-block-7 -->
                <div class="DS-clrar-20"></div>
                <div class="row DS-row-reduse">
                    <!-- block1 -->
                  <div class="form-group DS-contact-left">
                    <label class="control-label">Street Address</label>
                    <div class="controls">
                        <div class="input-group">
                      <span class="input-group-addon"><i class="fa fa-map-marker"></i></span>
                        <input type="text" class="form-control" id="addr" placeholder="Street Address ">
                      </div>
                    </div>
                  </div>
                  <!-- block2 -->
                  <div class="form-group DS-contact-right">
                    <label class="control-label">City</label>
                    <div class="controls">
                        <div class="input-group">
                      <span class="input-group-addon"><i class="fa fa-location-arrow"></i></span>
                        <input type="text" class="form-control" id="city" placeholder="City  ">
                      </div>
                    </div>
                  </div>

                </div>


                <!-- row-block-6 -->
                <div class="DS-clrar-20"></div>
                <div class="row DS-row-reduse">
                    <!-- block1 -->
                  <div class="form-group DS-contact-left">
                    <label class="control-label">State</label>
                    <div class="controls">
                        <div class="input-group">
                      <span class="input-group-addon"><i class="fa fa-bookmark-o"></i></span>
                        <input type="text" class="form-control" id="state" placeholder="State">
                      </div>
                    </div>
                  </div>
                  <!-- block2 -->
                  <div class="form-group DS-contact-right">
                    <label class="control-label">Country</label>
                    <div class="controls">
                        <div class="input-group">
                      <span class="input-group-addon"><i class="fa fa-flag-o"></i></span>
                        <input type="text" class="form-control" id="country" placeholder="Country ">
                      </div>
                    </div>
                  </div>

                </div>


                <!-- row-block-7 -->
                <div class="DS-clrar-20"></div>
                <div class="row DS-row-reduse">
                    <!-- block1 -->
                  <div class="form-group DS-contact-left">
                    <label class="control-label">ZIP</label>
                    <div class="controls">
                        <div class="input-group">
                      <span class="input-group-addon"><i class="fa fa-code"></i></span>
                        <input type="text" class="form-control" id="zip" placeholder="ZIP">
                      </div>
                    </div>
                  </div>
                  <!-- block2 -->
                  <div class="form-group DS-contact-right">
                    <label class="control-label">Available on Weekdays</label>
                    <div class="controls">
                        <div class="input-group">
                      <span class="input-group-addon"><i class="fa fa-calendar-o"></i></span>
                        <select name="Available on Weekdays" id="weekdays" class="form-control">
                            <option value="Select">Select</option>
                            <option value="Yes">Yes</option>
                            <option value="No">No</option>
                        </select>
                      </div>
                    </div>
                  </div>

                </div>


                <!-- row-block-8 -->
                <div class="DS-clrar-20"></div>
                <div class="row DS-row-reduse">
                    <!-- block1 -->
                  <div class="form-group DS-contact-left">
                    <label class="control-label">Available on Weekends</label>
                    <div class="controls">
                        <div class="input-group">
                      <span class="input-group-addon"><i class="fa fa-calendar-o"></i></span>
                        <select name="Available on Weekdays" id="weekends" class="form-control">
                            <option value="Select">Select</option>
                            <option value="Yes">Yes</option>
                            <option value="No">No</option>
                        </select>
                      </div>
                    </div>
                  </div>

                    <!-- block2 -->
                 <!--  <div class="form-group DS-contact-right">
                    <label class="control-label">Cost Per Hour<span class="DS-star">*</span>
                    <div class="DS-qust_emplye">
                            <div class="wrapper">
                              <i class="fa fa-question-circle"></i>
                              <div class="tooltip">The cost you quote is only for audio hour not for work hour</div>
                            </div>
                            </div>
                          </label>
                    <div class="controls">
                        <div class="input-group">
                      <span class="input-group-addon"><i class="fa fa-usd"></i></span>
                        <input type="text" class="form-control" id="hrcost" placeholder="Cost Per Hour">
                      </div>
                    </div>
                  </div> -->

                   <div class="form-group DS-contact-right">
                    <label class="control-label">Native Language</label>
                    <div class="controls">
                        <div class="input-group">
                      <span class="input-group-addon"><i class="fa fa-language"></i></span>
                        <input type="text" class="form-control" id="nativelang" placeholder="Native Language ">
                      </div>
                    </div>
                  </div>
                  
                </div>

              <!-- row-block-10 -->
                <div class="DS-clrar-20"></div>
                <div class="row DS-row-reduse">
                    <!-- block1 -->
                  <div class="form-group DS-contact-left">
                    <label class="control-label">Nationality</label>
                    <div class="controls">
                        <div class="input-group">
                      <span class="input-group-addon"><i class="fa fa-flag-o"></i></span>
                        <input type="text" class="form-control" id="nation" placeholder="Nationality">
                      </div>
                    </div>
                  </div>
                  <!-- block2 -->
                 

                </div>

                <div class="DS-clrar-20"></div>
                <div class="form-group ">
                      <label class="control-label">Comment</label>
                  <div class="controls">
                      <div class="input-group">
                    <span class="input-group-addon"><i class="glyphicon glyphicon-pencil"></i></span>
                      <textarea id="comment" class="form-control " rows="4" cols="78" placeholder="Comments:Write about your experience in detail"></textarea>

                    </div>
                  </div>
                </div>
                    <div class="DS-clrar-20"></div>
                    <div class="DS-aligncenter DS-row-reduse"><div id="submit" class="DS-h-btn2 cta hvr-float-shadow DS-contact-submitbtn">Grow With Us</div></div>
                    <div class="DS-quote-fmsg fmsg" name="fmsg" id="fmsg"></div>

                    <div class="DS-res-clear-25"></div>


                    <script type="text/javascript" src="js/jquery.min.js"></script>
                      <script type="text/javascript" src="js/LanguageEmpFormValidation.js"></script>
                      <script type="text/javascript">
                              function isNumberKey(evt)
                              {
                                var charCode = (evt.which) ? evt.which : event.keyCode;
                               console.log(charCode);
                                  if (charCode != 46 && charCode != 45 && charCode > 31
                                  && (charCode < 48 || charCode > 57))
                                   return false;

                                return true;
                              }
                      </script>

                <!-- form-end -->
            </div>