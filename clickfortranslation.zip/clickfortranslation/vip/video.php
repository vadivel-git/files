 <!-- button -->

            <div class="DS-clrar-50 DS-space-reduce-320"></div>

            <div class="row">

              <a href="http://clickfortranslation.com/Translation-Quote.php" onClick=”_gaq.push([‘_trackEvent’, ‘button1’, ‘click’, ‘button’, ‘1’]);"><div class="DS-btn DS-btn-primary" style="float: left;">

                 <!--<i class="fa fa-cloud-upload" style="font-size: 20px; margin: 0 8px 0 0;"></i>-->Translate now!<br>

                <span class="DS-button-text">Get Started Within A Minute</span>

              </div></a>

              <!-- video -->

<button class="video-button" data-toggle="modal" 

   data-target="#myModal2">

  <i class="fa fa-play-circle-o"style="font-size: 50px; color:#000; float: left;"></i> 

                    <a class="DS-youtube">We were featured in the 

                      <span class="DS-min">'Fox Business Network' - Watch Now </span></a>





</button>



<div class="modal fade" id="myModal2" tabindex="-1" role="dialog" 

   aria-labelledby="myModalLabel" aria-hidden="true">

   <div class="modal-dialog">

      <div class="modal-content">

   <div class="modal-body as-modal-body" style="padding:7px">
           <div  class="close my-close" data-dismiss="modal">&times;</div>
            <!--<iframe id="youtubevideo" title="YouTube video player" width="100%" height="400px" style="margin:0; padding:0; box-sizing:border-box; border:0; -webkit-border-radius:5px; -moz-border-radius:5px; border-radius:5px;" src="//www.youtube.com/embed/tIsl1OJWK5c?r rel=0&amp;showsearch=0&amp;autohide=2&amp;autoplay=0&amp;controls=1&amp;fs=1&amp;loop=0&amp;showinfo=0&amp;color=red&amp;theme=light&amp;wmode=transparent" frameborder="0" allowfullscreen="" seamless=""></iframe>-->
            <div class="embed-responsive embed-responsive-16by9">
                            <iframe id="video" src="https://player.vimeo.com/video/174468087?title=0&byline=0&portrait=0" width="640" height="360" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>
                            </div>
    </div>

        

      </div><!-- /.modal-content -->

  </div><!-- /.modal-dialog -->

</div><!-- /.modal -->



              

              

            </div>
			
			
			
				<script>

$('.close').click(function () {
  $('#myModal2').hide();
  $('#myModal2 iframe').attr("src", jQuery("#myModal2 iframe").attr("src"));
});
</script>
