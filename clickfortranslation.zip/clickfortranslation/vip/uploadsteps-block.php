      <!-- upload-steps -->
      <section class="DS-upload-steps">
         <div class="DS-clrar-50"></div>
        <div class="container">
          <div class="row DS-margin">
            <h3 class="DS-heade3"><a href="http://clickfortranslation.com/how-it-works.php" target="_blank">Easy Steps To Get Our Services </h3>
            <div class="DS-h-msg-slogen">Click for Quality Translations Quickly & Securely</div>
          </div>

          <div class="row">
            <div class="DS-clrar-20"></div>
            <div class="DS-clrar-20"></div>
            <div class="col-xs-6 col-sm-3 DS-easystep-width DS-last">
              <div class="DS-us-icon"><a href="http://clickfortranslation.com/Translation-Quote.php" target="_blank"><i class="
             fa fa-file-text-o" ></i></a></div>
              <div class="DS-small-head"><a href="http://clickfortranslation.com/Translation-Quote.php" target="_blank">Free Quote </a></div>
              <p class="DS-small-text colour-v ">
                  Get a free quote and  delivery details  when <br> you fill out details <br> about <br> your project. </p>
            </div>

            <div class="col-xs-6 col-sm-3 DS-easystep-width">
              <div class="DS-us-icon"><i class="fa fa-pencil-square-o" ></i></div>
              <div class="DS-small-head">
Confirmation E-Mail </div>
              <p class="DS-small-text"> We'll send a confirmation mail together with your turnaround details <br>for your <br>verification.</p>
            </div>

            <div class="col-xs-6 col-sm-3 DS-easystep-width DS-both">
              <div class="DS-us-icon"><!--a href="#" target="_blank"--><i class="fa fa-credit-card" ></i></a></div>
              <!--a href="" target="_blank"--><div class="DS-small-head">
      Pay Online</div></a>
              <p class="DS-small-text">Once verified, invoice will be sent for payment process. You can pay through credit cards, debit cards or PayPal.</p>
            </div>

            <div class="col-xs-6 col-sm-3 DS-easystep-width">
              <div class="DS-us-icon"><!--a href="" target="_blank"--><i class="fa fa-envelope-o" ></i></a></div>
              <!--a href="#" target="_blank"--><div class="DS-small-head">
     Get Output</div></a>
              <p class="DS-small-text">Receive output straight  from your email. A physical copy can be <br>sent as deemed <br>necessary</p>
            </div>

          </div>
      </div>
      <div class="DS-clrar-50 DS-space-reduce"></div>
      </section>