<section class="DS-home-baner">

        <div class="DS-clrar-50 DS-space-reduce-320"></div>

        <div class="DS-res-clear-25"></div>

        <div class="DS-clrar-50 DS-space-reduce"></div>

        <div class="container">



          <div class="row">

            <h1 class="DS-h-head1">60,000+ Fulfilled Customers and Growing</h1>

            <div class="DS-h-slogen">Find out why thousands of customers admire our topnotch translation services!</div>

            <div class="DS-clrar-20  DS-space-reduce-320"></div>

            <div class="DS-clrar-20"></div>

       <div style="width: 308px; margin: 0 auto;">     <a href="http://clickfortranslation.com/Translation-Quote.php"><div class="DS-btn DS-btn-primary">

                <!--<i class="fa fa-cloud-upload" style="font-size: 20px; margin: 0 8px 0 0;"></i>-->Translate now!<br>

                <span class="DS-button-text"> Get Started Within A Minute </span>

              </div></a></div>

          </div>

          <!-- offera-block -->

          <div class="row DS-h-offer">

              <div class="col-lg-3 col-sm-3">

                <div class="services_item first fl">

              <div class="services_item_regular">         

                <p class="services_item_title"><a href="http://clickfortranslation.com/discounts-and-offers.php">Red Hot Deals</a></p>

                <div class="services_backgr">

                  <p class="services_item_pic">

                    <a href="http://clickfortranslation.com/discounts-and-offers.php">

                      <img src="css/images/services/indoor_offer.png" alt="">

                    </a>

                  </p>

                  <div class="services_pic_line"> </div>

                  <p class="services_item_desc">

                Sizzling hot offers and huge chunk of discounts every time you place an order!

                  </p>

                </div>

              </div>

              <div class="services_item_hover">

                <h3 class="services_item_title_hover"><a href="http://clickfortranslation.com/discounts-and-offers.php">Red Hot Deals</a></h3>

                <p class="services_item_pic_hover">

                  <a href="http://clickfortranslation.com/discounts-and-offers.php">

                    <img src="css/images/services/offer.png" alt="">

                  </a>

                </p>

                <p class="services_item_link_hover">

                  <a href="http://clickfortranslation.com/discounts-and-offers.php">Grab It Now</a>

                </p>

              </div>                    

            </div>

        </div>



      <div class="col-lg-3 col-sm-3">

            <div class="services_item first fl">

          <div class="services_item_regular">         

            <p class="services_item_title"><a href="http://clickfortranslation.com/features.php">Special Features</a></p>

            <div class="services_backgr">

              <p class="services_item_pic">

                <a href="http://clickfortranslation.com/features.php">

                  <img src="css/images/services/indoor_features.png" alt="">

                </a>

              </p>

              <div class="services_pic_line"> </div>

              <p class="services_item_desc">

              Full suite of benefits minus the extra cost. Flawless results always within your budget.

              </p>

            </div>

          </div>

          <div class="services_item_hover">

            <h3 class="services_item_title_hover"><a href="http://clickfortranslation.com/features.php">Special Features</a></h3>

            <p class="services_item_pic_hover">

              <a href="http://clickfortranslation.com/features.php">

                <img src="css/images/services/Features.png" alt="">

              </a>

            </p>

            <p class="services_item_link_hover">

              <a href="http://clickfortranslation.com/features.php">Find More</a>

            </p>

          </div>                    

        </div>

      </div>



      <div class="col-lg-3 col-sm-3">

            <div class="services_item first fl">

          <div class="services_item_regular">         

            <p class="services_item_title"><a href="http://clickfortranslation.com/why-choose-us.php">WHY CHOOSE US</a></p>

            <div class="services_backgr">

              <p class="services_item_pic">

                <a href="http://clickfortranslation.com/why-choose-us.php">

                  <img src="css/images/services/indoor_why_choose_us.png" alt="">

                </a>

              </p>

              <div class="services_pic_line"> </div>

              <p class="services_item_desc">

              Unmatched translation quality with expert linguists and superb 24/7 customer service all rolled into one.

              </p>

            </div>

          </div>

          <div class="services_item_hover">

            <h3 class="services_item_title_hover"><a href="http://clickfortranslation.com/why-choose-us.php">why choose us</a></h3>

            <p class="services_item_pic_hover">

              <a href="http://clickfortranslation.com/why-choose-us.php">

                <img src="css/images/services/why_choose_us.png" alt="">

              </a>

            </p>

            <p class="services_item_link_hover">

              <a href="http://clickfortranslation.com/why-choose-us.php">Know more</a>

            </p>

          </div>                    

        </div>

      </div>



      <div class="col-lg-3 col-sm-3">

            <div class="services_item first fl">

          <div class="services_item_regular">         

            <p class="services_item_title"><a href="http://clickfortranslation.com/how-it-works.php">How it works</a></p>

            <div class="services_backgr">

              <p class="services_item_pic">

                <a href="http://clickfortranslation.com/how-it-works.php">

                  <img src="css/images/services/indoor_how_it_works.png" alt="">

                </a>

              </p>

              <div class="services_pic_line"> </div>

              <p class="services_item_desc">

             Easy-to-use service without the hassle. Ordering takes less than a minute.

              </p>

            </div>

          </div>

          <div class="services_item_hover">

            <h3 class="services_item_title_hover"><a href="http://clickfortranslation.com/how-it-works.php">How it works</a></h3>

            <p class="services_item_pic_hover">

              <a href="http://clickfortranslation.com/how-it-works.php">

                <img src="css/images/services/how_it_works.png" alt="">

              </a>

            </p>

            <p class="services_item_link_hover">

              <a href="http://clickfortranslation.com/how-it-works.php">Take a look</a>

            </p>

          </div>                    

        </div>

      </div>



          </div>

        </div>

      </section>