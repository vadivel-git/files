<?php
   include_once "common_setting.php"; //$COMMONSETTING, $CRMSERVERPATH
   include_once "lib/common_array.php";
   include_once "lib/functions.php";
   if(!isset($page)){
        $page = "quote";
   }
   $sitename = $serverdetail['HTTP_HOST'];
   $site_name = preg_replace('/^www\./', '', $sitename);
   $sitename=trim($site_name);
// $COMMONSETTINGJSON = file_get_contents($CRMSERVERPATH."common_setting.php");
// $COMMONSETTING = json_decode($COMMONSETTINGJSON, true);
   $dbwebsitedetails = getwebsitedetails($sitename);
  
   $dbmailid = $dbwebsitedetails['email'];
    // if(!$dbmailid=='' || $dbmailid=='salescs@vananservices.com'){
   if(!$dbmailid){
        $dbmailid = 'support@vananservices.com';
   }
   //To be replaced 
   //$dbmailid = 'inquiries@vananservices.com';
   if(isset($serverdetail['REQUEST_URI'])){
      $parts = parse_url($serverdetail['REQUEST_URI']);
      parse_str($parts['query'], $query);
      $target1 =  $query['target'];
      $target2 = explode(",",$target1);
      $sourceurl = $query['othersource'];
      $targeturl = $query['othertarget'];
   }
 
    ?>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<link rel="stylesheet" href="<?php echo $CRMSERVERPATH; ?>css/crm-form.css?<?php echo $COMMONSETTING['RANDOMNO'];?>">
<script> var jc = jQuery.noConflict(); </script>
<form name="crmform" id="crmform">
<div class="col-xs-12 col-sm-12 col-lg-8 fnew">
<div class="fs">
   <?php if ($page == "upload") { ?>
    <h2 class="chat-link"><?php if(isset($QUOTETITLE[$sitename]['uploadpage'])) {echo $QUOTETITLE[$sitename]['uploadpage']; } else{  ?>Fill in your details in the form below and upload your file. Or feel free to contact our <a id="full-view-button" href="javascript:void(null)" onclick="parent.LC_API.open_chat_window()"><span id="open-icon"></span><span id="open-label">24/7 Live chat </span></a>  service for any query.<?php } ?></h2>
   <?php } else { ?>
      <h2 class="chat-link"><?php if(isset($QUOTETITLE[$sitename]['quotepage'])) { echo $QUOTETITLE[$sitename]['quotepage'];  } else  {?>To accommodate your immediate order, contact us through our <a id="full-view-button" href="javascript:void(null)" onclick="parent.LC_API.open_chat_window()"><span id="open-icon"></span><span id="open-label"><br>24/7 online chat </span></a>  service or just fill out the required information below.<?php } ?></h2>
   <?php }
   if($sitename == 'vananinc.com')
      echo "<h2 class='chat-linknew'>You may also Share your files by sending your dropbox link to <span id='open-label'>support@vananinc.com</span></h2>";
   else{
    ?>
   <h2 class="chat-linknew">You can either upload your files here or send your dropbox link to  <span id="open-label"><?php echo $dbmailid; ?></span></h2>
   <?php } ?>
   <input type="hidden" name="version" value="<?php echo $_REQUEST['version'] ?>" />
   <div class="row">
      <div class="form-group col-lg-6">
         <label for="qnamecrm" class="control-label">Full Name</label><span class="ms">&#9733;</span>
         <div class="input-group"> <span class="input-group-addon">
            <i class="fa fa-user"></i>
            </span>
            <input type="text" class="form-control" id="qnamecrm" name="name_crm" placeholder="Your full name" data-placement="bottom"> 
         </div>
      </div>
      <div class=" form-group col-lg-6">
         <label for="qemailcrm" class="control-label">Email id</label><span class="ms">&#9733;</span>
         <div class="input-group"> <span class="input-group-addon">
            <i class="fa fa-envelope-o"></i>
            </span>
            <input type="email" class="form-control" id="qemailcrm" name="Email_crm" placeholder="Your email id" data-placement="bottom"> 
         </div>
      </div>
   </div>
   <!-- Row block1-->
   <div class="row">
      <div  class="form-group col-lg-6 plain-select">
         <label for="qcountryscrm" class="control-label">Country</label>
         <div class="input-group">
            <span class="input-group-addon"><i class="fa fa-flag-o"></i></span>
            <select id="qcountryscrm" name="country_crm" class="form-control plain-select" data-placement="bottom">
               <option value="">Select Country</option>
               <?php
                  foreach ($country as $country_key => $country_val) {
                      echo '<option value="' . $country_key . '">' . $country_val . '</option>';
                  }
                  ?>
            </select>
         </div>
      </div>
       
       
       <div class=" form-group col-lg-6">
         <label for="qphonecrm" class="control-label">Phone No</label>
         <div class="input-group"> <span class="input-group-addon">
            <i class="fa fa-phone"></i>
            </span>
            <input type="text" class="form-control" id="qphonecrm" name="Phone_crm" placeholder="Your Area code - Phone No" data-placement="bottom"> 
         </div>
      </div>
       
       
<!--      <div class=" form-group col-xs-12 col-lg-6">
         <div class="col-lg-4 nopadding">
            <label class="control-label">Area Code</label>
            <div class="input-group"> <span class="input-group-addon"><i class="fa fa-code"></i></span>
               <input type="email" class="form-control" id="acodecrm" name="areacode_crm" placeholder="Ex: 332" data-placement="bottom"> 
            </div>
         </div>
         <div class="col-xs-12 col-lg-7 nopadding pull-right padding980">
            <label class="control-label">Phone No</label>
            <div class="input-group"> <span class="input-group-addon"><i class="fa fa-phone"></i></span>
               <input type="email" class="form-control" id="qphonecrm" name="Phone_crm" placeholder="Your Phone No" data-placement="bottom"> 
            </div>
         </div>
      </div>-->
   </div>
   <!-- Row block2-->
   <div class="row">
      <div class=" form-group col-lg-6 plain-select">
         <label for="qsourcecrm" class="control-label"> Translate From </label><span class="ms">&#9733;</span>
         <div class="input-group">
            <span class="input-group-addon"><i class="fa fa-language"></i></span>
            <select name="language_crm" id="qsourcecrm" class="form-control plain-select" data-placement="bottom">
               <option value="">Select Source Language</option>
               <?php
                  foreach ($language as $language_key => $language_val) {
                     $lang_selected = '';
                      if($language_key == $query['source']){$lang_selected ='selected="selected"';} 
                      echo '<option value="' . $language_key . '" '.$lang_selected.'>' . $language_val . '</option>';
                  }
                  ?>
                  <option value="999"  <?php  if($query['source'] == 'Other Source Language') {?> id="othersource1" name="othersourcelang" selected="selected" <?php } ?> >Other Source Language</option>
            </select>
         </div>
      </div>
        
      <div class=" form-group col-lg-6 plain-select">
         <label for="qtargetcrm" class="control-label"> Translate To</label><span class="ms">&#9733;</span>
         <div class="input-group">
            <span class="input-group-addon"><i class="fa fa-language"></i></span>
            <select name="qtarget_crm" id="qtargetcrm" class="form-control plain-select select2"  multiple="multiple" data-placement="bottom">
               <?php
                  foreach ($language as $language_key => $language_val) {
                     $lang_selected = '';
                     foreach($target2 as $target3){
                       if($language_key == $target3){$lang_selected ='selected="selected"';} 
                     }
                      echo '<option value="' . $language_key . '"'.$lang_selected.'>' . $language_val . '</option>';
                  }
                  ?>
                  <option value="999" <?php if(in_array("Other Target Language", $target2) == 'Other Target Language'){?> id="othertarget1" name="othertargetlang" selected="selected" <?php } ?>>Other Target Languages</option>
            </select>
         </div>
      </div>
      
   </div>
   
   <div class="row">
      <div  class="form-group col-lg-6 plain-select">
         <label for="audioVideo" class="control-label">File type</label><span class="ms">&#9733;</span>
         <div class="input-group">
            <span class="input-group-addon"><i class="fa fa-flag-o"></i></span>
            <select id="audioVideo" name="audioVideo" class="form-control plain-select" data-placement="bottom">
               <option value="">Select File type</option>
               <option value="3">Document</option>
               <option value="4">Audio/Video</option>
            </select>
         </div>
      </div>
       </div>
   <!-- Row block-->
   <div class="row">
      <div class=" form-group col-lg-6" id="othercrm">
         <label for="otherlangcrm" class="control-label">Other Source Language</label>
         <div class="input-group">
            <span class="input-group-addon"><i class="fa fa-language"></i></span>
            <input class="form-control"  name="otherlang_crm" id="otherlangcrm" placeholder="Enter Your Language" type="text"  value="<?php echo $sourceurl;?>" data-placement="bottom">
         </div>
      </div>
      
      <div class=" form-group col-lg-6" id="other1crm">
         <label for="otherlang1crm" class="control-label">Other target Language</label>
         <div class="input-group">
            <span class="input-group-addon"><i class="fa fa-language"></i></span>
            <input class="form-control" name="otherlang1_crm" id="otherlang1crm" placeholder="Enter Your Language" value="<?php echo $targeturl;?>" type="text" data-placement="bottom">
         </div>
      </div>
   </div>
   <!-- multipart upload start-->
   <?php
      date_default_timezone_set('America/New_York');
      echo "<script>var folderPath='".date("dmY")."/"."'; datetime='".date("D M d Y h:i:s")."' </script>";
    
      ?>
   <link rel="stylesheet" type="text/css" href="<?php echo $CRMSERVERPATH;?>/css/checkout.css?<?php echo $RANDOMNO ?>">
   <link href="<?php echo $CRMSERVERPATH;?>css/my-styleNew.css?<?php echo $COMMONSETTING['RANDOMNO'] ?>" rel="stylesheet" type="text/css">
   <input type="hidden" id="quoteflag" name="quoteflag" value="0">
   <input type="hidden" id="quoteflagnew" name="quoteflagnew" value="0">
   <input type="hidden" id="recordkey" name="recordkey" value="">
   <input type="hidden" id="networkerrflag" name="networkerrflag" value="0">
   
   <input type="hidden" name="channel_id" id="channel_id" value="<?php if(isset($_POST['channel']) && $_POST['channel'] !='') echo $_POST['channel'];  else if($page == "upload") echo 2;else echo 1; ?>">
         <?php
            echo "<script> var crmRootpath = '".$CRMSERVERPATH."';
                           var crmFormsavepath = '".$CRMFORMSUBMITURL."';
 
                           var successpath = '".$QUOTEMAILERINFO[$sitename]['successpage'] ."';
                           var sitename = '".$protocol.$sitefullname."'
             </script>";
            if (isset($_COOKIE['devtest'])) {
                echo "<script> var update_url = '".$CRMFORMSUBMITURL."save/crmformdata'  </script>";
                echo '<script type="text/javascript" src="' . $CRMSERVERPATH . 'js/crm-upload2.js?' . $COMMONSETTING['RANDOMNO'] . '"></script>';
            } else {
                echo "<script> var update_url = '".$CRMFORMSUBMITURL."save/crmformdata'  </script>";
                echo '<script type="text/javascript" src="' . $CRMSERVERPATH . 'js/crm-upload.js?' . $COMMONSETTING['RANDOMNO'] . '"></script>';
            }
         ?>
   <div onclick="addFiles();" id="fileuploader" class="DS-color-id chooser" style="cursor: pointer; height: 45px; width: 150px; ">
      <input type="file" id="file" style="display:none;" multiple onChange="upload()">
   </div>
   <div class="col-sm-12">
   <div class="row">
      <label class="control-label"><strong>Note:</strong> You may upload multiple files at the same time.</label>
      </div>
   </div>
   
    <div class="upload_error" style="color:#e0271d; font-weight:bold; padding:5px 0px; display: none;">
      Network connection Error .. Please check your internet connection ...
   </div>
   <input type="hidden" name="referalsite" value="<?php echo $_SERVER['SERVER_NAME'];?>"></input>
   <input type="hidden" id="uploadprogress" value="0"></input>
   <div class="col-lg-12" id="fileuploadfield">
      <div class="panel panel-default" style="display:none;" id="info">
         <div class="row up-head">
            <div class="col-xs-8 col-sm-8 col-lg-8">File Name/URL</div>
            <div class="col-xs-4 col-sm-4 col-lg-4">Status</div>
         </div>
      </div>
   </div>
   <div id="my-welcome-message2" class="vd-welcome">
      <div class="modal-body no-padding vd-pad">
         <div class="pop">
            <img src="<?php echo $CRMSERVERPATH ?>img/vd-upload-pop.png" alt="upload" title="upload" class="vd-upload-pop">
            <div class="vd-hilights-pop">
           <!--  <div style="color:#e0271d; font-weight:bold; padding:5px 0px; display: none;" class="upload_error">
               Network connection Error .. <br>Please check your internet connection ...
            </div> -->
               <div id="uploading_msg">
                   Kindly don't close this window. 
               <br><b>Uploading in Progress...</b>
               <div id="completedfiletext"></div>
               </div>
               <div class="upload_errmsg" style="display: none;">
               There seems to be a problem with your request. <br>  Here are a few other options for you.<br> <br>
               <div style="text-align:left">
                  1. Upload your files <a href="AlternateUpload.php" target="_blank" style="color:blue"><u> here</u> </a> <br>
                  2. OR Share your dropbox link to support@vananservices.com <br>
                  3. OR Simply<span onClick="$('#open-icon').trigger('click')" style="color:blue;cursor: pointer"><u> Chat with us </u> </span> anytime.
               </div>
               </div>
               
            </div>
            <!-- Kindly don't close this page as your file(s) are being uploaded. -->
            <img src="<?php echo $CRMSERVERPATH ?>img/loading.gif" alt="upload gif" title="loading" class="vd-up-gif">
         </div>
      </div>
   </div>
   <!-- multipart upload end -->
   <div class="row ">
      <!-- block1 -->
      <!-- block1 -->
      <div class="col-xs-12">
         <label class="control-label"></label>
         <div class="checkbox pull-left">
            <label for="qnotecrm">
            <input id="qnotecrm" type="checkbox">   I would like to have <b>'Notarization Certificate'</b> for my files. </label>
         </div>
      </div>
       <div class="col-xs-12">
         <label class="control-label"></label>
         <div class="checkbox pull-left">
            <label for="qmailcrm">
            <input id="qmailcrm" type="checkbox">  I would like you to <b>'Mail the files'</b> to my Doorsteps. </label>
         </div>
      </div>
      
   </div>
   <div class="row">
        <div class="col-sm-12">
            <textarea name="msg_crm"  id="qmailmsgcrm" rows="5" cols="60" placeholder="* Door_Number,\nStreet_Name,\nCity,State,\nZip Code,\nCountry."></textarea>
            <div class="tooltip-con" style="top: 512px;">
                <div class="tooltip" id="tooladdr"></div></div>
        </div>
   </div>
   <div class="row">
       <br>
       <div class="form-group col-sm-12">
           <label for="qcommentcrm" class="control-label"><b>Comment</b></label>
           <div class="controls">
               <div class="input-group">
                   <span class="input-group-addon"><i class="fa fa-comments-o"></i></span>
                   <textarea name="msg" class="form-control " id="qcommentcrm" rows="4" cols="78" placeholder="Enter your Comment here" data-placement="bottom"></textarea>
               </div>
           </div>
       </div>
   </div>
   <div class="row">
      <div class="form-group col-sm-12">
         <div class="accordion_containercrm" style="border:none">
            <div class="accordion_headcrm accord-toggle"> <span class="plusminuscrm"><i class="fa fa-angle-down" aria-hidden="true"></i></span>  Need your Files Soon? Tell us some additional information.</div>
            <div class="accordion_bodycrm" style="display: none;">
               <div class="row">
                  <div class="form-group col-lg-6">
                     <label for="qtatcrm" class="control-label">Turnaround Time</label>
                     <div class="controls">
                        <div class="input-group">
                           <span class="input-group-addon"><i class="fa fa-clock-o"></i></span>
                           <div id="datetimepickercrm">
                              <span class="add-on">
                              <input data-format="dd/MM/yyyy" id="qtatcrm" placeholder="Pick the Date" class="" style="margin-bottom:0px; width: 100%; padding: 6px 12px;" type="text"></span>
                           </div>
                        </div>
                     </div>
                  </div>
                 
                  
                     <!-- block1 -->
                     <div class="form-group col-lg-6">
                        <label for="qpurposecrm" class="control-label">Purpose</label>
                        <div class="controls">
                           <div class="input-group">
                              <!--   <span class="input-group-addon"><i class="fa fa-question-circle"></i></span> -->
                              <span class="input-group-addon">
                                 <div class="wrapper">
                                    <i class="fa fa-question-circle"></i>
                                    <div class="tooltip"> Choose the purpose of translation for(eg).Academic,Certificate,immigration,Major needs etc..</div>
                                 </div>
                              </span>
                              <input class="form-control" id="qpurposecrm" placeholder="Eg: Immigration, Legal, etc." type="text" data-placement="bottom">
                              <!-- Select -->
                              <!--select id="qservice" class="form-control">
                                 <option value="">Select</option>
                                 <option value="Audio/Video">Audio/Video</option>
                                 <option value="Book">Book</option>
                                 <option value="Certified">Certified</option>
                                 <option value="Certificate">Certificate</option>
                                 <option value="Document">Document</option>
                                 
                                 
                                 <option value="Immigration">Immigration</option>
                                 <option value="Others">Others</option>
                                 </select-->
                              <!-- Select -->
                           </div>
                        </div>
                     </div>
                 
               </div>
               
            </div>
         </div>
      </div>
   </div>
   
   <div class="row text-center">
      <div  id="qsubmitcrm" class="crm-get-btn"><?php if ($page == "upload") { ?> Translate My Files  <?php } else { ?>
      Get A Quote <?php } ?></div>
      <input type="hidden" name="service" id="service" value="translation">
      <input type="hidden" name="formid" id="formid" value="crmform">
      <input type="hidden" name="serviceid" id="serviceid" value="1">
 
      <input type="hidden" name="crmpage" id="crmpage" value="<?php echo $page ?>">
      <!-- <button type="submit" id="qsubmitcrm" class="btn btn-success">Submit</button> -->
      <div class="DS-quote-fmsg" name="qfmsg_crm" id="qfmsgcrm"></div>
   </div>
   <!-- Form End-->
   <br>
  
</div>
<br>
<div class="row">
      <div class="col-sm-6 text-right">
         <p class="spp-para">&#10004; 100% Privacy - We secure your information.</p>
      </div>
      <div class="col-sm-6 text-left">
         <p class="spp-para">
            <input type="checkbox" id="qcopycrm">&nbsp; Subscribe to receive latest updates.
         </p>
      </div>
   </div>
<br>
   </div>
</form>
<!-- <link rel="stylesheet" href="<?php echo $CRMSERVERPATH; ?>css/bootstrap-multiselect.css?<?php echo $COMMONSETTING['RANDOMNO'];?>"> -->
<link rel="stylesheet" href="<?php echo $CRMSERVERPATH; ?>css/select2.min.css?<?php echo $COMMONSETTING['RANDOMNO'];?>">
<link rel="stylesheet" href="<?php echo $CRMSERVERPATH; ?>css/bootstrap-datetimepicker.min.css?<?php echo $COMMONSETTING['RANDOMNO'];?>">
<link rel="stylesheet" href="<?php echo $CRMSERVERPATH; ?>css/accordion.css?<?php echo $COMMONSETTING['RANDOMNO'];?>">
<script type="text/javascript" src="<?php echo $CRMSERVERPATH; ?>js/crmquote.js?<?php echo $COMMONSETTING['RANDOMNO'];?>"></script>
<script type="text/javascript" src="<?php echo $CRMSERVERPATH; ?>js/bootstrap-datetimepicker.min.js?<?php echo $COMMONSETTING['RANDOMNO'];?>"></script> 
<script type="text/javascript" src="<?php echo $CRMSERVERPATH; ?>js/multipleselect.js?<?php echo $COMMONSETTING['RANDOMNO'];?>"></script>    
<script type="text/javascript" src="<?php echo $CRMSERVERPATH; ?>js/validation.js?<?php echo $COMMONSETTING['RANDOMNO'];?>"></script>   
<!-- <script type="text/javascript" src="<?php echo $CRMSERVERPATH; ?>js/bootstrap-multiselect.js?<?php echo $COMMONSETTING['RANDOMNO'];?>"></script>   -->
<script type="text/javascript" src="<?php echo $CRMSERVERPATH; ?>js/select2.full.min.js?<?php echo $COMMONSETTING['RANDOMNO'];?>"></script>
<script type="text/javascript" src="<?php echo $CRMSERVERPATH; ?>js/jquery.MultiFile.js?<?php echo $COMMONSETTING['RANDOMNO']; ?>"></script> 
<script type="text/javascript" src="<?php echo $CRMSERVERPATH; ?>js/accordion.js?<?php echo $COMMONSETTING['RANDOMNO']; ?>"></script>  
<script type="text/javascript" src="<?php echo $CRMSERVERPATH; ?>js/bootstrap.min.js?<?php echo $COMMONSETTING['RANDOMNO'];?>"></script>  
<script type="text/javascript">
   function isNumberKeyq(evt) {
       var charCode = (evt.which) ? evt.which : event.keyCode;
       console.log(charCode);
       if (charCode != 45 && charCode > 31 && (charCode < 48 || charCode > 57))
           return false;
       return true;
   }
</script>
<script type="text/javascript">
      jc(document).ready(function () {
      jc('[data-toggle="tooltip"]').tooltip()
        // jc('#qtargetcrm').multiselect({
        //     maxHeight: 200
        // });
//        jc(".select2").select2();
          jc(".select2").select2({ placeholder: "Select Target Language" });
//        $(".select2-search--inline").text("Select Target Language");
//        jc('#qtargetcrm').change(function () {
//            $(".select2-search--inline").text("");
//            if($('.select2-selection__rendered').text() == ''){
//                $(".select2-search--inline").text("Select Target Language");
//            }
//        });
        
         jc('#datetimepickercrm').datetimepicker({
            startDate: new Date(datetime),
            format :'yyyy-MM-dd',
        }).on('changeDate', function (e) {
            jc(this).datetimepicker('hide');
        });
      jc('#qtatcrm').click(function () {
            var headerHeight = jc('#fileuploadfield').css('height');
            var qmailmsgheight = jc('#qmailmsgcrm:visible').css('height');
            if(qmailmsgheight){
               var height = parseInt(headerHeight) +  parseInt(qmailmsgheight) ;
            }else{
               var height = parseInt(headerHeight);
            }
      
     
          headerHeightnew = (parseInt(height) +120) + 'px';
       jc('.bootstrap-datetimepicker-widget.dropdown-menu').css("margin-top", headerHeightnew);
  });
   });
    var textAreas = document.getElementsByTagName('textarea');
    Array.prototype.forEach.call(textAreas, function (elem) {
        elem.placeholder = elem.placeholder.replace(/\\n/g, '\n');
    });
</script>
