<?php
error_reporting(0);
include_once "../lib/serverconnect.php";
include_once "../lib/functions.php";
date_default_timezone_set('America/New_York');
$createddate = date('Y-m-d H:i:s', strtotime("-30 minutes"));
$createddate2 = date('Y-m-d H:i:s', strtotime("-60 minutes"));
$query = "SELECT * FROM enquiry_transcription_payment WHERE flag=0 AND email !='' AND ip_address != '61.12.78.82' AND ip_address != '115.249.1.65' AND email NOT LIKE ('%vananservices.com%') AND email NOT LIKE ('%.vanan@gmail%') AND email != 'cr@advantagebroadcasting.tv' AND (created BETWEEN '$createddate2' AND '$createddate')";
$sql = mysql_query($query);
$temp = array('email','purpose','source','priceviewed','price');
$temptrl = array('email','filetype','purpose','source','target','pagecount','minutes','rush','notary','mailed','mailingcountry','mailingaddress','verbatime','timecode');
$filesarray = array();
$cus_emails = array();
while ($row = mysql_fetch_array($sql))
{
  $values = array();
  $service_type = '';
  $site = '';
  $filelist='';
  if($row['service'] == "Translation"){
      //$temp = $temptrl;      
        if($row['filetype'] == "Document"){
            $arr = array_diff($temptrl, array('minutes','verbatime','timecode'));
            $temp = $arr;
        }else{
            $arr = array_diff($temptrl, array('pagecount','rush','notary','mailed','mailingcountry','mailingaddress'));
            $temp = $arr;
        }
  }
  

  foreach ($temp as $val)
  {
	if($row[$val]){
	    if($val == 'ufile'){
                $filesarray = @explode(",",$row[$val]);
                $filecount=1;

                foreach ($filesarray as $singlefile) {
                    $singlefile = @explode("#-#",$singlefile);
                    $dispName = substr($singlefile[0], strpos($singlefile[0], 'xx_') + 3);
                    $filelist .= $filecount.") ".$dispName."<br>";

                    $filecount++;
                }

                $values['Files'] = $filelist;
            }else{
                $values[$val] = $row[$val];
            }
            $service_type = $row['service'];
            $site = str_ireplace('www.', '', $row['siteurl']);
            if(getwebsitedetails($site)) {
                $website = getwebsitedetails($site);
                $site = $website['sitename'];
            }
            $logo = 'http://'.str_ireplace('www.', '', $row['siteurl']) . '/img/DS-logo.png';
	}
  }
  $values = array_filter($values);

  $email_title = ucwords(str_replace("_", " ", $service_type));
  $ipaddress = $row['ip_address'];  
  $message = "";  
  $message = '<html>
<head>
	<title>Sample ' . $email_title . ' Enquiry - ' . $site . '</title>
	<style type="text/css">
		a, a:link, a:visited {
			color:#000000;
		}
		.ReadMsgBody {
			background-color: #E8E8E8;
		}
	</style>
</head>
<body bgcolor="#e8e8e8" style="background-color:#e8e8e8;">
	<br>
	<br>
	<table width="100%" bgcolor="#e8e8e8" cellpadding="0" cellspacing="0" border="0">
		<tr>
			<td>
				<!--HEADER-->
				<table cellpadding="0" cellspacing="0" border="0" width="620" align="center" bgcolor="#FFFFFF">
					<tr>
						<td colspan="3" height="9"></td>
					</tr>
					<tr>
						<td width="19">&nbsp;</td>
						<td width="587">
							<table align="center" style="text-align: center;" cellpadding="0" cellspacing="0" border="0">
								<tr>
									<td>
										<img src="' . $logo . '"  border="0" />
									</td>
								</tr>
								<tr>
									<td colspan="3" height="21"></td>
								</tr>
								<tr>
									<td colspan="2">
										<table align="center" style="font-family:Helvetica, Arial, sans-serif; background: #f2f7fa;border-bottom: 1px solid #e9edf0; width: 616px;    height: auto;    margin: 0 auto;    padding: 15px 0;">
											<tr>
												<td>
													<h1 style="text-align: center; margin: 0px; padding: 0 0 0 23px; font-size: 20px; font-weight: 300;  text-transform: capitalize;">' . $email_title . ' Payment Enquiry (Not Submitted) </h1>
												</td>
											</tr>
										</table>
									</td>
								</tr>
							</table>
						</td>
						<td width="19">&nbsp;</td>
					</tr>
					<tr>
						<td colspan="3" height="15"></td>
					</tr>
				</table>
				<table cellpadding="0" cellspacing="0" border="0" width="624" align="center" bgcolor="#FFFFFF">';
    $values = array_filter($values);
    $curren_cus_email = '';
    foreach ($values as $k => $v)
    {
        if($k == 'email'){
            $curren_cus_email = $v;
        }
	    $message .= '<tr>
				  <td align="left" style="padding:6px; width:170px;">
					  <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:170px;">' . ucwords($k) . ' : </p>
				  </td>
				  <td align="left" style="padding:6px;">
					  <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">' . $v . '</p>
				  </td>
			  </tr>
			  <tr>
				  <td height="5"></td>
			  </tr>';
    }

    $site_name = $site;
    $channelno = 17;
    $qservice =  $service_type;
    $email = $curren_cus_email;

    $hiddenservice = $servicelist[ucfirst($qservice)];
    $sitechannel = "abchidFS" . encrypt('__sitename_' . $site_name . '__ __channel_' . $channelno . '__ __service_' . $hiddenservice . '__ __cstemail_' . $email . '__ __ipaddress_' . $ipaddress . '__', 'vanancrm*encrypt') . "abchidFE";

    $message .= '<tr>
				  <td height="5"></td>
			  </tr>
			  </table>
                          <span class="'.$sitechannel.'" id="'.$sitechannel.'"></span>
			</body>
			</html>';
$to = 'support@vananservices.com,vananbackup@gmail.com';
$subject = $email_title . ' payment enquiry - ' . $site;
//sendMail($to, $subject, $message, "", "", "", "");
$headers = "From: support@vananservices.com" . "\r\n";
$headers .= "Reply-to: $curren_cus_email" . "\r\n";
$headers .= "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type: text/html; charset=iso-8859-1" . "\r\n";
if(!in_array($curren_cus_email, $cus_emails)){
    @mail($to, $subject, $message, $headers);
}
$cus_emails[]      =  $curren_cus_email;
}
?>