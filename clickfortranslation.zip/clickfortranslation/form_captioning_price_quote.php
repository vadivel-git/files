<?php
error_reporting(0);
include_once "common_setting.php";
include_once "lib/common_array_price_quote.php";
include_once "lib/functions.php";

if (substr($_SERVER['REMOTE_ADDR'], 0, 4) == '127.'
    || $_SERVER['REMOTE_ADDR'] == '::1') {
    $RANDOMNO       = rand();
    $channel_click  = "payment";
    $sitename       = 'localhost/projects/clickfortranslation/';
    $freequote      = 'show';
    echo "<script>var successpath = 'localhost/projects/clickfortranslation';</script>";
}else {
    $RANDOMNO       = $COMMONSETTING['RANDOMNO'];
    $channel_click  = ($_POST['freequote'] == 'show') ? "free quote" : "payment";
    $sitename       = $serverdetail['HTTP_HOST'];
    echo "<script>var successpath = '".$QUOTEMAILERINFO[$sitename]['successpage']."';</script>";
}


$page       = (isset($page)) ? $page : "quote";
$protocol   = (isset($serverdetail['HTTPS']) && $serverdetail['HTTPS'] != 'off') ? "https://" : "http://";
$pay_email          = isset($_POST['requestvariable']['customer_email']) ? $_POST['requestvariable']['customer_email'] : "";
$customer_dashboard = isset($_POST['requestvariable']['customer_dashboard']) ? $_POST['requestvariable']['customer_dashboard'] : "";
$pay_file_selected  = isset($_POST['requestvariable']['file_type'])? $_POST['requestvariable']['file_type'] : "";
$pay_sourcelan      = isset($_POST['requestvariable']['source_lang'])?$_POST['requestvariable']['source_lang']:"";
$pay_targetlan      = isset($_POST['requestvariable']['target_lang'])?$_POST['requestvariable']['target_lang']:"";

$trclang            = array('90','313','312','106','266','265','63','64','65','66','67','68','151','17','12','13','14','15','16','120','153','275','351');
$site_name          = preg_replace('/^www\./', '', $sitename);$sitename=trim($site_name);
date_default_timezone_set('America/New_York');
echo "<script>var folderPath='".date("dmY")."/"."';var datetime='".date("D M d Y h:i:s")."'; </script>";
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo $CRMSERVERPATH; ?>js/sweetalert.min.js?<?php echo $COMMONSETTING['RANDOMNO'];?>"></script>
<link rel="stylesheet" type="text/css" href="<?php echo $CRMSERVERPATH; ?>css/sweetalert.css">
<link type="text/css" href="<?php echo $CRMSERVERPATH; ?>css/checkout.css?<?php echo $RANDOMNO;?>" rel="stylesheet">
<link type="text/css" href="<?php echo $CRMSERVERPATH; ?>css/my-styleNew.css?<?php echo $RANDOMNO;?>" rel="stylesheet">
<link type="text/css" href="<?php echo $CRMSERVERPATH; ?>css/chosen.css?<?php echo $RANDOMNO;?>" rel="stylesheet">
<link type="text/css" href="<?php echo $CRMSERVERPATH; ?>css/captioning_price_quote.css?<?php echo $RANDOMNO;?>" rel="stylesheet">
<script type="text/javascript" src="<?php echo $CRMSERVERPATH; ?>js/chosen.jquery.js?<?php echo $RANDOMNO;?>"></script>
<script type="text/javascript">    var jc = jQuery.noConflict();
    var language_list       = <?php echo json_encode($language); ?>;
    var country_list        = <?php echo json_encode($country); ?>;    
    var serverPath          = <?php echo json_encode($CRMSERVERPATH); ?>;
    var originPath          = <?php echo json_encode($sitename); ?>;
    var channel_click       = <?php echo json_encode($channel_click); ?>;    
    var trclang             = <?php echo json_encode($trclang); ?>;
    var crmRootpath         = '<?php echo $CRMSERVERPATH; ?>';
//    var successpath         = '<?php //echo $QUOTEMAILERINFO[$sitename]['successpage']; ?>//';
    var sitename            = '<?php echo $sitename; ?>';    
    var update_quote        = '<?php echo $CRMSERVERPATH;?>captioning_update_price_quote.php';
</script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<body>
<div class="fr-container">
    <div class="col-xs-12 col-sm-8 col-md-8 col-lg-8 fr_no_padd">
        <div class="fr_title">Project Details</div>
        <?php $action = $CRMSERVERPATH."paypal/payment_v2.0.php"; ?>
        <form id="captioningForm" action="<?php echo $action; ?>" class="" method="post"  role="form">
            <input type="hidden" id="site_namee" name="site_namee" value="<?php echo $sitename; ?>">
            <input type="hidden" id="quoteflag" name="quoteflag" value="0">
            <input type="hidden" id="quoteflagnew" name="quoteflagnew" value="0">
            <input type="hidden" id="recordkey" name="recordkey" value="">
            <input type="hidden" id="networkerrflag" name="networkerrflag" value="0">
            <input type="hidden" id="item_name_1" name="item_name_1" value="captioning">
            <input type="hidden" id="item_number_1" name="item_number_1" value="">
            <input type="hidden" id="paymentamt" name="paymentamt"  value="">
            <input type="hidden" id="amount" name="amount"  value="1">
            <input type="hidden" id="totalfilelength" name="totalfilelength"  value="">
            <input type="hidden" id="filelength" name="filelength"  value="">
            <input type="hidden" id="formtype" name="formtype" value="payment">
            <input type="hidden" id="mode" name="mode" value="payment">
            <input type="hidden" id="service" name="service" value="captioning">
            <input type="hidden" id="uploadat" name="uploadat" value="fileupload">
            <!--<input type="hidden" id="mini_subamt" name="mini_subamt" value="0.00">-->
            <input type="hidden" id="version_payment" name="uploaddat" value="<?php echo $_POST['version_payment']; ?>">
            <input type="hidden" id="freequote" name="freequote" value="">
            <input type="hidden" id="camethrough" name="camethrough" value="<?php echo $channel_click; ?>">
            <?php date_default_timezone_set('America/New_York'); ?>
            <input type="hidden" name="referalsite" value="<?php echo $_SERVER['SERVER_NAME'];?>">
            <input type="hidden" id="cst_db" name="cst_db" value="<?php echo $customer_dashboard; ?>">
            <input type="hidden" id="uploadprogress" value="0">
            <input type="hidden" id="trgt_unitcost" value="0.00">
            <input type="hidden" id="trgt_totamt" value="0.00">
            <input type="hidden" id="trc_totamt" value="0.00">
            <input type="hidden" id="nota_subamt" value="0.00">
            <input type="hidden" id="script_cost" value="0.00">
            <input type="hidden" id="tcode_cost" value="0.00">
            <input type="hidden" id="notapro_subamt" value="0.00">
            <input type="hidden" id="mfile_subamt" value="0.00">
            <input type="hidden" id="timecode_subamt" value="0.00">
            <input type="hidden" id="subamttot" value="0.00">
            <input type="hidden" id="offerpct" value="0" >
            <input type="hidden" id="offerval" value="0" >
            <input type="hidden" id="finalround" value="0" >
            <input type="hidden" id="siteprtcl" value="<?php echo $protocol; ?>" >
            <input type="hidden" id="trans_price" name="trans_price" value="">
            <input type="hidden" id="agent_ref" name="agent_ref" >
            <div class="fr_overall">
                <div class="row">
                    <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 fr_form-group">
                        <div class="form-group plain-select">
                            <select name="srclang" id="srclang" data-placeholder="Select source language *" class="form-control del-time capturedata">
                                <option value="" ></option>
                                <?php
                                foreach ($language as $language_key => $language_val) {
                                    $lang_selected = '';
                                    if($pay_sourcelan == $language_val){$lang_selected ='selected="selected"';}                                    
                                    echo '<option value="' . $language_key . '"'.$lang_selected. '>' . $language_val . '</option>';
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 fr_form-group">
                        <div class="form-group plain-select">
                            <select name="trglang" id="trglang" data-placeholder="Select target language *" class="form-control del-time capturedata" multiple>
                                <option value="" ></option>
                                <?php
                                foreach ($language as $language_key => $language_val) {
                                    $lang_selected = '';
                                    if($pay_targetlan == $language_val){$lang_selected ='selected="selected"';}                                    
                                    echo '<option value="' . $language_key . '"'.$lang_selected. '>' . $language_val . '</option>';
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    </div>
                <div class="row">
                    <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 fr_form-group docfile">
                        <div class="form-group plain-select">
                            <select name="formatting" id="formatting" data-placeholder="Select Formatting *" class="form-control del-time capturedata">
                                <option value="" selected disabled>Select output format *</option>
                                <option value="Standalone">Standalone</option>
                                <option value="Embedded">Embedded</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 fr_form-group fr_extra_form-group">
                        <!--<div class="form-group">
                            <span class="input-group" >
                                <input id="prfilelength" name="prfilelength" title="" class="form-control onlynumbers del-time capturedata tooltiptrigger" type="text" placeholder="Enter file length in minutes *" data-original-title="Enter your file length in minutes. Eg: for 01:20:07, the file length is 81 minutes." >
                                <span class="input-group-addon fr_input-group-addon" >
                                    <div class="wrappervd">
                                        <a title="Enter your file length in minutes. Eg: for 01:20:07, the file length is 81 minutes." rel="tooltip">
                                            <i class="fa fa-question-circle"></i>
                                        </a>
                                    </div>
                                </span>
                            </span>
                        </div>-->
                        <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6 fr_nopadding fr_extra_form-group">
                            <div class="form-group">
                                <span class="input-group" >
                                    <input id="hours" name="hours" title="" class="form-control onlynumbers del-time capturedata" type="text" placeholder="Hours" >
                                </span>
                            </div>
                        </div>
                        <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6 fr_right_pa fr_extra_form-group">
                            <div class="form-group">
                                <span class="input-group" >
                                    <input id="minutes" name="minutes" title="" class="form-control onlynumbers del-time capturedata" type="text" placeholder="Minutes" >
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 fr_form-group docfile">
                        <div class="form-group plain-select">
                            <select name="specification_pay" id="specification_pay" data-placeholder="Select purpose" class="form-control del-time capturedata chozn-select" multiple>
                                <?php
                                foreach ($purposes as $key=>$val){
                                    echo '<option value="'.$key.'">'.$val.'</option>';
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 fr_form-group">
                        <div class="col-xs-7 col-sm-7 col-md-7 col-lg-7 form-group trcl displaynone">
                            <label>
                                <input type="checkbox" name="needtrc" id="needtrc" class="del-time displaynone">
                                <span id="trchave" class="displaynone">I have the transcription</span>
                                <span id="trlhave" class="displaynone">I have the translation</span>
                            </label>
                        </div>
                        <div class="col-xs-5 col-sm-5 col-md-5 col-lg-5 form-group freetrial displaynone">
                            <label>
                                <input type="checkbox" name="frtrial" id="frtrial" class="del-time capturedata">
                                <span>Free trial
                                    <div class="wrappervd">
                                        <a rel="tooltip" title="Your order is eligible for a free trial. Try our service with a free sample and order with conviction."> <i class="fa fa-question-circle"></i></a>
                                    </div>
                                </span>
                            </label>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
                <div class="uploadhere dv_border">
                    <!--FILE UPLOAD START-->
                    <div class="row " style="margin: 0 0 12px 0;">
                        <div class="col-sm-4 dv_col-sm-4">
                            <div onclick="addFiles();" id="fileuploader" class="DS-color-id chooser dv_addfiles">
                                <img src="<?php echo $CRMSERVERPATH ?>img/uploadfiles.png" >
                                <input type="file" id="file" style="display:none;" multiple onChange="upload()">
                            </div>
                        </div>
                        <div class="col-sm-12 text-center ">
                            <div class="sp1"></div>
                            <label class="control-label control-label-vd"><strong class="red_color">Note:</strong> You may upload multiple files at the same time.</label>
                            <br><label class="control-label control-label-vd">You may also upload your files later.</label>
                            <div class="sp1"></div>
                        </div>
                    </div>

                    <div class="upload_error" style="color:#e0271d; font-weight:bold; padding:5px 0px; display: none;">
                        Network connection Error .. Please check your internet connection ...
                    </div>
                    <div class="col-lg-12 dv_nopad" id="fileuploadfield">
                        <div class="panel panel-default" style="display:none;" id="info">
                            <div class="row up-head">
                                <div class="col-xs-4 col-sm-4 col-lg-4 fname">File Name</div>
                                <div class="col-xs-4 col-sm-4 col-lg-4 text-center mediafile">File Length</div>
                                <div class="col-xs-4 col-sm-4 col-lg-4 text-center">Status</div>
                            </div>
                        </div>
                    </div>
                    <div id="my-welcome-message2" class="displaynone vd-welcome">
                        <div class="modal-body no-padding vd-pad">
                            <div class="pop">
                                <img src="<?php echo $CRMSERVERPATH ?>img/vd-upload-pop.png" alt="upload" title="upload" class="vd-upload-pop">
                                <div class="vd-hilights-pop">
                                    <!--  <div style="color:#e0271d; font-weight:bold; padding:5px 0px; display: none;" class="upload_error">
                                        Network connection Error .. <br>Please check your internet connection ...
                                     </div> -->
                                    <div id="uploading_msg">
                                        Kindly don't close this window.
                                        <br><b>Uploading in Progress...</b>
                                        <div id="completedfiletext"></div>
                                    </div>
                                    <div class="upload_errmsg" style="display: none;">
                                        There seems to be a problem with your request. <br>  Here are a few other options for you.<br> <br>
                                        <div style="text-align:left">
                                            1. Upload your files <a href="AlternateUpload.php" target="_blank" style="color:blue"><u> here</u> </a> <br>
                                            2. OR Share your dropbox link to support@vananservices.com <br>
                                            3. OR Simply<span onClick="$('#open-icon').trigger('click')" style="color:blue;cursor: pointer"><u> Chat with us </u> </span> anytime.
                                        </div>
                                    </div>

                                </div>
                                <!-- Kindly don't close this page as your file(s) are being uploaded. -->
                                <img src="<?php echo $CRMSERVERPATH ?>img/loading.gif" alt="upload gif" title="loading" class="vd-up-gif">
                            </div>
                        </div>
                    </div>
                    <!---------------FILE UPLOAD END--------------->
                </div>
                <div class="clearfix"></div>
                <div class="row filecomment displaynone">
                    <div class="form-group form-modifier col-lg-12">
                        <textarea name="filecomments" id="filecomments" class="form-control capturedata textarea-modifier" rows="5" placeholder="Mention the names or other specific words in your files if any."></textarea>
                    </div>
                </div>
                <div id="delivery-timeline" class="row fr_row_bg  displaynone">
                    <div class="col-lg-12">
                        <b class="ui-turn">Turnaround time</b>
                        <div class="clearfix"></div>
                        <br>
                        <div class="col-xs-12 col-sm-12 col-md-7 col-lg-7">
                            <label>
                                <p class="pull-left fr_pull-left"> <input type="radio" class="capturedata form-check-input del-time" name="deliveryReq" value="option1" checked=""> </p>
                                <p class="fr_pay-left">Standard delivery of <span id="tat-val"></span></p>
                            </label>
                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-5 col-lg-5">
                            <label>
                                <p class="pull-left fr_pull-left"><input type="radio" id="expedited"  class="capturedata form-check-input del-time" name="deliveryReq" value="option2" ></p>
                                <p class="fr_pay-left">Expedited Service</p>
                            </label>
                        </div>
                    </div>
                <div class="col-xs-12 col-sm-10 col-md-8 col-lg-6 fr_form-group pull-right">
                <div class="col-xs-12 col-sm-7 col-md-7 col-lg-10 fr_form-group">
                    <input id="fileupload_tat" class="capturedata form-control expeditedblk displaynone" type="text" placeholder="Select the Date *">
                </div>
                </div>
                </div>
            </div>
        </form>
    </div>
    <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4 fr_lg_col-4 pull-right fr_nopadding">
        <div class="fr_title">Your Summary</div>
        <div class="fr_sumarry no-summary">
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 fr_default_txt">
                <div class="qt_msg">Enter the details to get the price quote for your project</div>
                <!--<div class="fr_CV_msg qt_mailinfo displaynone" onclick="parent.LC_API.open_chat_window()"><b>Chat with us</b></div>-->
                <div class="fr_CV_msg qt_mailinfo displaynone ui-chat" onclick="parent.LC_API.open_chat_window()"><i class="fa fa-comments cv-icon-blink" aria-hidden="true"></i> <b>Chat with us</b></div>
                <div class="qt_mailinfo displaynone">Or</div>
                <div class="qt_mailinfo displaynone fr_fo_si">Enter your email ID to receive a quote from us.</div>
            </div>
        </div>
        <div class="fr_sumarry_overall">
            <div class="order-summary displaynone">
                <div class="fr_sumarry">
                    <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8">Captioning cost ($<span id="trgtunitcost_disp"></span> /min)</div>
                    <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right">$<span id="trgt_tot"></span></div>
                </div>
                <div class="fr_sumarry displaynone script_amount-pr">
                    <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 " id="needtr">Transcription</div>
                    <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right">$<span id="script_amount"></span></div>
                </div>
                <div class="fr_sumarry displaynone tcode_amount-pr">
                    <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 " >Timecode</div>
                    <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right">$<span id="tcode_amount"></span></div>
                </div>
                <div class="fr_sumarry sub_amt-pr">
                    <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 ">Subtotal</div>
                    <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right">$<span id="sub_amt"></span></div>
                </div>
                <!--<div class="fr_sumarry displaynone minimum-pr">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 fr_txt_word_CV minimumcost">
                        Minimum order cost applies for orders less than $<span class="mini_sub_amt">50</span>.
                    </div>
                </div>
                <div class="fr_sumarry displaynone mediafile minimum-pr">
                    <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 ">Minimum order cost</div>
                    <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right">$<span class="mini_sub_amt"></span></div>
                </div>-->


                <div class="fr_sumarry displaynone coupval-pr">
                    <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 ">Coupon discount (-<span id="ofpct"></span>)</div>
                    <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right">$<span id="offerval_value"></span></div>
                </div>
                <div class="fr_sumarry displaynone coupval-pr">
                    <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 ">Offer price</div>
                    <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right">$<span id="sub_total"></span></div>
                </div>
                <div class="fr_sumarry">
                    <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 ">Transaction fee
                        <div class="wrappervd">
                            <a rel="tooltip" title="Transaction fee is 5% of total order cost. This fee covers credit card, banking partners, and PayPal processing fees"> <i class="fa fa-question-circle"></i></a>
                        </div>
                    </div>
                    <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right">$<span id="trans_rate"></span></div>
                </div>
                <div class="fr_sumarry fr_sumarry_bg">
                    <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 "><b>Grand total</b></div>
                    <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right"><b>$<span id="price_display"></span></b></div>
                </div>
                <?php if(in_array($sitename,$couponcodesites)){ ?>
                <div class="col-lg-12 float-label">
                    <div class="coupon-blk">
                        <div class="control">
                            <div class="input-group">
                                <input id="couponcode" name="couponcode" class="form-control ui-control form-control-success capturedata" placeholder="Coupon code" >
                                <span class="input-group-addon" id="applycoupon">apply</span>
                            </div>
                        </div>
                        <span id="couponmsg"></span>
                    </div>
                </div>
                <?php } ?>
            </div>

            <div class="fr_sumarry u-email displaynone">
                <div class="col-xs-11 col-sm-11 col-md-11 col-lg-11 fr_nopadding fr_centerpage">
                    <div class="form-group fr-nomargin">
                        <input id ="paytc_qemailcrm" name="paytc_qemailcrm" value="<?php echo $pay_email; ?>" placeholder="Your Email ID *" title="" class="capturedata form-control fr-nomargin" type="text">
                    </div>
                </div>
            </div>
        </div>
        <div class="fr_sumarry pt displaynone">
            <?php           
            $btnclass = 'col-xs-12 col-sm-12 col-md-12 col-lg-12';
            if($freequote == "show"){ $btnclass = 'col-xs-6 col-sm-6 col-md-6 col-lg-6';
            ?>
            <div id="emailquote-btn" class="col-xs-6 col-sm-6 col-md-6 col-lg-6 fr_nopadding btnhand">
                <div class="qsubmitcrm fr_email_btn" id="emailquote" value="Email Quote" >Email the Quote</div>
            </div>
            <?php } ?>
            <div id="proceedpayment-btn" class="<?php echo $btnclass; ?> text-right fr_nopadding btnhand">
                <div class="qsubmitcrm fr_email_btn fr_color" id="proceedpayment" value="Proceed to Payment" >Proceed to Payment</div>
            </div>
        </div>
        <div class="fr_sumarry qt displaynone">
            <div class="fr_nopadding btnhand">
                <div class="qsubmitcrm fr_email_btn" id="getquote" value="Get Quote" >Get Quote</div>
            </div>
        </div>
        <div class="fr_sumarry up displaynone">
            <div class="fr_nopadding btnhand">
                <div class="fr_email_btn" >Uploading...</div>
            </div>
        </div>
        <div class="fr_sumarry pr displaynone">
            <div class="fr_nopadding btnhand">
                <div class="processing-st" >Processing...</div>
            </div>
        </div>
    </div>
    <?php if($customer_dashboard == ''){
        $wwwurl = (in_array($sitename,$wwwwebsites))?"www.":"";
        ?>
        <div class="col-xs-12 col-sm-8 col-md-8 col-lg-8 text-center pad-top15 underl">
            <a href="<?php echo $protocol.$wwwurl.$site_name; ?>/Captioning-Send-Files.php">If you're an existing customer, upload files right away by
            <span class="text-primary">clicking here</span></a>
        </div>
    <?php } ?>
</div>
<link rel="stylesheet" href="<?php echo $CRMSERVERPATH; ?>css/jquery.datetimepicker.css?<?php echo $COMMONSETTING['RANDOMNO'];?>">
<script type="text/javascript" src="<?php echo $CRMSERVERPATH; ?>js/captioning_price_quote.js?<?php echo $RANDOMNO;?>"></script>
<script type="text/javascript" src="<?php echo $CRMSERVERPATH; ?>js/jquery.datetimepicker.full.js?<?php echo $COMMONSETTING['RANDOMNO'];?>"></script>
<script>
    paytc_resetVariables();
    jc('#fileupload_tat').datetimepicker({
        timepicker: false,
        format: 'm-d-Y',
        formatDate: 'm-d-Y',
        minDate: '-1970-01-01', // yesterday is minimum date
        scrollMonth : false,
        scrollInput : false

    });
    jc( document ).on('keydown','.onlynumbers', function(e) {
        if (e.keyCode == 46 || e.keyCode == 8 || e.keyCode == 9
            || e.keyCode == 27 || e.keyCode == 13
            || (e.keyCode == 65 && e.ctrlKey === true)
            || (e.keyCode >= 35 && e.keyCode <= 39)){
            return;
        }else {
            // If it's not a number stop the keypress
            if (e.shiftKey || (e.keyCode < 48 || e.keyCode > 57) && (e.keyCode < 96 || e.keyCode > 105 )) {
                e.preventDefault();
            }
        }
    });

    var textAreas = document.getElementsByTagName('textarea');
    Array.prototype.forEach.call(textAreas, function(elem) {
        elem.placeholder = elem.placeholder.replace(/\\n/g, '\n');
    });
</script>

</body>
</html>
