<?php
    error_reporting(0);
    header("Access-Control-Allow-Origin: *");
	
    $quoteInfo = array();
    if(isset($_REQUEST['quoteflag'])){
        $SEND_QUOTE =  $_REQUEST['quoteflag'];
        if ($SEND_QUOTE) {
           $quoteInfo = unserialize(base64_decode($_REQUEST['quoteinfo']));
        }
    }
    $sitename='';
    include_once "lib/serverconnect.php";
    include_once "lib/common_array_price_quote.php";
    include_once "lib/functions.php";
    include_once "common_setting.php";

    $site_url   = $_REQUEST['sitename'];        
    $input = trim($site_url, '/');
    
    // If scheme not included, prepend it
    if (!preg_match('#^http(s)?://#', $input)) {
        $input = 'http://' . $input;
    }
    $urlParts = parse_url($input);
    // remove www
    $site_name = preg_replace('/^www\./', '', $urlParts['host']);


    if($sitename == 'vananinc.com'){
        $dbmailid = 'support@vananinc.com';
    }else{
        $dbmailid = 'support@vananservices.com';
    }


if (isset($_REQUEST['command'])) {
    $command = isset($_REQUEST['command']) ? strtolower($_REQUEST['command']) : '';
    if ($command == "updatefilecount") {
        $filescount = $_REQUEST['completedfilecnt'] . "/" . $_REQUEST['totalfilecnt'];
        // echo "UPDATE ".$quoteInfo['uptblname']." SET filescount='" . $filescount . "' WHERE  ".$quoteInfo['uptblprimarykey']."=" . $quoteInfo['quoteid'];
        mysql_query("UPDATE ".$quoteInfo['uptblname']." SET filescount='" . $filescount . "' WHERE  ".$quoteInfo['uptblprimarykey']."=" . $quoteInfo['quoteid']);
        //echo "UPDATE uploads SET upload_status = 1 WHERE FileName = '$_REQUEST[uploadedFile]' ";
       mysql_query("UPDATE uploads SET upload_status = 1 WHERE created_ts >= DATE_SUB(CURDATE(),INTERVAL 1 day) AND FileName = '$_REQUEST[uploadedFile]' ");

    }
    // $_POST["uploadflag"] = $_REQUEST['uploadflag'];
    die('cnt updated...');
}

    $website        = $QUOTEMAILERINFO[$site_name]['name'];
    
    $ipaddress      = $_SERVER['REMOTE_ADDR'];
    date_default_timezone_set('America/New_York');
    $createddate    = date('Y-m-d H:i:s');
    $browserdetail  = $_SERVER['HTTP_USER_AGENT'];

    if (isset($_REQUEST['fieldinfocommand'])) {
        $commandinfo = isset($_REQUEST['fieldinfocommand']) ? strtolower($_REQUEST['fieldinfocommand']) : '';
        $valuearray=array();
        if ($commandinfo == "updatefieldinfo") {
            $valuearray=$_REQUEST['savedata'];
            $crmservice = ucfirst($valuearray['service']);
            $Fieldinfo_UniqeID = uniqid();
            if($valuearray["entryval"]){
                switch ($valuearray["fieldname"]) {
                    case 'paytc_qemailcrm':
                        $fieldname  = "email";
                        $fieldvalue = $valuearray["qemail"];
                        break;
                    case 'paytc_qnamecrm':
                        $fieldname  = "name";
                        $fieldvalue = $valuearray["qname"];
                        break;
                    case 'paytc_qcountryscrm':
                        $fieldname  = "country";
                        $fieldvalue = $valuearray["qcountrys"];
                        break;
                    case 'qpurposecrm':
                        $fieldname  = "purpose";
                        $fieldvalue = $valuearray["qpurpose"];
                        break;
                    case 'paytc_acodecrm':
                        $fieldname  = "areacode";
                        $fieldvalue = $valuearray["acode"];
                        break;
                    case 'paytc_qphonecrm':
                        $fieldname  = "phone";
                        $fieldvalue = $valuearray["qphone"];
                        break;  
                    case 'fileuploader':
                        $fieldname  = "ufile";
                        $fieldvalue = $valuearray["filedetails"];
                        break;    
                    default:
                        
                        break;
                }
               // echo "UPDATE enquiry_transcription_payment SET " . $fieldname . " ='" . $fieldvalue . "' WHERE entryid='" . $valuearray["entryval"]."'";
                mysql_query("UPDATE enquiry_transcription_payment SET " . $fieldname . " ='" . $fieldvalue . "',modified='$createddate' WHERE entryid='" . $valuearray["entryval"]."'");
                die($valuearray["entryval"]);
            }else{
                if($valuearray["qemail"]){
                    if($website==''){
                        $website=$site_name;
                    }
                    mysql_query("INSERT INTO enquiry_transcription_payment(name,email,created,ip_address,website,entryid,phone,areacode,country,purpose,browserdetail,service,ufile)VALUES('".mysql_real_escape_string(htmlentities($valuearray["qname"])) . "','".mysql_real_escape_string(htmlentities($valuearray["qemail"])) ."','$createddate','$ipaddress','$website','$Fieldinfo_UniqeID','$valuearray[qphone]','$valuearray[acode]','$valuearray[qcountrys]','$valuearray[qpurpose]','$browserdetail','$crmservice','".mysql_real_escape_string(htmlentities($valuearray["filedetails"])) ."')");
            $lastinsertedid= mysql_insert_id();
            if($lastinsertedid){
               $entryid= $Fieldinfo_UniqeID;
            }
            $output = $entryid;
            }
             die($output);
        }
            //die('field updated...');
           
        }
      
        if ($commandinfo == "mailnetworkerror") {
            
            $valuearray=$_REQUEST['networkerrordata'];
            $crmservice = ucfirst($valuearray["service"]);
            $networkerrflag = $valuearray["networkerrflag"];
            $email = $valuearray["qemail"];
            $name = $valuearray["qname"];
            $country = $valuearray["qcountrys"];
            $purpose = $valuearray["qpurpose"];
            $acode = $valuearray["acode"];
            $qphone = $valuearray["qphone"];
            $entryval = $valuearray["entryval"];
            $filedetails = $valuearray["filedetails"];
            $fileuploadstatus = $valuearray["fileuploadstatus"];
            $uploadprogress = $valuearray["uploadprogress"];
            $crmpage = $valuearray["crmpage"];
			$uploaderrorresponse = $valuearray["uploaderrorresponse"];
            $uploadedfiledetails = $valuearray["uploadedfiledetails"];
            $to = 'support@vananservices.com,vananbackup@gmail.com';
            //$subject        = $website.' - '.$crmservice." - Alternate upload options "; 
            $subject        = $crmservice.' '.$QUOTEMAILERINFO[$site_name]['subject']." : Alternate Upload Options "; 
            if($crmpage =="upload"){
                $subject        =  str_replace("Quote","Upload",$subject);
            }
            $foldername = "log";
            $filename ="networkerror";
            if (!is_dir($foldername)) {
                mkdir($foldername, 0777, true);
            }
            $date=date('d-m-Y');    
            $logdata = "<$createddate> ## <$entryval> ## <$email> ## <$filedetails> ## <$fileuploadstatus> ## <$uploadprogress> 
            ## <$uploaderrorresponse> ## <$uploadedfiledetails>";
            file_put_contents($foldername.'/'.$filename.'_'.$date.'.txt', $logdata . PHP_EOL, FILE_APPEND);
            $neterrmailreplace = array('__NETERR_SITEURL__' => $site_name.'/AlternateUpload.php'
                           );
            $fileopen             = fopen("mailer/networkerror.html", "r");
            $networkerrmail_content = fread($fileopen, filesize("mailer/networkerror.html"));
            fclose($fileopen);
            $networkerrmsg    = strtr($networkerrmail_content, $neterrmailreplace);
            if(multi_attach_mail($to, $subject, $networkerrmsg, $email, $sitename,1))
            {
                die("1");
            }else{
                die("0");
            }
           

        }
          
    }

if (isset($_POST['uptype'])) {
    $name = isset($_POST['name']) ? $_POST['name'] : "";
    $email = isset($_POST['email']) ? $_POST['email'] : "";
    $countryno = isset($_POST['country']) ? $_POST['country'] : "";
    $contact = isset($_POST['phone']) ? $_POST['phone'] : "";
    $paytc_hfc = isset($_POST["paytc_hfc"]) ? $_POST["paytc_hfc"] : "";
    $tatdate = isset($_POST['tatdate']) ? $_POST['tatdate'] : "";
    $sitename = isset($_POST['sitename']) ? $_POST['sitename'] : "";    
    $upcomments = isset($_POST['upcomments']) ? $_POST['upcomments'] : "";
    $getid = isset($_POST['pid']) ? $_POST['pid'] : "";
    $service_name = isset($_POST['service_name']) ? $_POST['service_name'] : "";
    $expedited = isset($_POST['expedited']) ? $_POST['expedited'] : "";
    $needotherservice = isset($_POST['needotherservice']) ? $_POST['needotherservice'] : "";

    $servicearray = explode(',', $needotherservice);
    $neeservicehtml = '';
    foreach ($servicearray as $servicename) {
        //$neeservicehtml .= $servicelist[$servicename];
        $neeservicehtml .= array_search($servicename, $additionalservice) . ',';
    }
    $neeservicehtml = rtrim($neeservicehtml, ',');

    $decrypted_param = encrypt_decrypt('decrypt', $getid);
    $decrypted_array = explode('|<>|', $decrypted_param);
    $ordid = $decrypted_array[0];
    $sno = $decrypted_array[1];
    $QUOTESERVICE = 'Translationupload';
    $fil = isset($_POST['uploadFiles']) ? $_POST['uploadFiles'] : "";
    $completedfilecnt = isset($_POST["completedfilecnt"]) ? $_POST["completedfilecnt"] : "";
    $count = isset($_POST["count"]) ? $_POST["count"] : "";
    $s = explode(',', $fil);
    $fie = '';
    $fill = '';
    $filink = '';
    $cou = count($s);
    $neworderIdhtml = "Your confirmation ID is $ordid.";
    for ($t = 0; $t < $cou; $t++) {
        if ($t != ($cou - 1)) {
            $fill = str_replace("\\", '/', $s[$t]);
            $fie = $fie . basename($fill) . "|,";
        } else {
            $fill = str_replace("\\", '/', $s[$t]);
            $fie = $fie . basename($fill);
        }
    }
    $filescount = $completedfilecnt . "/" . $count;

    $sql_customer = $file_detail = mysql_query("SELECT dp.*,up.FileName as existfilename FROM `tickets_transcription_payment` as dp LEFT JOIN uploads as up ON dp.orderno = up.OrderId  WHERE dp.id = '$sno'");
    $ufile = '';
    while ($customer_data = mysql_fetch_array($file_detail)) {
        $ufile = $customer_data['ufile'];
    }
    $fil1 = $fil;
    if ($ufile != "") {
        $fil1 = $ufile . ',' . $fil;
    }
    mysql_query("UPDATE tickets_transcription_payment 
                    SET name       = '" . mysql_real_escape_string(htmlentities($name)) . "',
                        country    = '" . mysql_real_escape_string(htmlentities($countryno)) . "',                        
                        phone      = '" . mysql_real_escape_string(htmlentities($contact)) . "',
                        needserv   = '" . mysql_real_escape_string(htmlentities($needotherservice)) . "',
                        ttime      = '" . mysql_real_escape_string(htmlentities($tatdate)) . "',
                        hf_contact = '" . mysql_real_escape_string(htmlentities($paytc_hfc)) . "',
                        comment    = '" . mysql_real_escape_string(htmlentities($upcomments)) . "',
                        ufile      = '" . mysql_real_escape_string(htmlentities($fil1)) . "',
                        filescount = '" . mysql_real_escape_string(htmlentities($filescount)) . "'                                              
                      WHERE id=$sno");


    $sno = $lastinsertedid;
    $fileInfo = $fileArr = array();
    $tbleCodeStr = $TABLECODE['tickets_transcription_payment'];
    if (!empty($_REQUEST['uploadedFileDetailsArr'])) {
        $uploadedfilesarr = explode(",", $_REQUEST['uploadedFileDetailsArr']);
    }
    foreach ($uploadedfilesarr as $arrayval) {
        $uploadedfilearr = explode("#-#", $arrayval);
        $uploadedfilenamearr[] = substr($uploadedfilearr[0], strpos($uploadedfilearr[0], '/') + 1);
    }
    $mn = 0;
    $filecontentrow = '';
    if (!empty($fil)) {
        $fileArr = explode(",", $fil);
        $duratnArr = explode(",", $duratnval);
        foreach ($fileArr as $val) {
            $UniqeID = uniqid();
            $duratn = $duratnArr[$mn];
            $infoArr = explode("#-#", $val);
            $param = array();
            $param['fileid'] = $UniqeID;
            $param['filename'] = substr($infoArr[0], strpos($infoArr[0], '/') + 1);
            $param['filesize'] = $infoArr[1];
            $param['fileduration'] = $duratn;
            $param['transfee'] = $transactionfee;
            $param['ordertotal'] = $ordertotal;
            $status = (in_array($param['filename'], $uploadedfilenamearr)) ? 1 : 0;
            $fileInfo[] = $param;

            mysql_query("INSERT INTO uploads (Id, OrderId, TableCode, FileName, FileFormat, FileSize, FileId, upload_status) 
                          values ('', '$ordid', '$tbleCodeStr', '$infoArr[0]', '$infoArr[2]', '$infoArr[1]', '$UniqeID', '$status') ");

            $mn++;
        }
    }


    $filink = $filesizeinfo = $filecontent = '';
    $j = 1;
    $fileDonwloadurl = $CRMSERVERPATH . 'filedownload.php?FileId=';

    foreach ($fileInfo as $val) {
        $dispName = substr($val['filename'], strpos($val['filename'], '_') + 1);
        $filink = '<a data-download="' . $val['filename'] . '" style="color:blue;" href="' . $fileDonwloadurl . $val['fileid'] . '">Download</a><br/>';
        $filecontentrow .= '<tr>
                <td align="center" style="border-right: 1px solid #e7e7e7;border-top: 1px solid #e7e7e7;"><p style="color: #302e2e;font-size: 14px;"> ' . $dispName . '</p></td>
                <td align="center" style="border-right: 1px solid #e7e7e7;border-top: 1px solid #e7e7e7;"><p style="color: #302e2e;font-size: 14px;"> ' . $filink . '</p></td>
            </tr>';
    }
//echo $filecontentrow;die;
    $filerowhtml = '';
    if (!empty($fileInfo)) {
        $filerowhtml = '<tr>
                <td style="padding-top: 10px;">
                    <table style="width:100%;border: 1px solid #e7e7e7;">
                        <tbody>
                        <tr>
                            <td align="center" style="border-right: 1px solid #e7e7e7;">
                                <p style="color:#333;font-size: 13px;font-weight: bold;">File name</p>
                            </td>
                            <td align="center" style="border-right: 1px solid #e7e7e7;">
                                <p style="color:#333;font-size: 13px;font-weight: bold;">Download link</p>
                            </td>
                        </tr>
                        ' . $filecontentrow . '
                        </tbody>
                    </table>
                </td>
            </tr>';
    }

    $expeditedhtml = "";
    if ($expedited == 'Yes') {
        $expeditedhtml = '<tr>
                    <td colspan="2" style="padding-top: 10px;padding-bottom:10px"><strong>Expedited Service</strong>: ' . $expedited . '</td>
                </tr>';
    }
    $tatdatehtml = "";
    if ($tatdate != '') {
        $tatdatehtml = '<tr>
                    <td colspan="2" style="padding-top: 10px;padding-bottom:10px"><strong>Turnaround Time</strong>: ' . $tatdate . '</td>
                </tr>';
    }
    $needservicehtml = '';
    if ($neeservicehtml != '') {
        $needservicehtml .= '<tr>
                    <td colspan="2" style="font-size:13px;padding-top: 10px;padding-bottom:10px"><strong>Services you interested </strong>: ' . $neeservicehtml . '</td>
                </tr>';
    }
    $upcommentshtml= '';
if($upcomments != ''){
    $upcommentshtml = '<tr>
        <td colspan="2" style="padding-top: 10px;padding-bottom:10px"><strong>Comment</strong>: ' . nl2br(stripslashes($upcomments)) . '</td>
    </tr>';
}
    $countryhtml= '';
    if($countryno != ''){
        $countryhtml = '<tr>
        <td colspan="2" style="padding-top: 10px;padding-bottom:10px"><strong>Country</strong>: ' . nl2br(stripslashes($country[$countryno])) . '</td>
    </tr>';
    }
    if(!in_array($sitename,$notcommonfootersites)) {
        $subjecthtml = "Vanan Online Services";
        $footerhtml = '<tr style="text-align: center;background: #006dce;border: solid 1px #006DCE;border-bottom-right-radius: 4px; border-bottom-left-radius: 4px;">
                <td style="padding: 16px 22px;"> <a href="https://vananservices.com/"><img src="https://vananservices.com/img/as-logo.png"></a>
                    <br>
                    <p style="color: #fff;font-size: 13px;margin: 8px 0 0 0;line-height: 30px;letter-spacing: 0.9px; text-align: center;"> Transcription | Translation |  Captioning/Subtitling  | Voice Over| Video Services |  Writing |  Typing |  Dictation</p>
                </td>
            </tr>

            <tr style="background:#f1f8fc;text-align: center;border: solid 1px #006DCE;border-bottom-right-radius: 4px; border-bottom-left-radius: 4px;">
                <td>
                    <p style="color: #333;font-size: 12px;font-weight: bold;margin: 0;line-height: 30px;letter-spacing: 0.9px;">  Toll-Free : &nbsp;<span style="color: #006dce;">US</span> : 1-888-535-5668 &nbsp; <span style="color: #006dce;">UK</span> : +44-80-8238-0078 &nbsp; <span style="color: #006dce;">AUS</span> : +44-80-8238-0078 </p>
                </td>
            </tr>';
    }else{
        $subjecthtml = "Helplancers";
        $footerhtml='<tr style="text-align: center;background: #006dce;border: solid 1px #006DCE;border-bottom-right-radius: 4px; border-bottom-left-radius: 4px;">
                <td style="padding: 16px 22px;">
                    <p style="color: #fff;font-size: 13px;margin: 8px 0 0 0;line-height: 30px;letter-spacing: 0.9px; text-align: center;"> Transcription | Translation |  Captioning/Subtitling  | Voice Over| Video Services |  Writing |  Typing |  Dictation</p>
                </td>
            </tr>

            <tr style="background:#f1f8fc;text-align: center;border: solid 1px #006DCE;border-bottom-right-radius: 4px; border-bottom-left-radius: 4px;">
                <td>
                    <p style="color: #333;font-size: 12px;font-weight: bold;margin: 0;line-height: 30px;letter-spacing: 0.9px;">  Toll-Free : &nbsp;<span style="color: #006dce;">US</span> : 1-888-422-2268 </p>
                </td>
            </tr>';
    }
//    echo $filerowhtml;die;

    //'Translationupload'=>'quote_upload_translation.html',

    $logo = rtrim($site_url, '/') . '/img/DS-logo.png';
 $mailreplace = array('__SITEURL__' => $site_url,
     '__SITELOGOIMG__' => $logo,
     '__NAME__' => $name,
     '__COUNTRY__' => $countryhtml,
     '__EMAIL__' => $email,
     '__PHONE__' => $contact,
     '__TATTIME__' => $tatdatehtml,
     '__EXPEDITED__' => $expeditedhtml,
     '__HEADERIMG__' => $logo,
     '__FILEROW__' => html_entity_decode($filerowhtml),
     '__OTRSERV__' => $needservicehtml,
     '__ORDERID__' => $neworderIdhtml,
     '__COMMENT__' => $upcommentshtml,
     '__SITESUB__' => $subjecthtml,
     '__FOOTER__' => $footerhtml,
     '__HFSERVICE__' => $paytc_hfc
 );



        //For mailer confirmation - start
        if ($_REQUEST['uploadflag'] == 'true') {
            $fileop             = fopen("mailer/".$CONFIRMMAILERCODE[$QUOTESERVICE], "r");
            $mail_content = fread($fileop, filesize("mailer/".$CONFIRMMAILERCODE[$QUOTESERVICE]));
            fclose($fileop);
            $messagenew     = strtr($mail_content, $mailreplace);
            //$to    = "support@vananservices.com,vananbackup@gmail.com";
            $subject        = $QUOTESERVICE." Quote Confirmation - ".$QUOTEMAILERINFO[$site_name]['name'];  // 'Translation Confiramtion Quote - Click For Translation';

            if($crmpage =="upload"){
                $subject        =  str_replace("Quote","Upload",$subject);
            }
            $to = $email;
            multi_attach_mail($to, $subject, $messagenew, $email, $sitename);
        }
        include_once 'lib/MailChimp.php';


        if ($_REQUEST['uploadflag'] == 'true') {

            $quoteArr = base64_encode(serialize(array('filesizeinfo' => $filesizeinfo, 'filink' => $filink, 'quoteid' => $sno,
                'uptblname'=>$updateTableName,'uptblprimarykey'=>$updateTablePrimaryKey,'quoteservice'=>$QUOTESERVICE,'mailarray'=>$mailreplace)));
            $output = json_encode(array('type' => 'quote', 'status' => '1', 'info' => $quoteArr));
            die($output);
        }else{
            $quoteInfo = array('filesizeinfo' => $filesizeinfo, 'filink' => $filink,'quoteservice'=>$service_name,'mailarray'=>$mailreplace);

        }


    if ($_POST['uploadflag'] == "false") {
        $service_name = $quoteInfo['quoteservice'] . ' Services - Quote'; //'Translation Services - Quote';
        $subject = $quoteInfo['quoteservice'] . $QUOTEMAILERINFO[$site_name]['subject'];//. $site_name;
        
        if ($QUOTESERVICE == "Translationupload") {
            $subject = str_replace("Quote", "Additional Information", $subject);
        }
        
        $mailreplace = $quoteInfo["mailarray"];
        $quotemailerarray = array(
            '__FILELINK__' => html_entity_decode($quoteInfo["filink"]),
            '__SERVICESUBJECT__' => $subject,
            '__FILESIZEINFO__' => html_entity_decode($quoteInfo["filesizeinfo"]),
            '__FILELINKDISP__' => (empty($quoteInfo["filink"])) ? "none" : "",
            '__SERVICENAME__' => $service_name);

        $mailreplacenew = array_merge($mailreplace, $quotemailerarray);
        $file = fopen("mailer/" . $MAILERCODE[$QUOTESERVICE], "r");
        $htmlmail_content = fread($file, filesize("mailer/" . $MAILERCODE[$QUOTESERVICE]));
        fclose($file);
        $html_content = strtr($htmlmail_content, $mailreplacenew);
        $to = $email;
        multi_attach_mail($to, $subject, $html_content, $email, $sitename);
        if (isset($_COOKIE['uploadtest'])) {
            echo "===>Success...";
        }


        $output = json_encode(array('ordsid' => $ordid, 'type' => 'message', 'text' => 'Your request has been sent successfully and you will receive an email from us shortly. Thank you!'));
        die($output);


    }
}else if(isset($_POST['name'])) {

    date_default_timezone_set('America/New_York');
    $source = $target = $qtat = $qtmin = $qtformat = "";
    $name               = isset($_POST['name']) ? $_POST['name'] : "";
    $email              = isset($_POST['email']) ? $_POST['email'] : "";
    $country            = isset($_POST['country']) ? $_POST['country'] : "";
    $purpose            = isset($_POST['service']) ? $_POST['service'] : "";
    $qservice           = $purpose;
    $camethrough        = isset($_POST['camethrough']) ? $_POST['camethrough'] : "";
    $code               = isset($_POST['acode']) ? $_POST['acode'] : "";
    $contact            = isset($_POST['phone']) ? $_POST['phone'] : "";
    $count              = isset($_POST["count"]) ? $_POST["count"] : "";
    $completedfilecnt   = isset($_POST["completedfilecnt"]) ? $_POST["completedfilecnt"] : "";
    $comment            = isset($_POST['comment']) ? $_POST['comment'] : "";
    $crmpage            = isset($_POST['crmpage']) ? $_POST['crmpage'] : "";
    $source             = isset($_POST['source']) ? $_POST['source'] : "";
    $target             = isset($_POST['target']) ? $_POST['target'] : "";
    $uploadat           = isset($_POST['uploadat']) ? $_POST['uploadat'] : "";
    $sourcefiletype     = isset($_POST['sourcefiletype']) ? $_POST['sourcefiletype'] : "";
    $prfilelength       = isset($_POST['prfilelength']) ? $_POST['prfilelength'] : "";
    $pagecount          = isset($_POST['pagecount']) ? $_POST['pagecount'] : "";
    $nota_subamt        = isset($_POST['nota_subamt']) ? $_POST['nota_subamt'] : "";
    $notapro_subamt     = isset($_POST['notapro_subamt']) ? $_POST['notapro_subamt'] : "";
    $mfile_subamt       = isset($_POST['mfile_subamt']) ? $_POST['mfile_subamt'] : "";
    $notacrmpay         = isset($_POST['notacrmpay']) ? $_POST['notacrmpay'] : "";
    $mailfilecrmpay     = isset($_POST['mailfilecrmpay']) ? $_POST['mailfilecrmpay'] : "";
    $mailcountry        = isset($_POST['mailcountry']) ? $_POST['mailcountry'] : "";
    $mailingaddr        = isset($_POST['mailingaddr']) ? $_POST['mailingaddr'] : "";
    $tatdate            = isset($_POST['tatdate']) ? $_POST['tatdate'] : "";
    $trgtunitcost       = isset($_POST["trgtunitcost"]) ? $_POST["trgtunitcost"] : "";
    $trgttotamt         = isset($_POST["trgttotamt"]) ? $_POST["trgttotamt"] : "";
    $catetype           = isset($_POST["catetype"]) ? $_POST["catetype"] : "";
    $buttonname         = isset($_POST["buttonname"]) ? $_POST["buttonname"] : "";
    $deliveryReq        = isset($_POST["deliveryReq"]) ? $_POST["deliveryReq"] : "";

    $btnvalue           = isset($_POST["btnvalue"]) ? $_POST["btnvalue"] : "";
    $agent_ref          = isset($_POST["agent_ref"]) ? $_POST["agent_ref"] : "";

    $notacrmpay         = ($notacrmpay == '1') ? 'Yes' : 'No';
    $mailfilecrmpay     = ($mailfilecrmpay == '1') ? 'Yes' : 'No';
    $deliveryReq        = ($deliveryReq == '1') ? 'Yes' : 'No';
    $notaryhtml         = '';
    if($notacrmpay == 'Yes'){
        $notaryhtml .='<tr>
                        <td colspan="5" align="right" style="border-right: 1px solid #e7e7e7;border-top: 1px solid #e7e7e7;padding-right: 10px;">  <p style="color: #302e2e;font-size: 13px;"> Notary</p></td>
                        <td align="right" style="border-top: 1px solid #e7e7e7;width: 20%;">  <p style="color: #302e2e;font-size: 13px;">$'.$nota_subamt.'</p> </td>
                    </tr>
                    <tr>
                        <td colspan="5" align="right" style="border-right: 1px solid #e7e7e7;border-top: 1px solid #e7e7e7;padding-right: 10px;">  <p style="color: #302e2e;font-size: 13px;"> Processing fee</p></td>
                        <td align="right" style="border-top: 1px solid #e7e7e7;width: 20%;">  <p style="color: #302e2e;font-size: 13px;">$'.$notapro_subamt.'</p> </td>
                    </tr>';
    }
    $mfilehtml         = '';
    if($mailfilecrmpay == 'Yes' && $mailcountry == "United States"){
        $mfilehtml .='<tr>
                        <td colspan="5" align="right" style="border-right: 1px solid #e7e7e7;border-top: 1px solid #e7e7e7;padding-right: 10px;">  <p style="color: #302e2e;font-size: 13px;"> Mailing</p></td>
                        <td align="right" style="border-top: 1px solid #e7e7e7;width: 20%;">  <p style="color: #302e2e;font-size: 13px;">$'.$mfile_subamt.'</p> </td>
                    </tr>';
    }
    $channelno = 11;
    if($buttonname == "Proceed to Payment"){
        $channelno = 10;
    }elseif ($buttonname == "Get Quote"){
        $channelno = 11;
    }elseif ($buttonname == "Email Quote"){
        $channelno = 19;
    }
    $sitechannel = "abchidFS".encrypt('__sitename_'.$site_name.'__ __channel_'.$channelno.'__','vanancrm*encrypt')."abchidFE";
   // if($_POST["service"] =="translation"){

        $QUOTESERVICE       = 'Translationpay';
        $QUOTESERVICEdb     = $QUOTESERVICE;
        if($btnvalue == "quote"){
            $QUOTESERVICEdb = 'Translationpayquote';
        }


        $updateTableName    = 'tickets_transcription_payment';
        $updateTablePrimaryKey    = 'id';

        $qtat               = isset($_POST["qtat"])?$_POST["qtat"]:"";
        $aprxtat            = isset($_POST["aprxtat"])?$_POST["aprxtat"]:"";
        $qpurpose           = $catetype;
        $qtmin              = isset($_POST["qtmin"])?$_POST["qtmin"]:""; // Transcription
        $qtlang             = isset($_POST["source"])?$_POST["source"]:""; //
        $pagecount1 = $pagecount;




        /*   VERBATIME BLOCK START  */
        $verbcostt          = isset($_POST['verbcostt']) ? $_POST['verbcostt'] : "";
        $qtver1             = isset($_POST["qtver"]) ? $_POST["qtver"] : ""; //verbatime check
        if($qtver1=='1'){
            $qtver = 'Yes';
            $trcHtml .='<tr><td align="right" colspan="5" style="border-right: 1px solid #e7e7e7;border-top: 1px solid #e7e7e7;padding-right: 10px;width: 75%;">  <p style="color: #302e2e;font-size: 13px;"> Verbatim </p></td>
                        <td align="right" style="border-top: 1px solid #e7e7e7;width: 20%;">  <p style="color: #302e2e;font-size: 13px;">$'.$verbcostt.'</p> </td></tr>';
        }else{
            $qtver = 'No';
        }

        /*   VERBATIME BLOCK END  */
        /*   TIMECODE BLOCK START  */
        $usrtimecode        = isset($_POST['usrtimecode']) ? $_POST['usrtimecode'] : "";
        $usrtimecodetype    = isset($_POST['usrtimecodetype']) ? $_POST['usrtimecodetype'] : "";
        $durtn              = $usrtimecode;
        $durntype           = $usrtimecodetype;
        $spkrchangepay      = isset($_POST['spkrchangepay']) ? $_POST['spkrchangepay'] : "";
        $timecode_detail    = '(Speaker change)';

        if($spkrchangepay != '1'){
            if($durtn == 1){
                $durntype = substr($durntype, 0, -1);
            }
            $timecode_detail = '(Every '.$durtn.'&nbsp;'.$durntype.')';
        }
        $timecodecostt      = isset($_POST['timecodecostt']) ? $_POST['timecodecostt']: "";
        $qttcode1           = isset($_POST["qttcode"]) ? $_POST["qttcode"] : ""; //timecode check
        if($qttcode1=='1'){
            $qttcode = 'Yes';
            $trcHtml .= '<tr><td align="right" colspan="5" style="border-right: 1px solid #e7e7e7;border-top: 1px solid #e7e7e7;padding-right: 10px;width: 75%;">  <p style="color: #302e2e;font-size: 13px;"> Time Code <br>'.$timecode_detail.' </p></td>
                    <td align="right" style="border-top: 1px solid #e7e7e7;width: 20%;">  <p style="color: #302e2e;font-size: 13px;">$'.$timecodecostt.'</p> </td></tr>';
        }else{
            $qttcode = 'No';
        }
        /*   TIMECODE BLOCK END  */

        /*   NATIVE SPEAKER BLOCK START  */
        $nativespeaker = isset($_POST["nativespeaker"]) ? $_POST["nativespeaker"] : "";
        $nativeavail = '';
        $nativespeaker = ($nativespeaker=='1') ? 'Yes' : 'No';
        if($nativespeaker == 'Yes'){
            $nativeavail = "You have availed U.S. native transcribers for your project that costs $1.75 per minute.";
        }
        /*   NATIVE SPEAKER BLOCK END  */
    //}
        
    $fil                = isset($_POST['filena']) ? $_POST['filena'] : "";
    $fildetail          = isset($_POST['fildetail']) ? $_POST['fildetail'] : "";
    $duratnval          = isset($_POST['duratnval']) ? $_POST['duratnval'] : "";
    $ordertotal         = isset($_POST['paymentamt']) ? $_POST['paymentamt'] : "";
    $transactionfee     = isset($_POST['transactionfee']) ? $_POST['transactionfee'] : "";
    $subamttot          = isset($_POST['subamttot']) ? $_POST['subamttot'] : "";
    $paytc_hfc          = isset($_POST["paytc_hfc"]) ? $_POST["paytc_hfc"] : "";


    $filena = '';
    $s      = explode(',', $fil);
    $fie    = '';
    $fill   = '';
    $filink = '';
    $cou    = count($s);

    for ($t = 0; $t < $cou; $t++) {
        if ($t != ($cou - 1)) {
            $fill = str_replace("\\", '/', $s[$t]);
            $fie = $fie . basename($fill) . "|,";
        } else {
            $fill = str_replace("\\", '/', $s[$t]);
            $fie = $fie . basename($fill);
        }
    }
	$filescount     = $completedfilecnt . "/" . $count;

    if ($SEND_QUOTE == 0) {
        if($website ==''){
            $website = 'Sitename not given';
        }
        if($QUOTESERVICE  == 'Translationpay'){
            $neworderIdhtml='';
            $neworderId='';
            mysql_query("INSERT INTO tickets_transcription_payment(id,email,minutes,tat,fileformat,servicetype,verbatim,tcode,language,speaker_change,how_often_length,how_often_type,site,  website,iscrm,ipaddress,createddate,browserdetail,filescount,purpose,service,native,paymentamt,notary,mailing,mailingcountry,mailingaddress,sourcefiletype,pagecount,source_lang,target_lang,agentid,buttonname,rush,camethrough) "
                    . "VALUES('','$email','$qtmin','$aprxtat','$qtformat','$qservice','$qtver','$qttcode','$qtlang','$spkrchangepay','$usrtimecode','$usrtimecodetype','Vanan new','$website',1,'$ipaddress','$createddate','$browserdetail','$filescount','$qpurpose','$QUOTESERVICEdb','$nativespeaker','$ordertotal','$notacrmpay','$mailfilecrmpay','$mailcountry','$mailingaddr','$sourcefiletype','$pagecount','$source','$target','$agent_ref','$buttonname','$deliveryReq','$camethrough')");


            //$query = "select max(id) as Sno from tickets_transcription_payment";
            $tbleCodeStr = $TABLECODE['tickets_transcription_payment'];
            $lastinsertedid=  mysql_insert_id();
           // if($btnvalue != "quote") {
                $todayDate = date('Y-m-d');
                $ordId = mysql_query("SELECT COUNT( * ) as total FROM  `tickets_transcription_payment` WHERE DATE(createddate) = '$todayDate' AND id < $lastinsertedid AND servicetype ='translation' AND orderno !=''");
                $data = mysql_fetch_assoc($ordId);
                $ordId = $data['total'];
                $ordId++;
                $neworderId = "TL" . date("dmy") . $ordId;
                $neworderIdhtml = "Your confirmation ID is $neworderId.";
                mysql_query("UPDATE tickets_transcription_payment SET orderno ='$neworderId'  WHERE id=$lastinsertedid");
            //}
        }
        $sno = $lastinsertedid;
        $fileInfo = $fileArr = array();
    
    if (!empty($_REQUEST['uploadedFileDetailsArr'])){
        $uploadedfilesarr = explode(",", $_REQUEST['uploadedFileDetailsArr']);
    }
    foreach ($uploadedfilesarr as $arrayval) {
        $uploadedfilearr= explode("#-#", $arrayval);
        $uploadedfilenamearr[] = substr($uploadedfilearr[0], strpos($uploadedfilearr[0], '/') + 1);
    }
    $mn=0;
    $filecontentrow='';
    if (!empty($fil)){
        $fileArr = explode(",", $fil);
        $duratnArr = explode(",", $duratnval);
        foreach ($fileArr as $val) {
            $UniqeID                = uniqid();
            $duratn                 = $duratnArr[$mn];
            $infoArr                = explode("#-#", $val);
            $param                  = array();
            $param['fileid']        = $UniqeID;
            $param['filename']      = substr($infoArr[0], strpos($infoArr[0], '/') + 1);
            $param['filesize']      = $infoArr[1];
            $param['fileduration']  = $duratn;
            $param['transfee']      = $transactionfee;
            $param['ordertotal']    = $ordertotal;
            $status                 = (in_array($param['filename'], $uploadedfilenamearr)) ? 1 :0;
            $fileInfo[]             = $param;

            mysql_query("INSERT INTO uploads (Id, OrderId, TableCode, FileName,FileFormat,FileSize,FileId,upload_status) values ('',$sno, '$tbleCodeStr', '$infoArr[0]','$infoArr[2]','$infoArr[1]', '$UniqeID',$status) ");
            //echo "INSERT INTO uploads_transcription_payment (Id, OrderId, TableCode, FileName,FileFormat,FileSize,fileduration,fileverbaitem,filetimecode,filenativespeaker,indtotal,transfee,ordertotal,FileId,upload_status) values ('',$sno, '$tbleCodeStr', '$infoArr[0]','$infoArr[2]','$infoArr[1]','$duratn','$veritm','$timecode','$ntvspeaker','$indcostbox','$transactionfee','$ordertotal',$UniqeID',$status)";
            mysql_query("INSERT INTO uploads_transcription_payment (Id, OrderId, TableCode, FileName,FileFormat,FileSize,fileduration,fileverbaitem,filetimecode,filenativespeaker,indtotal,transfee,ordertotal,FileId,upload_status) values ('',$sno, '$tbleCodeStr', '$infoArr[0]','$infoArr[2]','$infoArr[1]','$duratn','$veritm','$timecode','$ntvspeaker','$indcostbox','$transactionfee','$ordertotal','$UniqeID',$status) ");
            $mn++;
        }
    }
       
        //echo "UPDATE enquiry_transcription_payment SET flag ='1'  WHERE entryid='" . $_POST['recordkey']."'";
        if($sno){
            mysql_query("UPDATE enquiry_transcription_payment SET flag ='1'  WHERE entryid='" . $_POST['recordkey']."'");
        }
        $filink = $filesizeinfo = $filecontent = '';
        $j = 1;
        $fileDonwloadurl = $CRMSERVERPATH.'filedownload.php?FileId=';
        foreach ($fileInfo as $val) {
            $dispName        = substr($val['filename'], strpos($val['filename'], '_') + 1);
            $filink         .=$j . ')&nbsp;<a data-download="' . $val['filename'] . '" style="color:blue;" href="' . $fileDonwloadurl . $val['fileid'] . '">' . $dispName . '</a><br/>';
            $filesizeinfo   .= $j . ")&nbsp;" . $dispName . " " . $val['filesize'] . "<br/>";
            $j++;
            $filecontent    .='<tr>
                                    <td width="100" align="center" style="border-bottom:1px solid #d9d9d9">File:</td><td height="60" style="padding-bottom:5px;border-bottom:1px solid #d9d9d9">' . $dispName . " " . $val['filesize'] . '</td>
                                </tr>';
        }
        $fileDonwloadurl    = $CRMSERVERPATH.'filedownload.php?FileId=';
            
        foreach($fileInfo as $val){
            $filduro = $val['fileduration'];
            $indcost = $val['indcost'];
            $dispName = substr($val['filename'], strpos($val['filename'], '_') + 1);
            $filink ='<a data-download="' . $val['filename'] . '" style="color:blue;" href="' . $fileDonwloadurl . $val['fileid'] . '">Download</a><br/>';
            $filecontentrow .='<tr>
                                <td align="center" style="border-right: 1px solid #e7e7e7;border-top: 1px solid #e7e7e7;">
                                    <p style="color: #302e2e;font-size: 14px;"> '.$dispName.'</p>
                                </td>
                                <td align="center" style="border-right: 1px solid #e7e7e7;border-top: 1px solid #e7e7e7;">
                                    <p style="color: #302e2e;font-size: 14px;"> '.$filink.'</p>
                                </td></tr>';
        }

        $filerowhtml='';
        if(!empty($fileInfo)) {
            $filerowhtml = '<tr>
                <td style="padding-top: 10px;">
                    <table style="width:100%;border: 1px solid #e7e7e7;">
                        <tbody>
                        <tr>
                            <td align="center" style="border-right: 1px solid #e7e7e7;">
                                <p style="color:#333;font-size: 13px;font-weight: bold;">File name</p>
                            </td>
                            <td align="center" style="border-right: 1px solid #e7e7e7;">
                                <p style="color:#333;font-size: 13px;font-weight: bold;">Download link</p>
                            </td>
                        </tr>
                        ' . $filecontentrow . '
                        </tbody>
                    </table>
                </td>
            </tr>';
        }

        $service_name   = $QUOTESERVICE.' Services - Quote'; //'Translation Services - Quote';
        if($crmpage =="upload"){
            $service_name   =  str_replace("Quote","Upload",$service_name);
        }
        if($country){
            $query1 = mysql_query("SELECT `B` FROM `countrycode` WHERE `A` = '$country'");
            $ccode  = mysql_result($query1, 0, 'B');
            $ctcode = (int) $ccode;
            $phone  = '+' . $ctcode;
            $phone .= ' - ' . $code; // Area code must to call them
            $phone .= ' - ' . $contact;
            $phone = empty($contact)?"":$phone;
        }

        $logo = rtrim($site_url, '/') . '/img/DS-logo.png';
         $payicon = $CRMSERVERPATH . 'img/pay.png';
        $emailheaderimg = rtrim($site_url, '/') . '/img/Email.png';
        if($comment != ''){
            $comment = '<tr><td align="left" style="padding-left: 22px;border-right: 1px solid #e7e7e7;">                
                        <span style="color: #302e2e;font-size: 14px;max-height: 120px;overflow-x: scroll;"><strong>Comment: </strong>'.$comment.'</span>                
                    </td></tr>';
        }

        $mailingaddrhtml = '';
        if($mailfilecrmpay == 'Yes'){
            $mailingaddrhtml = '                    
                    <tr><td colspan="6" align="center" style="padding-left: 22px;">
                        <span style="color: #302e2e;font-size: 12px;max-height: 120px;overflow-x: scroll;"><strong>Physical address: </strong><br>'.$mailingaddr.'</span>                
                    </td>                    
                    </tr>
                    ';
        }

        $url_param = "$neworderId|^|$ordertotal|^|translation|^|$site_name";
        //TRC02052017|^|60|^|transcription|^|rajkumar@vananservices.com
        $encrypted_param = encrypt_decrypt('encrypt', $url_param);
        $paymentlink = $CRMSERVERPATH.'paypal/payment_v2.0.php?van='.$encrypted_param;

        $param = $neworderId.'|<>|'.$sno;
        $param = encrypt_decrypt('encrypt', $param);
        $fileuploadurl = "http://".$site_url."/Translation-Payment-Files.php?id=".$param;
        $paynowhtml = '<tr style="margin: 0 auto;    display: table;">
                    <td>
                        <a href="'.$paymentlink.'" style="text-decoration: none;"><div class="pay-btn" style="background-color:#00c853;padding:13px 36px;color:#fff!important;margin:10px 0px;">Pay Now</div></a>
                    </td>
                </tr>               
               
                 <tr>
                    <td align="center" colspan="6">
                        <span style="color:#333;font-size: 13px;">(Ignore if you have made the payment already)</span>
                    </td>
                </tr>
                 <tr style="margin: 0 auto;display: table;">
                    <td><img src="'.$payicon.'" alt="payment"></td>
                </tr>';

        $mailreplace = array('__SITELOGOIMG__' => $logo,
                            '__NAME__' => $name,
                            '__EMAIL__' => $email,
                            '__PHONE__' => $phone,
                            '__HEADERIMG__' => $logo,
                            '__TRANSACFEE__' => $transactionfee,
                            '__ORDERTOTAL__' => $ordertotal,
                            '__FILEROW__' => html_entity_decode($filerowhtml),
                            '__ORDERID__' => $neworderIdhtml,
                            '__COSTPERPAGE__' => $trgtunitcost,
                            '__TLCOST__' => $trgttotamt,
                            '__TRCHTM__' => $trcHtml,
                            '__TRLHTM__' => $needtrlsHtml,
                            '__NATIVECOST__' => $nativeavail,
                            '__SUBTOTALCOST__' => $subamttot,
                            '__INPUTFILEFORMAT__' => $qtformat,
                            '__TRANSCRIPTION__' => $qtlang,
                            '__SOURCE__' => $source,
                            '__TARGET__' => $target,
                            '__NOTE__' => $qnote,
                            '__GMAILCONTENT__' => $qmail,
                            '__GMAILCONTENTDISP__' => empty($qmail)?"none":"",
                            '__TATIME__' => $aprxtat,
                            '__PURPOSE__' => $qpurpose,
                            '__COMMENT__' => nl2br(stripslashes($comment)),
                            '__SERVICENAME__' => $service_name,
                            '__SITEURL__' => $site_url,
                            '__VERB__' => $qtver,
                            '__SITECHANNEL__' => $sitechannel,
                            '__TIMECODE__' => $qttcode,
                            '__Native__' => $nativespeaker,
                            '__SERVICETYPE__' => $qservice,
                            '__HFSERVICE__' => $paytc_hfc,
                            '__NOOFPAGES__' => $pagecount,
                            '__FORMAT__' => $format,
                            '__SUBJECT__' => $subjectcrm,
                            '__CAPTIONING__' => $captioningcrm,
                            '__NEEDTRANSCRIPTION__' => $needtranscriptioncrm,
                            '__VIDEOLENGTH__' => $videolengthcrm,
                            '__NEEDTRANSLATION__' => $needtranslationcrm,
                            '__SOURCEVOICEOVER__' => $sourcevoiceover,
                            '__SOURCEVOICEOVERDISP__' => (empty($needtranslationcrm) || $needtranslationcrm == 'No')?"none":"" ,
                            '__SCRIPTCRM__' => $scriptcrm,
                            '__COMMENTVOICEOVER__' => $commentvoiceover,
                            '__PURPOSEVOICEOVER__' => $purposevoiceover,
                            '__VOICECOUNTCRM__' => $voicecountcrm,
                            '__GENDERAGECRM__' => $genderage,
                            '__GENDERAGECRMDISP__' => empty($voicecountcrm)?"none":"",
                            '__SCRIPTVOICEOVER__' => $scriptcrm,
                            '__SCRIPTVOICEOVERDISP__' => (empty($scriptcrm) || $scriptcrm == 'No')?"none":"",
                            '__SITENAME__' => $site_name,
                            '__NOTARY__' =>$notaryhtml,
                            '__MAILED__' => $mfilehtml,
                            '__MAILADDR__' => $mailingaddrhtml,
                            '__PAYNOW__' => $paynowhtml,
                            '__UPLOADHERE__' => $fileuploadurl,
                            '__FILESIZEINFO__' => html_entity_decode($filesizeinfo)

                            );



        //For mailer confirmation - start
        if ($_REQUEST['uploadflag'] == 'true') {
            $fileop             = fopen("mailer/".$CONFIRMMAILERCODE[$QUOTESERVICE], "r");
            $mail_content = fread($fileop, filesize("mailer/".$CONFIRMMAILERCODE[$QUOTESERVICE]));
            fclose($fileop);
            $messagenew     = strtr($mail_content, $mailreplace);
            $to    = "support@vananservices.com,vananbackup@gmail.com";
            $subject        = $QUOTESERVICE." Quote Confirmation - ".$QUOTEMAILERINFO[$site_name]['name'];  // 'Translation Confiramtion Quote - Click For Translation';
     
            if($crmpage =="upload"){
                $subject        =  str_replace("Quote","Upload",$subject);
            }
            multi_attach_mail($to, $subject, $messagenew, $email, $sitename);
        }
        include_once 'lib/MailChimp.php';


        if ($_REQUEST['uploadflag'] == 'true') {

            $quoteArr = base64_encode(serialize(array('filesizeinfo' => $filesizeinfo, 'filink' => $filink, 'quoteid' => $sno,
                'uptblname'=>$updateTableName,'uptblprimarykey'=>$updateTablePrimaryKey,'quoteservice'=>$QUOTESERVICE,'mailarray'=>$mailreplace)));
            $output = json_encode(array('type' => 'quote', 'status' => '1', 'info' => $quoteArr));
            die($output);
        }else{
         $quoteInfo = array('filesizeinfo' => $filesizeinfo, 'filink' => $filink,'quoteservice'=>'Translation','mailarray'=>$mailreplace);

        }
    }
   
    if ($_POST['uploadflag'] == "false") {
    // vananbackup@gmail.com  into BCC
    //$to = $email;
    $to = 'support@vananservices.com,vananbackup@gmail.com';


        $service_name   = $quoteInfo['quoteservice'].' Services - Quote'; //'Translation Services - Quote';
        $subject        = $quoteInfo['quoteservice'].$QUOTEMAILERINFO[$site_name]['subject'];//. $site_name;
        if($QUOTESERVICEdb == "Translationpayquote"){
            $subject        =  str_replace("Quote","Email Quote",$subject);   
        }elseif ($QUOTESERVICE =="Translationpay"){
//            $service_name   =  str_replace("Quote","Upload",$service_name);
            $subject        =  str_replace("Quote","Price Quote",$subject);
        }


        $mailreplace = $quoteInfo["mailarray"];
        $quotemailerarray =array(
                            '__FILELINK__' => html_entity_decode($quoteInfo["filink"]),
                            '__SERVICESUBJECT__' => $subject,
                            '__FILESIZEINFO__' => html_entity_decode($quoteInfo["filesizeinfo"]) ,
                            '__FILELINKDISP__'  => (empty($quoteInfo["filink"]) )?"none":"",
                            '__SERVICENAME__' => $service_name);

        $mailreplacenew = array_merge($mailreplace,$quotemailerarray);
        //echo $MAILERCODE[$QUOTESERVICE];die;
        $file             = fopen("mailer/".$MAILERCODE[$QUOTESERVICE], "r");       

        $htmlmail_content = fread($file, filesize("mailer/".$MAILERCODE[$QUOTESERVICE]));
        
        fclose($file);

        $html_content     = strtr($htmlmail_content, $mailreplacenew);


        multi_attach_mail($to, $subject, $html_content, $email, $sitename);
        if (isset($_COOKIE['uploadtest'])) {
            echo "===>Success...";
        }


        $output = json_encode(array('ordsid' => $neworderId,'type' => 'message', 'text' => 'Your request has been sent successfully and you will receive an email from us shortly. Thank you!','param'=>$param));
        die($output);
    }
} else {

    if ($_POST['uploadflag'] == "false") {
        $output = json_encode(array('type' => 'message', 'text' => 'Sorry for inconvenience, Reach us at 1-888-308-1099'));
        die($output);
    }
}
?>