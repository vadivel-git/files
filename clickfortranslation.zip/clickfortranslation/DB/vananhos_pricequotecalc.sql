-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 12, 2017 at 06:52 AM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vananhos_pricequotecalc`
--

-- --------------------------------------------------------

--
-- Table structure for table `enquiry_transcription_payment`
--

CREATE TABLE `enquiry_transcription_payment` (
  `id` int(15) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `phone` varchar(150) NOT NULL,
  `areacode` varchar(150) NOT NULL,
  `country` varchar(150) NOT NULL,
  `ttime` varchar(50) NOT NULL,
  `hf_contact` varchar(200) NOT NULL,
  `agentid` varchar(25) NOT NULL,
  `comment` varchar(250) NOT NULL,
  `website` varchar(150) NOT NULL,
  `siteurl` varchar(100) NOT NULL,
  `filetype` varchar(50) NOT NULL,
  `purpose` varchar(150) NOT NULL,
  `source` varchar(150) NOT NULL,
  `target` varchar(150) NOT NULL,
  `pagecount` int(11) NOT NULL,
  `minutes` int(11) NOT NULL,
  `rush` varchar(10) NOT NULL,
  `proceedednext` varchar(10) NOT NULL,
  `ata` varchar(10) NOT NULL,
  `notary` varchar(10) NOT NULL,
  `mailed` varchar(10) NOT NULL,
  `mailingcountry` varchar(150) NOT NULL,
  `mailingaddress` text NOT NULL,
  `verbatime` varchar(10) NOT NULL,
  `timecode` varchar(10) NOT NULL,
  `camethrough` varchar(50) NOT NULL,
  `priceviewed` varchar(10) NOT NULL,
  `price` float(10,2) NOT NULL,
  `ip_address` varchar(100) NOT NULL,
  `browserdetail` text NOT NULL,
  `flag` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `entryid` varchar(100) NOT NULL,
  `service` varchar(60) NOT NULL,
  `ufile` varchar(500) NOT NULL,
  `needtranscript` varchar(10) NOT NULL,
  `needtranslation` varchar(10) NOT NULL,
  `nativespeaker` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tickets_transcription_payment`
--

CREATE TABLE `tickets_transcription_payment` (
  `id` int(11) NOT NULL,
  `orderno` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(60) NOT NULL,
  `country` varchar(60) NOT NULL,
  `acode` int(11) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `service` varchar(60) NOT NULL,
  `minutes` int(11) NOT NULL,
  `ttime` varchar(50) NOT NULL,
  `tat` varchar(100) NOT NULL,
  `fileformat` varchar(60) NOT NULL,
  `servicetype` varchar(60) NOT NULL,
  `verbatim` varchar(60) NOT NULL,
  `tcode` varchar(60) NOT NULL,
  `ata` varchar(10) NOT NULL,
  `notary` varchar(60) NOT NULL,
  `mailing` varchar(60) NOT NULL,
  `mailingcountry` varchar(100) NOT NULL,
  `mailingaddress` text NOT NULL,
  `agentid` varchar(25) NOT NULL,
  `wordconfirm` varchar(50) NOT NULL,
  `language` varchar(60) NOT NULL,
  `speaker_change` varchar(30) NOT NULL,
  `how_often_length` varchar(30) NOT NULL,
  `how_often_type` varchar(30) NOT NULL,
  `comment` text NOT NULL,
  `site` varchar(50) NOT NULL,
  `sourcefiletype` varchar(50) NOT NULL,
  `pagecount` int(11) NOT NULL,
  `source_lang` varchar(150) NOT NULL,
  `target_lang` varchar(150) NOT NULL,
  `ufile` varchar(500) NOT NULL,
  `purpose` text NOT NULL,
  `hf_contact` varchar(200) NOT NULL,
  `website` varchar(150) NOT NULL,
  `iscrm` tinyint(1) NOT NULL DEFAULT '0',
  `ipaddress` varchar(32) DEFAULT NULL,
  `createddate` timestamp NULL DEFAULT NULL,
  `browserdetail` text,
  `filescount` varchar(30) NOT NULL,
  `pages` int(11) NOT NULL,
  `format` varchar(50) NOT NULL,
  `subject` varchar(150) NOT NULL,
  `captioning` varchar(150) NOT NULL,
  `specification` varchar(20) NOT NULL,
  `service_cp` varchar(50) NOT NULL,
  `needtranscription` varchar(10) NOT NULL,
  `videolength` varchar(10) NOT NULL,
  `needtranslation` varchar(10) NOT NULL,
  `script` varchar(10) NOT NULL,
  `voiceovercomment` text NOT NULL,
  `voicepurpose` varchar(100) NOT NULL,
  `noofvoices` varchar(20) NOT NULL,
  `voicevalue` varchar(50) NOT NULL,
  `native` varchar(11) NOT NULL,
  `paymentamt` float NOT NULL,
  `totalfilelength` float NOT NULL,
  `fileslength` varchar(100) NOT NULL,
  `buttonname` varchar(150) NOT NULL,
  `rush` varchar(10) NOT NULL,
  `rushpercentage` varchar(10) NOT NULL,
  `camethrough` varchar(50) NOT NULL,
  `payment_status` tinyint(4) NOT NULL,
  `success_mail` int(11) NOT NULL DEFAULT '0',
  `priceviewed` varchar(10) NOT NULL,
  `ord_summary` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `uploads`
--

CREATE TABLE `uploads` (
  `Id` int(11) NOT NULL,
  `OrderId` varchar(50) NOT NULL,
  `TableCode` varchar(5) NOT NULL,
  `FileName` text NOT NULL,
  `FileFormat` varchar(150) NOT NULL,
  `FileSize` varchar(50) NOT NULL,
  `FileId` varchar(250) NOT NULL,
  `upload_status` tinyint(1) NOT NULL DEFAULT '0',
  `created_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `enquiry_transcription_payment`
--
ALTER TABLE `enquiry_transcription_payment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tickets_transcription_payment`
--
ALTER TABLE `tickets_transcription_payment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `uploads`
--
ALTER TABLE `uploads`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `enquiry_transcription_payment`
--
ALTER TABLE `enquiry_transcription_payment`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=506;
--
-- AUTO_INCREMENT for table `tickets_transcription_payment`
--
ALTER TABLE `tickets_transcription_payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `uploads`
--
ALTER TABLE `uploads`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14299;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
