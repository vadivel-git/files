<?php
//     echo "<pre>"; print_r($_REQUEST); echo "</pre>";
    header("Access-Control-Allow-Origin: *");
	
    $quoteInfo = array();
    if(isset($_REQUEST['quoteflag'])){
        $SEND_QUOTE =  $_REQUEST['quoteflag'];
        if ($SEND_QUOTE) {
           $quoteInfo = unserialize(base64_decode($_REQUEST['quoteinfo']));
        }
    }

    include_once "lib/serverconnect.php";
    include_once "lib/common_array.php";
    include_once "common_setting.php";
//    echo "<pre>"; print_r($_SERVER); echo "</pre>"; exit;

    $site_url   = $_SERVER['HTTP_ORIGIN'];
    $input = trim($site_url, '/');

    // If scheme not included, prepend it
    if (!preg_match('#^http(s)?://#', $input)) {
        $input = 'http://' . $input;
    }
    $urlParts = parse_url($input);
    // remove www
    $site_name = preg_replace('/^www\./', '', $urlParts['host']);

    
	//echo$logo = rtrim($site_url, '/') . '/img/DS-logo.png';
if (isset($_REQUEST['command'])) {
    $command = isset($_REQUEST['command']) ? strtolower($_REQUEST['command']) : '';
    if ($command == "updatefilecount") {
        $filescount = $_REQUEST['completedfilecnt'] . "/" . $_REQUEST['totalfilecnt'];
        // echo "UPDATE ".$quoteInfo['uptblname']." SET filescount='" . $filescount . "' WHERE Sno=" . $quoteInfo['quoteid'];
        mysql_query("UPDATE ".$quoteInfo['uptblname']." SET filescount='" . $filescount . "' WHERE Sno=" . $quoteInfo['quoteid']);
    }
    // $_POST["uploadflag"] = $_REQUEST['uploadflag'];
    die('cnt updated...');
}

    $website        = $QUOTEMAILERINFO[$site_name]['name'];
    $ipaddress      = $_SERVER['REMOTE_ADDR'];
    date_default_timezone_set('America/New_York');
    $createddate    = date('Y-m-d H:i:s');
    $browserdetail  = $_SERVER['HTTP_USER_AGENT'];

    if (isset($_REQUEST['fieldinfocommand'])) {
        $commandinfo = isset($_REQUEST['fieldinfocommand']) ? strtolower($_REQUEST['fieldinfocommand']) : '';
        if ($commandinfo == "updatefieldinfo") {
            $valuearray=$_REQUEST['savedata'];
            $Fieldinfo_UniqeID = uniqid();
            if($valuearray["entryval"]){
                switch ($valuearray["fieldname"]) {
                    case 'qemail':
                        $fieldname  = "email";
                        $fieldvalue = $valuearray["qemail"];
                        break;
                    case 'qname':
                        $fieldname  = "name";
                        $fieldvalue = $valuearray["qname"];
                        break;
                    case 'qcountrys':
                        $fieldname  = "country";
                        $fieldvalue = $valuearray["qcountrys"];
                        break;
                    case 'acode':
                        $fieldname  = "areacode";
                        $fieldvalue = $valuearray["acode"];
                        break;
                    case 'qphone':
                        $fieldname  = "phone";
                        $fieldvalue = $valuearray["qphone"];
                        break;    
                    default:
                        
                        break;
                }
                mysql_query("UPDATE user_entry SET " . $fieldname . " ='" . $fieldvalue . "' WHERE entryid='" . $valuearray["entryval"]."'");
                die($valuearray["entryval"]);
            }else{
                if($valuearray["qemail"]){
                    mysql_query("INSERT INTO user_entry(name,email,created,ip_address,website,entryid,phone,areacode,country,browserdetail)VALUES('".mysql_real_escape_string(htmlentities($valuearray["qname"])) . "','".mysql_real_escape_string(htmlentities($valuearray["qemail"])) ."','$createddate','$ipaddress','$website','$Fieldinfo_UniqeID','$valuearray[qphone]','$valuearray[acode]','$valuearray[qcountrys]','$browserdetail')");
            $lastinsertedid= mysql_insert_id();
            if($lastinsertedid){
               $entryid= $Fieldinfo_UniqeID;
            }
            $output = $entryid;
            }
             die($output);
        }
            //die('field updated...');
           
        }
          
    }

if (isset($_POST['name'])) {
   
    //  Getting and initiating variables For insertation Process
    $name               = $_POST['name'];
    $email              = $_POST['email'];
    $country            = $_POST['country'];
    $code               = $_POST['acode'];
    $contact            = $_POST['phone'];
    $source = $target = $qtat = $qtmin = $qtformat = "";
    $count              = isset($_POST["count"])?$_POST["count"]:"";
    $completedfilecnt   = $_POST["completedfilecnt"];
    $comment            = $_POST['comment'];

    // Translation
    if(isset($_POST["target"]) && !empty($_POST["target"])){
        $source             = isset($_POST["source"])?$_POST["source"]:""; // Translation
        $target             = isset($_POST["target"])?$_POST["target"]:"";  // Translation
        $qservice           = $_POST['qservice'];
        $qpurpose           = $_POST['qpurpose'];
        $QUOTESERVICE       = 'Translation';
        $updateTableName    = 'translationsite_quote';
        $qnote      = isset($_POST["qnote"])?$_POST["qnote"]:"";   
        $qmail              = isset($_POST["qmail"])?$_POST["qmail"]:"";
        if ($qnote == '1') {
            $qnote = 'Yes';
        } else {
            $qnote = 'No';
        }
        if ($qmail == '1') {
            $qmail = 'Yes';
        } else {
            $qmail = 'No';
        }

    }else{
        // Transcription
        $qpurpose           = $_POST['qpurpose'];
        $qtmin              = isset($_POST["qtmin"])?$_POST["qtmin"]:""; // Transcription
        $qtformat           = isset($_POST["qtformat"])?$_POST["qtformat"]:""; // Transcription
        $qservice           = $_POST["qtservice"];
        $QUOTESERVICE       = 'Transcription';
        $updateTableName    = 'transcription_tsus';
        $qtver = $_POST["qtver"];
        if($qtver=='1')
        {
            $qtver='Yes';
        }
        else
        {
            $qtver='No';
        }
        $qttcode = $_POST["qttcode"];
        if($qttcode=='1')
        {
            $qttcode='Yes';
        }
        else{
            $qttcode='No';
        }
    }
    $qtat               = isset($_POST["qtat"])?$_POST["qtat"]:"";      
    $fil                = $_POST['filena'];
    $copy               = isset($_POST["copy"])?$_POST["copy"]:"";
   
    $qtlang = $_POST["qtlang"];
    if ($qpurpose) {
        $simplemailsubject = $qpurpose;
    } else {
        $simplemailsubject = $comment;
    }

    $smsubject      = explode(" ", $simplemailsubject);
    $smsubjectnew   = join(" ", array_slice($smsubject, 0, 3));
    $other_part     = implode(" ", array_splice($smsubject, 3));

    if ($other_part) {
        $finalmailsubject = $smsubjectnew . "...";
    } else {
        $finalmailsubject = $smsubjectnew;
    }
    $qmailmsg   = isset($_POST["qmailmsg"])?$_POST["qmailmsg"]:"";
   
    if ($qmailmsg != '') {
        $qmmsg =  '<tr>
						<td align="left" valign="top"  style="padding:6px; width:170px;">
							  <p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-weight: bold;  text-transform: capitalize; font-size: 17px; color: #000000; width:170px;">Address : </p>
						</td>
						<td align="left" style="padding:6px;">
							<p style=" text-align: left; margin: 0px; padding: 0 0 0 23px; font-size: 15px; color: #000000;">' . $qmailmsg . ' </p>
						</td>
					</tr> ';
    } else {
        $qmmsg = '';
    }

    $filena = '';
    $s      = explode(',', $fil);
    $fie    = '';
    $fill   = '';
    $filink = '';
    $cou    = count($s);

    for ($t = 0; $t < $cou; $t++) {
        if ($t != ($cou - 1)) {
            $fill = str_replace("\\", '/', $s[$t]);
            $fie = $fie . basename($fill) . "|,";
        } else {
            $fill = str_replace("\\", '/', $s[$t]);
            $fie = $fie . basename($fill);
        }
    }
	 
    function multi_attach_mail($to, $subject, $message, $email, $name) {
            $headers = "From: $email";
            // boundary
            $semi_rand = md5(time());
            $mime_boundary = "==Multipart_Boundary_x{$semi_rand}x";
            // headers for attachment
            $headers .= "\nMIME-Version: 1.0\n" . "Content-Type: multipart/mixed;\n" . " boundary=\"{$mime_boundary}\"";
            // multipart boundary
            $message = "--{$mime_boundary}\n" . "Content-Type: text/html; charset=\"UTF-8\"\n" .
                       "Content-Transfer-Encoding: 7bit\n\n" . $message . "\n\n";

            // preparing attachments removed for crm
            $message    .= "--{$mime_boundary}--";
            $returnpath = "-f" . $email;
            //send email
            @mail($to, $subject, wordwrap($message), $headers, $returnpath);
        }

       $filescount     = $completedfilecnt . "/" . $count;
    
    if ($SEND_QUOTE == 0) {

        if($QUOTESERVICE  == 'Transcription'){
            mysql_query("INSERT INTO transcription_tsus(id,name,email,country,acode,phone,minutes,ttime,fileformat,servicetype,verbatim,tcode,language,comment,site,source_lang, target_lang, ufile, website,iscrm,ipaddress,createddate,browserdetail,filescount,purpose) VALUES('','" . mysql_real_escape_string(htmlentities($name)) . "','$email','$country','$code','$contact','$qtmin','$qtat','$qtformat','$qservice','$qtver','$qttcode','$qtlang','" . mysql_real_escape_string(htmlentities($comment)) . "','Vanan new','$source','$target','" . mysql_real_escape_string(htmlentities($fil)) . "','$website',1,'$ipaddress','$createddate','$browserdetail','$filescount','$qpurpose')");
            $query = "select max(id) as Sno from transcription_tsus";
            $tbleCodeStr = $TABLECODE['transcription_tsus'];
            
        }else{
            mysql_query("INSERT INTO translationsite_quote (Sno, name, email,country,areacode, phone, source_lang, target_lang, ufile, comment, website,iscrm,ipaddress,createddate,browserdetail,filescount,purpose) values ('','" . mysql_real_escape_string(htmlentities($name)) . "','$email','$country','$code','$contact','$source','$target','" . mysql_real_escape_string(htmlentities($fil)) . "','" . mysql_real_escape_string(htmlentities($comment)) . "','$website',1,'$ipaddress','$createddate','$browserdetail','$filescount','$qpurpose') ");
            $query = "select max(Sno) as Sno from translationsite_quote";
            $tbleCodeStr = $TABLECODE['translationsite_quote'];
        }

        $result = mysql_query($query) or trigger_error(mysql_error() . $query);
        $row = mysql_fetch_array($result, MYSQL_ASSOC);
        $sno = $row["Sno"];
        $fileInfo = $fileArr = array();
        if (!empty($fil))
            $fileArr = explode(",", $fil);
        foreach ($fileArr as $val) {
            $UniqeID = uniqid();
            $param = array();
            $infoArr = explode("#-#", $val);
            $param['fileid'] = $UniqeID;
            $param['filename'] = substr($infoArr[0], strpos($infoArr[0], '/') + 1);
            $param['filesize'] = $infoArr[1];
            $fileInfo[] = $param;

            mysql_query("INSERT INTO uploads (Id, OrderId, TableCode, FileName,FileFormat,FileSize,FileId) values ('',$sno, '$tbleCodeStr', '$infoArr[0]','$infoArr[2]','$infoArr[1]', '$UniqeID') ");
        }
        //echo "UPDATE user_entry SET flag ='1'  WHERE entryid='" . $_POST['recordkey']."'";
         mysql_query("UPDATE user_entry SET flag ='1'  WHERE entryid='" . $_POST['recordkey']."'");
        $filink = $filesizeinfo = $filecontent = '';
        $j = 1;
        $fileDonwloadurl = $CRMSERVERPATH.'filedownload.php?FileId=';
        foreach ($fileInfo as $val) {
            $dispName = substr($val['filename'], strpos($val['filename'], '_') + 1);
            $filink .=$j . ')&nbsp;<a data-download="' . $val['filename'] . '" style="color:blue;" href="' . $fileDonwloadurl . $val['fileid'] . '">' . $dispName . '</a><br/>';
            $filesizeinfo .= $j . ")&nbsp;" . $dispName . " " . $val['filesize'] . "<br/>";
            $j++;
            $filecontent .='<tr>
                                <td width="100" align="center" style="border-bottom:1px solid #d9d9d9">File:</td><td height="60" style="padding-bottom:5px;border-bottom:1px solid #d9d9d9">' . $dispName . " " . $val['filesize'] . '</td>
                            </tr>';
        }
        //For mailer confirmation - start
        $replace_array = array();
        $search_array = array();
        $search_array = array(  '__SITEURL__' => $site_url,
                                '__SITENAME__' => $site_name,
                                '__FINALMAILSUBJECT__' => $finalmailsubject,
                                '__MAILCONTENT__' => $filecontent);

        $fileop          = fopen('mailer/quoteconfirmation_mailer.html', "r");
        $mail_content    = fread($fileop, filesize('mailer/quoteconfirmation_mailer.html'));
        fclose($fileop);
        $messagenew         = strtr($mail_content, $search_array);

        //For mailer confirmation - end
        // $to             = $email; 
        //$to             = $email.",support@vananservices.com,vananbackup@gmail.com"; // 2 tickets will be created as per sugan approval
         $to = 'support@vananservices.com,vananbackup@gmail.com';
        // subject
        $subject        = "Confirmation Mail - ".$QUOTEMAILERINFO[$site_name]['name'];  // 'Translation Quote - Click For Translation';
 
       
       
       multi_attach_mail($to, $subject, $messagenew, $email, $name);
        include_once 'lib/MailChimp.php';
        if ($copy == 1) {
            $name = filter_var($_POST['name'], FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_LOW);
            $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);

            $mc = new \Drewm\MailChimp('25b1fe0e5e2d8bf7197dfd8ad0bdaab7-us11');
            $mvars = array('optin_ip' => $_SERVER['REMOTE_ADDR'], 'FNAME' => $name);
            $result = $mc->call('lists/subscribe', array(
                'id' => 'b207fdf956',
                'email' => array('email' => $email),
                'merge_vars' => $mvars,
                'double_optin' => true,
                'update_existing' => false,
                'replace_interests' => false,
                'send_welcome' => false
                    )
            );
        }

        if ($_REQUEST['uploadflag'] == 'true') {

            $quoteArr = base64_encode(serialize(array('filesizeinfo' => $filesizeinfo, 'filink' => $filink, 'quoteid' => $sno,
                'uptblname'=>$updateTableName,'quoteservice'=>$QUOTESERVICE)));
            $output = json_encode(array('type' => 'quote', 'status' => '1', 'info' => $quoteArr));
            die($output);
        }else{
         $quoteInfo = array('filesizeinfo' => $filesizeinfo, 'filink' => $filink,'quoteservice'=>$QUOTESERVICE);

        }
    }
    /*$link = mysql_connect('pricequotecalc.db.9113838.hostedresource.com', 'pricequotecalc', 'kjYU654#'); // Remote server
    if (!$link) {
        die('Could not connect: ' . mysql_error());
    }
    mysql_select_db("pricequotecalc");*/
    if($country){
    $query1 = mysql_query("SELECT `B` FROM `countrycode` WHERE `A` = '$country'");
    $ccode  = mysql_result($query1, 0, 'B');
    $ctcode = (int) $ccode;
    $phone  = '+' . $ctcode;
    $phone .= ' - ' . $code; // Area code must to call them
    $phone .= ' - ' . $contact;
    $phone = empty($contact)?"":$phone;
    }

    if ($_POST['uploadflag'] == "false") {
    // vananbackup@gmail.com  into BCC
        $to = 'support@vananservices.com,vananbackup@gmail.com';

// 
        $service_name   = $quoteInfo['quoteservice'].' Services - Quote'; //'Translation Services - Quote';
        $subject        = $quoteInfo['quoteservice'].$QUOTEMAILERINFO[$site_name]['subject']; //'Translation Quote - ' . $site_name;

        $logo = rtrim($site_url, '/') . '/img/DS-logo.png';
        $mailreplace = array('__SITELOGOIMG__' => $logo,
                            '__NAME__' => $name,
                            '__EMAIL__' => $email,
                            '__PHONE__' => $phone,
                            '__MINUTES__' => $qtmin,
                            '__MINUTESDISP__' => empty($qtmin)?"none":"",
                            '__INPUTFILEFORMAT__' => $qtformat,
                            '__INPUTFILEFORMATDISP__' => empty($qtformat)?"none":"",
                            '__TRANSCRIPTION__' => $qtlang,
                            '__TRANSCRIPTIONDISP__' => empty($qtlang)?"none":"",
                            '__SOURCE__' => $source,
                            '__SOURCEDISP__' => empty($source)?"none":"",
                            '__TARGET__' => $target,
                            '__TARGETDISP__' => empty($target)?"none":"",
                            '__FILESIZEINFO__' => html_entity_decode($quoteInfo["filesizeinfo"]) ,
                            '__FILELINK__' => html_entity_decode($quoteInfo["filink"]),
                            '__NOTE__' => $qnote,
                            '__NOTEDISP__' => empty($qnote)?"none":"",
                            '__GMAILCONTENT__' => $qmail,
                            '__GMAILCONTENTDISP__' => empty($qmail)?"none":"",
                            '__TATIME__' => $qtat,
                            '__PURPOSE__' => $qpurpose,
                            '__PURPOSEDISP__' => empty($qpurpose)?"none":"",
                            '__COMMENT__' => nl2br(stripslashes($comment)),
                            '__GMAILMSG__' => $qmmsg,
                            '__SERVICENAME__' => $service_name,
							'__SERVICESUBJECT__' => $subject,
							'__SITEURL__' => $site_url,
                            '__VERB__' => $qtver,
                            '__VERBDISP__' => empty($qtver)?"none":"",
                            '__TIMECODE__' => $qttcode,
                            '__TIMECODEDISP__' => empty($qttcode)?"none":""
                            );

        $file             = fopen("mailer/quote_mailer2.html", "r");
        $htmlmail_content = fread($file, filesize('mailer/quote_mailer2.html'));
        fclose($file);
        $html_content     = strtr($htmlmail_content, $mailreplace);
        
        multi_attach_mail($to, $subject, $html_content, $email, $name);
        if (isset($_COOKIE['uploadtest'])) {
            echo "===>Success...";
        }


        $output = json_encode(array('type' => 'message', 'text' => 'Your request has been sent successfully and you will receive an email from us shortly. Thank you!'));
        die($output);
    }
} else {

    if ($_POST['uploadflag'] == "false") {
        $output = json_encode(array('type' => 'message', 'text' => 'Sorry for inconvenience, Reach us at 1-888-308-1099'));
        die($output);
    }
}
?>