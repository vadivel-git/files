<?php
include_once "common_setting.php";
include_once "lib/common_array_price_quote.php";
include_once "lib/functions.php";

if (substr($_SERVER['REMOTE_ADDR'], 0, 4) == '127.'
    || $_SERVER['REMOTE_ADDR'] == '::1') {
    $RANDOMNO       = rand();
    $channel_click  = "payment";
    $sitename       = 'localhost/projects/clickfortranslation/';
    $freequote      = 'show';
    echo "<script>var successpath = 'localhost/projects/clickfortranslation';</script>";
}else {
    $RANDOMNO       = $COMMONSETTING['RANDOMNO'];
    $channel_click  = ($_POST['freequote'] == 'show') ? "free quote" : "payment";
    $sitename       = $serverdetail['HTTP_HOST'];
    echo "<script>var successpath = '".$QUOTEMAILERINFO[$sitename]['successpage']."';</script>";
}

$page               = (isset($page)) ? $page : "quote";
$protocol           = (isset($serverdetail['HTTPS']) && $serverdetail['HTTPS'] != 'off') ? "https://" : "http://";
$pay_email          = isset($_POST['requestvariable']['customer_email']) ? $_POST['requestvariable']['customer_email'] : "";
$customer_dashboard = isset($_POST['requestvariable']['customer_dashboard']) ? $_POST['requestvariable']['customer_dashboard'] : "";
$pay_category       = isset($_POST['requestvariable']['catetype'])? $_POST['requestvariable']['catetype'] : "";
$pay_sourcelan      = isset($_POST['requestvariable']['srclang'])?$_POST['requestvariable']['srclang']:"";
$pay_minutes        = isset($_POST['requestvariable']['audio_minutes'])?$_POST['requestvariable']['audio_minutes']:"";
$pay_targetlan      = '';
$trclang            = array('90');
$site_name          = preg_replace('/^www\./', '', $sitename);$sitename=trim($site_name);
$rush_scenario = array(
    "engnonnative" => array_merge(
        array(0 => array('6 to 8 hours','10 to 12 hours','16 to 20 hours','1 business day')),
        array(1 => array('1 business day','1 to 2 business days','2 to 3 business days','3 to 4 business days')),
        array(2 => array('1 to 2 business days','2 to 3 business days','3 to 4 business days','4 to 5 business days')),
        array(3 => array('2 to 3 business days','3 to 4 business days','4 to 5 business days','5 to 6 business days')),
        array(4 => array('2 to 3 business days','4 to 5 business days','5 to 6 business days','7 to 8 business days'))
    ),
    "engnative" => array_merge(
        array(0 => array('10 to 12 hours','16 to 20 hours','1 business day','1 to 2 business days')),
        array(1 => array('1 business day','1 to 2 business days','2 to 3 business days','3 to 4 business days')),
        array(2 => array('1 to 2 business days','2 to 3 business days','3 to 4 business days','4 to 5 business days')),
        array(3 => array('2 to 3 business days','3 to 4 business days','4 to 5 business days','5 to 6 business days')),
        array(4 => array('2 to 3 business days','4 to 5 business days','5 to 6 business days','7 to 8 business days'))
    ),
    "otr" => array_merge(
        array(0 => array('6 to 12 hours','12 to 18 hours','18 to 22 hours','1 business day')),
        array(1 => array('12 to 18 hours','18 to 22 hours','1 business day','1 to 2 business days')),
        array(2 => array('1 to 2 business days','2 to 3 business days','3 to 4 business days','4 to 5 business days')),
        array(3 => array('2 to 3 business days','3 to 4 business days','5 to 6 business days','7 to 8 business days')),
        array(4 => array('3 to 4 business days','5 to 6 business days','7 to 8 business days','9 to 10 business days')),
        array(5 => array('4 to 5 business days','6 to 7 business days','8 to 9 business days','10 to 12 business days'))
    )
);
$trcrushlanguage =array('90');
echo "<script>var folderPath='".date("dmY")."/"."';var datetime='".date("D M d Y h:i:s")."'; </script>";
?>
  <script type="text/javascript">
  var jc = jQuery.noConflict();
  var mindt =
    '<?php echo date("Y", strtotime("+5 hours")) . "-" . date("m", strtotime("+5 hours")) . "-" . date("d", strtotime("+5 hours")) . " " . date("H", strtotime("+5 hours")) . ":" . date("i", strtotime("+5 hours")) . ":00"?>';
  var maxdt =
    '<?php echo date("Y", strtotime("+24 hours")) . "-" . date("m", strtotime("+24 hours")) . "-" . date("d", strtotime("+24 hours")) . " " . date("H", strtotime("+24 hours")) . ":" . date("i", strtotime("+24 hours")) . ":00"?>';
  var curdt = '<?php echo date("Y-m-d H:i:s"); ?>';
  var todaydate = '<?php echo date("m") . ' / ' . date("d") . ' /
    ' . date("Y"); ?>';
  var cur_timee = '<?php echo date("H") . ":" . date("i") . ":" . date('
  s ');?>';
  var expeditedarr = <?php echo json_encode($rush_scenario); ?>;
  var trcrushlanguage = <?php echo json_encode($trcrushlanguage); ?>;
  var language_list = <?php echo json_encode($language); ?>;
  var country_list = <?php echo json_encode($country); ?>;
  var serverPath = <?php echo json_encode($CRMSERVERPATH); ?>;
  var originPath = <?php echo json_encode($sitename); ?>;
  var channel_click = <?php echo json_encode($channel_click); ?>;
  var trclang = <?php echo json_encode($trclang); ?>;
  var crmRootpath = '<?php echo $CRMSERVERPATH; ?>';
  var timcodeoptions = <?php echo json_encode($timcodeoptions); ?>;
  /* var successpath     = '<?php echo $QUOTEMAILERINFO[$sitename]['successpage']; ?>'; */
  var sitename = '<?php echo $sitename; ?>';
  var update_url = '<?php echo $CRMSERVERPATH; ?>crmquote_pay_update_trl.php';
  var update_quote =
    '<?php echo $CRMSERVERPATH;?>update_transcription_price_quote.php';
  </script>
  <link rel="stylesheet" type="text/css" href="<?php echo $CRMSERVERPATH; ?>css/transcription_price_quote.css">
  <link rel="stylesheet" type="text/css" href="<?php echo $CRMSERVERPATH; ?>css/transcription_price_quote_responsive.css">

  <link rel="stylesheet" type="text/css" href="css/mo-style.css">
  <link rel="stylesheet" type="text/css" href="css/mo-step.css">

  <script type="text/javascript" src="<?php echo $CRMSERVERPATH; ?>js/sweetalert.min.js?<?php echo $COMMONSETTING['RANDOMNO'];?>"></script>
  <link rel="stylesheet" type="text/css" href="<?php echo $CRMSERVERPATH; ?>css/sweetalert.css">
  <link type="text/css" href="<?php echo $CRMSERVERPATH; ?>css/checkout.css?<?php echo $RANDOMNO;?>"
    rel="stylesheet">
  <link type="text/css" href="<?php echo $CRMSERVERPATH; ?>css/my-styleNew.css?<?php echo $RANDOMNO;?>"
    rel="stylesheet">

  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

  <body>

    <div class="boxes">

      <div class="mo-place">Place your order</div>
      <!-- <div class="box"></div> -->
      <!-- <div class="box"></div> -->
      <div class="box" style="opacity: 1; z-index: 0; transform: matrix(1, 0, 0, 1, 0, 0);">

        <div class="progress1">
          <div class="bar">
            <div class="bar__fill" style="width: 50%"></div>
          </div>
          <div class="point point--complete">
            <div class="bullet"></div>
            <!-- <label class="label">1</label> -->
          </div>
          <div class="point point--active">
            <div class="bullet"></div>
            <!-- <label class="label">2</label> -->
          </div>
          <div class="point">
            <div class="bullet"></div>
            <!-- <label class="label">3</label> -->
          </div>
          <!-- <div class="point">
          <div class="bullet"></div>
          <label class="label">Success</label>
        </div> -->
        </div>
      </div>
    </div>


    <section class="ui-v-font">
      <div class="ui-container container">
        <div class="row scroll">
          <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 mas_design_bg ui_padding_00 row-eq-height">
            <div class="col-xs-12 col-sm-7 col-md-8 col-lg-8 ui-pb cf content">
              <?php $action = $CRMSERVERPATH."paypal/payment_v2.0.php"; ?>
              <form class="float-label" spellcheck="false" id="transcriptionForm" action="<?php echo $action; ?>"
                method="post" role="form">
                <!-- <h2 class="legend ui_hw">Project Details</h2> -->
                <input type="hidden" id="site_namee" name="site_namee" value="<?php echo $sitename; ?>">
                <input type="hidden" id="quoteflag" name="quoteflag" value="0">
                <input type="hidden" id="quoteflagnew" name="quoteflagnew" value="0">
                <input type="hidden" id="recordkey" name="recordkey" value="">
                <input type="hidden" id="networkerrflag" name="networkerrflag" value="0">
                <input type="hidden" id="item_name_1" name="item_name_1" value="transcription">
                <input type="hidden" id="item_number_1" name="item_number_1" value="">
                <input type="hidden" id="formtype" name="formtype" value="payment">
                <input type="hidden" id="mode" name="mode" value="payment">
                <input type="hidden" id="service" name="service" value="transcription">
                <input type="hidden" id="uploadat" name="uploadat" value="fileupload">
                <input type="hidden" id="version_payment" name="uploaddat" value="<?php echo $_POST['version_payment']; ?>">
                <input type="hidden" id="freequote" name="freequote" value="">
                <input type="hidden" id="camethrough" name="camethrough" value="<?php echo $channel_click; ?>">
                <?php date_default_timezone_set('America/New_York'); ?>
                <input type="hidden" name="referalsite" value="<?php echo $_SERVER['SERVER_NAME'];?>">
                <input type="hidden" id="cst_db" name="cst_db" value="<?php echo $customer_dashboard; ?>">
                <input type="hidden" id="paymentamt" name="paymentamt" value="">
                <input type="hidden" id="timecode_subamt" value="0.00">
                <input type="hidden" id="subamttot" value="0.00">
                <input type="hidden" id="trans_price" name="trans_price" value="">
                <input type="hidden" id="agent_ref" name="agent_ref">
                <input type="hidden" id="trcpriceb" value="0.00">
                <input type="hidden" id="trccostb" value="0.00">
                <input type="hidden" id="trcprice" value="0.00">
                <input type="hidden" id="trccost" value="0.00">
                <input type="hidden" id="trctcodecost" value="0.00">
                <input type="hidden" id="qcheckcost" value="0.00">
                <input type="hidden" id="trcverbacost" value="0.00">
                <input type="hidden" id="trctotcost" value="0.00">
                <input type="hidden" id="mfileprice" value="0.00">
                <input type="hidden" id="expprice" value="0.00">
                <input type="hidden" id="subamt" value="0.00">
                <input type="hidden" id="transrate" value="0.00">
                <input type="hidden" id="pricedisplay" value="0.00">
                <input type="hidden" name="amount" id="amount" value="0.00">
                <input type="hidden" id="offerpct" value="0">
                <input type="hidden" id="offerval" value="0">
                <input type="hidden" id="finalround" value="0">
                <input type="hidden" id="siteprtcl" value="<?php echo $protocol; ?>">
                <div class="clearfix"></div>

                <div class="row tr-ui-float-label">
                  <div class="card">
                    <div class="products">
                      <div class="product active mo-pad" product-id="1" product-color="#fff">
                        <div class="col-xs-12 docfile tr-ui-clear">
                          <div id="first5" class="ui-small ui-re-row-sapce">
                            <select name="srclang" id="srclang" data-placeholder="Enter source language *" class="form-control ui-control del-time capturedata comboselect">
                              <option selected="" disabled="" data-placehold="Enter source language" value="">Select Category</option>
                              <option data-placehold="General" value="">General</option>
                              <option data-placehold="Legal" value="">Legal</option>
                            </select>
                            <!-- <label class="fr-label">File type</label> -->
                          </div>
                        </div>

                        <div class="col-xs-12 docfile">
                          <div id="first2" class="ui-re-row-sapce col-xs-12 tr-ui-padding-0">
                            <input id="hours" name="hours" class="form-control ui-control del-time capturedata"
                              placeholder="Enter the file length" type="text" style="padding: 0 12px !important;">
                          </div>
                        </div>

                        <div class="col-xs-12 docfile tr-ui-clear">
                          <div id="first5" class="ui-small ui-re-row-sapce">
                            <select name="trglang" id="trglang" class="form-control del-time capturedata comboselect plain-select">
                              <option selected="" disabled="" data-placehold="Enter target language" value="">Enter language</option>
                              <?php
                                            foreach ($language as $language_key => $language_val) {
                                                $lang_selected = '';
                                                if($language_val == $pay_targetlan){$lang_selected ='selected="selected"';}
                                                echo '<option value="' . $language_key . '"'.$lang_selected. '>' . $language_val . '</option>';
                                            }
                                            ?>
                            </select>
                            <!-- <label class="fr-label">File type</label> -->
                          </div>
                        </div>

                        <div class="col-xs-12 docfile tr-ui-clear">
                          <div id="first5" class="ui-small ui-re-row-sapce">
                            <select name="srclang" id="srclang" data-placeholder="Enter source language *" class="form-control ui-control del-time capturedata comboselect">
                              <option selected="" disabled="" data-placehold="Enter source language" value="">Select time code</option>
                              <option data-placehold="General" value="">General</option>
                              <option data-placehold="Legal" value="">Legal</option>
                            </select>
                            <!-- <label class="fr-label">File type</label> -->
                          </div>
                        </div>

                        <div class="col-xs-12 text-left mr_cntr">
                          <span>
                            <input class="hidden-xs-up cbxid del-time capturedata" id="notacrmpay" type="checkbox"
                              onchange="eligibility();paytc_pricequoteclac();">
                            <label class="cbx" id="notacrmpay-lbl" tabindex="0" for="notacrmpay"></label>
                            <label class="lbl" for="notacrmpay">I need translation</label>
                          </span>
                        </div>

                        <div class="col-xs-12 docfile tr-ui-clear">
                          <div id="first5" class="ui-small ui-re-row-sapce">
                            <select name="trglang" id="trglang" class="form-control del-time capturedata comboselect plain-select">
                              <option selected="" disabled="" data-placehold="Enter target language" value="">Translate to</option>
                              <?php
                                            foreach ($language as $language_key => $language_val) {
                                                $lang_selected = '';
                                                if($language_val == $pay_targetlan){$lang_selected ='selected="selected"';}
                                                echo '<option value="' . $language_key . '"'.$lang_selected. '>' . $language_val . '</option>';
                                            }
                                            ?>
                            </select>
                            <!-- <label class="fr-label">File type</label> -->
                          </div>
                        </div>

                      </div>
                      <div class="product" product-id="2" product-color="#fff">
                        <div class="uploadhere displaynone" style="display: block;">
                          <div class="col-xs-12 tr-ui-clear">
                            <div class="ui-upolad" onclick="addFiles();">
                              <img src="<?php echo $CRMSERVERPATH ?>img/up.svg" width="70%" alt="addfiles"
                                class="img-responsive center-block" width="40" style="margin: 0 auto 14px auto;">
                              <input type="file" id="file" style="display:none;" multiple="" onchange="upload()"> Add files
                              <p style="padding-top: 12px;" class="text-center ui-p"><strong>Note : </strong>You may upload multiple files
                                at the same time.</p>
                              <p class="text-center ui-p">You may also upload your files later.</p>
                            </div>
                            <div class="upload_error" style="color:#e0271d; font-weight:bold; padding:5px 0px; display: none;">Network connection Error .. Please check your internet
                              connection ...</div>

                          </div>
                          <!-- <div class="col-xs-12 tr-ui-clear" id="fileuploadfield">
                                      <div class="panel panel-default" style="display:none;" id="info">
                                          <div class="row ui-up-head">
                                              <div class="col-xs-4 col-sm-4 col-lg-4 fname">File name</div>
                                              <div class="col-xs-4 col-sm-4 col-lg-4 text-center" >File length</div>
                                              <div class="col-xs-4 col-sm-4 col-lg-4 text-center pull-right">Status</div>
                                          </div>
                                      </div>
                                    </div> -->

                          <div class="col-xs-12 tr-ui-clear no-padding" id="fileuploadfield">
                            <div class="panel panel-default" style="display: block;" id="info">

                              <div class="row striped row-1">
                                <div class="col-xs-6 audioLengths ellipsisprgbar text-left text-size-ne mo-title-line"
                                  style="
">
                                  <span data-file="notification.mp3" data-modfy="16102017/ovPc2Nxx_notification.mp3"
                                    data-uploadid="" data-complete="0" id="removeFile-1"
                                    class="up-close removeboth-1" data-seerid="1" style="visibility: visible;">
                                    <a href="javascript:void(0)" data-placement="bottom" data-original-title="Remove file"
                                      class=""> <i class="fa fa-trash-o" aria-hidden="true" style="font-weight:bold"></i></a>
                                  </span>&nbsp; &nbsp; notification.mp3
                                  <span class="mo-filesize">924.9 kb</span>
                                </div>

                                <div class="clo-xs-4">

                                  <input type="text" data-ser="1" maxlength="4" id="durationnewpay-1" style="width: 55px;text-align: center;margin: 0 0;float: left;height: 33px !important;"
                                    class="length del-time onlynumbers text-center"
                                    placeholder="min" value="" onkeyup="paytc_pricequoteclac();paytc_paymentenable();"
                                    name="length[]">
                                  <span class="filetypes-1 hrdisplay" name="qfmsg" id="filetypespay1">(01:14)</span>
                                  <input type="hidden" class="fileNamepay" value="16102017/ovPc2Nxx_notification.mp3#-#(11.9 KB)#-#audio/mp3"
                                    id="uploadFiles-1" data-durat="" name="uploadFiles[]"
                                    data-serid="1">
                                </div>
                                <div class="col-xs-2 text-right text-size-ne no-padding">
                                  <span id="progpay-1" class="progress-upload" style="display: none;">
                                    <input type="hidden" class="filePath" name="filePaths[]" value="">
                                    <div class="awsupload-progress">
                                      <div style="width: 100%;" class="awsupload-progress-bar"></div>
                                      <div class="awsupload-progress-text">100%</div>
                                    </div>
                                  </span>
                                  <div class="audioLength text-center mo-filestatus" id="inp-1">
                                  <i class="fa fa-check-circle mo-fa-click" aria-hidden="true"></i>
                                 </div>
                                </div>
                                <audio class="audio" id="audio-1" src="blob:http://localhost/ebf5db46-2978-45ad-98d6-70598b3cf330"></audio>
                              </div>
                              <div class="row striped row-1" style="
    background-color: #ffffff;
">
                                <div class="col-xs-6 audioLengths ellipsisprgbar text-left text-size-ne mo-title-line"
                                  style="
">
                                  <span data-file="notification.mp3" data-modfy="16102017/ovPc2Nxx_notification.mp3"
                                    data-uploadid="" data-complete="0" id="removeFile-1"
                                    class="up-close removeboth-1" data-seerid="1" style="visibility: visible;">
                                    <a href="javascript:void(0)" data-placement="bottom" data-original-title="Remove file"
                                      class=""> <i class="fa fa-trash-o" aria-hidden="true" style="font-weight:bold"></i></a>
                                  </span>&nbsp; &nbsp; notification.mp3
                                  <span class="mo-filesize">924.9 kb</span>
                                </div>

                                <div class="clo-xs-4">

                                  <input type="text" data-ser="1" maxlength="4" id="durationnewpay-1" style="width: 55px;text-align: center;margin: 0 0;float: left;height: 33px !important;"
                                    class="length del-time onlynumbers text-center"
                                    placeholder="min" value="" onkeyup="paytc_pricequoteclac();paytc_paymentenable();"
                                    name="length[]">
                                  <span class="filetypes-1 hrdisplay" name="qfmsg" id="filetypespay1">(00:21)</span>
                                  <input type="hidden" class="fileNamepay" value="16102017/ovPc2Nxx_notification.mp3#-#(11.9 KB)#-#audio/mp3"
                                    id="uploadFiles-1" data-durat="" name="uploadFiles[]"
                                    data-serid="1">
                                </div>
                                <div class="col-xs-2 text-right text-size-ne no-padding">
                                  <span id="progpay-1" class="progress-upload" style="display: none;">
                                    <input type="hidden" class="filePath" name="filePaths[]" value="">
                                    <div class="awsupload-progress">
                                      <div style="width: 100%;" class="awsupload-progress-bar"></div>
                                      <div class="awsupload-progress-text">100%</div>
                                    </div>
                                  </span>
                                  <div class="audioLength text-center mo-filestatus" id="inp-1">
                                    <i class="fa fa-times-circle mo-fa-wrong" aria-hidden="true"></i>
                                  </div>
                                </div>
                                <audio class="audio" id="audio-1" src="blob:http://localhost/e25dbab4-d6f9-44e3-a9e0-d7b8a5880c8b"></audio>
                              </div>

                              <div class="row striped row-1">
                                <div class="col-xs-6 audioLengths ellipsisprgbar text-left text-size-ne mo-title-line"
                                  style="
">
                                  <span data-file="notification.mp3" data-modfy="16102017/ovPc2Nxx_notification.mp3"
                                    data-uploadid="" data-complete="0" id="removeFile-1"
                                    class="up-close removeboth-1" data-seerid="1" style="visibility: visible;">
                                    <a href="javascript:void(0)" data-placement="bottom" data-original-title="Remove file"
                                      class=""> <i class="fa fa-trash-o" aria-hidden="true" style="font-weight:bold"></i></a>
                                  </span>&nbsp; &nbsp; notification.mp3
                                  <span class="mo-filesize">924.9 kb</span>
                                </div>

                                <div class="clo-xs-4">

                                  <input type="text" data-ser="1" maxlength="4" id="durationnewpay-1" style="width: 55px;text-align: center;margin: 0 0;float: left;height: 33px !important;"
                                    class="length del-time onlynumbers text-center"
                                    placeholder="min" value="" onkeyup="paytc_pricequoteclac();paytc_paymentenable();"
                                    name="length[]">
                                  <span class="filetypes-1 hrdisplay" name="qfmsg" id="filetypespay1">(00:01)</span>
                                  <input type="hidden" class="fileNamepay" value="16102017/ovPc2Nxx_notification.mp3#-#(11.9 KB)#-#audio/mp3"
                                    id="uploadFiles-1" data-durat="" name="uploadFiles[]"
                                    data-serid="1">
                                </div>
                                <div class="col-xs-2 text-right text-size-ne no-padding">
                                  <span id="progpay-1" class="progress-upload" style="display: none;">
                                    <input type="hidden" class="filePath" name="filePaths[]" value="">
                                    <div class="awsupload-progress">
                                      <div style="width: 100%;" class="awsupload-progress-bar"></div>
                                      <div class="awsupload-progress-text">100%</div>
                                    </div>
                                  </span>
                                  <div class="audioLength text-center mo-filestatus" id="inp-1">
                                    <i class="fa fa-check-circle mo-fa-click" aria-hidden="true"></i>
                                  </div>
                                </div>
                                <audio class="audio" id="audio-1" src="blob:http://localhost/e25dbab4-d6f9-44e3-a9e0-d7b8a5880c8b"></audio>
                              </div>
                              <div class="row striped row-1">
                                <div class="col-xs-12 text-size-ne mo-position">
                                  <span id="progpay-1" class="progress-upload ">
                                    <input type="hidden" class="filePath" name="filePaths[]" value="">
                                    <div class="awsupload-progress">
                                      <div style="width: 100%;" class="awsupload-progress-bar"></div>
                                    </div>
                                  </span>
                                  <div class="audioLength text-center" id="inp-1" style="display:none;">File Uploaded. </div>
                                </div>
                                <div class="col-xs-6 audioLengths ellipsisprgbar text-left text-size-ne mo-title-line"
                                  style="
">
                                  <span data-file="notification.mp3" data-modfy="16102017/ovPc2Nxx_notification.mp3"
                                    data-uploadid="" data-complete="0" id="removeFile-1"
                                    class="up-close removeboth-1" data-seerid="1" style="visibility: visible;">
                                    <a href="javascript:void(0)" data-placement="bottom" data-original-title="Remove file"
                                      class=""> <i class="fa fa-trash-o" aria-hidden="true" style="font-weight:bold"></i></a>
                                  </span>&nbsp; &nbsp; notification.mp3
                                  <span class="mo-filesize">924.9 kb</span>
                                </div>
                                <div class="col-xs-4">
                                  <input type="text" data-ser="1" maxlength="4" id="durationnewpay-1" style="display:none;width:55px;text-align: center;float: left; margin: 0 0 0 18%;"
                                    class="length del-time onlynumbers text-center"
                                    placeholder="min" value="" onkeyup="paytc_pricequoteclac();paytc_paymentenable();"
                                    name="length[]">
                                  <span class="filetypes-1 hrdisplay" name="qfmsg" id="filetypespay1"></span>
                                  <div class="awsupload-progress-text mo-awsupload-progress-text">100%</div>
                                </div>

                                <div class="col-xs-2 text-center text-size-ne no-padding">
                                  <span id="progpay-1" class="progress-upload" style="display: none;">
                                    <input type="hidden" class="filePath" name="filePaths[]" value="">
                                    <div class="awsupload-progress">
                                      <div style="width: 100%;" class="awsupload-progress-bar"></div>
                                      <div class="awsupload-progress-text">100%</div>
                                    </div>
                                  </span>
                                  <div class="audioLength text-center mo-filestatus" id="inp-1">
                                    <i class="fa fa-times-circle mo-fa-wrong" aria-hidden="true"></i>
                                  </div>
                                </div>
                                <audio class="audio" id="audio-1"></audio>
                              </div>
                            </div>
                          </div>

                          <div class="col-xs-12 tr-ui-clear">
                            <div id="my-welcome-message2" class="displaynone vd-welcome">
                              <div class="modal-body no-padding vd-pad">
                                <div class="pop">
                                  <img src="<?php echo $CRMSERVERPATH ?>img/vd-upload-pop.png" alt="upload" title="upload"
                                    class="vd-upload-pop">
                                  <div class="vd-hilights-pop">
                                    <div id="uploading_msg">Kindly don't close this window.
                                      <br><b>Uploading in Progress...</b>
                                      <div id="completedfiletext"></div>
                                    </div>
                                    <div class="upload_errmsg" style="display: none;">
                                      There seems to be a problem with your request.
                                      <br> Here are a few other options for you.
                                      <br>
                                      <br>
                                      <div style="text-align:left">1. Upload your files
                                        <a href="AlternateUpload.php" target="_blank" style="color:blue"><u> here</u> </a>
                                        <br> 2. OR Share your dropbox link to support@vananservices.com
                                        <br> 3. OR Simply
                                        <span onclick="$('#open-icon').trigger('click')" style="color:blue;cursor: pointer"><u> Chat with us </u> </span> anytime.
                                      </div>
                                    </div>
                                  </div>
                                  <!-- Kindly don't close this page as your file(s) are being uploaded. -->
                                  <img src="<?php echo $CRMSERVERPATH ?>img/loading.gif" alt="upload gif" title="loading"
                                    class="vd-up-gif">
                                </div>
                              </div>
                            </div>
                          </div>

                          <div class="col-xs-12 tr-ui-clear">
                            <div class="filecomment displaynone tr-ui-ma">
                              <div class="form-group form-modifier col-lg-12 dv_nopad">
                                <textarea style="font-weight: 300 !important; font-size: 12px !important; line-height: 24px;"
                                  name="filecomments" id="filecomments" class="form-control ui-control textarea-modifier"
                                  rows="4" placeholder="Please enter spelling of names, locations, addresses and any additional information / notes (including handwritten or illegible text) that can help us accurately translate your specific requests."></textarea>
                              </div>
                            </div>
                          </div>

                        </div>
                        <div class="clearfix"></div>

                      </div>


                      <div class="product mo-pad1" product-id="3" product-color="#fff">
                        <!-- <h3 class="mo-h3 text-left">Your Order</h3> -->

                        <div class="row mo-bottum-line mo-seprate">
                          <div class="col-xs-8 text-left">
                            <p class="mo-price-p">Transcription by US
                              <br>
                              <span class="mo-price-s">Native Transcription ($1.75/min)</span>
                            </p>
                          </div>
                          <div class="col-xs-4 mo-text-right-p">
                            <p class="mo-price-p">$231.00
                              <br>
                              <!-- <span class="mo-price-s">---</span> -->
                            </p>
                          </div>
                        </div>

                        <div class="row mo-bottum-line mo-seprate">
                          <div class="col-xs-8 text-left">
                            <p class="mo-price-p">Run Time</p>
                          </div>
                          <div class="col-xs-4 mo-text-right-p">
                            <p class="mo-price-p">72 mins
                              <!-- <span class="mo-price-s">---</span> -->
                            </p>
                          </div>
                        </div>

                        <div class="row mo-bottum-line mo-seprate">
                          <div class="col-xs-8 text-left">
                            <p class="mo-price-p">Time Code
                              <!-- <span class="mo-price-s">---</span> -->
                            </p>
                          </div>
                          <div class="col-xs-4 mo-text-right-p">
                            <p class="mo-price-p">$270.00
                              <br>
                              <!-- <span class="mo-price-s">---</span> -->
                            </p>
                          </div>
                        </div>

                        <div class="row mo-bottum-line mo-seprate">
                          <div class="col-xs-8 text-left">
                            <p class="mo-price-p mo-text-green">Total Transcription Cost</p>
                          </div>
                          <div class="col-xs-4 mo-text-right-p">
                            <p class="mo-price-p mo-text-green">$221.98</p>
                          </div>
                        </div>

                        <div class="row">
                          <div class="mo-accordion">
                            <div class="app">
                              <div class="app_inner mo-space">
                                <input checked="" id="tab-1" name="buttons" type="radio">
                                <label for="tab-1">
                                  <div class="app_inner__tab">
                                    <div class="col-xs-8 text-left">
                                      <h2>Additional services</h2>
                                    </div>

                                    <div class="tab_left">
                                      <div class="col-xs-4 mo-text-right-p">
                                        <div class="tab_left__image"><i class="fa fa-plus" aria-hidden="true"></i></div>
                                      </div>
                                    </div>

                                    <div class="col-xs-8 text-left">
                                      <h2>
                                        <span>
                                          <input class="hidden-xs-up" id="notacrmpay" type="checkbox" onchange="eligibility();paytc_pricequoteclac();">
                                          <label class="cbx" id="notacrmpay-lbl" tabindex="0" for="notacrmpay" style="width: 20px;float: left;margin: 0 7px 0 0;"></label>
                                          <label class="lbl" for="notacrmpay">Include Verbatim</label>
                                        </span>
                                      <span class="mo-price-s-s">Verbatim means word to word typing. This comes at an additional price of $2.33/ minute</span>
                                      </h2>
                                    </div>
                                    <div class="tab_left">
                                      <div class="col-xs-4 mo-text-right-p">
                                        <div class="tab_left__image">$323.36</div>
                                      </div>
                                    </div>

                                    <div class="col-xs-8 text-left">
                                      <h2>
                                        <span>
                                          <input class="hidden-xs-up" id="notacrmpay" type="checkbox" onchange="eligibility();paytc_pricequoteclac();">
                                          <label class="cbx" id="notacrmpay-lbl" tabindex="0" for="notacrmpay" style="width: 20px;float: left;margin: 0 7px 15px 0;"></label>
                                          <label class="lbl" for="notacrmpay">Include Additional Quality Check</label>
                                        </span>
                                      <span class="mo-price-s-s">Experts review your project to ensure 98% accuracy.   This comes at an additional price of $2.33/ minute</span>
                                      </h2>
                                    </div>
                                    <div class="tab_left">
                                      <div class="col-xs-4 mo-text-right-p">
                                        <div class="tab_left__image">$670.80</div>
                                      </div>
                                    </div>

                                    <div class="col-xs-8 text-left">
                                      <h2>
                                        <span>
                                          <input class="hidden-xs-up" id="notacrmpay" type="checkbox" onchange="eligibility();paytc_pricequoteclac();">
                                          <label class="cbx" id="notacrmpay-lbl" tabindex="0" for="notacrmpay" style="width: 20px;float: left;margin: 0 7px 15px 0;"></label>
                                          <label class="lbl" for="notacrmpay">Ask for a trial @ no cost</label>
                                        </span>
                                      <span class="mo-price-s-s">Our free trial helps you evaluate if our standards and your expectations go hand in hand, so that you stay rest assured</span>
                                      </h2>
                                    </div>
                                    <div class="tab_left">
                                      <div class="col-xs-4 mo-text-right-p">
                                        <!-- <div class="tab_left__image">-</div> -->
                                      </div>
                                    </div>


                                    <div class="tab_right"> </div>
                                  </div>
                                </label>

                                <div class="col-xs-12 mo-space mo-color">
                                  <div class="row">
                            <div class="col-xs-12 text-left">
                              <p class="mo-price-p">Estimated Delivery
                              <br>
                              <span class="mo-price-s">Standard delivery Time: 5 to 6 business days</span>
                            </p>
                            </div>

                          </div>
                                </div>


                                <input false="" id="tab-2" name="buttons" type="radio">
                                <label for="tab-2">
                                  <div class="app_inner__tab mo-app_inner__tab">
                                    <div class="app_inner__tab">
                                      <div class="col-xs-8 text-left">
                                        <h2>Looking for earlier delivery?</h2>
                                      </div>

                                      <div class="tab_left">
                                        <div class="col-xs-4 mo-text-right-p">
                                          <div class="tab_left__image"><i class="fa fa-plus" aria-hidden="true"></i></div>
                                        </div>
                                      </div>

                                      <div class="col-xs-8 text-left">
                                        <h2>
                                          <span>
                                            <input class="hidden-xs-up" id="notacrmpay" type="checkbox" onchange="eligibility();paytc_pricequoteclac();">
                                            <label class="cbx" id="notacrmpay-lbl" tabindex="0" for="notacrmpay" style="width: 20px;float: left;margin: 0 7px 15px 0;"></label>
                                            <label class="lbl" for="notacrmpay">Rush delivery @ 50% additional cost</label>
                                          </span>
                                        <span class="mo-price-s-s">Get your files in 3 - 4  business days @ additional price</span>
                                        </h2>
                                      </div>
                                      <div class="tab_left">
                                        <div class="col-xs-4 mo-text-right-p">
                                          <div class="tab_left__image">$250</div>
                                        </div>
                                      </div>

                                      <div class="col-xs-8 text-left">
                                        <h2>
                                          <span>
                                            <input class="hidden-xs-up" id="notacrmpay" type="checkbox" onchange="eligibility();paytc_pricequoteclac();">
                                            <label class="cbx" id="notacrmpay-lbl" tabindex="0" for="notacrmpay" style="width: 20px;float: left;margin: 0 7px 15px 0;"></label>
                                            <label class="lbl" for="notacrmpay">Super Rush delivery @ 100% additional cost</label>
                                          </span>
                                        <span class="mo-price-s-s">Get your files in 3 - 4  business days @ additional price</span>
                                        </h2>
                                      </div>
                                      <div class="tab_left">
                                        <div class="col-xs-4 mo-text-right-p">
                                          <div class="tab_left__image">$250</div>
                                        </div>
                                      </div>

                                      <div class="col-xs-8 text-left">
                                        <h2>
                                          <span>
                                            <input class="hidden-xs-up" id="notacrmpay" type="checkbox" onchange="eligibility();paytc_pricequoteclac();">
                                            <label class="cbx" id="notacrmpay-lbl" tabindex="0" for="notacrmpay" style="width: 20px;float: left;margin: 0 7px 15px 0;"></label>
                                            <label class="lbl" for="notacrmpay">Express delivery @ 150% additional cost</label>
                                          </span>
                                        <span class="mo-price-s-s">Get your files in 3 - 4  business days @ additional price</span>
                                        </h2>
                                      </div>
                                      <div class="tab_left">
                                        <div class="col-xs-4 mo-text-right-p">
                                          <div class="tab_left__image">$250</div>
                                        </div>
                                      </div>


                                      <div class="tab_right"> </div>
                                    </div>
                                  </div>
                              </label>

                              <div class="mo-space"></div>
                              <input false="" id="tab-3" name="buttons" type="radio">
                              <label for="tab-3">
                                <div class="app_inner__tab mo-app_inner__tab1">
                                  <div class="app_inner__tab">
                                    <div class="col-xs-8 text-left">
                                      <h2>Estimated delivery</h2>
                                      <span class="mo-price-s">Standard delivery Time: 5 to 6 business days</span>
                                    </div>

                                    <div class="tab_left">
                                      <div class="col-xs-4 mo-text-right-p">
                                        <div class="tab_left__image"><i class="fa fa-plus" aria-hidden="true"></i></div>
                                      </div>
                                    </div>

                                    <div class="col-xs-8 text-left">
                                      <h2>

                                        <span>
                                          <input class="hidden-xs-up" id="notacrmpay" type="checkbox" onchange="eligibility();paytc_pricequoteclac();">
                                          <label class="cbx" id="notacrmpay-lbl" tabindex="0" for="notacrmpay" style="width: 20px;float: left;margin: 0 7px 15px 0;"></label>
                                          <label class="lbl" for="notacrmpay">Looking for earlier delivery?</label>
                                        </span>

                                      </h2>
                                    </div>
                                    <div class="tab_right"> </div>
                                  </div>
                                </div>
                            </label>
                            </div>
                          </div>
                        </div>
                      </div>


                        <div class="row">
                          <div class="col-xs-8 text-left">
                            <p class="mo-price-p pull-left mo-text-green">Net Payable Amount
                              <div class="wrappervd"><a rel="tooltip" title="This includes transaction fee. Its usually 5% of the total order value charged for so and so purposes"><span class="control-label"><div class="tooltip--questionmark"><span class="tooltip__question">?</span></div></span></a></div>
                            </p>
                          </div>
                          <div class="col-xs-4 mo-text-right-p">
                            <p class="mo-price-p mo-text-green">$1243.98</p>
                          </div>
                        </div>

                        <div class="row">
                        <div class="col-xs-12 docfile">
                          <div id="first2" class="ui-re-row-sapce col-xs-12 tr-ui-padding-0">
                            <input id="hours" name="email" class="form-control ui-control del-time capturedata" placeholder="Enter the email" type="text" style="padding: 0 12px !important;">
                          </div>
                        </div>
                        </div>




                    </div>

                  </div>
                  <div class="footer">
                    <a class="btn" id="prev" href="#" ripple="" ripple-color="#666666" style="background-color: #23b4cf;">Prev</a>
                    <a class="btn" id="next" href="#" ripple="" ripple-color="#fff">Next</a>
                    <!-- <a class="btn mo-btn" id="next" href="#" ripple="" ripple-color="#fff">Payment process</a> -->
                  </div>
                </div>




                <div class="clearfix"></div>


                <!--
<br>
<br>
<br> -->




            </div>





            </form>
          </div>
          <!-- <div class="ui_summary col-xs-12 col-sm-5 col-md-4 col-lg-4 ui_padding_0">
                        <div class="sidebar">
                            <h2 class="legend text-center">Quote Summary</h2>
                            <div class="fr_sumarry no-summary ">
                                <div class="qt_msg ui-msg">Enter <span id="mandat" class="text-highlight">project details</span> to get the price quote for your project.</div>
                                <div class="clearfix"></div>
                                <div class="row text-center ui-email">
                                    <div class="fr_CV_msg qt_mailinfo displaynone ui-chat" onclick="parent.LC_API.open_chat_window()"><i class="fa fa-comments cv-icon-blink" aria-hidden="true"></i> <b>Chat with us</b></div>
                                    <div class="qt_mailinfo displaynone">Or</div>
                                    <div class="qt_mailinfo displaynone fr_fo_si">Enter your email ID to receive a quote from us.</div>
                                </div>
                            </div>
                            <div class="ui-summarry">
                                <div class="order-summary displaynone">
                                    <div class="ui_fr_sumarry">
                                        <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 ui-pad-r0">Base price ($<span id="trcpriceb_disp">5.00</span>/min)</div>
                                        <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right">$<span id="trccostb_disp"></span></div>
                                    </div>
                                    <div class="ui_fr_sumarry displaynone availedoff">
                                        <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 ui-pad-r0">Discounted price ($<span id="trcprice_disp">5.00</span>/min)</div>
                                        <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right">$<span id="trccost_disp"></span></div>
                                    </div>
                                    <div class="ui_fr_sumarry displaynone availedoff">
                                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 fr_txt_word_CV">
                                            <span class="offval">You save $<span id="offprice"></span></span>
                                        </div>
                                    </div>
                                    <div class="ui_fr_sumarry verbatime-pr">
                                        <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 ui-pad-r0">Verbatim</div>
                                        <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right">$<span id="trcverbacost_disp"></span></div>
                                    </div>
                                    <div class="ui_fr_sumarry timecode-pr">
                                        <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 ui-pad-r0">Time code</div>
                                        <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right">$<span id="trctcodecost_disp"></span></div>
                                    </div>
                                    <div class="ui_fr_sumarry rush-view">
                                        <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 ui-pad-r0">Subtotal</div>
                                        <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right">$<span id="trctotcost_disp"></span></div>
                                    </div>

                                    <div class="ui_fr_sumarry  rush-view trlsum">
                                        <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 ui-pad-r0">Expedited service fee
                                            <div class="wrappervd"><a rel="tooltip" id="exptooltip" title=""> <span class="control-label"><div class="tooltip--questionmark"><span class="tooltip__question">?</span></div></span></a></div>
                                        </div>
                                        <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right">$<span id="expprice_disp"></span></div>
                                    </div>
                                    <div class="ui_fr_sumarry qcheck-pr">
                                        <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 ui-pad-r0">Additional quality check</div>
                                        <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right">$<span id="qcheckcost_disp"></span></div>
                                    </div>
                                    <div class="ui_fr_sumarry">
                                        <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 ui-pad-r0">Total cost</div>
                                        <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right">$<span id="sub_amt"></span></div>
                                    </div>
                                    <div class="ui_fr_sumarry displaynone coupval-pr">
                                        <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 ui-pad-r0">Coupon discount (-<span id="ofpct"></span>)</div>
                                        <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right">$<span id="offerval_value"></span></div>
                                    </div>
                                    <div class="ui_fr_sumarry displaynone coupval-pr">
                                        <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 ui-pad-r0">Offer price</div>
                                        <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right">$<span id="sub_total"></span></div>
                                    </div>
                                    <div class="ui_fr_sumarry">
                                        <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 ui-pad-r0">Transaction fee
                                            <div class="wrappervd">
                                                <a rel="tooltip" title="Transaction fee is 5% of total order cost. This fee covers credit card, banking partners, and PayPal processing fees"><span class="control-label"><div class="tooltip--questionmark"><span class="tooltip__question">?</span></div></span></a>
                                            </div>
                                        </div>
                                        <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right">$<span id="trans_rate"></span></div>
                                    </div>
                                    <div class="ui_fr_sumarry fr_sumarry_bg">
                                        <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 ui-pad-r0"><b>Grand total</b></div>
                                        <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right"><b>$<span id="price_display"></span></b></div>
                                    </div>
                                    <?php if(in_array($sitename,$couponcodesites)){ ?>
                                    <div class="col-lg-12 float-label">
                                        <div class="coupon-blk">
                                            <div class="control">
                                                <div class="input-group">
                                                    <input id="couponcode" name="couponcode" class="form-control ui-control form-control-success capturedata" placeholder="Coupon code" >
                                                    <span class="input-group-addon" id="applycoupon">apply</span>
                                                </div>
                                            </div>
                                            <span id="couponmsg"></span>
                                        </div>
                                    </div>
                                    <?php } ?>
                                </div>

                                <div class="col-lg-12 float-label">
                                    <div>
                                        <div id="first2" class="control">
                                            <input id="paytc_qemailcrm" name="paytc_qemailcrm" class="form-control ui-control form-control-success del-time capturedata" placeholder="Your Email ID *" value="<?php echo $pay_email; ?>" >
                                        </div>
                                    </div>
                                </div>
                              <p class="tr-ui-sample"> <a href="javascript:void(0)" id='view_sample'><u>Click to view our sample</u></a> </p>
                            </div>
                            <div class="col-lg-12">
                                <div class="ui_fr_sumarry pt displaynone">
                                    <?php
                                    //                                    ui-quote-btn-joint, ui-pay-btn-joint
                                    $qtbutton ='ui-quote-btn';
                                    $ptbutton = 'ui-pay-btn';
                                    $twobutton = '';
                                    $btnclass = 'col-xs-12 col-sm-12 col-md-12 col-lg-12';
                                    if($freequote == "show"){
                                        $btnclass = 'col-xs-6 col-sm-12 col-md-12 col-lg-6';
                                        $qtbutton ='ui-quote-btn-joint';
                                        $ptbutton = 'ui-pay-btn-joint';
                                        $twobutton = 'ui-joint-btn';
                                        ?>
                                        <div id="emailquote-btn" class="col-xs-6 col-sm-12 col-md-12 col-lg-6 fr_nopadding btnhand ui-btn-quote <?php echo $twobutton; ?>">
                                            <div class="qsubmitcrm fr_email_btn <?php echo $qtbutton; ?>" tabindex="0" id="emailquote" value="Email Quote">Email the Quote</div>
                                        </div>
                                    <?php } ?>
                                    <div id="proceedpayment-btn" class="<?php echo $btnclass; ?> text-right fr_nopadding btnhand ui-btn-quote <?php echo $twobutton; ?>">
                                        <div class="qsubmitcrm fr_email_btn fr_color <?php echo $ptbutton; ?>" tabindex="0" id="proceedpayment" value="Proceed to Payment">Proceed to Payment</div>
                                    </div>
                                    <p class="fr_vvv"> <i class="fa fa-lock" aria-hidden="true"></i> Safe &amp; Secure Payment </p>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="fr_sumarry qt displaynone">
                                    <div class="fr_nopadding btnhand">
                                        <div class="qsubmitcrm fr_email_btn ui-quote-btn" style="float: left;width: 100%;" tabindex="0" id="getquote" value="Get Quote">Get Quote</div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="fr_sumarry up displaynone">
                                    <div class="fr_nopadding btnhand">
                                        <div class="qsubmitcrm fr_email_btn ui-quote-btn">Uploading...</div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="fr_sumarry pr displaynone">
                                    <div class="fr_nopadding btnhand">
                                        <div class="qsubmitcrm fr_email_btn ui-col-green">Processing...</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> -->
        </div>
      </div>
      </div>
    </section>
    <div class="fr-container">
      <!-- <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8 fr_no_padd">
            <span id="timespendingid" class="displaynone"></span>
            <?php if($customer_dashboard == ''){
                $wwwurl = (in_array($sitename,$wwwwebsites))?"www.":"";
                ?>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 text-center pad-top15 ui-underl ">
                <a href="<?php echo $protocol.$wwwurl.$site_name; ?>/Transcription-Send-Files.php">If you're an existing customer, upload files right away by
                    <span class="text-primary ui-primary">clicking here</span>
                </a>
            </div>
            <?php } ?>
        </div> -->
      <div class="modal fade" id="sample_modal" role="dialog" aria-labelledby="myModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" id="modal-body-sample"></div>
      </div>
      <link rel="stylesheet" href="<?php echo $CRMSERVERPATH; ?>css/jquery.datetimepicker.css?<?php echo $COMMONSETTING['RANDOMNO'];?>">
      <script type="text/javascript" src="<?php echo $CRMSERVERPATH; ?>js/transcription_price_quote.js?<?php echo $RANDOMNO;?>"></script>
      <script type="text/javascript" src="<?php echo $CRMSERVERPATH; ?>js/jquery.datetimepicker.full.js?<?php echo $COMMONSETTING['RANDOMNO'];?>"></script>

      <script type="text/javascript" src="js/step.js"></script>
      <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
      <script src='http://cdnjs.cloudflare.com/ajax/libs/gsap/1.18.0/TweenMax.min.js'></script>
      <script type="text/javascript" src="https://secure-dt.com/dtforms/js/jquery.combo.select.js"></script>

      <script>
      var catetype = "<?php echo $pay_category; ?>";
      jc('#catetype').val(catetype);
      paytc_resetVariables();
      jc('#fileupload_tat').datetimepicker({
        timepicker: false,
        format: 'm-d-Y',
        formatDate: 'm-d-Y',
        minDate: '-1970-01-01',
        scrollMonth: false,
        scrollInput: false
      });
      jc(document).on('keydown', '.onlynumbers', function(e) {
        if (e.keyCode == 46 || e.keyCode == 8 || e.keyCode == 9 ||
          e.keyCode == 27 || e.keyCode == 13 ||
          (e.keyCode == 65 && e.ctrlKey === true) ||
          (e.keyCode >= 35 && e.keyCode <= 39)) {
          return;
        } else {
          if (e.shiftKey || (e.keyCode < 48 || e.keyCode > 57) && (e.keyCode <
              96 || e.keyCode > 105)) {
            e.preventDefault();
          }
        }
      });
      // tooltip_new_responsive
      jc(function() {
        var a = jc("[rel~=tooltip]"),
          b = !1,
          c = !1;
        a.bind("mouseenter", function() {
          if (b = jc(this), tip = b.attr("title"), c = jc(
              '<div id="tooltipvd"></div>'), !tip || "" == tip) return !
            1;
          b.removeAttr("title"), c.css("opacity", 0).html(tip).appendTo(
            "body");
          var a = function() {
            jc(window).width() < 1.5 * c.outerWidth() ? c.css(
              "max-width", jc(window).width() / 2) : c.css(
              "max-width", 340);
            var a = b.offset().left + b.outerWidth() / 2 - c.outerWidth() /
              2,
              d = b.offset().top - c.outerHeight() - 20;
            if (a < 0 ? (a = b.offset().left + b.outerWidth() / 2 -
                20,
                c.addClass("left")) : c.removeClass("left"), a + c.outerWidth() >
              jc(window).width() ? (a = b.offset().left - c.outerWidth() +
                b.outerWidth() / 2 + 20, c.addClass("right")) : c.removeClass(
                "right"), d < 0) {
              var d = b.offset().top + b.outerHeight();
              c.addClass("top")
            } else c.removeClass("top");
            c.css({
              left: a,
              top: d
            }).animate({
              top: "+=10",
              opacity: 1
            }, 50)
          };
          a(), jc(window).resize(a);
          var d = function() {
            c.animate({
              top: "-=10",
              opacity: 0
            }, 50, function() {
              jc(this).remove()
            }), b.attr("title", tip)
          };
          b.bind("mouseleave", d), c.bind("click", d)
        })
      });
      var textAreas = document.getElementsByTagName('textarea');
      Array.prototype.forEach.call(textAreas, function(elem) {
        elem.placeholder = elem.placeholder.replace(/\\n/g, '\n');
      });
      </script>
      <script src="<?php echo $CRMSERVERPATH; ?>js/jquery.combo.select.js"></script>
      <script>
      jc(function() {
        jc('.comboselect').comboSelect();
        jc('.js-select').change(function(e, v) {
          jc('.idx').text(e.target.selectedIndex)
          jc('.val').text(e.target.value)
        });
        jc('.combo-input').change(function(event) {
          var selectid = jc(this).parent().parent().attr('id');
          var thisvalue = jc('.float-label #' + selectid +
            ' select option:selected').val();
          if (thisvalue == '') {
            jc('.float-label #' + selectid + ' .combo-input').val('');
          }
        });
        jc(".option-item").hover(function() {
          jc(".option-item").removeClass("option-hover");
          jc(this).addClass("newhover");
        });
        jc('.comboselect').change(function(event) {
            var selectid = jc(this).parent().parent().attr('id');
            if (event.target.value != "") {
              jc(".float-label #" + selectid + " label").addClass(
                "selected-label");
            } else {
              jc(".float-label #" + selectid + " label").removeClass(
                "selected-label");
            }
          })
          /**
           * Open select
           */
        jc('.js-select-open').click(function(e) {
            jc('.js-select').focus()
            e.preventDefault();
          })
          /**
           * Open select
           */
        jc('.js-select-close').click(function(e) {
            jc('.js-select').trigger('comboselect:close')
            e.preventDefault();
          })
          /**
           * Add new options
           */
        var $select = jc('.js-select-3');
        jc('.js-select-add').click(function() {
          $select.prepend(jc('<option>', {
            text: 'A new option: ' + Math.floor(Math.random() *
              10) + 1
          })).trigger('comboselect:update')
          return false;
        })
      })
      </script>

      <script>
      var $boxOne = $('.box:nth-child(1)'),
        $boxTwo = $('.box:nth-child(2)'),
        $boxThree = $('.box:nth-child(3)');

      var boxOne = new TimelineMax(),
        boxTwo = new TimelineMax(),
        boxThree = new TimelineMax();

      boxOne.to($boxOne, 0.6, {
        opacity: 1,
        scale: 1,
        ease: Back.easeOut
      }).to($boxOne, 0.6, {
        rotation: 0,
        ease: Back.easeOut
      }, 2);

      boxTwo.to($boxTwo, 0.6, {
        opacity: 0.5,
        scale: 1,
        ease: Back.easeOut
      }, 0.6).to($boxTwo, 0.6, {
        rotation: 0,
        ease: Back.easeOut
      }, 1.8);

      boxThree.to($boxThree, 0.6, {
        opacity: 1,
        scale: 1,
        rotation: 0,
        ease: Back.easeOut
      }, 1.2);

      /**
       * Point Animation
       */
      $('.point').on('click', function(e) {
        var getTotalPoints = $('.point').length,
          getIndex = $(this).index(),
          getCompleteIndex = $('.point--active').index();

        TweenMax.to($('.bar__fill'), 0.6, {
          width: (getIndex - 1) / (getTotalPoints - 1) * 100 + '%'
        });

        if (getIndex => getCompleteIndex) {
          $('.point--active').addClass('point--complete').removeClass(
            'point--active');

          $(this).addClass('point--active');
          $(this).prevAll().addClass('point--complete');
          $(this).nextAll().removeClass('point--complete');
        }
      });


      var animateProgress = setInterval(progressAnimation, 1200);

      $(document).hover(function() {
        clearInterval(animateProgress)
      });

      $('.radius-toggle').on('click', function() {
        $('body').toggleClass('show-radius')
      });
      </script>
      <script type="text/javascript">
      $(document).ready(function() {
        var getProductHeight = $('.product.active').height();

        $('.products').css({
          height: getProductHeight
        });



        function animateContentColor() {
          var getProductColor = $('.product.active').attr('product-color');

          $('body').css({
            background: getProductColor
          });

          $('.title').css({
            color: getProductColor
          });

          $('.btn').css({
            color: getProductColor
          });
        }

        var productItem = $('.product'),
          productCurrentItem = productItem.filter('.active');

        $('#next').on('click', function(e) {
          e.preventDefault();

          var nextItem = productCurrentItem.next();

          productCurrentItem.removeClass('active');

          if (nextItem.length) {

            productCurrentItem = nextItem.addClass('active');
          } else {
            productCurrentItem = productItem.first().addClass('active');
          }

          calcProductHeight();
          animateContentColor();
        });

        $('#prev').on('click', function(e) {
          e.preventDefault();

          var prevItem = productCurrentItem.prev();

          productCurrentItem.removeClass('active');

          if (prevItem.length) {
            productCurrentItem = prevItem.addClass('active');
          } else {
            productCurrentItem = productItem.last().addClass('active');
          }

          calcProductHeight();
          animateContentColor();
        });

        // Ripple
        $('[ripple]').on('click', function(e) {
          var rippleDiv = $('<div class="ripple" />'),
            rippleSize = 60,
            rippleOffset = $(this).offset(),
            rippleY = e.pageY - rippleOffset.top,
            rippleX = e.pageX - rippleOffset.left,
            ripple = $('.ripple');

          rippleDiv.css({
            top: rippleY - (rippleSize / 2),
            left: rippleX - (rippleSize / 2),
            background: $(this).attr("ripple-color")
          }).appendTo($(this));

          window.setTimeout(function() {
            rippleDiv.remove();
          }, 1900);
        });
      });
      </script>



  </body>

  </html>
