<?php
header('Access-Control-Allow-Origin: *');
//error_reporting(0);
session_start();
date_default_timezone_set("America/New_York");
include './lib/serverconnect.php';
//$our_ipaddress = array('104.168.149.82','75.145.198.74','75.145.198.73','61.12.78.82','115.249.1.65');
$our_ipaddress = array();

// Function to get the device type with OS and version 
function getdevice($user_agent) {
    $os_platform    =   "Unknown OS Platform";
    $os_array       =   array(
        '/windows nt 6.3/i'     =>  'Desktop - Windows 8.1',
        '/windows nt 6.2/i'     =>  'Desktop - Windows 8',
        '/windows nt 6.1/i'     =>  'Desktop - Windows 7',
        '/windows nt 6.0/i'     =>  'Desktop - Windows Vista',
        '/windows nt 5.2/i'     =>  'Desktop - Windows Server 2003/XP x64',
        '/windows nt 5.1/i'     =>  'Desktop - Windows XP',
        '/windows nt 10.0/i'    =>  'Desktop - Windows 10',
        '/windows xp/i'         =>  'Desktop - Windows XP',
        '/windows nt 5.0/i'     =>  'Desktop - Windows 2000',
        '/windows me/i'         =>  'Desktop - Windows ME',
        '/win98/i'              =>  'Desktop - Windows 98',
        '/win95/i'              =>  'Desktop - Windows 95',
        '/win16/i'              =>  'Desktop - Windows 3.11',
        '/macintosh|mac os x/i' =>  'Apple - Mac OS X',
        '/mac_powerpc/i'        =>  'Apple - Mac OS 9',
        '/linux/i'              =>  'Desktop - Linux',
        '/ubuntu/i'             =>  'Desktop - Ubuntu',
        '/iphone/i'             =>  'iPhone - ios',
        '/ipod/i'               =>  'iPod - ios',
        '/ipad/i'               =>  'iPad - ios',
        '/android/i'            =>  'Android',
        '/blackberry/i'         =>  'BlackBerry',
        '/webos/i'              =>  'Mobile'
    );
    foreach ($os_array as $regex => $value) {
        if (preg_match($regex, $user_agent)) {
            $os_platform    =   $value;
        }
    }
    return $os_platform;
}
$Referral_channel = array(
    'www.google' => 'Google Search Engine',
    'com.google.android.gm' => 'Gmail',
    'com.google' => 'Mobile Quick Search Box',
    'yahoo' => 'Yahoo Search Engine',
    'facebook' => 'Social Media',
    'livechatinc' => 'Live Chat',
    'bing' => 'bing Search Engine' ,
    'outlook' => 'Outlook',
    'atanet' => 'Directory',   
    'blogspot' => 'Blogspot - Referral',
    'dn2i' => 'Directory',
    'forum' => 'Forum'    
);

// Form saving visits into database
if ($_POST['visit_type'] == 'save_visit') {
    $Domain     = $_POST['Domain'];
    $siteURL    = $_POST['siteURL'];
    $Refferal   = ($_POST['Refferal'] == "")?"Others":$_POST['Refferal'];
    $sysip      = $_POST['sysip'];
    $ip         = $_POST['ip_data']['ip'];
    $city       = $_POST['ip_data']['city'];
    $region     = $_POST['ip_data']['region'];
    $country    = $_POST['ip_data']['country'];
    $postal     = $_POST['ip_data']['postal'];
    $loc        = $_POST['ip_data']['loc'];
    $org        = $_POST['ip_data']['org'];
    $hostname   = $_POST['ip_data']['hostname'];
    $browser    = $_POST['browser'];
    $device     = getdevice($_POST['browser']);
    $screen     = $_POST['screen'];
    $createdat  = date('Y-m-d H:i:s');   
    $s          = date('Y-m-d',strtotime($date2.'-30 days'));
    $e          = date('Y-m-d');
    $Refferal_channel = "Others";
    $client_ip  = $_SERVER['REMOTE_ADDR'];
    $third_visitor_count = 0;
    foreach ($Referral_channel as $key => $value) {
        if(stripos($Refferal, $key)){
            $Refferal_channel = $value;
            break;
        }
    }
    $service = (
                (stripos($siteURL,'transcr')) ? "Transcription" :
                    ((stripos($siteURL,'transla')) ? "Translation" :
                        ((stripos($siteURL,'typing')) ? "Typing" :
                            ((stripos($siteURL,'captiong')) ? "Captioning" :
                                ((stripos($siteURL,'subtit')) ? "Subtitling" :
                                    ((stripos($siteURL,'video')) ? "Video" :
                                        ((stripos($siteURL,'voice')) ? "Voice Over" : "General"))))))
                );     
    $visit_session = $_POST['visit_session'];
    $ret_s_d = date('Y-m-d H:i:s',  strtotime('-1 hours'));
    $ret_e_d = date('Y-m-d H:i:s');
    
    // For returing customer identification
    $query_customer_type = "SELECT ipaddress FROM visits WHERE (date(visit_date) between '$s' and '$e') AND ipaddress = '$ip' AND domain = '$Domain'";
    $exist_customer      = mysql_query($query_customer_type);
    $customers           = mysql_num_rows($exist_customer);    
    $customer_type = ($customers)?2:1;   
    
    // for two one cour customer continuty
    $query_return_visitor = "SELECT visitid FROM visits WHERE (visit_date between '$ret_s_d' and '$ret_e_d') AND ipaddress = '$ip' AND domain = '$Domain' order by visit_date desc LIMIT 1";
    $return_visitor = mysql_query($query_return_visitor);
    $return_data = mysql_fetch_assoc($return_visitor);
    $return_id = $return_data['visitid'];
    $return_user_count = mysql_num_rows($return_visitor);
    
    // No Session means have to check today returnning customer
    if(!$visit_session){
        if($return_user_count > 0){
            $visit_session = $return_id;
        }else{
            // Thirtime visitor identification
            $thirdvisitor_s_date = date('Y-m-d').' 00:00:00';           
            $thirdvisitor_qry = "SELECT visitid FROM visits WHERE (visit_date between '$thirdvisitor_s_date' and '$ret_e_d') AND ipaddress = '$ip' AND domain = '$Domain' order by visit_date desc";
            $return_thirdvisitor = mysql_query($thirdvisitor_qry);  
            $return_thirdvisitor_data = mysql_fetch_assoc($return_thirdvisitor);
            $third_visitor_count = mysql_num_rows($return_thirdvisitor);           
            if($third_visitor_count >= 2){
                $visit_session =  $return_thirdvisitor_data['visitid'];
            }
        }
    }
    if(!in_array($ip, $our_ipaddress)){
        echo $visit_session."||".$third_visitor_count;
        if(!$visit_session && $third_visitor_count < 2){
            $query       = "INSERT INTO `visits`(`customer_type`, `domain`, `service`, `url`, `refferal`, `refferal_channel`, `sysip`, `ipaddress`, `client_ip`, `country`, `region`, `city`, `postal`, `location`, `origin`, `hostname`, `browser`, `visit_date`, `device`, `screen`) VALUES ('$customer_type','$Domain','$service','$siteURL','$Refferal','$Refferal_channel','$sysip','$ip','$client_ip','$country','$region','$city','$postal','$loc','$org','$hostname','$browser','$createdat','$device','$screen')";
            mysql_query($query); 
            $customer_id =  mysql_insert_id(); 
            $visit_session = $customer_id; 
        }   
        $page_query  = "INSERT INTO `visits_page`(`visitid`, `domain`, `service`, `url`,`refferal`, `refferal_channel`, `ipaddress`, `client_ip`, `visit_date`) VALUES ('$visit_session','$Domain','$service','$siteURL','$Refferal','$Refferal_channel','$ip', '$client_ip', '$createdat')";
        mysql_query($page_query); 
        $page_id     =  mysql_insert_id();
        echo json_encode(array('visitor_id'=>$visit_session , 'page_id'=>$page_id));
        
    }
}

// For updating Page visit duration
if (isset($_REQUEST['timeSpent']) && $_REQUEST['visit_type'] == 'duration') {
    $seconds    = isset($_REQUEST['timeSpent']) ? strtolower($_REQUEST['timeSpent']) : '';
    $timespent  = gmdate("H:i:s", $seconds);
//    $visitorid  = isset($_REQUEST['visitorid']) ? strtolower($_REQUEST['visitorid']) : '';
    $pageid     = isset($_REQUEST['visit_pageid']) ? strtolower($_REQUEST['visit_pageid']) : '';
    $visit_session = $_POST['visit_session'];
    if(!in_array($ip, $our_ipaddress) && $pageid != ''){
//           mysql_query("UPDATE visits SET duration = '$timespent' WHERE visitid = '$visitorid'");
           mysql_query("UPDATE visits_page SET duration = '$timespent' WHERE pageid = '$pageid' and visitid = '$visit_session'");
    }    
}

// For updating bookmark customers
if ($_REQUEST['visit_type'] == 'bookmark') {    
//      $visitorid  = isset($_REQUEST['visitorid']) ? strtolower($_REQUEST['visitorid']) : '';
      $pageid     = isset($_REQUEST['visit_pageid']) ? strtolower($_REQUEST['visit_pageid']) : '';
      $visit_session = $_POST['visit_session'];
      if(!in_array($ip, $our_ipaddress) && $pageid != ''){            
//            mysql_query("UPDATE visits SET bookmark = '1' WHERE visitid = '$visitorid'"); 
            mysql_query("UPDATE visits_page SET bookmark = '1' WHERE pageid = '$pageid' and visitid = '$visit_session'");
      }
}
// For walkthrough Video played customers update
if ($_REQUEST['visit_type'] == 'walkthrough') {    
//      $visitorid  = isset($_REQUEST['visitorid']) ? strtolower($_REQUEST['visitorid']) : '';
      $pageid     = isset($_REQUEST['visit_pageid']) ? strtolower($_REQUEST['visit_pageid']) : '';
      $visit_session = $_POST['visit_session'];
      if(!in_array($ip, $our_ipaddress) && $pageid != ''){            
//            mysql_query("UPDATE visits SET bookmark = '1' WHERE visitid = '$visitorid'"); 
            mysql_query("UPDATE visits_page SET walkthrough = '1' WHERE pageid = '$pageid' and visitid = '$visit_session'");
      }
}
// For Fox Video click customers update
if ($_REQUEST['visit_type'] == 'foxvideo') {    
//      $visitorid  = isset($_REQUEST['visitorid']) ? strtolower($_REQUEST['visitorid']) : '';
      $pageid     = isset($_REQUEST['visit_pageid']) ? strtolower($_REQUEST['visit_pageid']) : '';
      $visit_session = $_POST['visit_session'];
      if(!in_array($ip, $our_ipaddress) && $pageid != ''){            
//            mysql_query("UPDATE visits SET bookmark = '1' WHERE visitid = '$visitorid'"); 
            mysql_query("UPDATE visits_page SET foxvideo = '1' WHERE pageid = '$pageid' and visitid = '$visit_session'");
      }
}
?>