<?php include'vip/doctype.php';?>
    <link rel="canonical" href="https://vananservices.com/Transcription-Rates.php" />
    <title>Transcription Samples</title>
    <!-- Seo-meta-section -->
    <!-- <meta name="keywords" content="transcription rate, transcription rate per word, transcription rate per minute, transcription rate per hour,transcription audio per minute"/>
    <meta name="description" content="Vanan Services offers the best and accurate transcription Starting at $0.69/min."/> -->
    <?php include'vip/site-verification.php';?>
    <?php include'vip/css-links.php';?>
    <style>
/* Style the tab */
div.tab {
    overflow: hidden;
    margin:30px 0;
    background-color: #f9f9f9;
}

/* Style the buttons inside the tab */
div.tab button {
    background-color: inherit;
    float: left;
    border: none;
    outline: none;
    cursor: pointer;
    padding: 14px 16px;
    transition: 0.3s;
    font-size: 17px;
    font-weight:500;
   
}

/* Change background color of buttons on hover */
div.tab button:hover {
    background-color: #ddd;
}

/* Create an active/current tablink class */
div.tab button.active {
    background-color: #2196f3;
    color: #fff;
}

/* Style the tab content */
.tabcontent {
    display: none;
    padding: 6px 12px;
    border: 1px solid #ccc;
    padding-top:12px;
    height: 450px;
    overflow: scroll;
}
.tabcontent img{
  width:100%;
}
.sample-wr {
    float: none;
    margin: 0 auto;
}
a.download_links {
    display: inline-block;
    background: #2196f3;
    color: #fff;
    padding: 10px 15px;
    font-weight: 500;
    font-size: 15px;
    display:none;
}
.original-source_wr h2, h2.covt_file {
    font-size: 24px;
    font-weight: 500;
}
@media only screen and (max-width: 767px) and (min-width: 320px){

.as-new-center {
    margin: 30px auto 35px!important;
}
}
</style>
    <body>
        <!--Right side nav-->
        <?php include'vip/side-nav-menu.php';?>
        <!--Right side nav end-->
        <!--Start-->
        <div class="as-wrapper">
        <!--Header-->
        <?php include'vip/header.php';?>
        <!--Header end-->
            <!--Pricing heading-->
            <div class="section as-contact-bg">
                <div class="container">
                    <div class="row">
                        <h1 class="home-heading text-center as-white as-all-head tex-col">Samples of our Transcription</h1>
                        <h2 class="as-home-tagtext text-center as-white">Custom transcription formats and editing styles for all your needs </h2>
                        <div class="as-head-split"></div>
                    </div>
                </div>
            </div>
            <!--Pricing heading end-->
            <div class="as-50"></div>
            <div class="section">
            <!-- Sample Content-->
                <div class="container">
                    <div class="col-md-10 col-lg-10 col-sm-12 col-xs-12 sample-wr">
                        <div class="original-source_wr">
                            <img src="img/video-play-vanan2.png" title="vananservices" alt="vananservices" width="600" data-toggle="modal" onclick="return loadAddUrl('transcription/video');" aria-hidden="true" class="video-play-vanan img-responsive" style="margin:15px auto !important;">
                        </div>
                        <h2 class="covt_file">Transcription Formats :</h2>
                        <div class="tab">
                            <button class="tablinks col-xs-12 col-sm-4 col-md-4 active" onclick="openEvent(event, 'Clean')">Clean Transcription</button>
                            <button class="tablinks col-xs-12 col-sm-4 col-md-4" onclick="openEvent(event, 'Time')">Time Stamped</button>
                            <button class="tablinks col-xs-12 col-sm-4 col-md-4" onclick="openEvent(event, 'Verbatim')">Verbatim Transcription</button>
                        </div>
                        <div id="Clean" class="tabcontent col-xs-12" style="display:block;">
                            <img src="images/Vanan_Interview_Clean-1.jpg" width="" height="" alt=""/>
                            <img src="images/Vanan_Interview_Clean-2.jpg" width="" height="" alt=""/>
                            <a download class="download_links" target="_blank" href="images/Vanan_Interview_Clean.pdf">Download PDF</a>
                        </div>
                        <div id="Time" class="tabcontent col-xs-12">
                            <img src="images/Vanan_Interview_Time stamped-1.jpg" width="" height="" alt=""/>
                            <img src="images/Vanan_Interview_Time_stamped-2.jpg" width="" height="" alt=""/>
                            <a download class="download_links" target="_blank" href="images/Vanan_Interview_Time_stamped.pdf">Download PDF</a>
                        </div>
                        <div id="Verbatim" class="tabcontent col-xs-12">
                            <img src="images/Vanan_Interview_verbatim-1.jpg" width="" height="" alt=""/>
                            <img src="images/Vanan_Interview_verbatim-2.jpg" width="" height="" alt=""/>
                            <a download class="download_links" target="_blank" href="images/Vanan_Interview_verbatim.pdf">Download PDF</a>
                        </div>
                    </div>
                </div>
                <div class="row as-new-center text-center" style="margin-top:60px;">
                    <a href="https://vananservices.com/Transcription-Quote.php" class="as-new-btn">Free Quote</a>
                    <a href="https://vananservices.com/Transcription-Upload-Files.php" class="as-new-btn1">Place Order</a>
                    <div class="clearfix"></div>
                    <p class="as-nosign"><i class="fa fa-lock" aria-hidden="true"></i> Safe &amp; Secure Payment  </p>
                </div>
                <!--End Of smaple COntent-->
                <!--Subscribe now-->
                <?php include'vip/subscribe.php';?>
                <!--Subscribe now end-->
                <!--Footer-->
                <?php include'vip/footer-transcription.php';?>
                <!--Footer end-->
                </div></div>
                <!--End-->
                <!-- php (back-to-top) -->
                <?php include'vip/back-to-top.php';?>
                <?php include'vip/chat-option.php';?>
                <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
                <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script> -->
                <script src="js/jquery.min.js"></script>
                <!-- Include all compiled plugins (below), or include individual files as needed -->
                <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
                <!-- Common javascript plugins -->
                <script src="js/common-javascript.js"></script><?php include'vip/country-footer-script.php'; ?>
                <!-- Modal -->
                <div class="modal fade" id="myModalR" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                    <div class="modal-dialog rate-popup-box ezCustTrans" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                <h4 class="modal-title text-center" id="myModalLabel">What we deliver</h4>
                            </div>
                            <div class="modal-body" style="height: auto;background-color:#fff;">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <img class="image-alignn" src="img/modal1.png" title="vananservices" alt="Modal Sample">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Modal -->
                <div class="modal fade" id="myModalC" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                    <div class="modal-dialog rate-popup-box ezCustTrans" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                <h4 class="modal-title text-center" id="myModalLabel">What we deliver</h4>
                            </div>
                            <div class="modal-body" style="height: auto;background-color:#fff;">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <img class="image-alignn1" src="img/Without-CaseSummary.png" title="vananservices" alt="Modal Sample" >
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Modal -->
                <div class="modal fade" id="myModalJ" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                    <div class="modal-dialog rate-popup-box ezCustTrans" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                <h4 class="modal-title text-center" id="myModalLabel">What we deliver</h4>
                            </div>
                            <div class="modal-body as-popup-h" style="background-color:#fff;">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <img class="image-alignn1" src="img/With%20Case%20Summary-1.png" title="vananservices" alt="Modal Sample" >
                                        <img class="image-alignn1" src="img/With%20Case%20Summary-2.png" title="vananservices" alt="Modal Sample" >
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </body>
        </html>
<script>
function openEvent(evt, eventName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(eventName).style.display = "block";
    evt.currentTarget.className += " active";
}
</script>
     
