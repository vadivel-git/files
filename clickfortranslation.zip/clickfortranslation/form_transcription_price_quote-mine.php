<?php
include_once "common_setting.php";
include_once "lib/common_array_price_quote.php";
include_once "lib/functions.php";

if (substr($_SERVER['REMOTE_ADDR'], 0, 4) == '127.'
    || $_SERVER['REMOTE_ADDR'] == '::1') {
    $RANDOMNO       = rand();
    $channel_click  = "payment";
    $sitename       = 'localhost/projects/clickfortranslation/';
    $freequote      = 'show';
    echo "<script>var successpath = 'localhost/projects/clickfortranslation';</script>";
}else {
    $RANDOMNO       = $COMMONSETTING['RANDOMNO'];
    $channel_click  = ($_POST['freequote'] == 'show') ? "free quote" : "payment";
    $sitename       = $serverdetail['HTTP_HOST'];
    echo "<script>var successpath = '".$QUOTEMAILERINFO[$sitename]['successpage']."';</script>";
}

$page               = (isset($page)) ? $page : "quote";
$protocol           = (isset($serverdetail['HTTPS']) && $serverdetail['HTTPS'] != 'off') ? "https://" : "http://";
$pay_email          = isset($_POST['requestvariable']['customer_email']) ? $_POST['requestvariable']['customer_email'] : "";
$customer_dashboard = isset($_POST['requestvariable']['customer_dashboard']) ? $_POST['requestvariable']['customer_dashboard'] : "";
$pay_category       = isset($_POST['requestvariable']['catetype'])? $_POST['requestvariable']['catetype'] : "";
$pay_sourcelan      = isset($_POST['requestvariable']['srclang'])?$_POST['requestvariable']['srclang']:"";
$pay_minutes        = isset($_POST['requestvariable']['audio_minutes'])?$_POST['requestvariable']['audio_minutes']:"";
$pay_targetlan      = '';

$trclang            = array('90');
$site_name          = preg_replace('/^www\./', '', $sitename);$sitename=trim($site_name);
$rush_scenario = array(
    "engnonnative" => array_merge(
        array(0 => array('6 to 8 hours','10 to 12 hours','16 to 20 hours','1 business day')),
        array(1 => array('1 business day','1 to 2 business days','2 to 3 business days','3 to 4 business days')),
        array(2 => array('1 to 2 business days','2 to 3 business days','3 to 4 business days','5 to 6 business days')),
        array(3 => array('2 to 3 business days','3 to 4 business days','4 to 5 business days','6 to 7 business days')),
        array(4 => array('2 to 3 business days','4 to 5 business days','5 to 6 business days','7 to 8 business days'))
    ),
    "engnative" => array_merge(
        array(0 => array('10 to 12 hours','16 to 20 hours','1 business day','1 to 2 business days')),
        array(1 => array('1 business day','1 to 2 business days','2 to 3 business days','3 to 4 business days')),
        array(2 => array('1 to 2 business days','2 to 3 business days','3 to 4 business days','5 to 6 business days')),
        array(3 => array('2 to 3 business days','3 to 4 business days','4 to 5 business days','6 to 7 business days')),
        array(4 => array('2 to 3 business days','4 to 5 business days','5 to 6 business days','7 to 8 business days'))
    ),
    "otr" => array_merge(
        array(0 => array('6 to 12 hours','12 to 18 hours','18 to 22 hours','1 business day')),
        array(1 => array('12 to 18 hours','18 to 22 hours','1 business day','1 to 2 business days')),
        array(2 => array('1 to 2 business days','2 to 3 business days','3 to 4 business days','4 to 5 business days')),
        array(3 => array('2 to 3 business days','3 to 4 business days','5 to 6 business days','7 to 8 business days')),
        array(4 => array('3 to 4 business days','5 to 6 business days','7 to 8 business days','9 to 10 business days')),
        array(5 => array('4 to 5 business days','6 to 7 business days','8 to 9 business days','10 to 12 business days'))
    )

);
$trcrushlanguage =array('90');
echo "<script>var folderPath='".date("dmY")."/"."';var datetime='".date("D M d Y h:i:s")."'; </script>";
?>
<link rel="stylesheet" type="text/css" href="<?php echo $CRMSERVERPATH; ?>css/transcription_price_quote.css">
<link rel="stylesheet" type="text/css" href="<?php echo $CRMSERVERPATH; ?>css/transcription_price_quote_responsive.css">
<script type="text/javascript" src="<?php echo $CRMSERVERPATH; ?>js/sweetalert.min.js?<?php echo $COMMONSETTING['RANDOMNO'];?>"></script>
<link rel="stylesheet" type="text/css" href="<?php echo $CRMSERVERPATH; ?>css/sweetalert.css">
<link type="text/css" href="<?php echo $CRMSERVERPATH; ?>css/checkout.css?<?php echo $RANDOMNO;?>" rel="stylesheet">
<link type="text/css" href="<?php echo $CRMSERVERPATH; ?>css/my-styleNew.css?<?php echo $RANDOMNO;?>" rel="stylesheet">
<script type="text/javascript">
    var jc              = jQuery.noConflict();
    var mindt           = '<?php echo date("Y", strtotime("+5 hours")) . "-" . date("m", strtotime("+5 hours")) . "-" . date("d", strtotime("+5 hours")) . " " . date("H", strtotime("+5 hours")) . ":" . date("i", strtotime("+5 hours")) . ":00"?>';
    var maxdt           = '<?php echo date("Y", strtotime("+24 hours")) . "-" . date("m", strtotime("+24 hours")) . "-" . date("d", strtotime("+24 hours")) . " " . date("H", strtotime("+24 hours")) . ":" . date("i", strtotime("+24 hours")) . ":00"?>';
    var curdt           = '<?php echo date("Y-m-d H:i:s"); ?>';
    var todaydate       = '<?php echo date("m") . '/' . date("d") . '/' . date("Y"); ?>';
    var cur_timee       = '<?php echo date("H") . ":" . date("i") . ":" . date('s');?>';
    var expeditedarr    = <?php echo json_encode($rush_scenario); ?>;
    var trcrushlanguage = <?php echo json_encode($trcrushlanguage); ?>;
    var language_list   = <?php echo json_encode($language); ?>;
    var country_list    = <?php echo json_encode($country); ?>;
    var serverPath      = <?php echo json_encode($CRMSERVERPATH); ?>;
    var originPath      = <?php echo json_encode($sitename); ?>;
    var channel_click   = <?php echo json_encode($channel_click); ?>;
    var trclang         = <?php echo json_encode($trclang); ?>;
    var crmRootpath     = '<?php echo $CRMSERVERPATH; ?>';
    var timcodeoptions  = <?php echo json_encode($timcodeoptions); ?>;
//    var successpath     = '<?php //echo $QUOTEMAILERINFO[$sitename]['successpage']; ?>//';
    var sitename        = '<?php echo $sitename; ?>';
    var update_url      = '<?php echo $CRMSERVERPATH; ?>crmquote_pay_update_trl.php';
    var update_quote    = '<?php echo $CRMSERVERPATH;?>update_transcription_price_quote.php';
</script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<body>
    <section class="ui-v-font">
        <div class="ui-container container">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 mas_design_bg ui_padding_00 row-eq-height">
                    <div class="col-xs-12 col-sm-7 col-md-8 col-lg-8 ui-pb">
                        <?php $action = $CRMSERVERPATH."paypal/payment_v2.0.php"; ?>
                        <form class="float-label" spellcheck="false" id="transcriptionForm" action="<?php echo $action; ?>" method="post" role="form">
                            <h2 class="legend ui_hw">Project Details</h2>
                            <input type="hidden" id="site_namee" name="site_namee" value="<?php echo $sitename; ?>">
                            <input type="hidden" id="quoteflag" name="quoteflag" value="0">
                            <input type="hidden" id="quoteflagnew" name="quoteflagnew" value="0">
                            <input type="hidden" id="recordkey" name="recordkey" value="">
                            <input type="hidden" id="networkerrflag" name="networkerrflag" value="0">
                            <input type="hidden" id="item_name_1" name="item_name_1" value="transcription">
                            <input type="hidden" id="item_number_1" name="item_number_1" value="">
                            <input type="hidden" id="formtype" name="formtype" value="payment">
                            <input type="hidden" id="mode" name="mode" value="payment">
                            <input type="hidden" id="service" name="service" value="transcription">
                            <input type="hidden" id="uploadat" name="uploadat" value="fileupload">
                            <input type="hidden" id="version_payment" name="uploaddat" value="<?php echo $_POST['version_payment']; ?>">
                            <input type="hidden" id="freequote" name="freequote" value="">
                            <input type="hidden" id="camethrough" name="camethrough" value="<?php echo $channel_click; ?>">
                            <?php date_default_timezone_set('America/New_York'); ?>
                            <input type="hidden" name="referalsite" value="<?php echo $_SERVER['SERVER_NAME'];?>">
                            <input type="hidden" id="cst_db" name="cst_db" value="<?php echo $customer_dashboard; ?>">
                            <input type="hidden" id="paymentamt" name="paymentamt"  value="">
                            <input type="hidden" id="timecode_subamt" value="0.00">
                            <input type="hidden" id="subamttot" value="0.00">
                            <input type="hidden" id="trans_price" name="trans_price" value="">
                            <input type="hidden" id="agent_ref" name="agent_ref" >

                            <input type="hidden" id="trcpriceb" value="0.00" >
                            <input type="hidden" id="trccostb" value="0.00" >
                            <input type="hidden" id="trcprice" value="0.00" >
                            <input type="hidden" id="trccost" value="0.00" >
                            <input type="hidden" id="trctcodecost" value="0.00" >
                            <input type="hidden" id="qcheckcost" value="0.00" >
                            <input type="hidden" id="trcverbacost" value="0.00" >
                            <input type="hidden" id="trctotcost" value="0.00" >

                            <input type="hidden" id="mfileprice" value="0.00" >
                            <input type="hidden" id="expprice" value="0.00" >

                            <input type="hidden" id="subamt" value="0.00" >
                            <input type="hidden" id="transrate" value="0.00" >
                            <input type="hidden" id="pricedisplay" value="0.00" >
                            <input type="hidden" name="amount" id="amount" value="0.00" >
                            <input type="hidden" id="siteprtcl" value="<?php echo $protocol; ?>" >
                            <div class="clearfix"></div>
                            <div class="row tr-ui-float-label">
                                <div class="clo-xs-3 col-sm-4 col-md-3 col-lg-3 tr-ui-padding-left">
                                    <span class="ui-tr-icons"><i class="fa fa-file" aria-hidden="true"></i></span>
                                    <span class="tr-ui-lable tr-ui-title">File length</span>
                                </div>
                                <div class="col-xs-6 col-sm-4 col-md-4 col-lg-4 docfile">
                                    <div class="displaynone offer-blk fr_manual_tooltip">Transcribe <span id="needmin"></span> minutes more and receive <span id="availoff"></span> discount.</div>
                                    <div id="first2" class="ui-re-row-sapce col-xs-3 col-sm-5 col-md-5 col-lg-5 tr-ui-padding-0">
                                        <input id="hours" name="hours" class="form-control ui-control del-time capturedata tr-ui-witdh text-center" placeholder="00" type="text" style="padding: 0 6px !important;">
                                    </div>
                                    <span class="tr-ui-lable">Hours</span>
                                </div>
                                <div class="col-xs-6 col-sm-4 col-md-4 col-lg-4 docfile">
                                    <div id="first2" class="ui-re-row-sapce col-xs-3 col-sm-5 col-md-5 col-lg-5 tr-ui-padding-0">
                                        <input id="minutes" name="minutes" class="form-control ui-control del-time capturedata tr-ui-witdh text-center" placeholder="00" type="text" value="<?php echo $pay_minutes; ?>" style="padding: 0 6px !important;">
                                    </div>
                                    <span class="tr-ui-lable">Minutes</span>
                                </div>
                            </div>
                            <div class="row tr-ui-float-label">
                                <div class="clo-xs-3 col-sm-4 col-md-3 col-lg-3 tr-ui-padding-left">
                                    <span class="ui-tr-icons"><i class="fa fa-list-alt" aria-hidden="true"></i></span>
                                    <span class="tr-ui-lable tr-ui-title">Category
                                        <div class="wrappervd">
                                        <a title="<b>General Transcription:</b> Select general transcription if your project deals with academics, business, media, finance, focus groups or telephonic conversations. <br>
                                            <b>Legal Transcription:</b> Select legal transcription if your project involves legal/court proceedings, like interrogation sessions of the police department." rel="tooltip">
                                            <span class="control-label"><div class="tooltip--questionmark"><span class="tooltip__question">?</span></div></span>
                                        </a>
                                    </div>
                                    </span>
                                </div>
                                <?php $legalselected='';$genselected=''; ($pay_category == 'Legal')?$legalselected = 'checked':$genselected = 'checked'; ?>
                                <div class="col-xs-6 col-sm-3 col-md-4 col-lg-3 docfile tr-ui-ma">
                                    <label class="custom-control custom-radio">
                                        <input id="general" type="radio" class="del-time capturedata form-check-input custom-control-input" onclick="paytc_pricequoteclac();" name="catetype" value="General" <?php echo $genselected; ?> >
                                        <span class="custom-control-indicator"></span>
                                        <span class="lbl ui_lbl_radio custom-control-description">General</span>
                                    </label>
                                </div>
                                <div class="col-xs-6 col-sm-5 col-md-4 col-lg-3 docfile tr-ui-ma">
                                    <label class="custom-control custom-radio">
                                        <input id="legal" type="radio" class="del-time capturedata form-check-input custom-control-input" onclick="paytc_pricequoteclac();" name="catetype" value="Legal" <?php echo $legalselected; ?> >
                                        <span class="custom-control-indicator"></span>
                                        <span class="lbl ui_lbl_radio custom-control-description">Legal</span>
                                    </label>
                                </div>
                            </div>
                            <div class="row tr-ui-float-label">
                                <div class="clo-xs-3 col-sm-4 col-md-3 col-lg-3 tr-ui-padding-left">
                                    <span class="ui-tr-icons"><i class="fa fa-language" aria-hidden="true"></i></span>
                                    <span class="tr-ui-lable tr-ui-title">Language</span>
                                </div>
                                <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4 docfile tr-ui-clear">
                                    <div id="first5" class="ui-small ui-re-row-sapce">
                                        <select name="srclang" id="srclang" data-placeholder="Select source language *" class="form-control ui-control del-time capturedata comboselect">
                                            <option selected="" disabled="" value="">Select source language</option>
                                            <?php
                                            foreach ($language as $language_key => $language_val) {
                                                $lang_selected = '';
                                                if($pay_sourcelan == $language_val){$lang_selected ='selected="selected"';}
                                                echo '<option  value="' . $language_key . '"'.$lang_selected. '>' . $language_val . '</option>';
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-xs-12 col-sm-5 col-md-4 col-lg-4">
                                    <div class="tr-ui-cntr usnative-blk displaynone">
                                        <span>
                                            <input class="hidden-xs-up cbxid del-time capturedata" id="nativespkr" type="checkbox" onchange="paytc_pricequoteclac();">
                                            <label id="nativespkr-lbl" class="cbx" tabindex="0" for="nativespkr"></label>
                                            <label class="lbl" for="nativespkr">U.S. native speaker</label>
                                        </span>
                                    </div>
                                    <div class="tr-ui-cntr showtrl displaynone" >
                                        <span>
                                            <input class="hidden-xs-up cbxid del-time capturedata" id="needtranslation" type="checkbox" onchange="eligibility();paytc_pricequoteclac();">
                                            <label class="cbx" id="needtranslation-lbl" tabindex="0" for="needtranslation"></label>
                                            <label class="lbl" for="needtranslation">Need translation</label>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div class="row tr-ui-float-label displaynone needtrl">
                                <div class="clo-xs-3 col-sm-4 col-md-3 col-lg-3 tr-ui-padding-left">
                                    <span class="ui-tr-icons"><i class="fa fa-globe" aria-hidden="true"></i></span>
                                    <span class="tr-ui-lable tr-ui-title">Translate To</span>
                                </div>
                                <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4 docfile">
                                    <div id="first6" class="ui-small ui-re-row-sapce">
                                        <select name="trglang" id="trglang" class="form-control del-time capturedata comboselect">
                                            <option selected="" disabled="" value="">Select target language</option>
                                            <?php
                                            foreach ($language as $language_key => $language_val) {
                                                $lang_selected = '';
                                                if($language_val == $pay_targetlan){$lang_selected ='selected="selected"';}
                                                echo '<option value="' . $language_key . '"'.$lang_selected. '>' . $language_val . '</option>';
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row tr-ui-float-label verbaelm displaynone">
                                <div class="clo-xs-3 col-sm-4 col-md-3 col-lg-3 tr-ui-padding-left">
                                    <span class="ui-tr-icons"><i class="fa fa-font" aria-hidden="true"></i></span>
                                    <span class="tr-ui-lable tr-ui-title">Text format
                                        <div class="wrappervd"><a title="Verbatim Transcription means word by word transcription including the fillers uhh, umm, ah, laughing sounds etc.<br>( + $0.25/min)" rel="tooltip"><span class="control-label"><div class="tooltip--questionmark"><span class="tooltip__question">?</span></div></span></a></div>
                                    </span>
                                </div>
                                <div class="col-xs-6 col-sm-3 col-md-4 col-lg-3 tr-ui-ma">
                                    <label class="custom-control custom-radio">
                                        <input id="cleanverba" type="radio" class="del-time capturedata form-check-input custom-control-input" onclick="paytc_pricequoteclac();" name="qtvercrmpay" value="0">
                                        <span class="custom-control-indicator"></span>
                                        <span class="lbl ui_lbl_radio custom-control-description">Clean</span>
                                    </label>
                                </div>
                                <div class="col-xs-6 col-sm-5 col-md-4 col-lg-3 docfile tr-ui-ma">
                                    <label class="custom-control custom-radio">
                                        <input id="fullverba" type="radio" class="del-time capturedata form-check-input custom-control-input" onclick="paytc_pricequoteclac();" name="qtvercrmpay" value="1">
                                        <span class="custom-control-indicator"></span>
                                        <span class="lbl ui_lbl_radio custom-control-description">Full verbatim</span>
                                    </label>
                                </div>
                            </div>
                            <div class="row tr-ui-float-label">
                                <div class="clo-xs-3 col-sm-4 col-md-3 col-lg-3 tr-ui-padding-left">
                                    <span class="ui-tr-icons"><i class="fa fa-clock-o" aria-hidden="true"></i></span>
                                    <span class="tr-ui-lable tr-ui-title">Timecode</span>
                                </div>
                                <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4 docfile">
                                    <div id="first5" class="ui-small ui-re-row-sapce  plain-select">
                                        <select name="qttcodecrm" id="qttcodecrm" class="form-control ui-control del-time capturedata">
                                            <option value="" selected disabled >Select time code</option>
                                            <?php
                                            foreach ($timcodeoptions as $timcode=>$tcodeval){
                                                echo '<option value="'.$timcode.'" >'.$tcodeval["label"].'</option>';
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row tr-ui-float-label">
                                <div class="clo-xs-3 col-sm-4 col-md-3 col-lg-3 tr-ui-padding-left">
                                    <span class="ui-tr-icons"><i class="fa fa-plus-circle" aria-hidden="true"></i></span>
                                    <span class="tr-ui-lable tr-ui-title">Additional quality <span class="tr-ui-clear-both">check</span></span>
                                </div>
                                <div class="col-xs-6 col-sm-3 col-md-4 col-lg-3 docfile tr-ui-ma">
                                    <label class="custom-control custom-radio">
                                        <input id="qc1" type="radio" class="del-time capturedata form-check-input custom-control-input" onclick="paytc_pricequoteclac();" name="qcheck" value="1" >
                                        <span class="custom-control-indicator"></span>
                                        <span class="lbl ui_lbl_radio custom-control-description">Yes</span>
                                    </label>
                                </div>
                                <div class="col-xs-6 col-sm-5 col-md-4 col-lg-3 docfile tr-ui-ma">
                                    <label class="custom-control custom-radio">
                                        <input id="qc0" type="radio" class="del-time capturedata form-check-input custom-control-input" onclick="paytc_pricequoteclac();" name="qcheck" value="0" checked >
                                        <span class="custom-control-indicator"></span>
                                        <span class="lbl ui_lbl_radio custom-control-description">No</span>
                                    </label>
                                </div>
                            </div>
                            <div class="uploadhere displaynone" style="display: block;">
                                <div class="row">
                                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                        <div class="ui-upolad" onclick="addFiles();">
                                            <img src="https://secure-dt.com/dtforms/img/addfiles.png" alt="addfiles" class="img-responsive center-block" width="40" style="margin: 0 auto 14px auto;">
                                            <input type="file" id="file" style="display:none;" multiple="" onchange="upload()">
                                            Add files
                                            <p style="padding-top: 12px;" class="text-center ui-p"><strong>Note : </strong>You may upload multiple files at the same time.</p>
                                            <p class="text-center ui-p">You may also upload your files later.</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="upload_error" style="color:#e0271d; font-weight:bold; padding:5px 0px; display: none;">Network connection Error .. Please check your internet connection ...</div>
                                <div class="col-lg-12 dv_nopad" id="fileuploadfield">
                                    <div class="panel panel-default" style="display:none;" id="info">
                                        <div class="row ui-up-head">
                                            <div class="col-xs-4 col-sm-4 col-lg-4 fname">File name</div>
                                            <div class="col-xs-4 col-sm-4 col-lg-4 text-center" >File length</div>
                                            <div class="col-xs-4 col-sm-4 col-lg-4 text-center pull-right">Status</div>
                                        </div>
                                    </div>
                                </div>
                                <div id="my-welcome-message2" class="displaynone vd-welcome">
                                    <div class="modal-body no-padding vd-pad">
                                        <div class="pop">
                                            <img src="https://secure-dt.com/dtforms/img/vd-upload-pop.png" alt="upload" title="upload" class="vd-upload-pop">
                                            <div class="vd-hilights-pop">
                                                <div id="uploading_msg">Kindly don't close this window.<br><b>Uploading in Progress...</b>
                                                    <div id="completedfiletext"></div>
                                                </div>
                                                <div class="upload_errmsg" style="display: none;">
                                                    There seems to be a problem with your request.
                                                    <br> Here are a few other options for you.<br><br>
                                                    <div style="text-align:left">1. Upload your files
                                                        <a href="AlternateUpload.php" target="_blank" style="color:blue"><u> here</u> </a>
                                                        <br> 2. OR Share your dropbox link to support@vananservices.com
                                                        <br> 3. OR Simply
                                                        <span onclick="$('#open-icon').trigger('click')" style="color:blue;cursor: pointer"><u> Chat with us </u> </span> anytime.
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- Kindly don't close this page as your file(s) are being uploaded. -->
                                            <img src="https://secure-dt.com/dtforms/img/loading.gif" alt="upload gif" title="loading" class="vd-up-gif">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="filecomment displaynone tr-ui-ma" >
                                <div class="form-group form-modifier col-lg-12 dv_nopad">
                                    <textarea style="font-weight: 300 !important; font-size: 12px !important; line-height: 24px;" name="filecomments" id="filecomments" class="form-control ui-control textarea-modifier" rows="4" placeholder="Please enter spelling of names, locations, addresses and any additional information / notes (including handwritten or illegible text) that can help us accurately translate your specific requests."></textarea>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                            <div id="delivery-timeline" class="row displaynone ui-radiobox ui-last-radio">
                                <b class="ui-turn">Turnaround time</b>
                                <div class="clearfix"></div>
                                <div class="col-xs-12 col-sm-10 col-md-8 col-lg-6 rush-padding">
                                    <label class="custom-control custom-radio">
                                        <input type="radio" class="capturedata form-check-input del-time custom-control-input" onclick="paytc_pricequoteclac();" name="deliveryReq" value="option1" checked>
                                        <span class="custom-control-indicator"></span>
                                        <span class="tatlbl ui_lbl_radio custom-control-description" >Standard delivery of <span id="tat-val"></span></span>
                                    </label>
                                </div>
                                <div class="col-xs-12 col-sm-10 col-md-8 col-lg-6 rush-padding">
                                    <label class="custom-control custom-radio">
                                        <input id="expedited" type="radio" class="capturedata form-check-input del-time custom-control-input" onclick="paytc_pricequoteclac();" name="deliveryReq" value="option2">
                                        <span class="custom-control-indicator"></span>
                                        <span class="tatlbl ui_lbl_radio custom-control-description">Expedited Service</span>
                                    </label>
                                </div>
                                <div class="col-xs-12 col-sm-10 col-md-8 col-lg-8 fr_form-group fr_centerpage">
                                    <div class="col-xs-12 col-sm-7 col-md-7 col-lg-7 fr_form-group expeditedblk displaynone">
                                        <input id="fileupload_tat" class="del-time capturedata form-control " type="text" placeholder="Select the Date *">
                                    </div>
                                </div>
                            </div>
                            <div id="expedited-timeline" class="row ui-radiobox ui-last-radio displaynone"></div>
                        </form>
                    </div>
                    <div class="ui_summary col-xs-12 col-sm-5 col-md-4 col-lg-4 ui_padding_0">
                        <div class="">
                            <h2 class="legend text-center">Quote Summary</h2>
                            <div class="fr_sumarry no-summary ">
                                <div class="qt_msg ui-msg">Enter <span id="mandat" class="text-highlight">project details</span> to get the price quote for your project.</div>
                                <div class="clearfix"></div>
                                <div class="row text-center ui-email">
                                    <div class="fr_CV_msg qt_mailinfo displaynone ui-chat" onclick="parent.LC_API.open_chat_window()"><i class="fa fa-comments cv-icon-blink" aria-hidden="true"></i> <b>Chat with us</b></div>
                                    <div class="qt_mailinfo displaynone">Or</div>
                                    <div class="qt_mailinfo displaynone fr_fo_si">Enter your email ID to receive a quote from us.</div>
                                </div>
                            </div>
                            <div class="ui-summarry">
                                <div class="order-summary displaynone">
                                    <div class="ui_fr_sumarry">
                                        <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 ui-pad-r0">Base price ($<span id="trcpriceb_disp">5.00</span>/min)</div>
                                        <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right">$<span id="trccostb_disp"></span></div>
                                    </div>
                                    <div class="ui_fr_sumarry displaynone availedoff">
                                        <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 ui-pad-r0">Discounted price ($<span id="trcprice_disp">5.00</span>/min)</div>
                                        <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right">$<span id="trccost_disp"></span></div>
                                    </div>
                                    <!--<div class="availedoff fr_txt_word_CV"></div>-->
                                    <div class="ui_fr_sumarry displaynone availedoff">
                                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 fr_txt_word_CV">
                                            <span class="offval">You save $<span id="offprice"></span></span>
                                        </div>
                                    </div>
                                    <div class="ui_fr_sumarry verbatime-pr">
                                        <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 ui-pad-r0">Verbatim</div>
                                        <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right">$<span id="trcverbacost_disp"></span></div>
                                    </div>
                                    <div class="ui_fr_sumarry timecode-pr">
                                        <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 ui-pad-r0">Time code</div>
                                        <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right">$<span id="trctcodecost_disp"></span></div>
                                    </div>
                                    <div class="ui_fr_sumarry rush-view">
                                        <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 ui-pad-r0">Total cost</div>
                                        <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right">$<span id="trctotcost_disp"></span></div>
                                    </div>
                                    <div class="ui_fr_sumarry displaynone minimum-trcpr">
                                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 minimumcost ui-col-r">
                                            Minimum order cost applies to orders less than $<span id="trcmin_disp"></span>.
                                        </div>
                                    </div>
                                    <div class="ui_fr_sumarry  rush-view trlsum">
                                        <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 ui-pad-r0">Expedited service fee
                                            <div class="wrappervd"><a rel="tooltip" id="exptooltip" title=""> <span class="control-label"><div class="tooltip--questionmark"><span class="tooltip__question">?</span></div></span></a></div>
                                        </div>
                                        <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right">$<span id="expprice_disp"></span></div>
                                    </div>
                                    <div class="ui_fr_sumarry qcheck-pr">
                                        <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 ui-pad-r0">Additional quality check</div>
                                        <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right">$<span id="qcheckcost_disp"></span></div>
                                    </div>
                                    <div class="ui_fr_sumarry">
                                        <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 ui-pad-r0">Subtotal</div>
                                        <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right">$<span id="sub_amt"></span></div>
                                    </div>
                                    <div class="ui_fr_sumarry">
                                        <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 ui-pad-r0">Transaction fee
                                            <div class="wrappervd">
                                                <a rel="tooltip" title="Transaction fee is 5% of total order cost. This fee covers credit card, banking partners, and PayPal processing fees"><span class="control-label"><div class="tooltip--questionmark"><span class="tooltip__question">?</span></div></span></a>
                                            </div>
                                        </div>
                                        <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right">$<span id="trans_rate"></span></div>
                                    </div>
                                    <div class="ui_fr_sumarry fr_sumarry_bg">
                                        <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8 ui-pad-r0"><b>Grand total</b></div>
                                        <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 text-right"><b>$<span id="price_display"></span></b></div>
                                    </div>
                                </div>
                                <div class="col-lg-12 float-label">
                                    <div>
                                        <div id="first2" class="control">
                                            <input id="paytc_qemailcrm" name="paytc_qemailcrm" class="form-control ui-control form-control-success del-time capturedata" placeholder="Your Email ID *" value="<?php echo $pay_email; ?>" >
                                        </div>
                                    </div>
                                </div>
                                <p class="fr_sample">
                                    <a href="javascript:void(0)" id='view_sample'><u>Click to view our samples</u></a>
                                </p>
                            </div>
                            <div class="col-lg-12">
                                <div class="ui_fr_sumarry pt displaynone">
                                    <?php
                                    //                                    ui-quote-btn-joint, ui-pay-btn-joint
                                    $qtbutton ='ui-quote-btn';
                                    $ptbutton = 'ui-pay-btn';
                                    $twobutton = '';
                                    $btnclass = 'col-xs-12 col-sm-12 col-md-12 col-lg-12';
                                    if($freequote == "show"){
                                        $btnclass = 'col-xs-6 col-sm-12 col-md-12 col-lg-6';
                                        $qtbutton ='ui-quote-btn-joint';
                                        $ptbutton = 'ui-pay-btn-joint';
                                        $twobutton = 'ui-joint-btn';
                                        ?>
                                        <div id="emailquote-btn" class="col-xs-6 col-sm-12 col-md-12 col-lg-6 fr_nopadding btnhand ui-btn-quote <?php echo $twobutton; ?>">
                                            <div class="qsubmitcrm fr_email_btn <?php echo $qtbutton; ?>" tabindex="0" id="emailquote" value="Email Quote">Email the Quote</div>
                                        </div>
                                    <?php } ?>
                                    <div id="proceedpayment-btn" class="<?php echo $btnclass; ?> text-right fr_nopadding btnhand ui-btn-quote <?php echo $twobutton; ?>">
                                        <div class="qsubmitcrm fr_email_btn fr_color <?php echo $ptbutton; ?>" tabindex="0" id="proceedpayment" value="Proceed to Payment">Proceed to Payment</div>
                                    </div>
                                    <p class="fr_vvv"> <i class="fa fa-lock" aria-hidden="true"></i> Safe &amp; Secure Payment </p>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="fr_sumarry qt displaynone">
                                    <div class="fr_nopadding btnhand">
                                        <div class="qsubmitcrm fr_email_btn ui-quote-btn" style="float: left;width: 100%;" tabindex="0" id="getquote" value="Get Quote">Get Quote</div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="fr_sumarry up displaynone">
                                    <div class="fr_nopadding btnhand">
                                        <div class="qsubmitcrm fr_email_btn ui-quote-btn">Uploading...</div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="fr_sumarry pr displaynone">
                                    <div class="fr_nopadding btnhand">
                                        <div class="qsubmitcrm fr_email_btn ui-col-green">Processing...</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <div class="fr-container">
        <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8 fr_no_padd">
            <span id="timespendingid" class="displaynone"></span>
            <?php if($customer_dashboard == ''){ ?>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 text-center pad-top15 ui-underl ">
                <a href="<?php echo $protocol.$site_name; ?>/Transcription-Send-Files.php">If you're an existing customer, upload files right away by
                    <span class="text-primary ui-primary">clicking here</span>
                </a>
            </div>
            <?php } ?>
        </div>
        <link rel="stylesheet" href="<?php echo $CRMSERVERPATH; ?>css/jquery.datetimepicker.css?<?php echo $COMMONSETTING['RANDOMNO'];?>">
        <script type="text/javascript" src="<?php echo $CRMSERVERPATH; ?>js/transcription_price_quote.js?<?php echo $RANDOMNO;?>"></script>
        <script type="text/javascript" src="<?php echo $CRMSERVERPATH; ?>js/jquery.datetimepicker.full.js?<?php echo $COMMONSETTING['RANDOMNO'];?>"></script>
        <script>
            var catetype = "<?php echo $pay_category; ?>";
            jc('#catetype').val(catetype);
            paytc_resetVariables();
            jc('#fileupload_tat').datetimepicker({
                timepicker: false,
                format: 'm-d-Y',
                formatDate: 'm-d-Y',
                minDate: '-1970-01-01',
                scrollMonth : false,
                scrollInput : false
            });
            jc(document).on('keydown', '.onlynumbers', function(e) {
                if (e.keyCode == 46 || e.keyCode == 8 || e.keyCode == 9 ||
                    e.keyCode == 27 || e.keyCode == 13 ||
                    (e.keyCode == 65 && e.ctrlKey === true) ||
                    (e.keyCode >= 35 && e.keyCode <= 39)) {
                        return;
                } else {
                    if (e.shiftKey || (e.keyCode < 48 || e.keyCode > 57) && (e.keyCode <
                        96 || e.keyCode > 105)) {
                            e.preventDefault();
                    }
                }
            });
    // tooltip_new_responsive
            jc(function () {
                var a = jc("[rel~=tooltip]"),
                    b = !1,
                    c = !1;
                a.bind("mouseenter", function () {
                    if (b = jc(this), tip = b.attr("title"), c = jc(
                            '<div id="tooltipvd"></div>'), !tip || "" == tip) return !1;
                    b.removeAttr("title"), c.css("opacity", 0).html(tip).appendTo(
                        "body");
                    var a = function () {
                        jc(window).width() < 1.5 * c.outerWidth() ? c.css(
                                "max-width", jc(window).width() / 2) : c.css(
                                "max-width", 340);
                        var a = b.offset().left + b.outerWidth() / 2 - c.outerWidth() /
                                2,
                            d = b.offset().top - c.outerHeight() - 20;
                        if (a < 0 ? (a = b.offset().left + b.outerWidth() / 2 - 20,
                                    c.addClass("left")) : c.removeClass("left"), a + c.outerWidth() >
                            jc(window).width() ? (a = b.offset().left - c.outerWidth() +
                                    b.outerWidth() / 2 + 20, c.addClass("right")) : c.removeClass(
                                    "right"), d < 0) {
                            var d = b.offset().top + b.outerHeight();
                            c.addClass("top")
                        } else c.removeClass("top");
                        c.css({
                            left: a,
                            top: d
                        }).animate({
                            top: "+=10",
                            opacity: 1
                        }, 50)
                    };
                    a(), jc(window).resize(a);
                    var d = function () {
                        c.animate({
                            top: "-=10",
                            opacity: 0
                        }, 50, function () {
                            jc(this).remove()
                        }), b.attr("title", tip)
                    };
                    b.bind("mouseleave", d), c.bind("click", d)
                })
            });
            var textAreas = document.getElementsByTagName('textarea');
            Array.prototype.forEach.call(textAreas, function (elem) {
                elem.placeholder = elem.placeholder.replace(/\\n/g, '\n');
            });
    </script>
    <script src="<?php echo $CRMSERVERPATH; ?>js/jquery.combo.select.js"></script>
    <script>
        jc(function () {
            jc('.comboselect').comboSelect();
            jc('.js-select').change(function (e, v) {
                jc('.idx').text(e.target.selectedIndex)
                jc('.val').text(e.target.value)
            });
            jc('.combo-input').change(function (event) {
                var selectid  = jc(this).parent().parent().attr('id');
                var thisvalue = jc('.float-label #' + selectid + ' select option:selected').val();
                if (thisvalue == '') {
                    jc('.float-label #' + selectid + ' .combo-input').val('');
                }
            });
            jc(".option-item").hover(function () {
                jc(".option-item").removeClass("option-hover");
                jc(this).addClass("newhover");
            });
            jc('.comboselect').change(function (event) {
                var selectid = jc(this).parent().parent().attr('id');
                if (event.target.value != "") {
                    jc(".float-label #" + selectid + " label").addClass("selected-label");
                } else {
                    jc(".float-label #" + selectid + " label").removeClass("selected-label");
                }
            })
            /**
             * Open select
             */
            jc('.js-select-open').click(function (e) {
                jc('.js-select').focus()
                e.preventDefault();
            })
            /**
             * Open select
             */
            jc('.js-select-close').click(function (e) {
                jc('.js-select').trigger('comboselect:close')
                e.preventDefault();
            })
            /**
             * Add new options
             */
            var $select = jc('.js-select-3');
            jc('.js-select-add').click(function () {
                $select.prepend(jc('<option>', {
                    text: 'A new option: ' + Math.floor(Math.random() * 10) + 1
                })).trigger('comboselect:update')
                return false;
            })
        })
    </script>
</body>
</html>