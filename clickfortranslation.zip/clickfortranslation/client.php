<?php
header("Access-Control-Allow-Origin: *");
include_once "lib/serverconnect.php";
$service  = $_POST['service'];
$sitename = $_POST['sitename'];
$chennal  = $_POST['chennal'];
$version  = $_POST['version'];
$our_ipaddress = array('104.168.149.82','75.145.198.74','75.145.198.73','61.12.78.82','115.249.1.65');
$our_ipaddress = array();
// For getting user ip location details
function ip_details($IPaddress) {
    $json = file_get_contents("http://freegeoip.net/json/$IPaddress");
    $details = json_decode($json, true);
    $arr['ip_city'] = $details['city'];
    $arr['ip_region'] = $details['region_name'];
    $arr['ip_country'] = $details['country_name'];
    return $arr;
}
// For updating Page visit duration
if (isset($_REQUEST['timeSpent'])) {
    $seconds   = isset($_REQUEST['timeSpent']) ? strtolower($_REQUEST['timeSpent']) : '';
    $timespent = gmdate("H:i:s", $seconds);
    $recordid  = isset($_REQUEST['timespentrecordid']) ? strtolower($_REQUEST['timespentrecordid']) : '';
    if(!in_array($ip, $our_ipaddress) && $ip_details['ip_country'] != 'India'){
           mysql_query("UPDATE placeorder_click SET seconds = '$timespent' WHERE id = '$recordid'");
    }
    exit();
}

if($service != "" && $sitename !='' && $version != ''){
    $ip = $_SERVER['REMOTE_ADDR'];
    date_default_timezone_set('America/New_York');
    $createdat = date('Y-m-d H:i:s');  
    $browser = $_SERVER['HTTP_USER_AGENT'];
    $ip_details = ip_details($ip);
    if(!in_array($ip, $our_ipaddress) && $ip_details['ip_country'] != 'India'){
        $query = "INSERT INTO `placeorder_click`(`chennal`,`service`, `site`, `version`, `ipaddress`, `createdat`,`browser`) VALUES ('$chennal','$service','$sitename','$version','$ip','$createdat','$browser')";
        mysql_query($query); 
        echo mysql_insert_id();
    }
}else{
    echo 'Access Denied';
}


?>

