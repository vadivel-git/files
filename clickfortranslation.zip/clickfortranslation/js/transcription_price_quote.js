(function(a){(jQuery.browser=jQuery.browser||{}).mobile=/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i.test(a)||/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(a.substr(0,4))})(navigator.userAgent||navigator.vendor||window.opera);

var ismobile = jQuery.browser.mobile;
var jc              = jQuery.noConflict();
function calcProductHeight() {
  getProductHeight = jc('.product.active').height();
    console.log("getProductHeight : "+getProductHeight);
  jc('.products').css({
    height: getProductHeight
  });
}
jc(document).ready(function() {
    jc('#srclang').change(function () {
        //jc('#minutes').trigger('change');
        notThislang();
        showtrl();
    });
    /*jc('#trglang').change(function () {

        jc('#minutes').trigger('change');
    });*/
    jc('input[name=catetype]').click(function () {
        showtrl();
    });
    jc('#needtranslation,#srclang').change(function (){
        var srclang = jc("#srclang option:selected").val();
        var needtranslation = jc('#needtranslation').is(':checked');
        if(needtranslation && srclang != 90){
            jc('.needtrl').slideDown('fast');
        }else{
            jc('.needtrl').slideUp('fast');
        }
    });

     // For updating page visit duration
    var startTime;
    var endTime;
    startTime  = new Date()
    window.onunload = function(){
    endTime = new Date();
    var elapsedSeconds = endTime.getTime() - startTime.getTime();
    var seconds = parseFloat(elapsedSeconds)/1000;
    var timespentrecordid  = $("#timespendingid").html();
    var ajxurl      = window.location.href;
        $.ajax({
              url: serverPath+'client.php',
              data: {'timeSpent': seconds,
                     'timespentrecordid': timespentrecordid,
                     'ajxurl' : ajxurl
              },
              async: false,
              type: 'POST',
              success: function (data) {

              }

          });
     }
});
jc(document).on('click','#view_sample', function () {
    blurdataInfo           = {};
    blurdataInfo.comments  = 'Yes';
    blurdataInfo.fieldname = 'viewedsample';
    blurdataInfo.viewedsample = 'Yes';
    paytc_updateFormInfo(blurdataInfo);
});
jc(document).on('change','input[name=rushopts]', function () {
    var expedited               = '';
    var rushview      = jc('#expedited-timeline').is(':visible') ? 1 : 0;
    var standaredview = jc('#delivery-timeline').is(':visible') ? 1 : 0;
    //var rushopts = '';
    var rushper = '';
    if(standaredview) {
        expedited = jc("#expedited").is(':checked') ? 'Yes' : 'No';
    }else if(rushview){
        var rushopts  = jc('input[name=rushopts]:checked', '#transcriptionForm').val();
        expedited = (rushopts > 0)?'Yes':'No';

        if(rushopts == 3){
            rushper = '150%';
        }else if(rushopts == 2){
            rushper = '100%';
        }else if(rushopts == 1){
            rushper = '50%';
        }
    }

    if(rushopts > 0) {
        blurdataInfo             = {};
        blurdataInfo.comments    = 'Yes';
        blurdataInfo.fieldname   = 'expedited';
        blurdataInfo.expedited = 'Yes';
        paytc_updateFormInfo(blurdataInfo);


        setTimeout(function () {
            blurdataInfo             = {};
            blurdataInfo.comments   = rushper;
            blurdataInfo.fieldname  = 'rushper';
            blurdataInfo.rushper = rushper;
            paytc_updateFormInfo(blurdataInfo);
        }, 2000);
    }else{
        blurdataInfo             = {};
        blurdataInfo.comments    = '';
        blurdataInfo.fieldname   = 'expedited';
        blurdataInfo.expedited = '';
        paytc_updateFormInfo(blurdataInfo);

        setTimeout(function () {
            blurdataInfo             = {};
            blurdataInfo.comments   = '';
            blurdataInfo.fieldname  = 'rushper';
            blurdataInfo.rushper = '';
            paytc_updateFormInfo(blurdataInfo);
        }, 2000);
    }
});
function showtrl() {
    var srclang = jc("#srclang option:selected").val();
    var catetype  = jc('input[name=catetype]:checked', '#transcriptionForm').val();
    if(srclang == 90 && catetype == 'General'){
        jc('.usnative-blk').slideDown();
        jc('.showtrl').slideUp('fast');
    }else if((srclang == 90 && catetype != 'General')||(srclang == '')){
        jc('.usnative-blk').slideUp();
        jc('.showtrl').slideUp('fast');
    }else{
        jc('.usnative-blk').slideUp();
        jc('.showtrl').slideDown('fast');
    }
}
/* TAT calculation start */
function tatCalculation(srclang, prfilelength){

    notThislang();
    //paytc_pricequoteclac();
    var std_delivery = prfilelength/60;
    var std_delivery_calc = Math.ceil(std_delivery);
    var std_delivery_time='';
    var qcheck  = jc('#qc1').is(':checked');
    var extendtat = 0;
    if(qcheck){
        extendtat = 1;
    }
    if(std_delivery_calc <= 1 && srclang == 90){
        std_delivery_time = parseInt(std_delivery_calc+extendtat) + " business day";
    }else{
        var to_deltime = parseInt(std_delivery_calc+extendtat)+parseInt(1);
        std_delivery_time = parseInt(std_delivery_calc+extendtat)+' - '+to_deltime+ " business days";
    }
    console.log(std_delivery_time);
    return std_delivery_time;
}
function showerr(){
    jc('#uploadat').val('fileupload');
    jc('.order-summary').hide();
    jc('.pt').hide();
    jc('.u-email').hide();
    jc('.no-summary').show();
    jc('.qt').hide();
    jc('.hardcopytat').hide();
    jc("#expedited-timeline").hide();
    jc("#delivery-timeline").hide();
    jc('.expeditedblk').slideUp();
    jc('.offer-blk').hide();
}
function showquote(){
    jc('#uploadat').val('fileupload');
    jc('.order-summary').hide();
    jc('.pt').hide();
    jc('.u-email').show();
    jc('.qt_mailinfo').show();
    jc('.no-summary').show();
    if(!uploadProgress) {
        jc('.qt').show();
        /*if(ismobile){
            jc('.ext-btn').hide();
        }*/
    }
    jc('.offer-blk').hide();
    //showtimeline();
}
function showpay(){

    jc('#uploadat').val('fileuploadpay');
    jc('.no-summary').hide();
    jc('.qt').hide();
    jc('.qt_mailinfo').hide();
    jc('.order-summary').show();
    jc('.u-email').show();
    if(!uploadProgress) {
        jc('.pt').show();
    }
    jc('.offer-blk').hide();
    //showtimeline();
    // for save price viewed customer status.
    blurdataInfo           = {};
    blurdataInfo.comments  = 'Yes';
    blurdataInfo.fieldname = 'priceviewed';
    blurdataInfo.priceviewed = 'Yes';
    paytc_updateFormInfo(blurdataInfo);


    setTimeout(function() {
        blurdataInfo           = {};
        blurdataInfo.comments  = jc('#amount').val();
        blurdataInfo.fieldname = 'pricetotal';
        blurdataInfo.pricetotal = jc('#amount').val();
        paytc_updateFormInfo(blurdataInfo);
    }, 1000);
}
function reverseArr(input) {
    var ret = new Array;
    for(var i = input.length-1; i >= 0; i--) {
        ret.push(input[i]);
    }
    return ret;
}
function timeToSeconds(time) {
    time = time.split(/:/);
    return parseInt(time[0] * 3600 + time[1] * 60 + time[2]);
}
function showtimeline(){
    var hours           = parseInt(jc('#hours').val());
    var minutes         = parseInt(jc('#minutes').val());
    hours               = (!hours) ? 0 : hours;
    minutes             = (!minutes) ? 0 : minutes;
    var prfilelength    = minutes + hours * 60;
    var srclang         = jc("#srclang option:selected").val();
    var catetype        = jc('input[name=catetype]:checked', '#transcriptionForm').val();
    var deliveryReq     = jc('input[name=deliveryReq]:checked', '#transcriptionForm').val();
    var deliverytime    = jc('#delivery-timeline').is(':visible');
    var needtranslation = jc('#needtranslation').is(':checked');
    var qcheck          = jc('#qc1').is(':checked');
    var nativespkr ='';
    if(jc("#nativespkr-lbl").is(":visible")){
        nativespkr = (jc('#nativespkr').is(':checked'))?true:false;
    }


    if((prfilelength <= 900 && prfilelength > 0)
        && (jc.inArray(srclang, trclang) != -1)
        && (catetype)
    ){

        var days    = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        var d       = new Date(todaydate);
        var dayName = days[d.getDay()];

        var fri_e_timee    = '17:30:00';
        var sun_s_timee    = '22:00:00';
        var cur_secs       = timeToSeconds(cur_timee);
        var friday_e_timee = timeToSeconds(fri_e_timee);
        var sunday_s_timee = timeToSeconds(sun_s_timee);

        var weekoff = false;
        if(dayName != 'Saturday'){
            if(dayName == 'Friday' && cur_secs > friday_e_timee){
                weekoff = true;
            }else if(dayName == 'Sunday' && cur_secs < sunday_s_timee ){
                weekoff = true;
            }else{
                weekoff = false;
            }
        }else {
            weekoff = true;
        }
        weekoff = false;
        if(!qcheck && weekoff != true && prfilelength <= 600 && catetype == "General" && needtranslation != true && jc.inArray(srclang,trcrushlanguage) != -1){
            var doclength = 0;
            var nativespkr =false;
            if(jc("#nativespkr-lbl").is(":visible")) {
                nativespkr = (jc('#nativespkr').is(':checked')) ? true : false;
            }
            var rushscena  = 'otr';
            if(srclang == 90){
                if(nativespkr == true){
                    rushscena  = 'engnative';
                }else{
                    rushscena  = 'engnonnative';
                }
                doclength = (prfilelength > 0 && prfilelength <= 60) ? 0 : '';
                doclength = (prfilelength >= 61 && prfilelength <= 180) ? 1 : doclength;
                doclength = (prfilelength >= 181 && prfilelength <= 300) ? 2 : doclength;
                doclength = (prfilelength >= 301 && prfilelength <= 480) ? 3 : doclength;
                doclength = (prfilelength >= 481 && prfilelength <= 600) ? 4 : doclength;
            }else{
                doclength = (prfilelength > 0 && prfilelength <= 30) ? 0 : '';
                doclength = (prfilelength >= 31 && prfilelength <= 60) ? 1 : doclength;
                doclength = (prfilelength >= 61 && prfilelength <= 180) ? 2 : doclength;
                doclength = (prfilelength >= 181 && prfilelength <= 300) ? 3 : doclength;
                doclength = (prfilelength >= 301 && prfilelength <= 480) ? 4 : doclength;
                doclength = (prfilelength >= 481 && prfilelength <= 600) ? 5 : doclength;
            }

            var rushopts = jc('input[name=rushopts]:checked', '#transcriptionForm').val();
            var opts     = expeditedarr[rushscena][doclength];
            var optslist = '<b class="ui-turn">Turnaround time</b><div class="clearfix"></div>';
            opts = reverseArr(opts);
            jc.each( opts, function(tiers,tats) {
                var checked  = '';
                var rushname = '';
                if(tiers == 3){
                    rushname = ' (Express delivery)';
                }else if(tiers == 2){
                    rushname = ' (Super rush delivery)';
                }else if(tiers == 1){
                    rushname = ' (Rush delivery)';
                }else if(tiers == 0){
                    rushname = ' (Standard delivery)';
                    checked ='checked';
                }
                if(tiers == 0 || tiers == 2){
                    optslist += '<div class="row">';
                }
                optslist += '<div class="col-xs-12 col-sm-10 col-md-8 col-lg-6 rush-padding">'
                    +'<label class="custom-control custom-radio">'
                    +'<input id="rushopts'+tiers+'" type="radio" class="capturedata form-check-input del-time custom-control-input" onclick="paytc_pricequoteclac();" name="rushopts" value="'+tiers+'" '+checked+'>'
                    +'<span class="custom-control-indicator"></span>'
                    +'<span class="tatlbl ui_lbl_radio custom-control-description" id="tat-val'+tiers+'">'+tats+rushname+'</span>'
                    +'</label>'
                    +'</div>';
                if(tiers == 1 || tiers == 3){
                    optslist += '</div>';
                }
            });


            var tataval0 = jc('#tat-val'+0).html();
            var tataval1 = jc('#tat-val'+1).html();
            var tataval2 = jc('#tat-val'+2).html();
            var tataval3 = jc('#tat-val'+3).html();

            var artataval0 = [];
            var artataval1 = [];
            var artataval2 = [];
            var artataval3 = [];

            if(typeof tataval0 !== 'undefined'
                && typeof tataval1 !== 'undefined'
                && typeof tataval2 !== 'undefined'
                && typeof tataval3 !== 'undefined') {

                artataval0 = tataval0.split(' (');
                artataval1 = tataval1.split(' (');
                artataval2 = tataval2.split(' (');
                artataval3 = tataval3.split(' (');
            }
            if(opts[0] == artataval0[0]
                && opts[1] == artataval1[0]
                && opts[2] == artataval2[0]
                && opts[3] == artataval3[0]) {
                jc('#rushopts'+rushopts).attr('checked', 'checked');
            }else{
                jc('#expedited-timeline').html("");
                jc('#expedited-timeline').html(optslist);
            }

            jc("#delivery-timeline").hide();
            jc("#expedited-timeline").show();
        }else {
            jc("#expedited-timeline").hide();
            var std_delivery_time = tatCalculation(srclang, prfilelength);
            jc("#tat-val").html(std_delivery_time);

            jc("#delivery-timeline").show();
            if (deliveryReq == 'option2') {
                jc('.expeditedblk').slideDown('fast');
            } else {
                jc('.expeditedblk').slideUp('fast');
            }
        }
    }else{
        jc("#delivery-timeline").hide();
        jc("#expedited-timeline").hide();
        jc('.hardcopytat').hide();
    }
    paytc_pricequoteclac();
}
function validatepay(elem){
    var hours = parseInt(jc('#hours').val());
    var minutes = parseInt(jc('#minutes').val());
    hours = (!hours)?0:hours;
    minutes = (!minutes)?0:minutes;
    var prfilelength   = minutes + hours * 60;
    var srclang         = jc("#srclang option:selected").val();
    var trglang         = jc("#trglang option:selected").val();

    var thisid = jc(elem).attr("id");

    if(thisid != "hours" && thisid != "minutes" && (prfilelength == "" || prfilelength <= 0)){
        jc("#minutes").addClass("errmsg");
    }else if((thisid == "hours" || thisid == "minutes")&& (prfilelength == "" || prfilelength <= 0)){
        jc("#minutes").addClass("errmsg");
        return false;
    }else{
        jc("#minutes").removeClass("errmsg");
    }

    if(thisid != "hours" && thisid != "minutes" && thisid != "general" && thisid != "legal" && thisid != "srclang" && srclang == ""){
        jc('#srclang').closest('div').find('.combo-arrow').addClass("errmsg");
    }else if(thisid == "srclang" && srclang == ""){
        jc('#srclang').closest('div').find('.combo-arrow').addClass("errmsg");
        return false;
    }else{
        jc('#srclang').closest('div').find('.combo-arrow').removeClass("errmsg");
    }

    if(jc("#needtranslation-lbl").is(":visible") && jc("#needtranslation").is(":checked")){
        console.log(thisid+"--"+trglang);
        if(thisid != "hours" && thisid != "minutes" && thisid != "general" && thisid != "legal" && thisid != "srclang" && thisid != "needtranslation" && thisid != "trglang" && trglang == ""){
            jc('#trglang').closest('div').find('.combo-arrow').addClass("errmsg");
        }else if(thisid == "trglang" && trglang == ""){
            jc('#trglang').closest('div').find('.combo-arrow').addClass("errmsg");
            return false;
        }else{
            jc('#trglang').closest('div').find('.combo-arrow').removeClass("errmsg");
        }
    }


}
jc( document ).on('change keyup','.del-time', function() {
    var catetype        = jc('input[name=catetype]:checked', '#transcriptionForm').val();
    var srclang         = jc("#srclang option:selected").val();
    var trglang         = jc("#trglang option:selected").val();
    var deliveryReq     = jc('input[name=deliveryReq]:checked', '#transcriptionForm').val();
    var paytc_qemailcrm = jc("#paytc_qemailcrm").val();
    var needtranslation = jc("#needtranslation").is(':checked') ? 1 : 0;
    var nativespkr ='';
    if(jc("#nativespkr-lbl").is(":visible")){
        nativespkr = (jc('#nativespkr').is(':checked'))?true:false;
    }
    var min = 0;
    var minVal = jc("input[name='length[]']")
        .map(function () {
            return jc(this).val();
        }).get();

    var serialId = jc("input[name='uploadFiles[]']")
        .map(function () {
            return jc(this).data('serid');
        }).get();
    var len = minVal.length;
    min =(len > 0)?0:min;
    var i = 0;
    for (i = 0; i < len; i++) {
        if (!isNaN(min) && !isNaN(minVal[i]) && minVal[i] != '') {
            min = parseInt(min) + parseInt(minVal[i]);
        }
    }
    if (isNaN(min)) {
        min = 0;
    }
    if(i > 0) {
        prfilelength = min;
        var temphour = hourconverter(prfilelength);
        var res = temphour.replace("(", "").replace(")", "");
        var timear = res.split(':');

        jc('#hours').val(timear[0]);
        jc('#minutes').val(timear[1]);
    }

    var hours = parseInt(jc('#hours').val());
    var minutes = parseInt(jc('#minutes').val());
    hours = (!hours)?0:hours;
    minutes = (!minutes)?0:minutes;
    var prfilelength   = minutes + hours * 60;

    if(prfilelength >= 60){
        jc(".freetrial").slideDown("fast");
    }else{
        jc(".freetrial").slideUp("fast");
    }
    jc('.qt_msg').html('Enter project details to view the price.');
    if(srclang == 90 && catetype == "General") {
        jc('.verbaelm').slideDown();
    }else{
        jc('#cleanverba').prop('checked',true);
        jc('.verbaelm').slideUp();
    }
    validatepay(this);
    showtimeline();
    if(srclang == ''
        && (catetype == '')
        && (prfilelength == '')
    ){
            jc('.u-email').hide();
            jc('.pt').hide();
            jc('.qt').hide();
            jc('.no-summary').show();
            jc('.order-summary').hide();
    }else {

        var deliverytime = jc('#delivery-timeline').is(':visible');
        if(prfilelength == '' || prfilelength == 0){
            jc(".qt_msg").html("Enter <b class='text-highlight'>file length</b> to view the price.");
            showerr();
        }else if(catetype == ''){
            jc(".qt_msg").html("Select <b class='text-highlight'>category</b> to view the price.");
            showerr();
        }else if(!srclang){
            jc(".qt_msg").html("Select <b class='text-highlight'>source language</b> to view the price.");
            showerr();
        }else if((jc.inArray(srclang, trclang) == -1)){
            jc('.qt_msg').html('Customized rate apply for  '+language_list[srclang]+'.');
            showquote();
        }else if (prfilelength > 900) {
            jc('.qt_msg').html('Customized rate apply for file length above <b>900</b> minutes.');
            showquote();
        }else if(srclang != 90 && needtranslation && trglang == ''){
            jc('.qt_msg').html('Select <b class="text-highlight">target language</b> to view the price.');
            showquote();
        }else if(deliveryReq == 'option2' && deliverytime) {
            jc('.qt_msg').html('Customized rate apply for <b>expedited service</b>.');
            showquote();
        }else{
            showpay();
        }
    }
    if(srclang == 90 && catetype == "General" && nativespkr != true){
        if(prfilelength != '' && prfilelength < 180 ){
            var needmin = 180-prfilelength;
            jc('#needmin').html(needmin);
            jc('#availoff').html('10%');
            jc('.offer-blk').show();
        }else if(prfilelength != '' && prfilelength >= 180 && prfilelength < 360){
            var needmin = 360-prfilelength;
            jc('#needmin').html(needmin);
            jc('#availoff').html('20%');
            jc('.offer-blk').show();
        }else if(prfilelength != '' && prfilelength >= 360 && prfilelength < 720){
            var needmin = 720-prfilelength;
            jc('#needmin').html(needmin);
            jc('#availoff').html('30%');
            jc('.offer-blk').show();
        }else{
            jc('.offer-blk').hide();
        }
    }else{
        jc('.offer-blk').hide();
    }
    paytc_pricequoteclac();
});
/* TAT calculation end */
function remove_allfiles(){
    jc('.up-close').each(function() {
        jc(this).trigger("click");
    });
}
function isNumberKeyq(evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode;
    //console.log(charCode);
    if (charCode != 45 && charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
    return true;
}
function notThislang(){
    var selectedlang = jc( "#srclang option:selected" ).val();
    var selectedtrs = jc( "#trglang option:selected" ).val();
    var trsopt='<option value="">Select target language</option>';
    var seltrgtlang;
    if(selectedlang == selectedtrs){
        jc('#trglang').siblings('.combo-input:first').val('');
    }
    jc.each( language_list, function(r,x) {
        seltrgtlang='';
        if(r != selectedlang || x == ""){
            if(selectedtrs == r){
                seltrgtlang ='selected="selected"';
            }
            trsopt += '<option '+seltrgtlang+' value="'+r+'">'+x+'</option>';
        }
    });
    if(trsopt != '') {
        jc('#trglang')
            .find('option')
            .remove()
            .end()
            .append(trsopt)
            .trigger('comboselect:update');
    }
}
jc(document).on('change', '#filepay', function() {
    paytc_upload('filepay');
});
window.onload = function() {
    notThislang();
    var hours = parseInt(jc('#hours').val());
    var minutes = parseInt(jc('#minutes').val());
    hours = (!hours)?0:hours;
    minutes = (!minutes)?0:minutes;
    var prfilelength   = minutes + hours * 60;
    var srclang         = jc("#srclang option:selected").val();

    if((prfilelength != "" && prfilelength > 0) && (srclang != "" && srclang != null )){
        jc('#minutes').trigger("change");
        showtrl();
    }
    //jc('#minutes').trigger("change");
};
/* here js */
var source1;
var target;
var valFind;
jc(document).ready(function() {
	var bs_url = window.location;
    var base_urls = bs_url.protocol + "//" + bs_url.host;
    var isVisible = jc('#fileuploader').is(':visible');
	if(isVisible == false){
		jc.ajax({
			url:base_urls+'/logdetails.php',
			data : 'siteurl='+base_urls,
			type: 'POST',
			success: function(data){
				// alert(data);
			},
			error : function (data) {
				//alert(data);
			}
		});
	}
});
/* here submit */
jc(document).on('click','#filesubmit', function(e) {
    var name        = jc('#cont_qnamecrm').val();
    var country     = jc('#cont_qcountryscrm').val();
    var phone       = jc('#cont_qphonecrm').val();
    var payt_tatcrm = jc('#cont_tatcrm').val();
    var paytc_hfc   = jc("#cont_hfc").val();
    var expedited   = jc("#expedited").val();
    var pid         = jc("#pid").val();
    var deliveryReq = jc('input[name=deliveryReq]:checked', '#transcriptionForm').val();


    var email    = $('#trans_email').val();
    var sitename = $('#sitename').val();
    var comment    = $('#upcomments').val();
    var filena     = new Array();
    var files      = '';
    var UploadFlag = uploadProgress;
    var ordId      = $('#ordId').val();
    filena         = [];
    $(".fileName").each(function (index) {
        elemval = $(this).val().trim();
        filena.push(elemval);
    });
    var count = filena.length;
    var completedfilecnt = $('.audioLength:visible').length;
    var recordkeyval = $('#recordkey').val();
    var form_data = new FormData();


    form_data.append('name', name);
    form_data.append('country', country);
    form_data.append('phone', phone);
    form_data.append('tatdate', payt_tatcrm);
    form_data.append('paytc_hfc', paytc_hfc);
    form_data.append('expedited', expedited);

    form_data.append('recordkey', recordkeyval);
    form_data.append('uploadFiles', filena);
    form_data.append('count', count);
    form_data.append('ordId', ordId);
    form_data.append('completedfilecnt', completedfilecnt);
    form_data.append('quoteflag', $('#quoteflag').val());
    form_data.append('uploadflag', UploadFlag);
    form_data.append('uptype', 1);
    form_data.append('upcomments', comment);
    form_data.append('email', email);
    form_data.append('sitename', sitename);
    form_data.append('pid', pid);
    form_data.append('uploadedFileDetailsArr', uploadedFileDetailsArr);
    $('#qfmsgcrm').css({'color': '#3573A6'});
    $('#qfmsgcrm').html('Processing...');
    $('#quoteflagnew').val(1);
    if ($('#quoteflag').val() == 0) {
        $('#fileuploader').prop('onclick', null);
        document.getElementById('fileuploader').style.removeProperty('cursor');
        $('span.up-close').hide();
        if (uploadProgress == true) {
            showMessage('#my-welcome-message2');
        }
    } else {
        form_data.append('quoteinfo', quoteInfo);
        form_data.append('ticketID', ticketID);
    }
    $('#filesubmit').hide();
    $('#processing').show();
    $.ajax({
        url: update_url,
        dataType: 'json',
        contentType: false,
        processData: false,
        data: form_data,
        type: 'POST',
        success: function (data) {
            if (data.type == 'quote' && data.status == 1) {
                $('#quoteflag').val(data.status);
                quoteInfo = data.info;
                ticketID = data.ticketid;
            }
            if (data.type == 'error') {
                output = data.text;
            }
            else {
                $('#qfmsgcrm').html('');
                output = data.text;
                if (output == 'Your request has been sent successfully and you will receive an email from us shortly. Thank you!') {
                    if (successpath) {
                        location.href = "http://" + successpath + "/success.php?crmpage=upload";
                    } else {
                        $('#qfmsgcrm').html(output);
                        window.setTimeout(function () {
                            location.reload()
                        }, 7000);
                    }
                }
                else {
                    $('#qfmsgcrm').html(output);
                    $('#qfmsgcrm').css({'color': '#333'});
                }
            }
        }
    });
});
jc('#exp_tat').keypress(function () {
    jc('#exp_tat').tooltip('destroy');
});
/* here qsubmit */
jc(document).on('click','.qsubmitcrm', function(e) {
    var reg        = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
    var buttonname = jc(this).attr('value');
    var prfilelength    = '';
    var qttcode         = '';
    var qtvercrmpay     = '';
    var deliveryReq     = '';
    var needtranslation = '';
    var nativespkr      = '';
    var catetype        = '';
    var srclang         = '';
    var trglang         = '';
    var ofpct           = '';
    var filena      = new Array();
    var files       = '';
    var UploadFlag  = uploadProgress;
    filena          = [];

    deliveryReq    = jc('#expedited').is(":checked") ? 1 : 0;

    var trcpriceb    = 0;
    var trccostb     = 0;
    var trcprice     = 0;
    var trccost      = 0;
    var trctcodecost = 0;
    var trcverbacost = 0;
    var qcheckcost   = 0;
    var trctotcost   = 0;
    var mfileprice   = 0;
    var expprice     = 0;
    var subamt       = 0;
    var transrate    = 0;
    var pricedisplay = 0;
    var offerval        = 0;
    var finalround      = 0;
    var rushview      = jc('#expedited-timeline').is(':visible') ? 1 : 0;
    var standaredview = jc('#delivery-timeline').is(':visible') ? 1 : 0;
    var qcheck        = jc('#qc1').is(':checked') ? 1 : 0;
    var rushopts = '';
    var aprxtat = '';
    var fileupload_tat ='';
    if(standaredview) {
        if (!jc('#fileupload_tat').is(':visible') && jc('#tat-val').is(':visible')) {
            aprxtat = jc("#tat-val").html();
        }
        if (jc('#fileupload_tat').is(':visible')) {
            fileupload_tat = jc("#fileupload_tat").val();
        }
    }else if(rushview){
        rushopts      = jc('input[name=rushopts]:checked', '#transcriptionForm').val();
        aprxtat       = jc("#tat-val" + rushopts).html();
        if(rushopts != 0) {
            deliveryReq = 1;
        }
        expprice = jc('#expprice').val();
    }

    if (buttonname != "Get Quote") {

        trcpriceb    = jc('#trcpriceb').val();
        trccostb     = jc('#trccostb').val();
        trcprice     = jc('#trcprice').val();
        trccost      = jc('#trccost').val();
        trctcodecost = jc('#trctcodecost').val();
        trcverbacost = jc('#trcverbacost').val();
        if(qcheck){
            qcheckcost = jc('#qcheckcost').val();
        }
        trctotcost   = jc('#trctotcost').val();
        mfileprice   = jc('#mfileprice').val();
        subamt       = jc('#subamt').val();
        transrate    = jc('#transrate').val();
        pricedisplay = jc('#pricedisplay').val();
    }

   /* var trcmin_disp = '';
    if(jc('#trcmin_disp').is(':visible')) {
        trcmin_disp = jc('#trcmin_disp').html();
    }*/

    var cst_db   = jc("#cst_db").val();
    var hours    = parseInt(jc('#hours').val());
    var minutes  = parseInt(jc('#minutes').val());
    hours        = (!hours) ? 0 : hours;
    minutes      = (!minutes) ? 0 : minutes;
    prfilelength = minutes + hours * 60;
    catetype     = jc('input[name=catetype]:checked', '#transcriptionForm').val();
    srclang      = jc("#srclang").val();
    qtvercrmpay  = jc('input[name=qtvercrmpay]:checked', '#transcriptionForm').val();
    qttcode      = jc('#qttcodecrm option:selected').val();
    if (jc('#needtranslation-lbl').is(':visible')) {
        needtranslation = jc("#needtranslation").is(':checked') ? 1 : 0;
    }
    if(jc("#trglang").is(':visible')){
        // trglangg = jc("#trglang option:selected").val();
        trglang = jc("#trglang").val();
    }
    if (jc('#nativespkr-lbl').is(':visible')) {
        nativespkr = jc("#nativespkr").is(':checked') ? 1 : 0;
    }

    var email        = jc('#paytc_qemailcrm').val();
    var form_data    = new FormData();
    var uploadat     = jc("#uploadat").val();
    var recordkeyval = jc('#recordkey').val();
    var service      = jc('#service').val();
    var sitename     = jc("#site_namee").val();
    var camethrough  = jc("#camethrough").val();
    var source       = srclang;
    var target       = trglang;

    jc( ".fileNamepay" ).each(function( index ) {
        elemval = jc( this ).val().trim();
        filena.push(elemval);
    });
    var filesserid = jc("input[name='uploadFiles[]']")
        .map(function () {
            return jc(this).data('serid');
        }).get();
    var i               = 0;
    var fildetail       = [];
    var duratnval       = [];
    var tempfildetail   = '';
    var tempdur         = '';
    jc.each(filesserid, function (index, value) {
        i = value;
        tempfildetail = jc("#uploadFiles-"+i).val().trim();
        fildetail.push(tempfildetail);
        tempdur = jc("#durationnewpay-"+i).val().trim();
        duratnval.push(tempdur);
    });
    var count            = filena.length;
    var completedfilecnt = jc('.audioLengths:visible').length;
    var filecomments     = jc('#filecomments').val();
    var siteprtcl        = jc('#siteprtcl').val();
    ofpct                = jc("#ofpct").html();
    var offerpct         = jc("#offerpct").val();
    offerval             = jc("#offerval").val();
    finalround           = jc("#finalround").val();
    if(offerpct <= 0 && offerval <= 0){
        offerval   = 0;
        finalround = 0;
        ofpct      = '';
    }
    var frtrial= '';
    if(jc(".freetrial").is(":visible")){
        var frtrial= jc('input[name=frtrial]:checked', '#transcriptionForm').val();
    }
    form_data.append('cst_db', cst_db);
    form_data.append('completedfilecnt', completedfilecnt);
    form_data.append('count', count);
    form_data.append('fildetail', fildetail);
    form_data.append('duratnval', duratnval);
    form_data.append('filena', filena);
    form_data.append('uploadflag', UploadFlag);
    form_data.append('recordkey', recordkeyval);
    form_data.append('prfilelength',prfilelength);
    form_data.append('source', source);
    form_data.append('target', target);
    form_data.append('catetype',catetype);
    form_data.append('fileupload_tat', fileupload_tat);
    form_data.append('needtranslation',needtranslation);
    form_data.append('nativespkr',nativespkr);

    form_data.append('qtvercrmpay', qtvercrmpay);
    form_data.append('qttcode', qttcode);
    form_data.append('uploadat', uploadat);
    form_data.append('email', email);

    form_data.append('trcprice',trcprice);
    form_data.append('trccost',trccost);
    form_data.append('trctcodecost',trctcodecost);
    form_data.append('trcverbacost',trcverbacost);
    form_data.append('trctotcost',trctotcost);
    form_data.append('mfileprice',mfileprice);

    form_data.append('expprice',expprice);
    form_data.append('subamt',subamt);
    form_data.append('transrate',transrate);
    form_data.append('pricedisplay',pricedisplay);
    form_data.append('amount',pricedisplay);
    // form_data.append('trcmin_disp',trcmin_disp);

    form_data.append('aprxtat', aprxtat);
    form_data.append('camethrough', camethrough);
    form_data.append('service', service);
    form_data.append('sitename', sitename);
    form_data.append('deliveryReq',deliveryReq);
    form_data.append('buttonname', buttonname);
    form_data.append('rushopts', rushopts);
    form_data.append('filecomments', filecomments);
    form_data.append('qcheck', qcheck);
    form_data.append('qcheckcost', qcheckcost);
    form_data.append('trcpriceb', trcpriceb);
    form_data.append('trccostb', trccostb);
    form_data.append('siteprtcl', siteprtcl);
    form_data.append('offerval', offerval);
    form_data.append('finalround', finalround);
    form_data.append('ofpct', ofpct);
    form_data.append('frtrial', frtrial);

    if(prfilelength == '' || prfilelength ==0){
        jc('#minutes').tooltip({title: "File length is required!"});
        jc('#minutes').focus();
        jc('#minutes').keypress(function () {
            jc('#minutes').tooltip('destroy');
        });
        return false;
    }
    if(!catetype){
        jc('#general').tooltip({title: "Category is required!"});
        jc('input[name="catetype"]').click(function() {
            jc('#general').tooltip('destroy');
        });
        return false;
    }
    if(srclang ==''){
        jc('#srclang_chosen').tooltip({title: "Source language is required !"});
        jc('#srclang_chosen').trigger("mousedown");
        jc('#srclang').change(function() {
            jc('#srclang').tooltip('destroy');
        });
        return false;
    }
    if(needtranslation && trglang == ''){
        jc('#trglang_chosen').tooltip({title: "Target language is required !"});
        jc('#trglang_chosen').trigger("mousedown");
        jc('#trglang').change(function() {
            jc('#trglang').tooltip('destroy');
        });
        return false;
    }

    var filelengthvalid = true;
    var invalidlength ='';

    jc(".length").each(function (i) {
        var thisid = jc(this).attr('id');
        var arr = thisid.split('-');
        i = arr[1];
        var dur = parseInt(jc("#durationnewpay-"+i).val());
        if (isNaN(dur) || dur == '' || dur < 1) {
            /*jc("#filetypespay" + i).show();
             jc("#filetypespay" + i).removeClass("hrdisplay").addClass("errlength");
             jc("#filetypespay" + i).html("Enter file length!");*/
            filelengthvalid = false;
            invalidlength = i;
        }
    });

    if(!filelengthvalid){
        jc('#durationnewpay-'+ invalidlength).tooltip({title: "Enter file length!"});
        jc('#durationnewpay-'+ invalidlength).focus();
        jc('#durationnewpay-'+ invalidlength).keypress(function () {
            jc('#durationnewpay-'+ invalidlength).tooltip('destroy');
        });
        return false;
    }

    if(standaredview && deliveryReq == 1 && fileupload_tat ==''){
        jc('#fileupload_tat').tooltip({title: "Turnaround time is required!"});
        jc('#fileupload_tat').focus();
        jc('#fileupload_tat').keypress(function () {
            jc('#fileupload_tat').tooltip('destroy');
        });
        return false;
    }

    if (jc("#fileupload_tat").hasClass("invalid") && jc('#uploadat').val() != 'fileupload') {
        jc('#fileupload_tat').tooltip({title: "Turnaround time must be greater than 5 hours from now."});
        jc('#fileupload_tat').focus();
        return false;
    }

    if(email ==''){
        jc('#paytc_qemailcrm').tooltip({title: "Email id is required!"});
        jc('#paytc_qemailcrm').focus();
        jc('#paytc_qemailcrm').keypress(function () {
            jc('#paytc_qemailcrm').tooltip('destroy');
        });
        return false;
    }
    if(email !='' && (reg.test(email.trim()) == false)){
        jc('#paytc_qemailcrm').tooltip({title: "Email id is invalid!"});
        jc('#paytc_qemailcrm').focus();
        jc('#paytc_qemailcrm').keypress(function () {
            jc('#paytc_qemailcrm').tooltip('destroy');
        });
        return false;
    }
    jc('.qt,.pt').hide();
    jc('.pr').show();
    jc.ajax({
        url:update_quote,
        dataType: 'json',  // what to expect back from the PHP script, if anything
        contentType: false,
        processData: false,
        data: form_data,
        type: 'POST',
        success: function(data){
            if (uploadat == "fileuploadpay" && buttonname == "Proceed to Payment") {
                jc('#item_number_1').val(data.ordsid);
                jc("#transcriptionForm").submit();
                return false;
            }else{
                if(data.type == 'quote' && data.status == 1){
                    jc('#quoteflag').val(data.status);
                    quoteInfo = data.info;
                }
                if(data.type == 'error'){
                    output = data.text;
                }else{
                    jc('#qfmsgcrm').html('');
                    output = data.text;
                    if(output=='Your request has been sent successfully and you will receive an email from us shortly. Thank you!'){
                        if (successpath) {
                            var redurl = "http://"+successpath+"/additional-information.php?id="+data.param;
                            location.href = redurl;
                        } else {
                            jc('#qfmsgcrm').html(output);
                            window.setTimeout(function () {
                                location.reload()
                            }, 7000);
                        }
                    }else{
                        jc('#qfmsgcrm').html(output);
                        jc('#qfmsgcrm').css({'color':'#333'});
                    }
                }
            }
        },
        error : function (data) {
            jc("#qsubmitcrm").removeAttr('disabled');
        }
    });
});
function rushcalculator(){
    var rushopts       = jc('input[name=rushopts]:checked', '#transcriptionForm').val();
    var rushview = jc('#expedited-timeline').is(':visible');
    var expd = 0;
    if(!isNaN(parseInt(rushopts)) && rushview){
        if(rushopts == 3){
            expd = 1.5;
        }else if(rushopts == 2){
            expd =1;
        }else if(rushopts == 1){
            expd = 0.5;
        }
    }
    return expd;
}
function paytc_pricequoteclac() {
    var srclang        = jc("#srclang option:selected").val();
    jc('.availedoff').hide();
    if(jc.inArray(srclang,trclang) != -1) {
        var catetype     = jc('input[name=catetype]:checked', '#transcriptionForm').val();
        var hours = parseInt(jc('#hours').val());
        var minutes = parseInt(jc('#minutes').val());
        hours = (!hours)?0:hours;
        minutes = (!minutes)?0:minutes;
        var prfilelength   = minutes + hours * 60;
        var nativespkr ='';
        if(jc("#nativespkr-lbl").is(":visible") && catetype != 'Legal'){
            nativespkr      = jc("#nativespkr").is(":checked");
        }
        var qttcodecrm      = jc("#qttcodecrm option:selected").val();
        var qtvercrmpay      = jc('input[name=qtvercrmpay]:checked', '#transcriptionForm').val();
        var qcheck          = jc("#qc1").is(":checked");
        var needtranslation = jc("#needtranslation").is(":checked");
        var trglang         = jc("#trglang option:selected").val();
        var deliveryReq     = jc('input[name=deliveryReq]:checked', '#transcriptionForm').val();
        var rushopts        = jc('input[name=rushopts]:checked', '#transcriptionForm').val();
        var language        = jc('#srclang').val();
        //jc('.expeditedblk').hide();
        jc('.notary-pr,.mailed-pr').hide();

        var total             = 0;
        var min               = prfilelength;
        var price             = 0;
        var trctimecode       = 0;
        var trcverbatime      = 0;
        var Transactionfee    = '';

        var trcprice_disp     = 0.00;
        var trccost_disp      = 0.00;
        var trctcodecost_disp = 0.00;
        var trcverbacost_disp = 0.00;
        var trctotcost_disp   = 0.00;
        var mfileprice_disp   = 0.00;
        var expprice_disp     = 0.00;

        var sub_amt           = 0.00;
        var trans_rate        = 0.00;
        var price_display     = 0.00;
        var tatpercentage     = 0;
        var noofferprice      = 0.00;
        var nooffercost       = 0.00;
        var trc_minordcost    = 0;

        if((jc.inArray(srclang, trclang) != -1)
            && (catetype)
            && (prfilelength > 0 && prfilelength <= 900)
        ){
            price = 0.99;
            price = (srclang == 90 && catetype == 'Legal')?2.00:price;
            price = (srclang == 90 && nativespkr)?1.75:price;
            price = (srclang != 90)?5.00:price;

            noofferprice = price;
            nooffercost = parseFloat(price * min);
            if(srclang == 90 && catetype == "General" && !nativespkr) {
                if (prfilelength != '' && prfilelength >= 180 && prfilelength < 360) {
                    price = price-(price*0.1).toFixed(2);
                    jc('.availedoff').show();
                } else if (prfilelength != '' && prfilelength >= 360 && prfilelength < 720) {
                    price =price-(price*0.2).toFixed(2);
                    jc('.availedoff').show();
                } else if (prfilelength != '' && prfilelength >= 720) {
                    price =price-(price*0.3).toFixed(2);
                    jc('.availedoff').show();
                }
            }

            tatpercentage = rushcalculator();
            tatpercentage = (isNaN(tatpercentage))?0:tatpercentage;
            jc('.timecode-pr').hide();
            if(qttcodecrm > 0){
                jc('.timecode-pr').show();
                trctimecode = timcodeoptions[qttcodecrm]['price'];
                trctcodecost_disp = parseFloat(trctimecode * min);
            }

            if(qtvercrmpay == "1"){
                trcverbatime = 0.25;
                trcverbacost_disp = parseFloat(trcverbatime * min);
                jc('.verbatime-pr').show();
            }else{
                jc('.verbatime-pr').hide();
            }
            var qcheckcost = 0.00;
            jc('.qcheck-pr').hide();
            if(qcheck) {
                jc('.qcheck-pr').show();
                if (srclang == 90) {
                    qcheckcost = parseFloat(0.25 * min);
                } else {
                    qcheckcost = parseFloat(1.00 * min);
                }
            }
            if(jc('.availedoff').is(':visible')) {
                trcprice_disp = parseFloat(price);
                trccost_disp  = parseFloat(price * min);
                trctotcost_disp = parseFloat(trccost_disp+trctcodecost_disp+trcverbacost_disp);
            }else{
                trctotcost_disp = parseFloat(nooffercost+trctcodecost_disp+trcverbacost_disp);
            }

            /*var mintxt = 0;
            if((trctotcost_disp+qcheckcost) < trc_minordcost && trctotcost_disp > 0){
                trctotcost_disp = trc_minordcost;
                jc('.minimum-trcpr').show();
                jc('#trcmin_disp').html(trctotcost_disp.toFixed(2));
            }else{
                mintxt = 1;
                jc('.minimum-trcpr').hide();
            }*/
            if(tatpercentage > 0) {
                expprice_disp = parseFloat(trctotcost_disp * tatpercentage);
                var rushtat       = jc("#tat-val" + rushopts).html();
                var rushperctge = tatpercentage*100
                jc('#exptooltip').prop('title', rushperctge+'% Expedited service fee applies as you have chosen '+rushtat+' as the turnaround time.');
                jc(".rush-view").show();
            }else{
                jc(".rush-view").hide();
            }

            sub_amt       = parseFloat(expprice_disp+trctotcost_disp + mfileprice_disp+qcheckcost);
            // sub_amt=(mintxt)?(sub_amt + qcheckcost):sub_amt;

            var offpct = jc("#offerpct").val();
            var offervalue = parseFloat(sub_amt * offpct);
            var sub_ttooll = (sub_amt - offervalue);
            trans_rate    = (sub_ttooll / 100) * 5;
            price_display = parseFloat(sub_ttooll + trans_rate);


            var offpr = parseFloat(nooffercost - trccost_disp);
            if(offpr > 0 ){
                jc('#offprice').html(offpr.toFixed(2));
            }

            if(offervalue > 0) {
                jc(".coupval-pr").slideDown();
            }else{
                jc(".coupval-pr").slideUp();
            }

            jc("#offerval_value").html(offervalue.toFixed(2));
            jc("#sub_total").html(sub_ttooll.toFixed(2));

            jc("#offerval").val(offervalue.toFixed(2));
            jc("#finalround").val(sub_ttooll.toFixed(2));


            jc('#trcpriceb_disp').html(noofferprice.toFixed(2));
            jc('#trccostb_disp').html(nooffercost.toFixed(2));
            jc('#trcprice_disp').html(trcprice_disp.toFixed(2));
            jc('#trccost_disp').html(trccost_disp.toFixed(2));
            jc('#trctcodecost_disp').html(trctcodecost_disp.toFixed(2));
            jc('#trcverbacost_disp').html(trcverbacost_disp.toFixed(2));
            jc('#qcheckcost_disp').html(qcheckcost.toFixed(2));
            jc('#trctotcost_disp').html(trctotcost_disp.toFixed(2));

            jc('#mfileprice_disp').html(mfileprice_disp.toFixed(2));
            jc('#expprice_disp').html(expprice_disp.toFixed(2));

            jc('#sub_amt').html(sub_amt.toFixed(2));
            jc('#trans_rate').html(trans_rate.toFixed(2));
            jc('#price_display').html(price_display.toFixed(2));


            jc('#trcpriceb').val(noofferprice.toFixed(2));
            jc('#trccostb').val(nooffercost.toFixed(2));
            jc('#trcprice').val(trcprice_disp.toFixed(2));
            jc('#trccost').val(trccost_disp.toFixed(2));
            jc('#trctcodecost').val(trctcodecost_disp.toFixed(2));
            jc('#trcverbacost').val(trcverbacost_disp.toFixed(2));
            jc('#qcheckcost').val(qcheckcost.toFixed(2));

            jc('#trctotcost').val(trctotcost_disp.toFixed(2));

            jc('#mfileprice').val(mfileprice_disp.toFixed(2));
            jc('#expprice').val(expprice_disp.toFixed(2));

            jc('#subamt').val(sub_amt.toFixed(2));
            jc('#transrate').val(trans_rate.toFixed(2));
            jc('#pricedisplay').val(price_display.toFixed(2));
            jc('#amount').val(price_display.toFixed(2));

        }
    }
}
function  paytc_showsubtotal(){
    jc('#time_rate').show();
    jc('#verb_rate').show();
    jc(".rate-show1").show();
    jc(".rate-show2").show();
    jc('#verb_rate').html('$0.00');
    jc('#time_rate').html('$0.00');
}
function tohour(durminutes){
    var hours = Math.floor( durminutes / 60);
    var minutes = (durminutes % 60).toFixed(0);
    hours = pad(hours, 2);
    minutes = pad(minutes, 2);
    return duhrs = parseFloat(hours+"."+minutes);
}
function paytc_resetVariables() {
    sureUploadSize = 0, probableUplaodSize = 0;
    partsLeft = [];
    cancelFlag             = false
    fileuploadstatus       = [];
    uploadFilesArr         = [];
    uploadedFilesArr       = [];
    uploadedFileDetailsArr = [];
}
function pad(str, max) {
    str = str.toString();
    return str.length < max ? pad("0" + str, max) : str;
}
function paytc_updateFormInfo(blurdataInfo) {
        var hours = parseInt(jc('#hours').val());
        var minutes = parseInt(jc('#minutes').val());
        hours = (!hours)?0:hours;
        minutes = (!minutes)?0:minutes;
        var prfilelength   = minutes + hours * 60;
        var expedited               = '';
        var rushview      = jc('#expedited-timeline').is(':visible') ? 1 : 0;
        var standaredview = jc('#delivery-timeline').is(':visible') ? 1 : 0;

        var rushper = '';
        if(standaredview) {
            expedited = jc("#expedited").is(':checked') ? 'Yes' : 'No';
        }else if(rushview){
            var rushopts  = jc('input[name=rushopts]:checked', '#transcriptionForm').val();
            expedited = (rushopts > 0)?'Yes':'No';
            if(rushopts == 3){
                rushper = '150%';
            }else if(rushopts == 2){
                rushper = '100%';
            }else if(rushopts == 1){
                rushper = '50%';
            }
        }
        var qtvercrmpay      = jc('input[name=qtvercrmpay]:checked', '#transcriptionForm').val();


        var trglangg = '';
        if(jc("#trglang").is(':visible')){
            trglangg = jc("#trglang option:selected").val();
        }
        var frtrial= '';
        if(jc(".freetrial").is(":visible")){
            var frtrial= jc('#ft1').is(":checked")?"Yes":"No";
        }
        blurdataInfo.qemail         = jc('#paytc_qemailcrm').val();
        blurdataInfo.entryval       = jc('#recordkey').val();
        blurdataInfo.service        = jc('#service').val();
        blurdataInfo.catetype       = jc('input[name=catetype]:checked', '#transcriptionForm').val();
        blurdataInfo.srclang        = jc("#srclang option:selected").val();
        blurdataInfo.trglang        = trglangg;
        blurdataInfo.prfilelength   = prfilelength;
        blurdataInfo.camethrough    = jc("#camethrough").val();
        blurdataInfo.fileupload_tat = jc("#fileupload_tat").val();
        blurdataInfo.filecomments   = jc("#filecomments").val();
        blurdataInfo.qcheck         = jc("#qc1").is(':checked') ? 'Yes' : 'No';
        blurdataInfo.expedited      = expedited;
        blurdataInfo.rushper        = rushper;
        blurdataInfo.frtrial        = frtrial;
        blurdataInfo.qtvercrmpay     = (qtvercrmpay == "1") ? 'Yes' : 'No';
        blurdataInfo.qttcodecrm      = jc("#qttcodecrm option:selected").val();
        blurdataInfo.needtranslation = jc("#needtranslation").is(':checked') ? 'Yes' : 'No';
        var ntivespkr = '';
        if(jc("#nativespkr-lbl").is(":visible")){
            ntivespkr = jc("#nativespkr").is(':checked') ? 'Yes' : 'No';
        }
        blurdataInfo.nativespkr      = ntivespkr;
        blurdataInfo.filedetails = uploadedFileDetailsArr.toString();
        $.ajax({
            url: update_quote,
            data: {
                fieldinfocommand: 'updatefieldinfo',
                sitename: sitename,
                savedata: blurdataInfo,
                async: false,
            },
            type: 'POST',
            success: function (data) {
                jc('#recordkey').val(data);
            }
        });
    }
    //on blur data capturing - end
jc(document).ready(function () {
    //jc(".capturedata").change(function () {
    jc(document).on('change','.capturedata', function(e) {
        var fieldid = jc(this).attr('id');
        var fieldval = jc(this).val();
        if(fieldid == "hours" || fieldid == "minutes"){
            fieldid = "prfilelength";
        }
        if(fieldid == 'general' || fieldid == 'legal'){
            fieldid = "catetype";
        }
        if(fieldid == 'qc1' || fieldid == 'qc0'){
            fieldid = "qcheck";
            fieldval = (jc(this).val() == 1)?"Yes":"No";
        }
        if(fieldid == 'ft1' || fieldid == 'ft0'){
            fieldid = "frtrial";
            fieldval = (jc(this).val() == 1)?"Yes":"No";
        }
        if(fieldid == 'fullverba' || fieldid == 'cleanverba'){
            fieldid = "qtvercrmpay";
            fieldval = (jc(this).val() == 1)?"Yes":"No";
        }
        blurdataInfo           = {};
        blurdataInfo.comments  = fieldval;
        blurdataInfo.fieldname = fieldid;
        paytc_updateFormInfo(blurdataInfo);
    });
});
var ajxurl = window.location.href;
jc.ajax({
    url: serverPath+'client.php',
    data: 'chennal='+channel_click+'&service=Transcription&version=V1.0&sitename='+originPath+'&ajxurl='+ajxurl,
    type: 'POST',
    success: function (data) {
        jc('#timespendingid').html(data);
    },
    error: function (data) {
        //alert(data);
    }
});
jc("#minutes,#hours").keyup(function(e){
    e.target.value = e.target.value.replace(/[^\d]/g,'');
    //return false;
});
jc( document ).on('click','#applycoupon', function(){
    var couponcode = jc("#couponcode").val();
    jc.ajax({
        url:update_quote,
        dataType: 'json',
        data: { coupon: couponcode },
        type: 'POST',
        success: function(data){
            if(data == 0){
                jc("#couponmsg").removeClass("text-success").addClass("text-danger").html("Invalid coupon code!");
            }else{
                jc("#couponmsg").removeClass("text-danger").addClass("text-success").html("Coupon code applied successfully");
                jc("#ofpct").html((data*100)+"%");
            }
            jc("#offerpct").val(data);
            paytc_pricequoteclac();
        }
    });
});


/*-------- FILE UPLOAD START ------------*/
var crmupload                      = true;
var sendBackData;
var partSize                       = 50 * 1024 * 1024; // constant
var totalSize;
var sureUploadSize                 = 0, probableUplaodSize = 0;
var numParts;
var partsLeft                      = [];
var file;
var cancelFlag                     = false;
var uploadFilesArr                 = [], uploadedFilesArr = [], uploadedFileDetailsArr = [], onblurdataarray = [];
var upItem                         = 0, j = 0, InitialVal = 0;
var checkUnprocessFlag             = false;
var checkUnprocessCompletePartFlag = false;
var checkUnprocesStartingPartFlag  = false;
var stageObj                       = {"/addfiles": 1, "/signin": 2, "/payment": 3, "booked": 4};
var currentStage                   = stageObj[window.location.pathname];
var awsUrl                         = 'https://s3-ap-southeast-1.amazonaws.com/';
var uploadProgress                 = false;
var filesUploadStatus              = [];
var HOSTNAME                       = 'http://' + window.location.host;
var COSTPERMIN                     = 1;
var VERBATIMCOST                   = 0.25;
var TIMESTAMPCOST                  = 0.25;
var serialno                       = 1;
var serverpath                     = crmRootpath + "lib/";
var uploadserver                   = serverpath + "server.php";
var vendorupload                   = false;

var awsUser = 'user';

function resetParam() {
    sendBackData;
    // partSize = 5 * 1024 * 1024; // constant
    totalSize;
    sureUploadSize = 0, probableUplaodSize = 0;
    numParts;
    partsLeft = [];
    file;
    cancelFlag = false;
}
function reorder() {
    var serialno = 1;
    jc('.serialno').each(function () {
        jc(this).text(serialno);
        serialno++;
    });
}
function addFiles() {
    jc('#file').val(null);
    var uploadfile = document.getElementById("file");
    uploadfile.click();  // here i can browse the file without clicking on file brows button
}
function updateInfo(Obj) {
    var lastserialno = jc(".serialno:last").text();
    if (lastserialno) {
        lastserialno++;
        var serialno = lastserialno;
    } else {
        var serialno = 1;
    }
    jc('#info').show();
    uploadFilename = Obj.name;
    addRow ='<div class="row striped row-'+upItem2+'">'+
    '<div class="col-xs-12 text-size-ne mo-position"> <span id="progpay-' + upItem2 + '" class="progress-upload ">'+
    '<input type="hidden" class="filePath" name="filePaths[]" value="" /><div class="awsupload-progress">'+
    '<div style="width:0%;" class="awsupload-progress-bar"></div>'+
    '<div class="awsupload-progress-text mo-awsupload-progress-text"></div>'+ '</div>'+
    '</span><div  class="audioLength text-center" id="inp-' + upItem2 + '" style="display:none;" >File Uploaded. </div></div>'+
        '<div class="col-xs-4 col-sm-4 col-lg-4 audioLengths ellipsisprgbar text-left text-size-ne" ><span data-file="'+Obj.name+'" data-modfy="'+Obj.modifyName+'" data-uploadid="" data-complete="0" id="removeFile-'+upItem2+'" class="up-close removeboth-'+upItem2+'" data-seerid="'+upItem2+'"  ><a href="javascript:void(0)"  data-placement="bottom" data-original-title="Remove file"> <i class="fa fa-trash-o" aria-hidden="true" style="font-weight:bold"></i></a></span>&nbsp;&nbsp;<span class="serialno">'+serialno+'</span>. '+Obj.name+'<input type="hidden" class="fileNamepay" value="'+Obj.modifyName+'#-#('+bytesToSize(Obj.size, 1).replace(".0", "") +')#-#'+Obj.type+'" id="uploadFiles-'+upItem2+'" data-durat="" name="uploadFiles[]" data-serid="'+upItem2+'" /></div>'+
        '<div class="col-xs-4 col-sm-4 col-lg-4 audioLengthpay text-size-ne text-center"><input type="text" data-ser="'+upItem2+'" maxlength="4" id="durationnewpay-'+upItem2+'" style="display:none;width:55px;text-align: center;float: left; margin: 0 0 0 18%;" class="length del-time onlynumbers text-center" placeholder="min" value="" onkeyup="paytc_pricequoteclac();paytc_paymentenable();"  name="length[]"> <span class="filetypes-'+upItem2+' hrdisplay" name="qfmsg" id="filetypespay'+upItem2+'" ></span></div> '+
        '<audio class="audio" id="audio-'+upItem2+'"></audio>'+
        '</div>';
    jc('#info').append(addRow);
    objectUrl = URL.createObjectURL(Obj);
    jc('#audio-' + upItem2).prop("src", objectUrl);

    var completedfilecnt = jc('.audioLength:visible').length;
    var totalfilecnt     = jc('.audioLength').length;
    jc('#completedfiletext').html("Uploaded " + completedfilecnt + "/" + totalfilecnt + " Files");
    serialno++;
}
function updateFinalInfo() {

    jc('#progpay-' + upItem).hide();
    jc('#inp-' + upItem).show();
    if (jc('#formtype').val() == "payment") {
        if (jc('[id^=audio-' + upItem + ']').length > 0) {
            var vid     = document.getElementById('audio-' + upItem);
            var seconds = vid.duration;
            var minutes = seconds / 60;
            var result  = Math.ceil(minutes);
            jc('#durationnewpay-' + upItem).delay(1100).fadeIn();

            if (result > 0 && result != 'NaN') {
                jc("#filetypespay" + upItem).show();
                jc("#filetypespay" + upItem).removeClass("errlength").addClass("hrdisplay");
                var durinhrs = hourconverter(result);
                jc("#filetypespay" + upItem).html(durinhrs);
                var precedres = pad(result, 2);
                precedres = (precedres == 0)?'':precedres;
                jc('#durationnewpay-' + upItem).val(precedres);
                jc('#uploadFiles-' + upItem).data("durat", result);
            } else {
                jc('#durationnewpay-' + upItem).val();
                jc('#uploadFiles-' + upItem).data("durat", 0);
                jc('.filetypes-' + upItem).delay(1100).fadeIn();
                jc("#filetypespay" + upItem).removeClass("hrdisplay").addClass("errlength");
                jc("#filetypespay" + upItem).html("Enter file length!");
            }
        }
    }

    jc('#removeFile-' + upItem).data('complete', 1);
    jc('#removeFile-' + upItem).css('visibility', 'visible');
    var completedfilecnt = jc('.audioLength:visible').length;
    var totalfilecnt     = jc('.audioLength').length;
    jc('#completedfiletext').html("Uploaded " + completedfilecnt + "/" + totalfilecnt + " Files");

    if (jc('#quoteflag').val() == 1) {
        $.ajax({
            url: update_quote,
            data: {
                command: 'updatefilecount',
                uploadflag: uploadProgress,
                completedfilecnt: completedfilecnt,
                //uploadedFile :uploadedFileName,
                ticketid: ticketID,
                quoteflag: jc('#quoteflag').val(),
                totalfilecnt: totalfilecnt,
            },
            type: 'POST'
        });
    }
    paytc_pricequoteclac();
    jc('#minutes').trigger('chamge');
    if(uploadedFilesArr != ''){
        jc('.filecomment').show();
        calcProductHeight();
    }
}
function updateUploadStatus() {
    var uploadFile       = filesUploadStatus[upItem]['file'];
    var uploadedFileName = uploadFile.modifyName;
    $.ajax({
        url: update_quote,
        data: {
            command: 'updateuploadstatus',
            uploadedFile: uploadedFileName,
        },
        type: 'POST'
    });
}
function updateProgressBar() {
    var progwidth = ((sureUploadSize + probableUplaodSize) / totalSize * 100).toFixed(1).replace(".0", "") + '%';
    var progtxt   = bytesToSize(sureUploadSize + probableUplaodSize, 1).replace(".0", "") + '/' + bytesToSize(totalSize, 1).replace(".0", "");
    jc('#progpay-' + upItem + ' .awsupload-progress .awsupload-progress-bar').css('width', progwidth);
    jc('#progpay-' + upItem + ' .awsupload-progress .awsupload-progress-text').html(progwidth);
    //jc('#progpay-' + upItem + ' .awsupload-progress .awsupload-progress-text').html(progtxt + ' - (' + progwidth + ')');

}
function resetProgressBar() {
    jc('#progress').attr('max', 0);
    jc('#progress').attr('value', 0);
}
function deletefile(filename, obj) {
    if (jc(obj).data('complete') == "0") {
        if (jc(obj).data('uploadid') != "") {
            cancel();
        }
        return;
    } else {
        $.ajax({
            url: uploadserver,
            data: {
                command: 'deletefile',
                Filename: filename
            }
        }).done(function (data) {
            jc("#minutes").trigger("keyup");
            //cancelFlag = true;
        });
    }


}
function completeMultipartUpload() {
    $.ajax({
        url: uploadserver,
        timeout: 5000,
        data: {
            command: 'CompleteMultipartUpload',
            sendBackData: sendBackData
        },
        beforeSend: function () {
            //console.log('before send');
        },
        error: function (event, request, settings, data) {
            var errorResponse = JSON.stringify(data);
            if (cancelFlag) {
                changeCancelFlag();
            } else {
                jc('#uploading_msg').hide();
                //jc('.upload_error, .upload_errmsg').show();
                jc('.upload_errmsg').show();
                showMessage('#my-welcome-message2');
                saveuploaderror(errorResponse);
                if (!checkUnprocessCompletePartFlag) {
                    checkUnprocessCompletePart();
                }
            }
        }, success: function () {
            if (checkUnprocessCompletePartFlag) {
                checkUnprocessCompletePartFlag = false;
                clearInterval(intervalfunc_complete);
                jc('.upload_error, .upload_errmsg ').hide();
                jc('#uploading_msg').show();
                if (jc('#quoteflagnew').val() == 0)
                    jc('#fvpp-blackout, #my-welcome-message2').hide();


            }
        }
    }).done(function (data, textStatus, jqXHR) {
        // console.log('==== CompleteMultipartUpload Final===='+ filesUploadStatus[upItem]['file'].name);
        resetProgressBar();
        resetParam();
        uploadedFilesArr.push(filesUploadStatus[upItem]['file'].name);

        var uploadFile = filesUploadStatus[upItem]['file'];
        uploadedFileDetailsArr.push(uploadFile.modifyName + '#-#(' + bytesToSize(uploadFile.size, 1).replace(".0", "") + ')#-#' + uploadFile.type);
        updateFinalInfo();
        if (jc('#quoteflag').val() == 1 || jc('#quoteflagnew').val() == 1) {
            updateUploadStatus();
        }
        blurdataInfo           = {};
        blurdataInfo.fieldname = "fileuploader";
        updateFormInfo(blurdataInfo);
        // Checking file exist or not to  upload
        if (++upItem in filesUploadStatus) {
            if (uploadFilesArr.length == uploadedFilesArr.length) {
                if (jc('#quoteflag').val() == 1 || jc('#quoteflagnew').val() == 1) {
                    //console.log("finalsubmit");
                    setTimeout(function () {
                        jc("#qsubmitcrm").trigger("click");
                    }, 5000);
                }
            }
            decideFileUpload();
        }
        else {
            uploadProgress = false;
            //Added by Rohini R on 20/12/2016 to disable submit in CRM File upload while upload in progress
            /*if (jc("#filesubmit").length) {
             jc("#filesubmit").removeAttr("disabled");
             }*/

            jc(".up").hide();
            jc('#minutes').trigger('change');
            if(uploadedFilesArr != ''){
                jc('.filecomment').show();
            }


            if (jc('#quoteflag').val() == 1 || jc('#quoteflagnew').val() == 1) {
                setTimeout(function () {
                    jc("#qsubmitcrm").trigger("click");
                }, 5000);
            }
            //jc( "#qsubmitcrm" ).trigger( "click" );
            //}


            //quotesubmitbtn(uploadProgress);
            // console.log("************* ALL Files uploaded successfully*************");
        }
    });


}
function uploadPart(partNum) {
    //alert('upload part'+ partNum);
    if (cancelFlag) {
        cancelFlag = false;
        resetProgressBar();
        resetParam();
        decideFileUpload();
        return;
    }
    if (partNum > numParts) {
        completeMultipartUpload();
        filesUploadStatus[upItem]['status'].upload_status = 'complete';
        return;
    }
    var start = (partNum - 1) * partSize;
    var end   = start + partSize;
    if (end > totalSize)
        end = totalSize;
    var length = end - start;

    // var curBlobPart = processingFile.slice(start, end);

    if (typeof processingFile.slice === 'function') {
        var curBlobPart = processingFile.slice(start, end);
    } else if (typeof processingFile.webkitSlice === 'function') {
        var curBlobPart = processingFile.webkitSlice(start, end);
    } else {
        console.log('unable to slice processingFile (slice /webkitSlice) ');
    }

    $.ajax({
        url: uploadserver,
        timeout: 5000,
        data: {
            command: 'SignUploadPart',
            partNumber: partNum,
            contentLength: length,
            sendBackData: sendBackData
        }, error: function (data) {
            if (cancelFlag) {
                changeCancelFlag();
            } else {
                jc('#uploading_msg').hide();
                // jc('.upload_error, .upload_errmsg').show();
                jc('.upload_errmsg').show();
                showMessage('#my-welcome-message2');
                data.partNumber   = partNum;
                var errorResponse = JSON.stringify(data);
                saveuploaderror(errorResponse);
                if (!checkUnprocessFlag)
                    checkUnprocessData(partNum);
                return;
            }
        }, success: function () {
            if (checkUnprocessFlag) {
                checkUnprocessFlag = false;
                clearInterval(intervalfunc);
                jc('.upload_error, .upload_errmsg').hide();
                jc('#uploading_msg').show();
                if (jc('#quoteflagnew').val() == 0)
                    jc('#fvpp-blackout, #my-welcome-message2').hide();
            }
        }
    }).done(function (data, textStatus, jqXHR) {
        //console.log('==== SignUploadPart ====');
        var url = data['url'];

        // updating uploaded file path.
        jc('#prog-' + upItem + ' .filePath').val(getAwsLocation(url));
        var authHeader = data['authHeader'];
        var dateHeader = data['dateHeader'];
        var request    = new XMLHttpRequest();
        request.open('PUT', url, true);
        request.contentLength = length;

        request.onreadystatechange = function () {
            // console.log("++++++ onreadystatechange ++++++");
            // console.log(request.status);
            // console.log(request);

            if (request.readyState === 4) {
                if (request.status === 200) {
                    filesUploadStatus[upItem]['status'].upload_status = 'process';
                    if (checkUnprocessFlag) {

                        checkUnprocessFlag = false;
                        clearInterval(intervalfunc);
                        jc('#uploading_msg').show();
                        jc('.upload_error, .upload_errmsg').hide();
                        if (jc('#quoteflagnew').val() == 0)
                            jc('#fvpp-blackout, #my-welcome-message2').hide();
                    }
                    probableUplaodSize = 0;
                    sureUploadSize += request.contentLength;
                    updateProgressBar();
                    uploadPart(partNum + 1);
                } else {
                    if (cancelFlag) {
                        changeCancelFlag();
                    } else {
                        console.log('Request status Error');
                        jc('#uploading_msg').hide();
                        // jc('.upload_error, .upload_errmsg').show();
                        jc('.upload_errmsg').show();
                        showMessage('#my-welcome-message2');
                        var errorResponse = JSON.stringify(data);
                        saveuploaderror(errorResponse);

                        filesUploadStatus[upItem]['status'].upload_status = 'error';
                        if (!checkUnprocessFlag)
                            checkUnprocessData(partNum);
                        return;
                    }
                }
            }
        };
        request.upload.onprogress  = function (e) {
            //console.log("++++++ upload.onprogress ++++++" + request.status);
            if (e.lengthComputable) {
                probableUplaodSize = e.loaded;
                updateProgressBar();
            }
        };
        request.setRequestHeader("x-amz-date", dateHeader);
        request.setRequestHeader("Authorization", authHeader);
        //request.setRequestHeader("Content-Length", length);
        request.send(curBlobPart);

    });
}
function startPartitionAndUpload() {
    updateProgressBar();
    numParts = Math.ceil(totalSize / partSize);
    uploadPart(1);
}
function cancel() {
    $.ajax({
        url: uploadserver,
        data: {
            command: 'AbortMultipartUpload',
            sendBackData: sendBackData
        }
    }).done(function (data) {
        cancelFlag = true;
        console.log('upload cancelled');

    });
}
function upload() {
    var url = window.location.href;
    var re  = /\/upload\?type=delivery/g;
    if (re.test(url)) {
        var vendorupload = true;
    }

    if (window.File && window.FileReader && window.FileList && window.Blob && window.Blob.prototype.slice) {
        for (i = 0; i < jc('#file')[0].files.length; i++, InitialVal++) {
            fileObj = jc('#file')[0].files[i];

            //  console.log(i+"<=i######## step 1##########>InitialVal"+InitialVal);
            exist_file_name = jc('#exist_file_name').val();
            if (vendorupload && typeof exist_file_name !== 'undefined') {
                // variable is undefined
                var upd_file_name   = fileObj.name.substr(0, fileObj.name.lastIndexOf('.'));
                var exist_file_name = exist_file_name.substr(0, exist_file_name.lastIndexOf('.'));
                if (exist_file_name != upd_file_name) {
                    alert('Uploading filename should be same.');
                    location.reload();
                    jc('#uploadbuttoncls').hide();
                    InitialVal--;
                    continue;
                }
            }

            // already file in the list

            var filetype        = fileObj.type;
            var filtype         = filetype.split("/");
            //var sourcefiletype3 = jc("#sourcefiletype option:selected").val();
            //console.log(filtype[0] + '-' + sourcefiletype3);
            if ((filtype[0] != "audio") && (filtype[0] != "video"))
            {
                sweetAlert("Sorry...", "Please upload audio,video files only.", "error");
                InitialVal--;
                continue;
            }else if (uploadFilesArr.indexOf(fileObj.name) != -1)
            {
                alert('Already ' + fileObj.name + ' uploaded...');
                InitialVal--;
                continue;
            } else {

                //   console.log(i+"<=i######## step 2 else block ##########>InitialVal"+InitialVal);

                uploadFilesArr.push(fileObj.name);

                originalFile         = fileObj.name;
                var replacedFilename = originalFile.replace(/[^A-Za-z0-9\_\-\.]/g, '');
                if (replacedFilename.substring(0, replacedFilename.lastIndexOf('.')) == '') {
                    var ext          = replacedFilename.split('.').pop().toLowerCase();
                    replacedFilename = 'file_' + Math.floor(Math.random() * 90000) + '.' + ext;
                }
                if (jc("#bucketcode").length) {
                    var bucketcd  = jc('#bucketcode').val();
                    var bucketkey = bucketcd;
                } else {
                    var bucketkey = 'xx';
                }
                fileObj.modifyName                      = folderPath + makeid(6) + bucketkey + "_" + replacedFilename;
                //  console.log(i+"<=i######## step 3 before filesUploadStatus##########>InitialVal"+InitialVal);
                filesUploadStatus[InitialVal]           = {};
                filesUploadStatus[InitialVal]['file']   = fileObj;
                filesUploadStatus[InitialVal]['status'] = {
                    upload_status: 'start',
                    item_no: InitialVal,
                    file_name: fileObj.modifyName,
                    file_size: bytesToSize(fileObj.size, 1).replace(".0", ""),
                    file_type: fileObj.type
                };

                // console.log(i+"<=i######## step 3 after filesUploadStatus##########>InitialVal"+InitialVal);
                upItem2 = InitialVal;

                updateInfo(fileObj);
                if (uploadProgress == false) {
                    uploadProgress = true;
                    //Added by Rohini R on 20/12/2016 to disable submit in CRM File upload while upload in progress
                    /*if (jc("#filesubmit").length) {
                     jc('#filesubmit').attr('disabled', 'disabled');
                     }*/

                    jc(".up").show();
                    jc(".pt,.qt").hide();
                    //jc('#minutes').trigger('change');
                    // quotesubmitbtn(uploadProgress);
                    uploadFile(filesUploadStatus[upItem]['file']);
                }
            }

        }//for loop
    } else {
        alert('The File APIs are not fully supported in this browser.');
    }
    //jc('[data-toggle="tooltip"]').tooltip();

}
function uploadFile(uploadFile) {
    console.log('Upload file...');
    uploadProgress = true;
    //quotesubmitbtn(uploadProgress);
    processingFile = uploadFile;
    totalSize      = uploadFile.size;
    $.ajax({
        url: uploadserver,
        timeout: 5000,
        data: {
            command: 'CreateMultipartUpload',
            fileInfo: {
                name: uploadFile.modifyName,
                type: uploadFile.type,
                size: uploadFile.size,
                lastModifiedDate: uploadFile.lastModifiedDate
            },
            otherInfo: {
                user: awsUser,
                pass: 'pass'
            }
        }, beforeSend: function () {
            // console.log('before start ');
        }, error: function (data) {
            if (cancelFlag) {
                changeCancelFlag();
            } else {
                jc('#uploading_msg').hide();
                // jc('.upload_error, .upload_errmsg').show();
                jc('.upload_errmsg').show();
                showMessage('#my-welcome-message2');
                var errorResponse = JSON.stringify(data);
                saveuploaderror(errorResponse);
                if (!checkUnprocesStartingPartFlag) {
                    checkUnprocesStartingPart(uploadFile);
                }
            }
        }, success: function () {
            if (checkUnprocesStartingPartFlag) {
                checkUnprocesStartingPartFlag = false;
                clearInterval(intervalfunc_start);
                jc('.upload_error, .upload_errmsg').hide();
                jc('#uploading_msg').show();
                if (jc('#quoteflagnew').val() == 0)
                    jc('#fvpp-blackout, #my-welcome-message2').hide();
            }
        }
    }).done(function (data, textStatus, jqXHR) {
        // console.log('==== CreateMultipartUpload ===='+upItem+"==>"+data.uploadId);
        jc('#removeFile-' + upItem).data('uploadid', data.uploadId);
        sendBackData = data;
        startPartitionAndUpload();
    });
}
function decideFileUpload() {
    // console.log('decideFileUpload ====> ');
    for (i = upItem; i < filesUploadStatus.length; i++) {
        if (uploadFilesArr.indexOf(filesUploadStatus[upItem]['file']['name']) >= 0) {
            uploadFile(filesUploadStatus[upItem]['file']);
            return;
        }
        else upItem = upItem + 1;
    }

    uploadProgress = false;
    //Added by Rohini R on 20/12/2016 to disable submit in CRM File upload while upload in progress
    /* if (jc("#filesubmit").length) {
     jc("#filesubmit").removeAttr("disabled");
     }*/

    jc(".up").hide();
    jc('#minutes').trigger('change');
    if(uploadedFilesArr != ''){
        jc('.filecomment').show();
    }
    //quotesubmitbtn(uploadProgress);
    //console.log("************* ALL Files uploaded successfully*************");
}
function bytesToSize(bytes, precision) {
    var kilobyte = 1024;
    var megabyte = kilobyte * 1024;
    var gigabyte = megabyte * 1024;
    var terabyte = gigabyte * 1024;

    if ((bytes >= 0) && (bytes < kilobyte)) {
        return bytes + ' B';

    } else if ((bytes >= kilobyte) && (bytes < megabyte)) {
        return (bytes / kilobyte).toFixed(precision) + ' KB';
    } else if ((bytes >= megabyte) && (bytes < gigabyte)) {
        return (bytes / megabyte).toFixed(precision) + ' MB';

    } else if ((bytes >= gigabyte) && (bytes < terabyte)) {
        return (bytes / gigabyte).toFixed(precision) + ' GB';
    } else if (bytes >= terabyte) {
        return (bytes / terabyte).toFixed(precision) + ' TB';
    } else {
        return bytes + ' B';
    }
}
function getAwsLocation(href) {
    var l   = document.createElement("a");
    l.href  = href;
    var str = l.hostname;
    str.indexOf(".");
    var s3Bucket = str.substr(0, str.indexOf("."));
    return awsUrl + s3Bucket + l.pathname;
}
//on blur data capturing - start
function updateFormInfo(blurdataInfo) {
    var fieldname  = blurdataInfo.fieldname;
    var fieldlabel = jc('label[for="' + fieldname + '"]').text();
    var fieldlabel = fieldlabel.trim();
    var fieldvalue = jc('#' + fieldname).val();
    var fieldtype  = jc('#' + fieldname).attr('type');
    if (fieldtype == 'checkbox') {
        if (jc('#' + fieldname).is(':checked')) {
            fieldvalue = 'Yes';
        } else {
            fieldvalue = 'No';
        }
    }
    if (fieldlabel) {
        if ((fieldlabel == 'Translate To' || fieldlabel == 'Target Language' || fieldlabel == 'Language') && fieldvalue) {
            fieldvalue = fieldvalue.toString().replace(/,/g, '-');
        }
        if (fieldlabel == 'How Long is Your Video?' && fieldvalue) {
            fieldvalue = fieldvalue.toString().replace(/:/g, '-');
        }
        onblurdataarray.push(fieldlabel + ':' + fieldvalue);
    } else {
        if (fieldname == 'qmailmsgcrm')
            fieldname = 'mail comment';
        onblurdataarray.push(fieldname + ':' + fieldvalue);
    }
    if (jc('#qsourcecrm').val())
        onblurdataarray.push('Translate From' + ':' + jc('#qsourcecrm').val());
    else if (jc('#qsourcevoicecrm').val())
        onblurdataarray.push('Translate From' + ':' + jc('#qsourcevoicecrm').val());
    else if (jc('#language').val() && jc('#channel_id').val() == 7)
        onblurdataarray.push('language' + ':' + jc('#language').val());

    blurdataInfo.qname       = jc('#qnamecrm').val();
    blurdataInfo.qemail      = jc('#qemailcrm').val();
    blurdataInfo.qcountrys   = jc('#qcountryscrm').val();
    blurdataInfo.acode       = jc('#acodecrm').val();
    blurdataInfo.qphone      = jc('#qphonecrm').val();
    blurdataInfo.entryval    = jc('#recordkey').val();
    blurdataInfo.serviceid   = jc('#serviceid').val();
    blurdataInfo.channel_id  = jc('#channel_id').val();
    blurdataInfo.filedetails = uploadedFileDetailsArr.toString();
    blurdataInfo.fieldname1  = onblurdataarray.toString();
    if (jc('#recordkey').val()) {
        var id = '';
    } else {
        var id = new Date().getTime();
        jc('#recordkey').val(id);
    }
    blurdataInfo.id = id;
    if (jc('#qemailcrm').val()) {
        $.ajax({
            url: crmFormsavepath + 'save/crmformdata',
            data: {
                command: 'updatefieldinfo',
                sitename: sitename,
                savedata: blurdataInfo,
                async: false,
            },
            type: 'POST',
            success: function (data) {
                jc('#recordkey').val(data.trim());
            }
        });
    }
}
var etat = '';
//on blur data capturing - end
jc(document).ready(function () {
    getUploadPartSize();
    //on blur data capturing - start

    if (jc('#channel_id').val() == 7) {
        var formid = jc('#quick_servicetype').val();
    }
    else {
        var formid = jc('#formid').val();
    }
    jc('#' + formid + " :input").each(function () {
        var input = jc(this).attr("id"); // This is the jquery object of the input, do what you will

        if (input == 'qtargetcrm')
            var j = jc('#' + input);
        else if (input == 'expected_turnaround')
            var j = jc('.datetimepicker');
        else
            var j = jc('#' + input);

        j.on('change blur', function (e) {
            var email = jc('#qemailcrm').val();
            var reg   = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
            if (reg.test(email) == true) {
                blurdataInfo           = {};
                blurdataInfo.comments  = jc(this).val();
                blurdataInfo.fieldname = jc(this).attr('id');
                if (input == 'expected_turnaround')
                    setTimeout(function () {
                        var etat                         = jc('#expected_turnaround').val();
                        blurdataInfo.expected_turnaround = etat;
                        updateFormInfo(blurdataInfo);
                    }, 100);
                else if (input != 'file')
                    updateFormInfo(blurdataInfo);

            }

        });
    });

//    } else {
//            jc("#qemailcrm,#qcountryscrm,#acodecrm,#qphonecrm,#qnamecrm").blur(function () {
//                var email = jc('#qemailcrm').val();
//                var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
//                if (reg.test(email) == true)
//                {
//                    blurdataInfo = {};
//                    blurdataInfo.comments = jc(this).val();
//                    blurdataInfo.fieldname = jc(this).attr('id');
//                    updateFormInfo(blurdataInfo);
//                }
//            });
//        }
    //on blur data capturing - end
});
jc(document).on('click', '.up-close', function () {
    uploadId    = jc(this).data('uploadid');
    var remFile = jc(this).data('file');
    deletefile(remFile,this);
    uploadFilesArr.splice(uploadFilesArr.indexOf(remFile), 1);
    uploadedFilesArr.splice(uploadedFilesArr.indexOf(remFile), 1);

    if (uploadedFileDetailsArr.length > 0) {
        for (i = 0; i < uploadedFileDetailsArr.length; i++) {
            var uploadedarrfilename  = uploadedFileDetailsArr[i].split("#-#");
            var uploadedarrfilename1 = uploadedarrfilename[0].substring(uploadedarrfilename[0].indexOf("_") + 1);
            if (uploadedarrfilename1 == remFile.replace(/[^A-Za-z0-9\_\-\.]/g, '')) {
                uploadedFileDetailsArr.splice(uploadedFileDetailsArr.indexOf(uploadedFileDetailsArr[i]), 1);
                blurdataInfo           = {};
                blurdataInfo.fieldname = "fileuploader";
                updateFormInfo(blurdataInfo);
            }
        }
    }

    jc(this).parent().parent().remove();
    if (!uploadFilesArr.length)
        jc('#info').hide();
    reorder();
    if(uploadedFilesArr == ''){
        jc('.filecomment').hide();
    }
    calcProductHeight();
});
function quotesubmitbtn(upProgress) {
    if (upProgress) {
        jc('.progressbtn').show();
        jc('.quotebtn').hide();
    } else {
        jc('.progressbtn').hide();
        jc('.quotebtn').show();
    }
    jc('#uploadprogress').val(upProgress);
}
function makeid(Strlen) {
    var text     = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    for (var i = 0; i < Strlen; i++)
        text += possible.charAt(Math.floor(Math.random() * possible.length));
    return text;
}
function checkUnprocessData(partNum) {
    console.log('checkUnprocessData : ' + partNum);
    checkUnprocessFlag = true;
    var counter        = 0;
    intervalfunc       = setInterval(function () {
        counter++;
        uploadPart(partNum);
        if (counter >= 20) {
            clearInterval(intervalfunc);
        }
    }, 10000);
}
function getUploadPartSize() {
    $.getJSON('//freegeoip.net/json/?callback=?', function (data) {
        var country_code = data.country_code;
        switch (country_code) {
            case "IN":
                partSize = 5 * 1024 * 1024;
                break;
            case "US":
                partSize = 50 * 1024 * 1024;
                break;
            case "GB":
            case "AU":
            case "UK":
                partSize = 20 * 1024 * 1024;
                break;
            default :
                partSize = 50 * 1024 * 1024;
                break;
        }
    });

}
function showMessage(id) {
    var $body   = jc('body');
    var $dialog = jc(id);
    $body.append('<div id="fvpp-blackout"></div>');
    $dialog.append('');
    $blackout = jc('#fvpp-blackout');
    var $blackout;
    $blackout.show();
    jc("#fvpp-close").css({'display': "none"});
    $dialog.show();
    jc(".DS-sidefixed-nav").css({'display': "none"});

}
function checkUnprocessCompletePart() {
    checkUnprocessCompletePartFlag = true;
    var counter                    = 0;
    intervalfunc_complete          = setInterval(function () {
        counter++;
        completeMultipartUpload();
        if (counter >= 20) {
            clearInterval(intervalfunc_complete);
        }
    }, 10000);
}
function checkUnprocesStartingPart(uploadFiles) {
    checkUnprocesStartingPartFlag = true;
    var counter                   = 0;
    intervalfunc_start            = setInterval(function () {
        counter++;
        uploadFile(uploadFiles);
        if (counter >= 20) {
            clearInterval(intervalfunc_start);
        }
    }, 10000);
}
function saveuploaderror(errorResponse) {
    dataInfo                 = {};
    var networkerrormailsent = 0;
    dataInfo.qname           = jc('#qnamecrm').val();
    if (jc('#qemailcrm').length) {
        dataInfo.qemail = jc('#qemailcrm').val();
    } else {
        dataInfo.qemail = jc('#sample_email').val();
    }
    dataInfo.entryval            = jc('#recordkey').val();
    dataInfo.networkerrflag      = jc('#networkerrflag').val();
    dataInfo.serviceid           = jc('#serviceid').val();
    dataInfo.crmpage             = jc('#crmpage').val();
    dataInfo.filedetails         = JSON.stringify(uploadFilesArr);
    dataInfo.fileuploadstatus    = JSON.stringify(filesUploadStatus);
    dataInfo.uploadprogress      = uploadProgress;
    dataInfo.uploaderrorresponse = errorResponse;
    dataInfo.uploadedfiledetails = JSON.stringify(uploadedFileDetailsArr);
    if ((jc('#qemailcrm').val() || jc('#sample_email').val()) && jc('#networkerrflag').val() == 0) {
        $.ajax({
            url: crmFormsavepath + 'save/crmformdata',
            data: {
                command: 'networkerror',
                networkerrordata: dataInfo,
                sitename: sitename,
                async: false,
            },
            type: 'POST',
            success: function (data) {
                jc('#networkerrflag').val(data);
            }
        });
    }
}
function changeCancelFlag() {
    uploadProgress = false;
    resetProgressBar();
    resetParam();
    updateFinalInfo();
    decideFileUpload();
}
function hourconverter(durminutes) {
    var hours   = Math.floor(durminutes / 60);
    var minutes = durminutes % 60;
    hours       = pad(hours, 2);
    minutes     = pad(minutes, 2);
    return duhrs = "(" + hours + ":" + minutes + ")";
    //jc('.convertedHour').html(hours);
    //jc('.convertedMin').html(minutes);
}
function pad(str, max) {
    str = str.toString();
    return str.length < max ? pad("0" + str, max) : str;
}
function paytc_paymentenable() {
    var durationcheck = [];
    jc(".length").each(function () {
        var  i = jc(this).attr("data-ser");
        var dur = parseInt(jc('#durationnewpay-' + i).val());
        if (isNaN(dur) || dur == '' || dur < 1) {
            jc("#filetypespay" + i).show();
            jc("#filetypespay" + i).removeClass("hrdisplay").addClass("errlength");
            jc("#filetypespay" + i).html("Enter file length!");
            jc('#durationnewpay-' + i).val();
            dur = '00';
        } else {
            jc("#filetypespay" + i).show();
            jc("#filetypespay" + i).removeClass("errlength").addClass("hrdisplay");
            var durinhrs = hourconverter(dur);
            jc("#filetypespay" + i).html(durinhrs);
        }
        jc('#durationnew-' + i).val(dur);
        durationcheck.push(dur);
        paytc_pricequoteclac();
    });
}
/*-------- FILE UPLOAD END ------------*/

// Samples files view popup
jc('#view_sample').click(function(){
    if(jc('#qttcodecrm option:selected').val() != '' && jc('#qttcodecrm option:selected').val() != '0'){
        jc("#modal-body-sample").attr("align", "left").load(serverPath+"lib/transcription_samples/timestamped.php")
    }else if(jc('#fullverba').is(":checked")){
        jc("#modal-body-sample").attr("align", "left").load(serverPath+"lib/transcription_samples/verbtaim_transcription.php")
    }else{
        jc("#modal-body-sample").attr("align", "left").load(serverPath+"lib/transcription_samples/clean_verbtaim.php")
    }
    jc("#sample_modal").modal("show");
});

// For place holder hide and show onfocus
jc('input,textarea').focus(function(){
    jc(this).data('placeholder',jc(this).attr('placeholder'))
          .attr('placeholder','');
}).blur(function(){
    jc(this).attr('placeholder',jc(this).data('placeholder'));
});
