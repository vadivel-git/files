
jQuery.fn.highlight = function (pat) {
    function innerHighlight(node, pat) {
        var skip = 0;
        if (node.nodeType == 3) {
            var pos = node.data.toUpperCase().indexOf(pat);
            if (pos >= 0) {
                var spannode = document.createElement('span');
                spannode.className = 'highlight';
                var middlebit = node.splitText(pos);
                var endbit = middlebit.splitText(pat.length);
                var middleclone = middlebit.cloneNode(true);
                spannode.appendChild(middleclone);
                middlebit.parentNode.replaceChild(spannode, middlebit);
                skip = 1;
            }
        } else if (node.nodeType == 1 && node.childNodes && !/(script|style)/i.test(node.tagName)) {
            for (var i = 0; i < node.childNodes.length; ++i) {
                i += innerHighlight(node.childNodes[i], pat);
            }
        }
        return skip;
    }
    return this.length && pat && pat.length ? this.each(function () {
        innerHighlight(this, pat.toUpperCase());
    }) : this;
};
jQuery.fn.removeHighlight = function () {
    return this.find("span.highlight").each(function () {
        this.parentNode.firstChild.nodeName;
        with(this.parentNode) {
            replaceChild(this.firstChild, this);
            normalize();
        }
    }).end();
};
/* end plugin */

var $finder = $('#text-finder, .input-group'),
    $field = $finder.children().last(),
    $clear = $field.next(),
    $area = $('.inner-list'),
    $viewport = $('html, body');

$field.on("keyup", function () {

 if($(this).val())
 {
    $area.removeHighlight().highlight(this.value); // Highlight text inside `$area` on keyup
    $viewport.scrollTop($area.find('span.highlight').first().offset().top - 300); // Jump the viewport to the first highlighted term
    $('.text-finder').css( "position", "fixed" );

   $(window).scroll(function(){
  var sticky = $('.text-finder'),
      scroll = $(window).scrollTop();

  if (scroll <= 100) sticky.addClass('fixed');
  else sticky.removeClass('fixed');
});

 }

 else


 { 
      $('.text-finder').css( "position", "static" );
 $area.removeHighlight().highlight(this.value); // Highlight text inside `$area` on keyup
    $viewport.scrollTop($area.find('span.highlight').first().offset().top - 300); // Jump the viewport to the first highlighted term



 }

});

$field.on("keydown", function () {

var text = $("#search-text").val().focus();
if(text == "") {
            $('.text-finder').css( "position", "static" );
        } 
  
 var scrollPos =  $("#text-finder").offset().top;
 $(window).scrollTop(scrollPos);

});


$clear.on("click", function () {
    $area.removeHighlight(); // Remove all highlight inside `$area`
    $field.val('').trigger("focus"); // Clear the search field
    $viewport.scrollTop(0); // Jump the viewport to the top
    return false;
});
