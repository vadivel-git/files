jc( document ).on('focus focusin','#pagecount', function() {
    jc("#pagecount").trigger("mouseenter");
});
jc( document ).on('mouseenter','#pagecount', function() {
    jc('#pagecount').tooltip();

});
jc( document ).on('blur','#pagecount', function() {
    jc('#pagecount').tooltip('destroy');
});
/*show file length or page count based on file type start*/
jc( document ).on('change','#sourcefiletype', function() {
    var sourcefiletype = jc(this).val();
    if (sourcefiletype == 'Document'){
        jc('#prfilelength').val('');
        jc('.media-blk').hide();
        jc('.doc-blk').show();
    }else{
        jc('#pagecount').val('');
        jc('.media-blk').show();
        jc('.doc-blk').hide();
    }
});
/*show file length or page count based on file type end*/
/* TAT calculation start */
jc(document).on('change blur keyup keypress focus', '.del-time', function () {
    var pagecount      = (!isNaN(parseInt(jc('#pagecount').val()))) ? parseInt(jc('#pagecount').val()) : 0;
    var formatting     = jc("#formatting option:selected").val();
    var srclang        = jc("#srclang option:selected").val();
    var sourcefiletype = jc("#sourcefiletype option:selected").val();

    if ((pagecount > 0)
        && (formatting != "Handwritten" && formatting != "")
        && (sourcefiletype == "Document")
        && (jc.inArray(srclang, allowedlang) !== -1)
    ) {
        var std_delivery_time = '';
        var std_delivery      = pagecount / 1;
        var pagecount1        = 0 ;


        if (pagecount >= 1 && pagecount <= 3) {
            std_delivery_time = "1 business day";
        } else if (pagecount >= 4 && pagecount <= 5) {
            std_delivery_time = "1 to 2 business days";
        } else if (pagecount >= 6 && pagecount <= 20) {
            std_delivery_time = "2 to 3 business days";
        } else if (pagecount >= 21 && pagecount <= 50) {
            std_delivery_time = "5 to 6 business days";
        } else if (pagecount >= 51 && pagecount <= 80) {
            std_delivery_time = "8 to 9 business days";
        } else if (pagecount >= 81 && pagecount <= 100) {
            std_delivery_time = "10 to 12 business days";
        } else{
            var startday   = 11;
            pagecount1     = pagecount - 100;
            var reminder   = Math.ceil(pagecount1/20);
            var tottaldays = parseInt(startday) + parseFloat(reminder*2);
            var std_delivery_time = tottaldays+' to '+(tottaldays+1)+" business days";

        }


        //     if (pagecount >= 10 && pagecount <= 15) {
        //     std_delivery_time = "8 to 10 business days";
        // } else if (pagecount >= 16 && pagecount <= 20) {
        //     std_delivery_time = "10 to 12 business days";
        // }

        jc("#tat-val").html(std_delivery_time);
        jc("#delivery-timeline").show();
    } else {
        jc("#delivery-timeline").hide();
    }
    if (srclang != "English") {
        jc("#native-spkr").hide();
        jc('#nativecrmpay').prop('checked', false);
        jc('.onlyeng').hide();
    } else {
        jc("#native-spkr").show();
        jc('.onlyeng').show();
    }
});
/* TAT calculation end */

jc(document).on('click', '#validate-quote,.payment-nav-pills #tabid2,.payment-nav-pills #tabid3,#wizshow3,#wizshow2', function () {

    var pagecount   = (!isNaN(parseInt(jc('#pagecount').val()))) ? parseInt(jc('#pagecount').val()) : 0;
    var formatting  = jc("#formatting option:selected").val();
    var srclang     = jc("#srclang option:selected").val();
    var deliveryReq = jc('input[name=deliveryReq]:checked', '#translationForm').val();
    var next_step   = true;
    var prfilelength = jc('#prfilelength').val();
    var mailcountry    = jc("#mailcountry option:selected").val();
    var mailcountrycrm = jc("#mailcountrycrm option:selected").val();
    var mailaddresspay = jc("#mailaddresspay").val();
    var mailaddresscrm = jc("#mailaddresscrm").val();
    var sourcefiletype = jc("#sourcefiletype option:selected").val();

    if(mailcountry){
        jc( "#mailcountry").val(mailcountry);
        jc( "#mailcountrycrm").val(mailcountry);
    }else if(mailcountrycrm){
        jc( "#mailcountry").val(mailcountrycrm);
        jc( "#mailcountrycrm").val(mailcountrycrm);
    }
    if(mailaddresspay){
        jc( "#mailaddresspay").val(mailaddresspay);
        jc( "#mailaddresscrm").val(mailaddresspay);
    }else if(mailaddresscrm){
        jc( "#mailaddresspay").val(mailaddresscrm);
        jc( "#mailaddresscrm").val(mailaddresscrm);
    }

    if(!sourcefiletype){
        jc('#sourcefiletype').tooltip({title: "File type is required !"});
        jc('#sourcefiletype').focus();
        jc('#sourcefiletype').change(function() {
            jc('#sourcefiletype').tooltip('destroy');
        });
        next_step = false;
        return false;
    }
    else{
        next_step = true;
    }
    if(sourcefiletype == 'Document') {
        if (pagecount == "" || pagecount == null || isNaN(pagecount) || pagecount <= '0') {
            jc('#pagecount').tooltip({title: "Page count is required !"});
            jc('#pagecount').focus();
            jc('#pagecount').keypress(function () {
                jc('#pagecount').tooltip('destroy');
            });
            next_step = false;
            return false;
        } else {
            next_step = true;
        }
    }
    else{
        if (prfilelength == "" || prfilelength == null || isNaN(prfilelength) || prfilelength <= '0') {
            jc('#prfilelength').tooltip({title: "File Length is required !"});
            jc('#prfilelength').focus();
            jc('#prfilelength').keypress(function () {
                jc('#prfilelength').tooltip('destroy');
            });
            next_step = false;
            return false;
        } else {
            next_step = true;
        }
    }

    if (!srclang) {
        jc('#srclang').tooltip({title: "language is required !"});
        jc('#srclang').focus();
        jc('#srclang').change(function () {
            jc('#srclang').tooltip('destroy');
        });
        next_step = false;
        return false;
    }
    else {
        next_step = true;
    }
    if (!formatting && sourcefiletype == 'Document') {
        jc('#formatting').tooltip({title: "formatting is required !"});
        jc('#formatting').focus();
        jc('#formatting').change(function () {
            jc('#formatting').tooltip('destroy');
        });
        next_step = false;
        return false;
    }
    else {
        next_step = true;
    }

    if (next_step) {
        if ((pagecount > 0)
            && (sourcefiletype == 'Document')
            && (formatting != "Handwritten")
            && (jc.inArray(srclang, allowedlang) !== -1)
            && (deliveryReq == "option1")
        ) {
            jc(".paychart").hide();
            jc("#pay_chart").slideUp("fast");

            var filesclr = jc('#uploadat').val();
            if (filesclr != 'fileuploadpay') {
                jc('#uploadat').val('fileuploadpay');
            }
            jc('.docfile').show();
            jc('.audvid').hide();
            availOpstopay();

            if (uploadFilesArr != '') {
                jc("#info_payment").show();
                jc('.skip-files').hide();
                jc('#skipfiles').prop('checked', false);
            }
            jc('.wiz2').hide();
            jc('.wiz3').show();

            paytc_pricequoteclac();
            paytc_paymentenable();

            jc('.payment-nav-pills #tabid2').parent('li').hide();
            jc('.payment-nav-pills #tabid3').parent('li').show();
            jc('.payment-nav-pills #tabid3').attr('href', '#tab3');
            jc('.payment-nav-pills #tabid3').parent('li').removeClass('disabled');
            jc('.payment-nav-pills a[href="#tab3"]').tab('show');
            jc('html, body').animate({'scrollTop': jc("#page-top").position().top}, 'fast');

        } else {
            jc(".paychart").hide();
            jc("#pay_chart").slideUp("fast");
            jc('.payment-nav-pills #tabid1').attr('href', '#tab1');
            jc('.payment-nav-pills #tabid2').attr('href', '#tab2');
            jc('.payment-nav-pills #tabid3').parent('li').hide();
            jc('.payment-nav-pills #tabid2').parent('li').show();
            jc('.payment-nav-pills #tabid2').parent('li').removeClass('disabled');
            var filesclr = jc('#uploadat').val();
            if (filesclr != 'fileupload') {
                jc('#uploadat').val('fileupload');
            }

            if (uploadFilesArr != '') {
                jc("#info").show();
            }
            jc('.wiz3').hide();
            jc('.wiz2').show();
            if (jc("#srclang").val() != "English") {
                jc("#native-spkr").hide();
                jc('#nativecrmpay').prop('checked', false);
                jc('.onlyeng').hide();
            } else {
                jc("#native-spkr").show();
                jc('.onlyeng').show();
            }

            jc('.docfile').show();
            jc('.audvid').hide();
            availOpstofile();

            jc('.payment-nav-pills a[href="#tab2"]').tab('show');
            jc('html, body').animate({'scrollTop': jc("#page-top").position().top}, 'fast');
        }
    }
});

jc(document).on('click', '.payment-nav-pills #tabid4', function () {

    if (jc('#uploadat').val() == 'fileupload') {
        if (jc('.payment-nav-pills #tabid2').parent('li').hasClass('disabled') && jc('.payment-nav-pills #tabid3').parent('li').hasClass('disabled')) {
            return false;
        } else {
            jc("#upload-files").trigger("click");
        }
    } else {
        jc("#contact-details").trigger("click");
    }

});

jc(document).on('click', '#upload-files', function () {
    jc(".paychart").hide();
    jc("#pay_chart").slideUp("fast");
    jc('.payment-nav-pills #tabid4').attr('href', '#tab4');
    jc('.payment-nav-pills #tabid4').parent('li').removeClass('disabled');

    jc('.wiz3').hide();
    jc('.wiz2').show();
    var mailfilecrm = jc('#mailfilecrm').is(':checked');
    if (mailfilecrm) {
        jc('.mailingaddress').show();
    } else {
        jc('.mailingaddress').hide();
    }
    jc('.payment-nav-pills a[href="#tab4"]').tab('show');
    jc('html, body').animate({'scrollTop': jc("#page-top").position().top}, 'fast');
});
jc(document).on('click', '#skipupload', function () {
    var skipfiles = jc('#skipfiles').prop('checked', true);
});
jc(document).on('click', '#contact-details,#skipupload', function () {
    var totalfilecnt   = jc('.audioLengthpay').length;
    var skipfiles      = jc('#skipfiles').is(':checked');
    var mailcountry    = jc('#mailcountry option:selected').val();
    var mailfilecrmpay = jc('#mailfilecrmpay').is(':checked');
    var mailaddresspay = jc('#mailaddresspay').val();
    if (mailfilecrmpay) {
        jc('.mailingaddress').show();
    } else {
        jc('.mailingaddress').hide();
    }

    if (!mailcountry && mailfilecrmpay) {
        jc('#mailcountry').tooltip({title: "select country!"});
        jc('#mailcountry').focus();
        jc('#mailcountry').keypress(function () {
            jc('#mailcountry').tooltip('destroy');
        });
        return false;
    }
    if (mailfilecrmpay && mailaddresspay == '') {
        jc('#mailaddresspay').tooltip({title: "Enter mailing address!"});
        jc('#mailaddresspay').focus();
        jc('#mailaddresspay').keypress(function () {
            jc('#mailaddresspay').tooltip('destroy');
        });
        return false;
    }

   /* if (totalfilecnt <= 0 && !skipfiles) {
        jc('.payment-nav-pills #tabid4').attr('href', '');
        jc('.payment-nav-pills #tabid4').parent('li').addClass('disabled');
        sweetAlert("Sorry...", "Please upload your file(s) to proceed!", "error");
        return false;
    }*/
    if(mailcountry !='' && mailcountry != 1){
        jc('#uploadat').val('fileupload');
    }

    jc(".paychart").hide();
    jc("#pay_chart").slideUp("fast");
    jc('.payment-nav-pills #tabid4').attr('href', '#tab4');
    if (jc('#uploadat').val() == 'fileupload') {
        jc('.wiz3').hide();
        jc('.wiz2').show();
    } else {
        jc('.wiz2').hide();
        jc('.wiz3').show();
    }

    jc('.payment-nav-pills #tabid4').parent('li').removeClass('disabled');
    jc('.payment-nav-pills #tabid4').attr('href', '#tab4');
    jc('.payment-nav-pills a[href="#tab4"]').tab('show');
    jc('html, body').animate({'scrollTop': jc("#page-top").position().top}, 'fast');
});
jc(document).on('click', '#move-tab1,#pre-upload-payment,.payment-nav-pills #tabid1', function () {
    jc(".paychart").show();
    jc("#pay_chart").slideUp("fast");
    jc("#filesat").val("payuploaddfile");
    jc('.del-time').trigger('change');
    jc('.payment-nav-pills #tabid1').attr('href', '#tab1');
    jc('.payment-nav-pills #tabid1').parent('li').removeClass('disabled');
    jc('.payment-nav-pills a[href="#tab1"]').tab('show');
    jc('html, body').animate({'scrollTop': jc("#page-top").position().top}, 'fast');
});

/*show mailing country start Quote*/
jc(document).on('change', '#mailfilecrm', function () {
    var mailfilecrm = jc('#mailfilecrm').is(':checked');
    if (mailfilecrm) {
        jc('.mail_country').show();
        jc('.mailingaddress').show();
    } else {
        jc('#mailcountrycrm').prop('selectedIndex', 0);
        jc('.mail_country').hide();
        jc('.mailingaddress').hide();
    }
});
/*show mailing country end Quote*/

/*show mailing country start*/
jc(document).on('change', '#mailfilecrmpay', function () {
    var mailfilecrmpay = jc('#mailfilecrmpay').is(':checked');
    if (mailfilecrmpay) {
        jc('.mail_country').show();
        jc('.mailingaddress').show();
    } else {
        jc('#mailcountry').prop('selectedIndex', 0);
        jc('.mail_country').hide();
        jc('.mailingaddress').hide();
    }
});
/*show mailing country end*/


function remove_allfiles() {
    jc('.up-close').each(function () {
        jc(this).trigger("click");
    });
}
function availOpstopay() {

    if (jc('#notacrm').is(':checked')) {
        jc('#notacrmpay').prop('checked', true);
    } else {
        jc('#notacrmpay').prop('checked', false);
    }
    if (jc('#mailfilecrm').is(':checked')) {
        jc('#mailfilecrmpay').prop('checked', true);
        jc("#mailcountry").val(jc("#mailcountrycrm").val());
        jc("#mailaddresspay").val(jc("#mailaddresscrm").val());
    } else {
        jc('#mailfilecrmpay').prop('checked', false);
    }


}
function availOpstofile() {
    if (jc('#notacrmpay').is(':checked')) {
        jc('#notacrm').prop('checked', true);
    } else {
        jc('#notacrm').prop('checked', false);
    }
    if (jc('#mailfilecrmpay').is(':checked')) {
        jc('#mailfilecrm').prop('checked', true);
        jc("#mailcountrycrm").val(jc("#mailcountry").val());
        jc("#mailaddresscrm").val(jc("#mailaddresspay").val());
    } else {
        jc('#mailfilecrm').prop('checked', false);
    }

}

function isNumberKeyq(evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode;
    //console.log(charCode);
    if (charCode != 45 && charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
    return true;
}

jc(document).on('click', '#view-chart', function () {
    var focusto = jc(".place_order2").is(":visible");
    jc("#pay_chart").slideToggle("slow");
    if (!focusto) {
        jc('html, body').animate({'scrollTop': jc("#pay_chart").position().top}, 'fast');
    } else {
        jc('html, body').animate({'scrollTop': jc("#page-top").position().top}, 'fast');
    }
});

//jc( document ).on('click','#needtrl', function() {
function trsSummary() {
    //paytc_pricequoteclac();
    if (jc("#needtrl").prop('checked') == true) {
        jc("#trs-to").show();
        jc(".trl-ord-sum").show();
    } else {
        jc("#trs-to").hide();
        jc(".trl-ord-sum").hide();
    }
}

jc(document).on('change', '#filepay', function () {
    paytc_upload('filepay');
});


/* here js */

if (jc('#otherlangcrm').val() || jc('#othersource1').val()) {
    jc('#othercrm').show();
} else {
    jc('#othercrm').hide();
}
if (jc('#otherlang1crm').val() || jc('#othertarget1').val()) {
    jc('#other1crm').show();
} else {
    jc('#other1crm').hide();
}
jc('.verbatimid').hide();
var source1;
var target;
var valFind;
jc(document).ready(function () {
    var bs_url    = window.location;
    //var base_urls = bs_url.protocol + "//" + bs_url.host + "/" + bs_url.pathname.split('/')[1];
    var base_urls = bs_url.protocol + "//" + bs_url.host;
    var isVisible = jc('#fileuploader').is(':visible');
    if (isVisible == false) {
        jc.ajax({
            url: base_urls + '/logdetails.php',
            data: 'siteurl=' + base_urls,
            type: 'POST',
            success: function (data) {
                // alert(data);
            },
            error: function (data) {
                //alert(data);
            }
        });
    }
    jc('#qtargetcrm').change(function (option, checked) {
        var source2 = jc('#qtargetcrm').val();
        var valFind = '';
        if (source2) {
            valFind = source2.indexOf("Other");
        }
        if (valFind == '-1' || source2 == null) {
            jc('#other1crm').hide();
        } else {
            jc('#other1crm').show();
            jc('#qtargetcrm').dropdown('toggle');
            jc('#otherlang1crm').focus();
        }
        jc('#drop').tooltip('destroy');
    });

});
jc('#qsourcecrm').change(function () {

    source1 = jc('#qsourcecrm option:selected').val();
    if (source1 == 'Other') {
        jc('#othercrm').show();
        jc('#otherlangcrm').focus();
    } else {
        jc('#othercrm').hide();
    }
    if (source1 == 'English') {
        jc('.nativetranscls').show();
    } else {
        jc('.nativetranscls').hide();
        jc('#nativecrm').attr('checked', false);
    }
});
jc('#qsourcevoicecrm').change(function () {
    source2 = jc('#qsourcevoicecrm option:selected').val();
    if (source2 == 'Other') {
        jc('#othercrm').show();
        jc('#otherlangcrm').focus();
    } else {
        jc('#othercrm').hide();
    }
});
jc('#qmailmsgcrm').hide();
jc('#qmailcrm').click(function () {
    var qmail1 = '';
    if (jc('#qmailcrm').is(":checked")) {
        qmail1 = '1';
    } else {
        qmail1 = '0';
    }
    if (qmail1 == 1) {
        jc('#qmailmsgcrm').show();
    } else {
        jc('#qmailmsgcrm').hide();
    }
});
jc('#qservicecrm').change(function () {

    service1 = jc('#qservicecrm option:selected').val();
    if (service1 == 'Audio') {
        jc('.verbatimid').show();
        //jc('#otherlangcrm').focus();
    } else {
        jc('.verbatimid').hide();
    }
});
if (jc('#service').val() == 'voiceover') {
    jc('#fileuploader').hide();
    jc('.comment_voiceover').hide();
    jc('#source_language').hide();
    jc('#needtranslationcrm').change(function () {
        needtrans = jc('#needtranslationcrm option:selected').val();
        if (needtrans == 'Yes') {
            jc('#source_language').show();
        } else {
            jc('#source_language').hide();
        }
    });
    jc('#scriptcrm').change(function () {
        scriptcrm = jc('#scriptcrm option:selected').val();
        if (scriptcrm == 'Yes') {
            jc('#fileuploader').show();
            jc('.comment_voiceover').show();
        } else {
            jc('#fileuploader').hide();
            jc('.comment_voiceover').hide();
        }
    });
    jc('#voicecountcrm').change(function () {
        jc('#voicecountvalues').html('');
        for (var i = 1; i <= jc('#voicecountcrm option:selected').val(); i++) {
            var voices = '<div class="row">' +
                '<div class="form-group col-lg-6">' +
                '<div class="input-group"><span class="input-group-addon"><i class="fa fa-users"></i></span><select id="gender_' + i + '" name="gender" class="form-control minimal voiceovergender" data-placement="bottom"><option value="" selected="selected">* Gender</option><option value="Male">Male</option><option value="Female">Female</option></select></div>' +
                '</div>' +
                '<div class="form-group col-lg-6">' +
                '<div class="input-group"><span class="input-group-addon"><i class="fa fa-users"></i></span><select id="age_' + i + '" name="age" class="form-control minimal voiceoverage" data-placement="bottom"><option value="" selected="selected">* Age</option><option value="Under 14">Under 14</option><option value="15-18">15-18</option><option value="19-25">19-25</option><option value="26-35">26-35</option><option value="Older">Older</option></select></div>' +
                '</div>' +
                '</div>';
            jc('#voicecountvalues').append(voices);
        }
    });
}
/* here submit */
jc(document).on('click', '.qsubmitcrm', function (e) {
    var name        = jc('#paytc_qnamecrm').val();
    var email       = jc('#paytc_qemailcrm').val();
    var country     = jc('#paytc_qcountryscrm').val();
    var acode       = jc('#paytc_acodecrm').val();
    var phone       = jc('#paytc_qphonecrm').val();
    var payt_tatcrm = jc('#payt_tatcrm').val();
    var paytc_hfc   = jc("#paytc_hfc").val();
    var agent_ref   = jc("#agent_ref").val();
    var comment     = jc('#paytc_comment').val();
    var form_data   = new FormData();
    var reg         = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
    var eaddress    = email;
    var files       = '';
    var UploadFlag  = uploadProgress;
    var filena      = new Array();
    filena          = [];

    var uploadat    = jc("#uploadat").val();
    if (uploadat == "fileuploadpay") {
        jc(".fileNamepay").each(function (index) {
            elemval = jc(this).val().trim();
            filena.push(elemval);
        });
    } else {
        jc(".fileName").each(function (index) {
            elemval = jc(this).val().trim();
            filena.push(elemval);

        });
    }
    var filesserid = jc("input[name='length[]']")
        .map(function () {
            return jc(this).data('serid');
        }).get();

    var filescheck = jc("input[name='uploadFiles[]']")
        .map(function () {
            return jc(this).val();
        }).get();
    var i             = 0;
    var fildetail     = [];
    var duratnval     = [];
    var indcostbox    = [];
    var tempfildetail = '';
    var tempdur       = '';
    var tempcostbox   = '';
    var mailfilecrmpay = '';
    var mailcountry    = '';
    var notacrmpay     = '';
    var mailingaddr    = '';
    jc.each(filesserid, function (index, value) {
        //m=index;
        i             = value;
        tempfildetail = jc("#uploadFiles-" + i).val().trim();
        fildetail.push(tempfildetail);

        tempdur = jc("#durationnew-" + i).val().trim();
        duratnval.push(tempdur);

        tempcostbox = jc("#costbox-" + i).val().trim();
        indcostbox.push(tempcostbox);

    });
    var count            = filena.length;
    var completedfilecnt = jc('.audioLength:visible').length;
    var subamttot        = jc("#subamttot").val();
    if (uploadat == "fileuploadpay") {
        mailfilecrmpay = jc("#mailfilecrmpay").is(':checked') ? 1 : 0;
        mailcountry    = jc("#mailcountry option:selected").val();
        notacrmpay     = jc("#notacrmpay").is(':checked') ? 1 : 0;
        mailingaddr    = jc("#mailaddresspay").val();
    } else {
        mailfilecrmpay = jc("#mailfilecrm").is(':checked') ? 1 : 0;
        mailcountry    = jc("#mailcountrycrm option:selected").val();
        notacrmpay     = jc("#notacrm").is(':checked') ? 1 : 0;
        mailingaddr    = jc("#mailaddresscrm").val();
    }
    var recordkeyval   = jc('#recordkey').val();
    var service        = jc('#service').val();
    var paymentamt     = jc("#paymentamt").val();
    var transactionfee = jc("#trans_price").val();
    var sitename       = jc("#site_namee").val();

    var pagecount      = jc("#pagecount").val();

    var prfilelength   = jc("#prfilelength").val();

    var srclang        = jc("#srclang").val();
    var nota_subamt    = jc("#nota_subamt").val();
    var notapro_subamt = jc("#notapro_subamt").val();
    var mfile_subamt   = jc("#mfile_subamt").val();
    var formatting     = jc("#formatting").val();
    var trgttotamt     = jc("#trgt_totamt").val();
    var source         = srclang;
    var trgtunitcost   = jc("#trgt_unitcost").val();
    var sourcefiletype = jc("#sourcefiletype option:selected").val();
    var qtvercrm = 0;
    var qttcodecrm = 0;
    if(sourcefiletype != "Document"){
        var qtvercrm = jc("#qtvercrm").is(':checked')?1:0;
        var qttcodecrm = jc("#qttcodecrm").is(':checked')?1:0;
    }

    var btnvalue = $(this).data("process");

    form_data.append('recordkey', recordkeyval);
    form_data.append('name', name);
    form_data.append('email', email);
    form_data.append('country', country);
    form_data.append('acode', acode);
    form_data.append('phone', phone);
    form_data.append('agent_ref', agent_ref);
    form_data.append('source', source);

    form_data.append('filena', filena);
    form_data.append('count', count);
    form_data.append('comment', comment);
    form_data.append('fildetail', fildetail);
    form_data.append('duratnval', duratnval);
    form_data.append('indcostbox', indcostbox);
    form_data.append('paymentamt', paymentamt);
    form_data.append('transactionfee', transactionfee);
    form_data.append('uploadflag', UploadFlag);

    form_data.append('completedfilecnt', completedfilecnt);
    form_data.append('quoteflag', jc('#quoteflag').val());

    form_data.append('service', service);
    form_data.append('sitename', sitename);

    form_data.append('subamttot', subamttot);
    form_data.append('uploadat', uploadat);
    form_data.append('paytc_hfc', paytc_hfc);
    form_data.append('pagecount', pagecount);
    form_data.append('nota_subamt', nota_subamt);
    form_data.append('notapro_subamt', notapro_subamt);
    form_data.append('mfile_subamt', mfile_subamt);
    form_data.append('notacrmpay', notacrmpay);
    form_data.append('mailfilecrmpay', mailfilecrmpay);
    form_data.append('mailcountry', mailcountry);
    form_data.append('mailingaddr', mailingaddr);
    form_data.append('tatdate', payt_tatcrm);
    form_data.append('trgtunitcost', trgtunitcost);
    form_data.append('trgttotamt', trgttotamt);
    form_data.append('formatting', formatting);
    form_data.append('sourcefiletype', sourcefiletype);
    form_data.append('prfilelength', prfilelength);
    form_data.append('qtvercrm', qtvercrm);
    form_data.append('qttcodecrm', qttcodecrm);
    form_data.append('btnvalue', btnvalue);

    form_data.append('uploadedFileDetailsArr', uploadedFileDetailsArr);

    //if (name != '' && email != '' && mailingaddr != '' && reg.test(eaddress) != false && source != '' && ((jc('#qtargetcrm').length) && (options1.length != 0) || (jc('#qtargetcrm').length) == 0 ) && ((jc('#formatcrm').length) && (format != "") || (jc('#formatcrm').length) == 0 ) && ((jc('#pagescrm').length) && (noofpages != "") || (jc('#pagescrm').length) == 0 ) && ((jc('#subjectcrm').length) && (subjectcrm != "") || (jc('#subjectcrm').length) == 0 ) && ((jc('#needtranscriptioncrm').length) && (needtranscriptioncrm != "") || (jc('#needtranscriptioncrm').length) == 0 ) && ((jc('#videolengthcrm').length) && (videolengthcrm != "") || (jc('#videolengthcrm').length) == 0 ) && ((jc('#scriptcrm').length) && (scriptcrm != "") || (jc('#scriptcrm').length) == 0 ) && ((jc('#purposevoiceover').length) && (purposevoiceover != "") || (jc('#purposevoiceover').length) == 0 )) {

    if (name != ''
        && email != ''
        && reg.test(eaddress) != false
    ){

        jc('#quoteflagnew').val(1);

        // crm upload start
        if (jc('#quoteflag').val() == 0) {
            jc('#fileuploader').prop('onclick', null);
            document.getElementById('fileuploader').style.removeProperty('cursor');
            jc('span.up-close').hide();
            if (uploadProgress == true) {
                paytc_showMessage('#my-welcome-message2');
                return false;
            } else {
                jc('.upload_error, .upload_errmsg ').hide();
                jc('#uploading_msg').show();
                jc('#fvpp-blackout, #my-welcome-message2').hide();
            }
        } else {
            form_data.append('quoteinfo', quoteInfo);

        }

        var uploding_url = update_url;
        if (uploadat == "fileuploadpay" || btnvalue == "quote") {
            uploding_url = update_payment_url;
        } else {
            uploding_url = update_url;
        }
        jc(".pay_or").hide();
        if (uploadat == "fileuploadpay" && btnvalue != "quote") {
            jc(".quotebtn").hide();
            jc(".paybtn").html("Payment processing...");
        }else if (uploadat == "fileuploadpay" && btnvalue == "quote"){
            jc(".paybtn").hide();
            jc(".quotebtn").html("Quote sending...");
        }else{
            jc(".paybtn").html("Payment processing...");
            jc(".quotebtn").html("Quote sending...");
        }

        jc.ajax({
            url: uploding_url,
            dataType: 'json',  // what to expect back from the PHP script, if anything
            contentType: false,
            processData: false,
            data: form_data,
            type: 'POST',
            success: function (data) {
                if (uploadat == "fileuploadpay" && btnvalue != "quote") {
                    jc('#item_number_1').val(data.ordsid);
                    jc("#translationForm").submit();
                    jc('#qsubmitcrm').html('payment processing...');
                    return false;
                } else {
                    if (data.type == 'quote' && data.status == 1) {
                        jc('#quoteflag').val(data.status);
                        quoteInfo = data.info;
                    }
                    if (data.type == 'error') {
                        output = data.text;
                        //alert(output);

                    }
                    else {
                        jc('#qfmsgcrm').html('');
                        output = data.text;
                        //alert(output);
                        if (output == 'Your request has been sent successfully and you will receive an email from us shortly. Thank you!') {

                            jc('#qfmsgcrm').css({'color': '#fff'});
                            jc('#paytc_qnamecrm').val('');
                            jc('#paytc_qemailcrm').val('');
                            jc('#paytc_qcountryscrm').val('');
                            jc('#paytc_acodecrm').val('');
                            jc('#paytc_qphonecrm').val('');
                            jc('#qsourcecrm').val('');
                            jc('#qupfile').val('');
                            jc('#qtargetcrm').val('');
                            jc('#qtatcrm').val('');
                            jc('#qservicecrm').val('');
                            jc('#qcommentcrm').val('');
                            jc('#qpurposecrm').val('');
                            jc('#qcopycrm').attr('checked', false);
                            jc('#qnotecrm').attr('checked', false);
                            jc('#qmailcrm').attr('checked', false);
                            jc('#qmailmsgcrm').val('');
                            jc('.MultiFile-label').text('');
                            jc('#quoteflag').val(0);
                            jc('#recordkey').val('');
                            jc('#qtvercrm').attr('checked', false);
                            jc('#qttcodecrm').attr('checked', false);
                            jc('#subjectcrm').val('');
                            jc('#captioningcrm').val('');
                            jc('#needtranscriptioncrm').val('');
                            jc('#videolengthcrm').val('');
                            jc('#needtranslationcrm').val('');
                            jc('#scriptcrm').val('');
                            jc('#commentvoiceover').val('');
                            jc('#purposevoiceover').val('');
                            jc('#voicecountcrm').val('');
                            jc('#pagescrm').val('');
                            jc('#formatcrm').val('');
                            jc('#quoteflagnew').val('');
                            jc('#file').val('');


                            if (successpath) {
                                location.href = "http://" + successpath + "/success.php?crmpage=quote";
                            } else {
                                jc('#qfmsgcrm').html(output);
                                window.setTimeout(function () {
                                    location.reload()
                                }, 7000);
                            }

                        }
                        else {
                            jc('#qfmsgcrm').html(output);
                            jc('#qfmsgcrm').css({'color': '#333'});
                        }
                    }
                }
            },
            error: function (data) {
                jc("#qsubmitcrm").removeAttr('disabled');
            }
        });
    }
    else {
        if (name == '') {
            jc('#paytc_qnamecrm').tooltip({title: "Enter Name !"});
            jc('#paytc_qnamecrm').focus();
            jc('#paytc_qnamecrm').keypress(function () {
                jc('#paytc_qnamecrm').tooltip('destroy');
            });
        }
        else if (email == '') {
            jc('#paytc_qemailcrm').tooltip({title: "Enter Email ID !"});
            jc('#paytc_qemailcrm').focus();
            jc('#paytc_qemailcrm').keypress(function () {
                jc('#paytc_qemailcrm').tooltip('destroy');
            });
        }
        else if (reg.test(eaddress) == false) {
            jc('#paytc_qemailcrm').tooltip({title: "Enter Valid Email ID !"});
            jc('#paytc_qemailcrm').focus();
            jc('#paytc_qemailcrm').keypress(function () {
                jc('#paytc_qemailcrm').tooltip('destroy');
            });
        }
        else if (mailingaddr == '') {
            jc('#paytc_mailaddress').tooltip({title: "Enter Mailing address !"});
            jc('#paytc_mailaddress').focus();
            jc('#paytc_mailaddress').keypress(function () {
                jc('#paytc_mailaddress').tooltip('destroy');
            });
        }
        /*  else if(country=='')
         {
         jc('#qcountryscrm').tooltip({title: "Select Country !"});
         jc('#qcountryscrm').focus();
         jc('#qcountryscrm').change(function() {
         jc('#qcountryscrm').tooltip('destroy');
         });
         }*/

        else if (source == '') {
            jc('#qsourcecrm').tooltip({title: "Select Source Language !"});
            jc('#qsourcecrm').focus();
            jc('#qsourcecrm').change(function () {
                jc('#qsourcecrm').tooltip('destroy');
            });
        }
        else if ((options1.length == 0) && (jc('#qtargetcrm').length)) {
            jc('#drop').tooltip({title: "Select Target Language !"});
            jc('#drop').focus();
            jc('#drop').css({"border": "1px solid red"});
            jc('#qtargetcrm').change(function () {
                jc('#qtargetcrm').tooltip('destroy');
                jc('#drop').tooltip('destroy');
            });
        }
        else if (noofpages == '') {
            jc('#pagescrm').tooltip({title: "Enter No. of pages !"});

            jc('#pagescrm').focus();
            jc('#pagescrm').keypress(function () {
                jc('#pagescrm').tooltip('destroy');
            });
        }
        else if (format == '') {
            jc('#formatcrm').tooltip({title: "Select Format !"});
            jc('#formatcrm').focus();
            jc('#formatcrm').change(function () {
                jc('#formatcrm').tooltip('destroy');
            });
        }
        else if (subjectcrm == '') {
            jc('#subjectcrm').tooltip({title: "Enter Subject !"});
            jc('#subjectcrm').focus();
            jc('#subjectcrm').change(function () {
                jc('#subjectcrm').tooltip('destroy');
            });
        }
        else if (needtranscriptioncrm == '') {
            jc('#needtranscriptioncrm').tooltip({title: "Do you need transcription?"});
            jc('#needtranscriptioncrm').focus();
            jc('#needtranscriptioncrm').change(function () {
                jc('#needtranscriptioncrm').tooltip('destroy');
            });
        }
        else if (videolengthcrm == '') {
            jc('#videolengthcrm').tooltip({title: "Enter video length"});
            jc('#videolengthcrm').focus();
            jc('#videolengthcrm').change(function () {
                jc('#videolengthcrm').tooltip('destroy');
            });
        }
        else if (scriptcrm == '') {
            jc('#scriptcrm').tooltip({title: "Select Script !"});
            jc('#scriptcrm').focus();
            jc('#scriptcrm').change(function () {
                jc('#scriptcrm').tooltip('destroy');
            });
        }
        else if (purposevoiceover == '') {
            jc('#purposevoiceover').tooltip({title: "Enter Purpose of Voice Over"});
            jc('#purposevoiceover').focus();
            jc('#purposevoiceover').change(function () {
                jc('#purposevoiceover').tooltip('destroy');
            });
        }


    }
});
function paytc_pricequoteclac() {
    if (jc('#mode').val() == "payment") {
        if (jc('#service').val() == "typing") {
            var total = 0;
            jc('#price_div').show();
            jc('#adv_div').hide();
            jc('#div_subtotal').hide();
            jc("#isonly-file").hide();
            jc('.subtotal-block2').hide();
            jc('.verbafee').hide();
            jc('#verba_sub_amt').html('$0.00');
            jc('#verba_subamt').val('0.00');
            var selectedlang = jc('#srclang').val();
            jc('.timefee').hide();
            jc('#timcde_sub_amt').html('$0.00');
            jc('#timcde_sub_amt').val('0.00');
            if (jc.inArray(selectedlang, allowedlang) != -1) {

                jc('#trc_minorder_text').html('');
                jc('#trgt_minorder_text').html('');
                var language       = jc('#srclang').val();
                var min            = 0;
                var price          = 0.99;
                var Transactionfee = '';
                var notacrmpay     = jc("#notacrmpay").is(":checked");
                var mailfilecrmpay = jc("#mailfilecrmpay").is(":checked");
                var mailfilecrm    = jc("#mailfilecrm").is(":checked");
                var srclang        = jc("#srclang option:selected").val();
                var mailcountry    = jc("#mailcountry option:selected").val();
                var servicetype    = jc("#servicetype option:selected").val();
                var pagecount      = jc("#pagecount").val();
                var formatting       = jc("#formatting option:selected").val();
                var minVal         = jc("input[name='length[]']")
                    .map(function () {
                        return jc(this).val();
                    }).get();
                var serialId       = jc("input[name='length[]']")
                    .map(function () {
                        return jc(this).data('serid');
                    }).get();
                var len            = minVal.length;
                var i              = 0;
                for (i = 0; i < len; i++) {
                    if (!isNaN(min) && !isNaN(minVal[i]) && minVal[i] != '') {
                        min = parseInt(min) + parseInt(minVal[i]);
                    }
                }
                if (isNaN(min)) {
                    min = 0;
                }
                jc('#duration_val').html(min);
                var cost              = 0.00;
                if(srclang == "English" && servicetype == "General" && formatting == "Yes"){
                    price = 3.00;
                }else if(srclang == "English" && servicetype == "General" && formatting == "No"){
                    price = 2.00;
                }else if(srclang == "English" && servicetype == "Legal"){
                    price = 3.50;
                }else if(srclang != "English" && servicetype == "Legal" && formatting == "Yes"){
                    price = 7.00;
                }else if(srclang != "English" && servicetype == "Legal" && formatting == "No"){
                    price = 5.00;
                }

                cost  = parseFloat(pagecount) * price;
                total = parseFloat(total) + parseFloat(cost);
                //if (serialId.length > 0) {
                    paytc_showsubtotal();
               // }

                var trltotal = total;
                var minimumordcost = 0;
                if(srclang == "English"){
                    minimumordcost = 15.00;
                }else{
                    minimumordcost = 30.00
                }

                if(trltotal < minimumordcost){
                    total = minimumordcost;
                    jc('#minorder_text').show();
                    jc('#minorder_dp').html(minimumordcost);
                    jc('#minorder_title').prop('title', 'Minimum order cost applies to orders less than $ '+minimumordcost);


                }else{
                    jc('#minorder_text').hide();
                    jc('#minorder_dp').html('');
                    jc('#minorder_title').prop('title','');
                }

                jc("#trgtunitcost_disp").html(price.toFixed(2));
                jc("#trgt_unitcost").val(price.toFixed(2));
                jc('#trgt_totamt').val(total.toFixed(2));
                jc('#trgt_tot').html('$' + total.toFixed(2));
                var notacost        = 5.00;
                var notaprocesscost = 10.00;
                var mailfilecost    = 20.00;

                if (notacrmpay && total != "" && total != 0) {
                    total += parseFloat(notacost) + parseFloat(notaprocesscost);

                    jc('#nota_sub_amt').html('$' + notacost.toFixed(2));
                    jc('#nota_subamt').val(notacost.toFixed(2));
                    jc('#notapro_sub_amt').html('$' + notaprocesscost.toFixed(2));
                    jc('#notapro_subamt').val(notaprocesscost.toFixed(2));
                    jc('.notafee').show();
                } else {
                    jc('.notafee').hide();
                    jc('#nota_sub_amt').html('$0.00');
                    jc('#nota_subamt').val('0.00');
                    jc('#notapro_sub_amt').html('$0.00');
                    jc('#notapro_subamt').val('0.00');
                }

                if (mailfilecrmpay && total != "" && total != 0 && mailcountry == 1) {
                    total += parseFloat(mailfilecost);
                    jc('#mfile_sub_amt').html('$' + mailfilecost.toFixed(2));
                    jc('#mfile_subamt').val(mailfilecost.toFixed(2));
                    jc('.mfilefee').show();
                }
                else {
                    jc('.mfilefee').hide();
                    jc('#mfile_sub_amt').html('$0.00');
                    jc('#mfile_subamt').val('0.00');
                }
                if(mailfilecrmpay || mailfilecrm){
                    if(mailcountry == 1 || mailcountry == ''){
                        jc(".ord_sum").show();
                    }else{
                        jc(".ord_sum").hide();
                    }
                }


                jc('#sub_amt').html("$" + total.toFixed(2));
                jc('#subamttot').val(total.toFixed(2));
                Transactionfee = (total / 100) * 5;
                jc('#trans_rate').html("$" + Transactionfee.toFixed(2));
                jc('#trans_price').val(Transactionfee.toFixed(2));
                total = total + Transactionfee;

                var pagecount1 = 0;
                var std_delivery_time = '';

                if (pagecount >= 1 && pagecount <= 3) {
                    std_delivery_time = "1 business day";
                } else if (pagecount >= 4 && pagecount <= 5) {
                    std_delivery_time = "1 to 2 business days";
                } else if (pagecount >= 6 && pagecount <= 20) {
                    std_delivery_time = "2 to 3 business days";
                } else if (pagecount >= 21 && pagecount <= 50) {
                    std_delivery_time = "5 to 6 business days";
                } else if (pagecount >= 51 && pagecount <= 80) {
                    std_delivery_time = "8 to 9 business days";
                } else if (pagecount >= 81 && pagecount <= 100) {
                    std_delivery_time = "10 to 12 business days";
                } else{
                    var startday   = 11;
                    pagecount1     = pagecount - 100;
                    var reminder   = Math.ceil(pagecount1/20);
                    var tottaldays = parseInt(startday) + parseFloat(reminder*2);
                    var std_delivery_time = tottaldays+' to '+(tottaldays+1)+" business days";

                }

                jc('#crm-lang').html(language);
                jc('#crm-srclang').html(srclang);
                jc('#aprx-tat').html(std_delivery_time);
                jc('#totalpageno-disp').html(pagecount);

                jc('#price_display').html("$" + total.toFixed(2));
                jc('#paymentamt').val(total.toFixed(2));
                jc('#totalfilelength').val(min);


                jc('#amount').val(total.toFixed(2));
                if (min >= 900) {
                    jc("#time-exceed-msg").show();
                } else {
                    jc("#time-exceed-msg").hide();
                }
            }
        }
    } else {
        jc('#price_div').hide();
        jc('#adv_div').show();
        paytc_clearCost();
        jc('#mode').val('');
        jc('#qsubmitcrm').html('Get A Quote');
//        jc('#total_rate').html('$'+total.toFixed(2));
    }

}
function paytc_clearCost() {
    var minVal = jc("input[name='length[]']")
        .map(function () {
            return jc(this).val();
        }).get();
    var len    = minVal.length;
    var i      = 0;
    for (i = 0; i < len; i++) {
        jc('#costnew-' + i).html("");
        jc('#costbox-' + i).val("");

    }
}
function paytc_showsubtotal() {
    jc('#div_subtotal').show();
    jc("#isonly-file").show();
    jc('.subtotal-block2').show();
    jc('#time_rate').show();
    jc('#verb_rate').show();
    jc(".rate-show1").show();
    jc(".rate-show2").show();
    jc('#verb_rate').html('$0.00');
    jc('#time_rate').html('$0.00');
}
function tohour(durminutes) {
    var hours   = Math.floor(durminutes / 60);
    var minutes = (durminutes % 60).toFixed(0);
    hours       = pad(hours, 2);
    minutes     = pad(minutes, 2);
    return duhrs = parseFloat(hours + "." + minutes);
}

jc.ajax({   
    url: serverPath+'client.php',
    data: 'chennal=payment&service=Typing&version=V1.0&sitename='+originPath,
    type: 'POST',
    success: function (data) {
        // alert(data);
    },
    error: function (data) {
        //alert(data);
    }
});

