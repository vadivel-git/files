$('#other').hide();

$('#other1').hide();



var source1;

var target;

var valFind;

//var valFind1;

$(document).ready(function() {

	

    $('#qtarget').multiselect({

        maxHeight: 200,

        onChange : function(option, checked) {

          var source2 = $('#qtarget').val();

          valFind = source2.indexOf("Other");         

			 if(valFind != "-1"){

			 	$('#other1').show();

			 	$('#qtarget').dropdown('toggle');

			 	$('#otherlang1').focus();



			 }else{

			 	$('#other1').hide();

			 }

        }

    });

//    $('#qsource').multiselect({

//        maxHeight: 200,

//        onChange : function(option, checked) {

//          var source2 = $('#qsource').val();

//          valFind1 = source2.indexOf("Other");         

//			 if(valFind1 != "-1"){

//			 	$('#other').show();

//			 }else{

//			 	$('#other').hide();

//			 }

//        }

//    });

});

$('#qsource').change(function(){

    

    source1 = $('#qsource option:selected').val();



    if(source1=='Other'){

        $('#other').show();

        $('#otherlang').focus();

    }else{

        $('#other').hide();

    }

});







$('#qmailmsg').hide();







$('#qmail').click(function(){



	var qmail1='';



	if ($('#qmail').is(":checked"))



	{



	  	qmail1='1';



	}



	else



	{



		qmail1='0';



	}



	if(qmail1==1)



	{



		$('#qmailmsg').show();



	}



	else



	{



		$('#qmailmsg').hide();



	}



});



function showMessage(id){

        var $body = $('body');

        var $dialog = $(id);

        $body.append('<div id="fvpp-blackout"></div>');

        $dialog.append('');

        $blackout = $('#fvpp-blackout');

        var $blackout;

        $blackout.show();

        $("#fvpp-close").css({ 'display': "none" });

        $dialog.show();

		$(".DS-sidefixed-nav").css({ 'display': "none" });

}



$('#qsubmit').click(function(){

		if(source1=='Other'){

        source = 'Other - ' + $('#otherlang').val();

    }else{

        source = $('#qsource').val();

    }

	if(valFind != "-1"){

	 	target = $('#qtarget').val() +' - '+ $('#otherlang1').val();

	 }else{

	 	target = $('#qtarget').val();

	 }

	

	var name=$('#qname').val();



	var email=$('#qemail').val();



	var country=$('#qcountrys').val();



	var acode=$('#qacode').val();



	var phone=$('#qphone').val();



//	var source=$('#qsource').val();

	var target1=$('#qtarget option:selected');

	/*var target = "";

      target1.each(function () {

          target += $(this).text() + ", ";

      });

      //alert(target);*/

	var qtat=$('#qtat').val();	



	var qservice=$('#qservice').val();	



	var qpurpose=$('#qpurpose').val();	           



    var form_data = new FormData(); 



	var comment=$('#qcomment').val();

	var options1 = $('#qtarget > option:selected');

	var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;



    var eaddress = email;



    var filena= new Array();



    var files='';

	var UploadFlag=uploadProgress;

      



 



// crm-upload start

//if(typeof(crmupload) != "undefined"){

	filena = [];

    $( ".fileName" ).each(function( index ) {

      elemval = $( this ).val().trim(); 

      // FileName += elemval +'|' ;

      filena.push(elemval);

    

    });

//}

// crm-upload end



	var count =filena.length;

	var completedfilecnt = $('.audioLength:visible').length;

	// alert();	



	var copy='';



	if ($('#qcopy').is(":checked"))



	{



	  	copy='1';



	}



	else



	{



		copy='0';



	}



	



	var qnote='';



	if ($('#qnote').is(":checked"))



	{



	  	qnote='1';



	}



	else



	{



		qnote='0';



	}



	var qmail='';



	if ($('#qmail').is(":checked"))



	{



	  	qmail='1';



	}



	else



	{



		qmail='0';



	}



	var qmailmsg=$('#qmailmsg').val();







 	form_data.append('name', name);



    form_data.append('email', email);



    form_data.append('country', country);



    form_data.append('acode', acode);



    form_data.append('phone', phone);   



    form_data.append('source', source);



    form_data.append('target', target);



    form_data.append('filena', filena);



    form_data.append('count', count);



    form_data.append('copy', copy);



    form_data.append('comment', comment); 



    form_data.append('qtat', qtat);



    form_data.append('qservice', qservice);

    form_data.append('qpurpose', qpurpose);



    form_data.append('qnote', qnote);



    form_data.append('qmail', qmail);



    form_data.append('qmailmsg', qmailmsg);

	

	form_data.append('uploadflag', UploadFlag);

	

	form_data.append('completedfilecnt', completedfilecnt);







if(name!='' && email!='' && reg.test(eaddress) != false && country!='' && source!=''  && options1.length != 0)



{   







	if(qmail==1)



	{



		if(qmailmsg==''){



		$('#tooladdr').show();



		$('#qmailmsg').focus();	



		$('#tooladdr').html('Enter Address !');



		return false;



	}



	}







	$('#qfmsg').css({'color':'#3573A6'});		



	$('#qfmsg').html('Processing...');	

    $('#quoteflag').val(1);

    if($('#quoteflag').val() ==1){

        $('#fileuploader').prop('onclick',null);

        document.getElementById('fileuploader').style.removeProperty('cursor');

        $('span.up-close').hide();

        if(uploadProgress ==true){

			showMessage('#my-welcome-message2');

        }

    }



	$.ajax({	

// http://vananhost.com/vanancrm/quote_translation_crm.php

		url:'http://vananhost.com/vanancrm/quote_translation_crm.php',



	    dataType: 'json',  // what to expect back from the PHP script, if anything



        //cache: false,



        contentType: false,



        processData: false,



        data: form_data,                         



        type: 'POST',



	



	success: function(data){



		



		if(data.type == 'error')



		{



			output = data.text;



			//alert(output);



						 



		}



		else{



			$('#qfmsg').html('');



			output = data.text;



			//alert(output);



			if(output=='Your request has been sent successfully and you will receive an email from us shortly. Thank you!')



			{



				$('#qfmsg').html(output);



				$('#qfmsg').css({'color':'#333'});



				$('#qname').val('');



				$('#qemail').val('');



				$('#qcountrys').val('');



				$('#qacode').val('');



				$('#qphone').val('');				



				$('#qsource').val('');



				$('#qupfile').val('');



				$('#qtarget').val('');



				$('#qtat').val('');



				$('#qservice').val('');



				$('#qcomment').val('');

                

                $('#qpurpose').val('');



				$('#qcopy').attr('checked', false);



				$('#qnote').attr('checked', false);



				$('#qmail').attr('checked', false);



				$('#qmailmsg').val('');



				$('.MultiFile-label').text('');

				

				$('#quoteflag').val('');



				



				window.setTimeout(function(){location.reload()},7000);



	    



			



				



				

			}



			else



			{



				$('#qfmsg').html(output);



				$('#qfmsg').css({'color':'#333'});







			}



						 



						



			}	



	},



	error : function (data) {



		//alert(data);		



	}		







	});







	}







	else{



	    if(name=='')



	    {

			$('#qname').tooltip({title: "Enter Name !"}); 

		



            $('#qname').focus();

            $('#qname').keypress(function() {

                $('#qname').tooltip('destroy');

            });    

		}



		else if(email=='')



		{

			$('#qemail').tooltip({title: "Enter Email ID !"}); 

            $('#qemail').focus();

            $('#qemail').keypress(function() {

                $('#qemail').tooltip('destroy');

            }); 

		}



		else if(reg.test(eaddress) == false)



		{ 

			$('#qemail').tooltip({title: "Enter Valid Email ID !"}); 

            $('#qemail').focus();

            $('#qemail').keypress(function() {

                $('#qemail').tooltip('destroy');

            });

        }



        else if(country=='')



        {

			$('#qcountrys').tooltip({title: "Select Country !"}); 

            $('#qcountrys').focus();

            $('#qcountrys').change(function() {

                $('#qcountrys').tooltip('destroy');

            });

		}

		

		else if(source=='')



		{

			$('#qsource').tooltip({title: "Select Source Language !"}); 

            $('#qsource').focus();

            $('#qsource').change(function() {

                $('#qsource').tooltip('destroy');

            });	

		}

		else if(options1.length == 0)

		{

			$('#drop').tooltip({title: "Select Target Language !"}); 

            $('#drop').focus();

            $('#qtarget').change(function() {

                $('#qtarget').tooltip('destroy');

            });

		}

	}



});







