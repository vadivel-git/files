jc(document).ready(function() {
    jc('.chozn-src').chosen();
    jc('.chozn-trg').chosen();
    jc('#srclang').chosen().change(function () {
        notThislang();
    });
    jc('#srclang,#trglang').chosen().change(function () {
        jc(".capturedata").trigger("blur");
    });
});

//jc("#srclang_chosen .chosen-drop .chosen-search-input").attr("placeholder", "Search here");


/*show file length or page count based on file type start*/
jc( document ).on('change','#sourcefiletype', function() {
    var sourcefiletype = jc(this).val();


    if (sourcefiletype == 'Document'){
        jc('#prfilelength').val('');
        jc('.media-blk').hide();
        jc('.doc-blk').show();
    }else{
        // jc('#wordconfirmpay').prop("checked",false);
        // jc('#wordconfirm').prop("checked",false);
        jc('#pagecount').val('');
        jc('.media-blk').show();
        jc('.doc-blk').hide();

        jc('#mailfilecrmpay').prop('checked', false);
        jc('#mailfilecrm').prop('checked', false);
        jc('#mailfilecrmpay').trigger("change");
        jc('#mailfilecrm').trigger("change");
    }
});
/*show file length or page count based on file type end*/
jc( document ).on('focus focusin','#pagecount', function() {
    jc("#pagecount").trigger("mouseenter");
});
jc( document ).on('mouseenter focusin','#pagecount', function() {
    jc('#pagecount').tooltip();
});
jc( document ).on('blur','#pagecount', function() {
    jc('#pagecount').tooltip('destroy');
});
/* TAT calculation start */
function tatCalculation(srclang,trglang,srctier,trgtier,pagecount){
    notThislang();
    var std_delivery_time = '';
    var pagecount1        = 0;
    var srctiercost       = 0;
    var trgtiercost       = 0;
    var startday          = 0;
    var statictatpage     = 0;
    var tottaldays        = 0;
    var crosstier         = 0;
    var totatdiff         = 3;


    var trgttierind = trgtier;
    if (srclang == "English") {
        trgttierind = trgtier;
    }else if(trglang == "English"){
        trgttierind = srctier;
    }else{
        trgttierind = srctier;
    }

    srctiercost   = (trgttierind != 'undefined') ? tierarray[trgttierind]['tier_price'] : 0;
    trgtiercost   = (trgttierind != 'undefined') ? tierarray[trgttierind]['tier_price'] : 0;
    statictatpage = (trgttierind != 'undefined') ? tierarray[trgttierind]['statictatpage'] : 0;
    startday      = (trgttierind != 'undefined') ? tierarray[trgttierind]['statictatday'] : 0;
    totatdiff     = (trgttierind != 'undefined') ? tierarray[trgttierind]['durdiff'] : 0;
    crosstier     = (trgttierind != 'undefined') ? tierarray[trgttierind]['crosstier'] : 0;

    if ((pagecount <= statictatpage) && (srclang == "English" || trglang == "English")) {
        std_delivery_time = (trgttierind != '' && trgttierind != 'undefined' && pagecount != '') ? tierarray[trgttierind]['tat'][pagecount][0] : 0;
    } else {
        pagecount1   = pagecount - (statictatpage + 1);
        var reminder = Math.floor(pagecount1 / 10);
        tottaldays   = parseInt(startday) + parseFloat(reminder * totatdiff);
        if (srclang != "English" && trglang != "English") {
            if(pagecount <= statictatpage){
                tottaldays        = (trgttierind != '' && trgttierind != 'undefined' && pagecount != '') ? tierarray[trgttierind]['tat'][pagecount][1] : 0;
                totatdiff = 1
            }
            tottaldays = (tottaldays * 2);
            if(srctier != trgtier){
                tottaldays += crosstier;
            }
            //totatdiff         = parseInt(crosstier);
            std_delivery_time = tottaldays + ' to ' + (tottaldays + totatdiff) + " business days";
        } else {
            if (srctier == "tr1") {
                std_delivery_time = tottaldays + ' to ' + (tottaldays + totatdiff) + " days";
            } else {
                std_delivery_time = tottaldays + ' to ' + (tottaldays + totatdiff) + " business days";
            }
        }
    }


    return std_delivery_time;
}
jc( document ).on('change blur keyup','.del-time', function() {
    var reg         = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
    var sourcefiletype     = jc("#sourcefiletype option:selected" ).val();
    var prfilelength   = (!isNaN(parseInt(jc('#prfilelength').val()))) ? parseInt(jc('#prfilelength').val()) : 0;
    var pagecount    = (!isNaN(parseInt(jc('#pagecount').val()))) ? parseInt(jc('#pagecount').val()) : 0;
    var catetype     = jc( "#catetype option:selected" ).val();
    var srclang      = jc( "#srclang option:selected" ).val();
    var srctier      = jc( "#srclang option:selected" ).data('tier');
    var trglang      = jc( "#trglang option:selected" ).val();
    var trgtier      = jc( "#trglang option:selected" ).data('tier');



    //var wordconfirm    = jc("input[name='wordconfirm']:checked").val();
    var paytc_qemailcrm = jc("#paytc_qemailcrm").val();

    if((sourcefiletype)
        && (pagecount <= 50 && pagecount > 0)
        && (reg.test(paytc_qemailcrm) != false)
        && (catetype != "Handwritten")
        && ((srclang in tirelanguage) == true)
        && ((trglang in tirelanguage) == true)
    ){
        var std_delivery_time = tatCalculation(srclang,trglang,srctier,trgtier,pagecount);

        jc("#tat-val").html(std_delivery_time);
        jc("#delivery-timeline").show();
    }else{
        jc("#delivery-timeline").hide();
    }
    if(srclang != "English"){
        jc("#native-spkr").hide();
        jc('#nativecrmpay').prop('checked', false);
        jc('.onlyeng').hide();
    }else{
        jc("#native-spkr").show();
        jc('.onlyeng').show();
    }
});
/* TAT calculation end */
jc('.chosen-container').tooltip({
    animate: true,
    placement: 'top',
    trigger: 'focus'
});


jc( document ).on('click','#validate-quote,.payment-nav-pills #tabid2,.payment-nav-pills #tabid3,#wizshow3,#wizshow2', function() {

    var sourcefiletype       = jc("#sourcefiletype option:selected").val();
    var prfilelength         = (!isNaN(parseInt(jc('#prfilelength').val()))) ? parseInt(jc('#prfilelength').val()) : 0;
    var pagecount            = (!isNaN(parseInt(jc('#pagecount').val()))) ? parseInt(jc('#pagecount').val()) : 0;
    var catetype             = jc("#catetype option:selected").val();
    var srclang              = jc("#srclang option:selected").val();
    var trglang              = jc("#trglang option:selected").val();
    var deliveryReq          = jc('input[name=deliveryReq]:checked', '#translationForm').val();
    var next_step            = true;
    var mailcountry          = jc("#mailcountry option:selected").val();
    var mailcountrycrm       = jc("#mailcountrycrm option:selected").val();
    var paytc_mailaddresspay = jc("#paytc_mailaddresspay").val();
    var paytc_mailaddresscrm = jc("#paytc_mailaddresscrm").val();
    // var wordconfirm          = "";
    var reg                  = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
    var paytc_qemailcrm      = jc("#paytc_qemailcrm").val();


    if(mailcountry){
        jc( "#mailcountry").val(mailcountry);
        jc( "#mailcountrycrm").val(mailcountry);
    }else if(mailcountrycrm){
        jc( "#mailcountry").val(mailcountrycrm);
        jc( "#mailcountrycrm").val(mailcountrycrm);
    }
    if(paytc_mailaddresspay){        
        jc( "#paytc_mailaddresspay").val(paytc_mailaddresspay);
        jc( "#paytc_mailaddresscrm").val(paytc_mailaddresspay);
    }else if(paytc_mailaddresscrm){        
        jc( "#paytc_mailaddresspay").val(paytc_mailaddresscrm);
        jc( "#paytc_mailaddresscrm").val(paytc_mailaddresscrm);
    }
    if(paytc_qemailcrm == ""){
        jc('#paytc_qemailcrm').tooltip({title: "Email id is required !"});
        jc('#paytc_qemailcrm').focus();
        jc('#paytc_qemailcrm').change(function() {
            jc('#paytc_qemailcrm').tooltip('destroy');
        });
        next_step = false;
        return false;
    }
    else{
        next_step = true;
    }

    if(reg.test(paytc_qemailcrm) == false){
        jc('#paytc_qemailcrm').tooltip({title: "Enter valid email id!"});
        jc('#paytc_qemailcrm').focus();
        jc('#paytc_qemailcrm').change(function() {
            jc('#paytc_qemailcrm').tooltip('destroy');
        });
        next_step = false;
        return false;
    }
    else{
        next_step = true;
    }
    if(!sourcefiletype){
        jc('#sourcefiletype').tooltip({title: "File type is required !"});
        jc('#sourcefiletype').focus();
        jc('#sourcefiletype').change(function() {
            jc('#sourcefiletype').tooltip('destroy');
        });
        next_step = false;
        return false;
    }
    else{
        next_step = true;
    }
    if(!catetype){
        jc('#catetype').tooltip({title: "Service type is required !"});
        jc('#catetype').focus();
        jc('#catetype').change(function() {
            jc('#catetype').tooltip('destroy');
        });
        next_step = false;
        return false;
    }
    else{
        next_step = true;
    }

    if(!srclang){
        jc('#srclang_chosen').tooltip({title: "Source language is required !"});
        //jc("#srclang").trigger('chosen:activate');
        jc('#srclang_chosen').trigger("mousedown");
        next_step = false;
        return false;
    }
    else{
        next_step = true;
    }
    if(!trglang){
        jc('#trglang_chosen').tooltip({title: "Target language is required !"});
        //jc("#trglang").trigger('chosen:activate');
        jc('#trglang_chosen').trigger("mousedown");
        jc('#trglang').change(function() {
            jc('#trglang').tooltip('destroy');
        });
        next_step = false;
        return false;
    }
    else{
        next_step = true;
    }
    if(sourcefiletype == 'Document') {
        if (pagecount == "" || pagecount == null || isNaN(pagecount) || pagecount <= '0') {
            jc('#pagecount').tooltip({title: "Page count is required !"});
            jc('#pagecount').focus();
            jc('#pagecount').keypress(function () {
                jc('#pagecount').tooltip('destroy');
            });
            next_step = false;
            return false;
        } else {
            next_step = true;
        }
        /*if(!jc('input[name=wordconfirm]').is(':checked')){
            jc('#wordconfirmpay').tooltip({title: "Please choose any!"});
            jc('#wordconfirmpay').focus();
            jc('input[name=wordconfirm]').click(function () {
                jc('#wordconfirmpay').tooltip('destroy');
            });
            next_step = false;
            return false;
        }else{
            var wordconfirm    = jc("input[name='wordconfirm']:checked").val();
            next_step = true;
        }*/
    }
    else{
        if (prfilelength == "" || prfilelength == null || isNaN(prfilelength) || prfilelength <= '0') {
            jc('#prfilelength').tooltip({title: "File Length is required !"});
            jc('#prfilelength').focus();
            jc('#prfilelength').keypress(function () {
                jc('#prfilelength').tooltip('destroy');
            });
            next_step = false;
            return false;
        } else {
            next_step = true;
        }
    }

    if(next_step){
        blurdataInfo ={};
        blurdataInfo.clicknext = 'Yes';
        blurdataInfo.fieldname = 'clicknext';
        paytc_updateFormInfo(blurdataInfo);

        if((sourcefiletype == 'Document')
            && (pagecount <= 50 && pagecount > 0)
            && (catetype != "Handwritten")
            && ((srclang in tirelanguage) == true)
            && ((trglang in tirelanguage) == true)
            && (deliveryReq == "option1")
        ){
            jc(".paychart").hide();
            jc("#pay_chart").slideUp("fast");

            var filesclr = jc('#uploadat').val();
            if(filesclr != 'fileuploadpay'){
                jc('#uploadat').val('fileuploadpay');
            }
            if(sourcefiletype == 'Document'){
                jc('.docfile').show();
                jc('.audvid').hide();
                uncheckall();
                //availOpstofile();
                availOpstopay();
            }else{
                jc('.audvid').show();
                jc('.docfile').hide();
                //availOpstopay();
                availOpstofile();
            }
            if(uploadFilesArr != ''){
                jc("#info_payment").show();
                jc('.skip-files').hide();
                jc('#skipfiles').prop('checked', false);
            }
            jc('.wiz2').hide();
            jc('.wiz3').show();

            paytc_pricequoteclac();
            paytc_paymentenable();
            eligibility();
            jc('.payment-nav-pills #tabid2').parent('li').hide();
            jc('.payment-nav-pills #tabid3').parent('li').show();
            jc('.payment-nav-pills #tabid3').attr('href','#tab3');
            jc('.payment-nav-pills #tabid3').parent('li').removeClass('disabled');
            jc('.payment-nav-pills a[href="#tab3"]').tab('show');
            jc('html, body').animate({'scrollTop' : jc("#page-top").position().top},'fast');

        }else{
            jc(".paychart").hide();
            jc("#pay_chart").slideUp("fast");
            jc('.payment-nav-pills #tabid1').attr('href','#tab1');
            jc('.payment-nav-pills #tabid2').attr('href','#tab2');
            jc('.payment-nav-pills #tabid3').parent('li').hide();
            jc('.payment-nav-pills #tabid2').parent('li').show();
            jc('.payment-nav-pills #tabid2').parent('li').removeClass('disabled');
            var filesclr = jc('#uploadat').val();
            if(filesclr != 'fileupload'){
                jc('#uploadat').val('fileupload');
            }

            if(uploadFilesArr != ''){
                jc("#info").show();
            }
            jc('.wiz3').hide();
            jc('.wiz2').show();
            if(jc("#srclang").val() != "English"){
                jc("#native-spkr").hide();
                jc('#nativecrmpay').prop('checked', false);
                jc('.onlyeng').hide();
            }else{
                jc("#native-spkr").show();
                jc('.onlyeng').show();
            }
            if(sourcefiletype == 'Document'){
                jc('.docfile').show();
                jc('.audvid').hide();
                uncheckall();
                availOpstofile();
            }else{
                jc('.audvid').show();
                jc('.docfile').hide();
            }
            availOpstofile();

            jc('.payment-nav-pills a[href="#tab2"]').tab('show');
            jc('html, body').animate({'scrollTop' : jc("#page-top").position().top},'fast');
        }
    }
});

jc( document ).on('click','.payment-nav-pills #tabid4', function() {

    if (jc('#uploadat').val() == 'fileupload') {
        if (jc('.payment-nav-pills #tabid2').parent('li').hasClass('disabled') && jc('.payment-nav-pills #tabid3').parent('li').hasClass('disabled')) {
            return false;
        }else {
            jc("#upload-files").trigger("click");
        }
    } else {
       jc("#contact-details").trigger("click");

    }

});

jc( document ).on('click','#upload-files', function() {
    jc(".paychart").hide();
    jc("#pay_chart").slideUp("fast");
    jc('.payment-nav-pills #tabid4').attr('href','#tab4');
    jc('.payment-nav-pills #tabid4').parent('li').removeClass('disabled');

    jc('.wiz3').hide();
    jc('.wiz2').show();
    var mailfilecrm = jc('#mailfilecrm').is(':checked');
    var mailcountrycrm = jc('#mailcountrycrm option:selected').val();
    var paytc_mailaddresscrm = jc('#paytc_mailaddresscrm').val();
    
    if(mailfilecrm){
        jc('.mailingaddress').show();
    }else{
        jc('.mailingaddress').hide();
    }
    
    if(!mailcountrycrm && mailfilecrm){
    
        jc('#mailcountrycrm').tooltip({title: "select country!"});
        jc('#mailcountrycrm').focus();
        jc('#mailcountrycrm').keypress(function() {
            jc('#mailcountrycrm').tooltip('destroy');
        });
        return false;
    }
    
    if(paytc_mailaddresscrm ==''  && mailfilecrm){
        jc('#paytc_mailaddresscrm').tooltip({title: "Enter mailing address!"});
        jc('#paytc_mailaddresscrm').focus();
        jc('#paytc_mailaddresscrm').keypress(function() {
            jc('#paytc_mailaddresscrm').tooltip('destroy');
        });
        return false;
    }
    jc("#paytc_mailaddresspay").val(paytc_mailaddresscrm);
    jc('.payment-nav-pills a[href="#tab4"]').tab('show');
    jc('html, body').animate({'scrollTop' : jc("#page-top").position().top},'fast');
});
jc( document ).on('click','.skipupload', function() {
    var skipfiles = jc('#skipfiles').prop('checked',true);
});
jc( document ).on('click','#contact-details,.skipupload', function() {
    var totalfilecnt = jc('.audioLengthpay').length;
    var skipfiles = jc('#skipfiles').is(':checked');
    var mailcountry = jc('#mailcountry option:selected').val();
    var paytc_mailaddresspay = jc('#paytc_mailaddresspay').val();
    var mailfilecrmpay = jc('#mailfilecrmpay').is(':checked');
    if(mailfilecrmpay){
        jc('.mailingaddress').show();
    }else{
        jc('.mailingaddress').hide();
    }
    if(!mailcountry && mailfilecrmpay){
        jc('#mailcountry').tooltip({title: "select country!"});
        jc('#mailcountry').focus();
        jc('#mailcountry').keypress(function() {
            jc('#mailcountry').tooltip('destroy');
        });
        return false;
    }
    if(paytc_mailaddresspay ==''  && mailfilecrmpay){
        jc('#paytc_mailaddresspay').tooltip({title: "Enter mailing address!"});
        jc('#paytc_mailaddresspay').focus();
        jc('#paytc_mailaddresspay').keypress(function() {
            jc('#paytc_mailaddresspay').tooltip('destroy');
        });
        return false;
    }
    jc("#paytc_mailaddresscrm").val(paytc_mailaddresspay);
    /*if(totalfilecnt <= 0 && !skipfiles){
        jc('.payment-nav-pills #tabid4').attr('href','');
        jc('.payment-nav-pills #tabid4').parent('li').addClass('disabled');
        sweetAlert("Sorry...", "Please upload your file(s) to proceed!", "error");
        return false;
    }*/
    if(mailcountry !='' && mailcountry != 'United States'){
        jc('#uploadat').val('fileupload');
    }
    jc(".paychart").hide();
    jc("#pay_chart").slideUp("fast");
    if(jc('#prfilelength').val() > 899){
        jc("#time-exceed-msg").show();
        jc('#uploadat').val('fileupload');
    }else{
        jc("#time-exceed-msg").hide();
    }
    jc('.payment-nav-pills #tabid4').attr('href','#tab4');
    if(jc('#uploadat').val() == 'fileupload'){
        jc('.wiz3').hide();
        jc('.wiz2').show();
    }else{
        jc('.wiz2').hide();
        jc('.wiz3').show();
    }

    jc('.payment-nav-pills #tabid4').parent('li').removeClass('disabled');
    jc('.payment-nav-pills #tabid4').attr('href','#tab4');
    jc('.payment-nav-pills a[href="#tab4"]').tab('show');
    jc('html, body').animate({'scrollTop' : jc("#page-top").position().top},'fast');
});
function eligibility() {
    var mailcountry = jc('#mailcountry option:selected').val();
    var paytc_mailaddresspay = jc('#paytc_mailaddresspay').val();
    var mailfilecrmpay = jc('#mailfilecrmpay').is(':checked');

    if(mailcountry !='' && mailcountry != 'United States'){
        jc('#uploadat').val('fileupload');
    }else{
        jc('#uploadat').val('fileuploadpay');
    }
    if(jc('#uploadat').val() == 'fileupload'){
        jc('.wiz3').hide();
        jc('.wiz2').show();
    }else{
        jc('.wiz2').hide();
        jc('.wiz3').show();
    }
}
jc( document ).on('click','#move-tab1,#pre-upload-payment,.payment-nav-pills #tabid1', function() {
    jc(".paychart").show();
    jc("#pay_chart").slideUp("fast");
    jc("#filesat").val("payuploaddfile");
    jc('.del-time').trigger('change');
    jc('.payment-nav-pills #tabid1').attr('href','#tab1');
    jc('.payment-nav-pills #tabid1').parent('li').removeClass('disabled');
    jc('.payment-nav-pills a[href="#tab1"]').tab('show');
    jc('html, body').animate({'scrollTop' : jc("#page-top").position().top},'fast');
});

/*show mailing country start Quote*/
jc( document ).on('change','#mailfilecrm,#sourcefiletype', function() {
    var mailfilecrm = jc('#mailfilecrm').is(':checked');
    if (mailfilecrm){
        jc('.mail_country').show();
    }else{
        jc('#mailcountrycrm').prop('selectedIndex',0);
        jc('.mail_country').hide();
    }
});
/*show mailing country end Quote*/

/*show mailing country start*/
jc( document ).on('change','#mailfilecrmpay,#sourcefiletype', function() {
    var mailfilecrmpay = jc('#mailfilecrmpay').is(':checked');
    if (mailfilecrmpay){
        jc('.mail_country').show();
    }else{
        //jc('#mailcountry').prop('selectedIndex',0);
        jc('.mail_country').hide();
    }
    jc('#mailcountry').trigger("change");
});
/*show mailing country end*/
jc(document).on('change', '#mailfilecrmpay,#mailfilecrm', function() {
    var mailfilecrmpay = jc('#mailfilecrmpay').is(':checked');
    var mailfilecrm = jc('#mailfilecrm').is(':checked');
    if (mailfilecrmpay || mailfilecrm) {
        jc('.mailingaddress').show();
    } else {
        jc('.mailingaddress').hide();
    }
});

jc( document ).on('change','#mailcountry', function() {
    var mailcountry = jc('#mailcountry').val();
    if (mailcountry != "" && mailcountry != "United States"){
        jc(".ord_sum").hide()
    }else{
        jc(".ord_sum").show();
    }
});

function remove_allfiles(){
    jc('.up-close').each(function() {
        jc(this).trigger("click");
    });
}
function availOpstopay(){
    if(jc('#qtvercrm').is(':checked')){
        jc('#qtvercrmpay').prop('checked', true);
    }else{
        jc('#qtvercrmpay').prop('checked', false);
    }
    if(jc('#qttcodecrm').is(':checked')){
        jc('#qttcodecrmpay').prop('checked', true);
        //jc("#qttcodecrmpay").trigger("click");
    }else{
        jc('#qttcodecrmpay').prop('checked', false);
        //jc("#qttcodecrmpay").trigger("click");
    }

    if(jc('#nativecrm').is(':checked')){
        jc('#nativecrmpay').prop('checked', true);
    }else{
        jc('#nativecrmpay').prop('checked', false);
    }

    if(jc('#notacrm').is(':checked')){
        jc('#notacrmpay').prop('checked', true);
    }else{
        jc('#notacrmpay').prop('checked', false);
    }
    if(jc('#mailfilecrm').is(':checked')){
        jc('#mailfilecrmpay').prop('checked', true);
        jc("#mailcountry").val(jc("#mailcountrycrm").val());
        jc("#paytc_mailaddresspay").val(jc("#paytc_mailaddresscrm").val());
    }else{
        jc('#mailfilecrmpay').prop('checked', false);
    }



}
function availOpstofile(){
    if(jc('#qtvercrmpay').is(':checked')){
        jc('#qtvercrm').prop('checked', true);
    }else{
        jc('#qtvercrm').prop('checked', false);
    }
    if(jc('#qttcodecrmpay').is(':checked')){
        jc('#qttcodecrm').prop('checked', true);
    }else{
        jc('#qttcodecrm').prop('checked', false);
    }

    if(jc('#nativecrmpay').is(':checked')){
        jc('#nativecrm').prop('checked', true);
    }else{
        jc('#nativecrm').prop('checked', false);
    }

    if(jc('#notacrmpay').is(':checked')){
        jc('#notacrm').prop('checked', true);
    }else{
        jc('#notacrm').prop('checked', false);
    }
    if(jc('#mailfilecrmpay').is(':checked')){
        jc('#mailfilecrm').prop('checked', true);
        jc("#mailcountrycrm").val(jc("#mailcountry").val());
        jc("#paytc_mailaddresscrm").val(jc("#paytc_mailaddresspay").val());
    }else{
        jc('#mailfilecrm').prop('checked', false);
    }

}
function uncheckall(){
    //jc("#qtvercrmpay,#qttcodecrmpay,#nativecrmpay").trigger("click");
    jc('#qtvercrmpay,#qttcodecrmpay,#nativecrmpay').prop('checked', false);

}


function isNumberKeyq(evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode;
    //console.log(charCode);
    if (charCode != 45 && charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
    return true;
}
function notThislang(){
    var selectedlang = jc( "#srclang option:selected" ).val();
    var selectedtrs = jc( "#trglang option:selected" ).val();
    var trsopt='<option value=""></option>';
    var seltrgtlang;
    //jc.each( allowedlang, function(r,x) {
    jc.each( language_list, function(r,x) {
        seltrgtlang='';
        if(x != selectedlang || x == ""){
            if(selectedtrs == x){                
                seltrgtlang ='selected="selected"';
            }
            var tgtiername = (tirelanguage[x]) ? tirelanguage[x] : "Other";
            trsopt += '<option data-tier="'+tgtiername+'" '+seltrgtlang+' value="'+x+'">'+x+'</option>';
        }
    });
    if(trsopt != '') {
        jc('#trglang')
            .find('option')
            .remove()
            .end()
            .append(trsopt);
    }
    jc('#trglang').trigger('chosen:updated');
    jc(".chosen-search-input").attr("placeholder", "Type here");
}

jc( document ).on('click','#view-chart', function() {
    var focusto = jc(".place_order2").is(":visible");
    jc("#pay_chart").slideToggle("slow");
    if(!focusto){
        jc('html, body').animate({'scrollTop' : jc("#pay_chart").position().top},'fast');
    }else{
        jc('html, body').animate({'scrollTop' : jc("#page-top").position().top},'fast');
    }
});

jc( document ).on('click','#qttcodecrmpay', function() {
    if(jc("#qttcodecrmpay").prop('checked') == true){
        jc(".timecodeneed").show();
    }else{
        jc("#howoftn").val("");
        jc("#spkrchange").prop('checked', false);
        jc(".timecodeneed").hide();
    }
});
//jc( document ).on('click','#needtrl', function() {
function trsSummary(){
    //paytc_pricequoteclac();
    if (jc("#needtrl").prop('checked') == true) {
        jc("#trs-to").show();
        jc(".trl-ord-sum").show();
    } else {
        jc("#trs-to").hide();
        jc(".trl-ord-sum").hide();
    }
}

jc(document).on('change', '#filepay', function() {
    paytc_upload('filepay');
});

//var formSubmitting = false;
//var setFormSubmitting = function() { formSubmitting = true; };

window.onload = function() {
    notThislang();
    window.addEventListener("beforeunload", function (e) {
        if (!uploadProgress) {
            return undefined;
        }

        var confirmationMessage = 'It looks like you have been editing something. '
            + 'If you leave before saving, your changes will be lost.';

        (e || window.event).returnValue = confirmationMessage; //Gecko + IE
        return confirmationMessage; //Gecko + Webkit, Safari, Chrome etc.
    });
    jc(".chosen-search-input").attr("placeholder", "Type here");
};



/* here js */

if(jc('#otherlangcrm').val() || jc('#othersource1').val()){
	jc('#othercrm').show();
}else{
	jc('#othercrm').hide();
}
if(jc('#otherlang1crm').val() || jc('#othertarget1').val()){	
	jc('#other1crm').show();
}else{
	 jc('#other1crm').hide();
}
jc('.verbatimid').hide();
var source1;
var target;
var valFind;
jc(document).ready(function() {
    //jc(".select2").select2();
	var bs_url = window.location;
	//var base_urls = bs_url.protocol + "//" + bs_url.host + "/" + bs_url.pathname.split('/')[1];
    var base_urls = bs_url.protocol + "//" + bs_url.host;
    var isVisible = jc('#fileuploader').is(':visible');
	if(isVisible == false){
		jc.ajax({
			url:base_urls+'/logdetails.php',
			data : 'siteurl='+base_urls,                       
			type: 'POST',
			success: function(data){
				// alert(data);
			},
			error : function (data) {
				//alert(data);		
			}		
		});
	}	
     jc('#qtargetcrm').change(function(option, checked){
            var source2 = jc('#qtargetcrm').val();
            var valFind = '';
          	if(source2){
           		valFind = source2.indexOf("Other");  
          	}  
          	if(valFind == '-1' || source2 == null){
      			jc('#other1crm').hide();			 	
			} else{
			 	jc('#other1crm').show();
			 	jc('#qtargetcrm').dropdown('toggle');
			 	jc('#otherlang1crm').focus();
			}
			jc('#drop').tooltip('destroy');	
    });

});
jc('#qsourcecrm').change(function(){
    
    source1 = jc('#qsourcecrm option:selected').val();
    if(source1=='Other'){
        jc('#othercrm').show();
        jc('#otherlangcrm').focus();
    }else{
        jc('#othercrm').hide();
    }
    if(source1 =='English'){
    	jc('.nativetranscls').show();
    }else{
    	jc('.nativetranscls').hide();
    	jc('#nativecrm').attr('checked', false);
    }
});
jc('#qsourcevoicecrm').change(function(){
    source2 = jc('#qsourcevoicecrm option:selected').val();
    if(source2=='Other'){
        jc('#othercrm').show();
        jc('#otherlangcrm').focus();
    }else{
        jc('#othercrm').hide();
    }
});
jc('#qmailmsgcrm').hide();
jc('#qmailcrm').click(function(){
	var qmail1='';
	if (jc('#qmailcrm').is(":checked")){
	  	qmail1='1';
	}else {
		qmail1='0';
	}
	if(qmail1==1){
		jc('#qmailmsgcrm').show();
	}else {
		jc('#qmailmsgcrm').hide();
	}
});
jc('#qservicecrm').change(function(){
    
    service1 = jc('#qservicecrm option:selected').val();
    if(service1=='Audio'){
        jc('.verbatimid').show();
        //jc('#otherlangcrm').focus();
    }else{
		jc('.verbatimid').hide();
    }
});
if(jc('#service').val() == 'voiceover'){
	jc('#fileuploader').hide();
	jc('.comment_voiceover').hide();
	jc('#source_language').hide();
	jc('#needtranslationcrm').change(function(){
	    needtrans = jc('#needtranslationcrm option:selected').val();
	    if(needtrans=='Yes'){
	    	jc('#source_language').show();
	    }else{
	        jc('#source_language').hide();
	    }
	});
	jc('#scriptcrm').change(function(){
	    scriptcrm = jc('#scriptcrm option:selected').val();
	    if(scriptcrm=='Yes'){
		    jc('#fileuploader').show();
			jc('.comment_voiceover').show();
	    }else{
	       	jc('#fileuploader').hide();
			jc('.comment_voiceover').hide();
	    }
	});
    jc('#voicecountcrm').change(function(){
		jc('#voicecountvalues').html('');
			for(var i = 1; i<=jc('#voicecountcrm option:selected').val() ; i++) {
				var voices = '<div class="row">'+
	    '<div class="form-group col-lg-6">'+
	    '<div class="input-group"><span class="input-group-addon"><i class="fa fa-users"></i></span><select id="gender_'+i+'" name="gender" class="form-control minimal voiceovergender" data-placement="bottom"><option value="" selected="selected">* Gender</option><option value="Male">Male</option><option value="Female">Female</option></select></div>'+
	    '</div>'+
	    '<div class="form-group col-lg-6">'+
	           '<div class="input-group"><span class="input-group-addon"><i class="fa fa-users"></i></span><select id="age_'+i+'" name="age" class="form-control minimal voiceoverage" data-placement="bottom"><option value="" selected="selected">* Age</option><option value="Under 14">Under 14</option><option value="15-18">15-18</option><option value="19-25">19-25</option><option value="26-35">26-35</option><option value="Older">Older</option></select></div>'+
	    '</div>'+
		'</div>';	
			jc('#voicecountvalues').append(voices);
		}
	}); 
}
/* here submit */
jc(document).on('click','#filesubmit', function(e) {
    var name        = jc('#cont_qnamecrm').val();
    var country     = jc('#cont_qcountryscrm').val();
    var phone       = jc('#cont_qphonecrm').val();
    var payt_tatcrm = jc('#cont_tatcrm').val();
    var paytc_hfc   = jc("#cont_hfc").val();
    var expedited   = jc("#expedited").val();
    var pid         = jc("#pid").val();
    var service_name = jc("#service_name").val();
    var deliveryReq  = jc('input[name=deliveryReq]:checked', '#translationForm').val();
    var otherservice = jc('input[name=needotherservice]:checked').map(function() {
        return this.value;
    }).get();
    var needotherservice  = otherservice.join();
    var email    = $('#trans_email').val();
    var sitename = $('#sitename').val();
    var comment    = $('#upcomments').val();
    var filena     = new Array();
    var files      = '';
    var UploadFlag = uploadProgress;
    var ordId      = $('#ordId').val();
    filena         = [];
    $(".fileName").each(function (index) {
        elemval = $(this).val().trim();
        filena.push(elemval);
    });
    var count = filena.length;
    var completedfilecnt = $('.audioLength:visible').length;
    var recordkeyval = $('#recordkey').val();
    var form_data = new FormData();


    form_data.append('name', name);
    form_data.append('country', country);
    form_data.append('phone', phone);
    form_data.append('tatdate', payt_tatcrm);
    form_data.append('paytc_hfc', paytc_hfc);
    form_data.append('expedited', expedited);
    form_data.append('service_name', service_name);
    form_data.append('recordkey', recordkeyval);
    form_data.append('uploadFiles', filena);
    form_data.append('count', count);
    form_data.append('ordId', ordId);
    form_data.append('completedfilecnt', completedfilecnt);
    form_data.append('quoteflag', $('#quoteflag').val());
    form_data.append('uploadflag', UploadFlag);
    form_data.append('uptype', 1);
    form_data.append('upcomments', comment);
    form_data.append('email', email);
    form_data.append('sitename', sitename);
    form_data.append('pid', pid);
    form_data.append('needotherservice', needotherservice);
    form_data.append('uploadedFileDetailsArr', uploadedFileDetailsArr);
    $('#qfmsgcrm').css({'color': '#3573A6'});
    $('#qfmsgcrm').html('Processing...');
    $('#quoteflagnew').val(1);
    if ($('#quoteflag').val() == 0) {
        $('#fileuploader').prop('onclick', null);
        //document.getElementById('fileuploader').style.removeProperty('cursor');
        $('span.up-close').hide();
        if (uploadProgress == true) {
            showMessage('#my-welcome-message2');
        }
    } else {
        form_data.append('quoteinfo', quoteInfo);
        form_data.append('ticketID', ticketID);
    }
    $('#filesubmit').hide();
    $('#processing').show();
    $.ajax({
        url: update_url,
        dataType: 'json',
        contentType: false,
        processData: false,
        data: form_data,
        type: 'POST',
        success: function (data) {
            if (data.type == 'quote' && data.status == 1) {
                $('#quoteflag').val(data.status);
                quoteInfo = data.info;
                ticketID = data.ticketid;
            }
            if (data.type == 'error') {
                output = data.text;
            }
            else {
                $('#qfmsgcrm').html('');
                output = data.text;
                if (output == 'Your request has been sent successfully and you will receive an email from us shortly. Thank you!') {
                    if (successpath) {
                        location.href = "http://" + successpath + "/success.php?crmpage=payment";
                    } else {
                        $('#qfmsgcrm').html(output);
                        window.setTimeout(function () {
                            location.reload()
                        }, 7000);
                    }
                }
                else {
                    $('#qfmsgcrm').html(output);
                    $('#qfmsgcrm').css({'color': '#333'});
                }
            }
        }
    });
});
/* here qsubmit */
jc(document).on('click','.qsubmitcrm', function(e) {
    var buttonname = jc(this).val();
	var name        = jc('#paytc_qnamecrm').val();
	var email       = jc('#paytc_qemailcrm').val();
	var country     = jc('#paytc_qcountryscrm').val();
	var phone       = jc('#paytc_qphonecrm').val();
	var acode       = jc('#paytc_acodecrm').val();
	var payt_tatcrm = jc('#payt_tatcrm').val();
    var agent_ref   = jc("#agent_ref").val();
    var form_data   = new FormData();
	var comment     = jc('#paytc_comment').val();
	var reg         = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
    var eaddress    = email;
    var filena      = new Array();
    var files       = '';
	var UploadFlag  = uploadProgress;
	filena          = [];
    var uploadat    = jc("#uploadat").val();
    var deliveryReq = jc('#expedited').is(":checked")?1:0;

    if(uploadat == "fileuploadpay"){
        jc( ".fileNamepay" ).each(function( index ) {
            elemval = jc( this ).val().trim();
            filena.push(elemval);
          });
    }else{
        jc( ".fileName" ).each(function( index ) {
          elemval = jc( this ).val().trim();
          filena.push(elemval);

        });
    }
    var filesserid = jc("input[name='length[]']")
    .map(function () {
        return jc(this).data('serid');
    }).get();
    var filescheck = jc("input[name='uploadFiles[]']")
    .map(function () {
        return jc(this).val();
    }).get();
    
    var i               = 0;
    var fildetail       = [];
    var duratnval       = [];
    var indcostbox      = [];
    var tempfildetail   = '';
    var tempdur         = '';
    var tempcostbox     = '';
    jc.each(filesserid, function (index, value) {
        //m=index;
        i = value;
        tempfildetail = jc("#uploadFiles-"+i).val().trim();       
        fildetail.push(tempfildetail);
      
        tempdur = jc("#durationnew-"+i).val().trim();
        duratnval.push(tempdur);
        
        tempcostbox = jc("#costbox-"+i).val().trim();
        indcostbox.push(tempcostbox);

    });

	var count            = filena.length;
	var completedfilecnt = jc('.audioLength:visible').length;

	//transcription start
    var qtver           = '';
    var qttcode         = '';
    var nativespeaker   = '';
    var verbcostt       = jc("#verba_subamt").val();
    var timecodecostt   = jc("#timcde_subamt").val();
    var subamttot       = jc("#subamttot").val();
    var spkrchangepay   = '';
    var usrtimecode     = '';
    var usrtimecodetype = '';

    if(uploadat == "fileuploadpay"){
        qtver = (jc('#qtvercrmpay').is(":checked")) ? 1 : 0;
        if(jc('#qttcodecrmpay').is(":checked")){
            qttcode='1';
            if(jc('#spkrchange').is(':checked')) {
                spkrchangepay ='1';
            }
            usrtimecode = jc('#howoftn').val();
            usrtimecodetype = jc("#oftnmtd option:selected").val();
        }  else{
            qttcode='0';
        }
        var nativespeaker   = (jc('#nativecrmpay').is(":checked")) ? 1 : 0;

    }
    else{
        qtver               = (jc('#qtvercrm').is(":checked")) ? 1 : 0;
        qttcode             = (jc('#qttcodecrm').is(":checked")) ? 1 : 0;
        nativespeaker       = (jc('#nativecrm').is(":checked")) ? 1 : 0;
    }

    var qtat            ='';
    var qtmin           ='';
    var mailfilecrmpay  ='';
    var mailcountry     ='';
    var notacrmpay      ='';
    var mailingaddr     ='';
    if(uploadat == "fileuploadpay"){
        qtat=jc('#filelength').val();
        qtmin=jc('#filelength').val();
        mailfilecrmpay  = jc("#mailfilecrmpay").is(':checked') ? 1:0;
        mailcountry     = jc("#mailcountry option:selected").val();
        notacrmpay      = jc("#notacrmpay").is(':checked') ? 1:0;
        mailingaddr     = jc("#paytc_mailaddresspay").val();



    }else{
        qtat=jc('#prfilelength').val();
        qtmin=jc('#prfilelength').val();
        mailfilecrmpay  = jc("#mailfilecrm").is(':checked') ? 1:0;
        mailcountry     = jc("#mailcountrycrm option:selected").val();
        notacrmpay      = jc("#notacrm").is(':checked') ? 1:0;
        mailingaddr     = jc("#paytc_mailaddresscrm").val();
    }




    if(!mailcountry && mailfilecrmpay){
        if(jc('#mailcountry').is(":visible")) {
            jc('#mailcountry').tooltip({title: "select country!"});
            jc('#mailcountry').focus();
            jc('#mailcountry').keypress(function () {
                jc('#mailcountry').tooltip('destroy');
            });
        }
        if(jc('#mailcountrycrm').is(":visible")) {
            jc('#mailcountrycrm').tooltip({title: "select country!"});
            jc('#mailcountrycrm').focus();
            jc('#mailcountrycrm').keypress(function () {
                jc('#mailcountrycrm').tooltip('destroy');
            });
        }

        return false;
    }
    if(mailingaddr ==''  && mailfilecrmpay){
        if(jc('#paytc_mailaddresspay').is(":visible")) {
            jc('#paytc_mailaddresspay').tooltip({title: "Enter mailing address!"});
            jc('#paytc_mailaddresspay').focus();
            jc('#paytc_mailaddresspay').keypress(function () {
                jc('#paytc_mailaddresspay').tooltip('destroy');
            });
        }
        if(jc('#paytc_mailaddresscrm').is(":visible")) {
            jc('#paytc_mailaddresscrm').tooltip({title: "Enter mailing address!"});
            jc('#paytc_mailaddresscrm').focus();
            jc('#paytc_mailaddresscrm').keypress(function () {
                jc('#paytc_mailaddresscrm').tooltip('destroy');
            });
        }
        return false;
    }



    var aprxtat         = jc("#aprx-tat").html();
    var fileupload_tat  = jc("#fileupload_tat").val();
    var paytc_hfc       = jc("#paytc_hfc").val();
    var recordkeyval    = jc('#recordkey').val();
    var service         = jc('#service').val();
    var paymentamt      = jc("#paymentamt").val();
    var transactionfee  = jc("#trans_price").val();
    var sitename        = jc("#site_namee").val();
    var camethrough     = jc("#camethrough").val();

    var sourcefiletype  = jc("#sourcefiletype option:selected").val();
    var prfilelength    = jc("#prfilelength").val();
    var pagecount       = jc("#pagecount").val();
    var srclang         = jc("#srclang").val();
    var trglang         = jc("#trglang").val();
    var nota_subamt     = jc("#nota_subamt").val();
    var notapro_subamt  = jc("#notapro_subamt").val();
    var mfile_subamt    = jc("#mfile_subamt").val();

    var trgttotamt      = jc("#trgt_totamt").val();

    var source          = srclang;
    var target          = trglang;
    var trgtunitcost    = jc("#trgt_unitcost").val();
    var catetype        = jc("#catetype").val();
    //Voice over end
    var btnvalue = $(this).data("process");
    form_data.append('recordkey', recordkeyval);
    form_data.append('name', name);
    form_data.append('email', email);
    form_data.append('country', country);
    form_data.append('acode', acode);
    form_data.append('phone', phone);
    form_data.append('agent_ref', agent_ref);
    form_data.append('source', source);
    form_data.append('target', target);
    form_data.append('filena', filena);
    form_data.append('count', count);
    form_data.append('comment', comment);
    form_data.append('qtat', qtat);
    form_data.append('aprxtat', aprxtat);
    form_data.append('fileupload_tat', fileupload_tat);
    form_data.append('camethrough', camethrough);

    form_data.append('fildetail', fildetail);
    form_data.append('duratnval', duratnval);
    form_data.append('indcostbox', indcostbox);
    form_data.append('paymentamt', paymentamt);
    form_data.append('transactionfee', transactionfee);
    form_data.append('uploadflag', UploadFlag);

    form_data.append('completedfilecnt', completedfilecnt);
    form_data.append('quoteflag', jc('#quoteflag').val());
    form_data.append('qtver', qtver);
    form_data.append('qttcode', qttcode);
    form_data.append('qtmin', qtmin);
    form_data.append('service', service);
    form_data.append('sitename', sitename);
    form_data.append('nativespeaker', nativespeaker);


    form_data.append('verbcostt', verbcostt);
    form_data.append('timecodecostt', timecodecostt);
    form_data.append('subamttot', subamttot);
    form_data.append('uploadat', uploadat);
    form_data.append('paytc_hfc', paytc_hfc);

    form_data.append('spkrchangepay', spkrchangepay);
    form_data.append('usrtimecode', usrtimecode);
    form_data.append('usrtimecodetype', usrtimecodetype);

    form_data.append('sourcefiletype',sourcefiletype);
    form_data.append('prfilelength',prfilelength);
    form_data.append('pagecount',pagecount);
    form_data.append('deliveryReq',deliveryReq);
    form_data.append('nota_subamt',nota_subamt);
    form_data.append('notapro_subamt',notapro_subamt);
    form_data.append('mfile_subamt',mfile_subamt);
    form_data.append('notacrmpay',notacrmpay);
    form_data.append('mailfilecrmpay',mailfilecrmpay);
    form_data.append('mailcountry',mailcountry);
    form_data.append('mailingaddr',mailingaddr);
    form_data.append('tatdate',payt_tatcrm);
    form_data.append('trgtunitcost',trgtunitcost);
    form_data.append('trgttotamt',trgttotamt);
    form_data.append('catetype',catetype);
    form_data.append('btnvalue', btnvalue);
    form_data.append('buttonname', buttonname);

    form_data.append('uploadedFileDetailsArr', uploadedFileDetailsArr);

if(email!='' && reg.test(eaddress) != false)
{

	jc('#qfmsgcrm').css({'color':'#3573A6'});
	jc('#qfmsgcrm').html('Processing...');
	jc('#quoteflagnew').val(1);
    var uploding_url = update_url;
    if (uploadat == "fileuploadpay" || btnvalue == "quote") {
        uploding_url = update_payment_url;
    } else {
        uploding_url = update_url;
    }
     // console.log("test:"+uploding_url);
     // return false;

    jc(".pay_or").hide();
    if (uploadat == "fileuploadpay" && btnvalue != "quote") {
        jc(".quotebtn").hide();
        jc(".paybtn").html("processing...");
    }else if (uploadat == "fileuploadpay" && btnvalue == "quote"){
        jc(".paybtn").hide();
        jc(".quotebtn").html("processing...");
    }else{
        jc(".paybtn").html("processing...");
        jc(".quotebtn").html("processing...");
    }


	    jc.ajax({
            url:uploding_url,
	        dataType: 'json',  // what to expect back from the PHP script, if anything
            //cache: false,
            contentType: false,
            processData: false,
            data: form_data,
            type: 'POST',
	        success: function(data){
                if (uploadat == "fileuploadpay" && btnvalue != "quote") {
                    jc('#item_number_1').val(data.ordsid);
                    jc( "#translationForm" ).submit();
                    jc('#qsubmitcrm').html('processing...');
                    return false;
                }else{
		if(data.type == 'quote' && data.status == 1){
			jc('#quoteflag').val(data.status);
			quoteInfo = data.info;
		}
		if(data.type == 'error')
		{
			output = data.text;
			//alert(output);

		}
		else{
			jc('#qfmsgcrm').html('');
			output = data.text;
			//alert(output);
			if(output=='Your request has been sent successfully and you will receive an email from us shortly. Thank you!')
			{
                if (successpath) {
                    //location.href = "http://" + successpath + "/success.php?crmpage=quote";
                    var redurl = "http://"+successpath+"/Translation-Payment-Files.php?id="+data.param;
                    location.href = redurl;
                } else {
                    jc('#qfmsgcrm').html(output);
                    window.setTimeout(function () {
                        location.reload()
                    }, 7000);
                }

            }
			else
			{
                            jc('#qfmsgcrm').html(output);
                            jc('#qfmsgcrm').css({'color':'#333'});
			}
                    }
                }
	},
	error : function (data) {
            jc("#qsubmitcrm").removeAttr('disabled');
            //alert(JSON.stringify(data));
	}
	});
	}
	else{

    /* if(name=='')
	    {
			jc('#paytc_qnamecrm').tooltip({title: "Enter Name !"});
                        jc('#paytc_qnamecrm').focus();
                        jc('#paytc_qnamecrm').keypress(function() {
                        jc('#paytc_qnamecrm').tooltip('destroy');
            });
		}
		else if(email=='')
		{
			jc('#paytc_qemailcrm').tooltip({title: "Enter Email ID !"});
            jc('#paytc_qemailcrm').focus();
            jc('#paytc_qemailcrm').keypress(function() {
                jc('#paytc_qemailcrm').tooltip('destroy');
            });
		}
		else if(reg.test(eaddress) == false)
		{
			jc('#paytc_qemailcrm').tooltip({title: "Enter Valid Email ID !"});
            jc('#paytc_qemailcrm').focus();
            jc('#paytc_qemailcrm').keypress(function() {
                jc('#paytc_qemailcrm').tooltip('destroy');
            });
        }
        else if(mailingaddr == '')
        {
            jc('#paytc_mailaddress').tooltip({title: "Enter Mailing address !"});
            jc('#paytc_mailaddress').focus();
            jc('#paytc_mailaddress').keypress(function() {
                jc('#paytc_mailaddress').tooltip('destroy');
            });
        } else if(country=='')
        {
			jc('#qcountryscrm').tooltip({title: "Select Country !"});
            jc('#qcountryscrm').focus();
            jc('#qcountryscrm').change(function() {
                jc('#qcountryscrm').tooltip('destroy');
            });
		}else if(source=='')
		{
			jc('#qsourcecrm').tooltip({title: "Select Source Language !"});
            jc('#qsourcecrm').focus();
            jc('#qsourcecrm').change(function() {
                jc('#qsourcecrm').tooltip('destroy');
            });
		}
		else if((options1.length == 0) && (jc('#qtargetcrm').length))
		{
			jc('#drop').tooltip({title: "Select Target Language !"});
            jc('#drop').focus();
            jc('#drop').css({"border":"1px solid red"});
            jc('#qtargetcrm').change(function() {
                jc('#qtargetcrm').tooltip('destroy');
                jc('#drop').tooltip('destroy');
            });
		}
		else if(noofpages=='')
	    {
			jc('#pagescrm').tooltip({title: "Enter No. of pages !"});

            jc('#pagescrm').focus();
            jc('#pagescrm').keypress(function() {
                jc('#pagescrm').tooltip('destroy');
            });
		}
		else if(format=='')
		{
			jc('#formatcrm').tooltip({title: "Select Format !"});
            jc('#formatcrm').focus();
            jc('#formatcrm').change(function() {
                jc('#formatcrm').tooltip('destroy');
            });
		}
		else if(subjectcrm=='')
		{
			jc('#subjectcrm').tooltip({title: "Enter Subject !"});
            jc('#subjectcrm').focus();
            jc('#subjectcrm').change(function() {
                jc('#subjectcrm').tooltip('destroy');
            });
		}
		else if(needtranscriptioncrm=='')
		{
			jc('#needtranscriptioncrm').tooltip({title: "Do you need transcription?"});
            jc('#needtranscriptioncrm').focus();
            jc('#needtranscriptioncrm').change(function() {
                jc('#needtranscriptioncrm').tooltip('destroy');
            });
		}
		else if(videolengthcrm=='')
		{
			jc('#videolengthcrm').tooltip({title: "Enter video length"});
            jc('#videolengthcrm').focus();
            jc('#videolengthcrm').change(function() {
                jc('#videolengthcrm').tooltip('destroy');
            });
		}
		else if(scriptcrm=='')
		{
			jc('#scriptcrm').tooltip({title: "Select Script !"});
            jc('#scriptcrm').focus();
            jc('#scriptcrm').change(function() {
                jc('#scriptcrm').tooltip('destroy');
            });
		}
		else if(purposevoiceover=='')
		{
			jc('#purposevoiceover').tooltip({title: "Enter Purpose of Voice Over"});
            jc('#purposevoiceover').focus();
            jc('#purposevoiceover').change(function() {
                jc('#purposevoiceover').tooltip('destroy');
            });
		}*/




	}
});
function paytc_pricequoteclac() {
    if (jc('#mode').val() == "payment") {
        if (jc('#service').val() == "translation") {
            var total = 0;
            jc('#price_div').show();
            jc('#adv_div').hide();
            jc('#div_subtotal').hide();
            jc("#isonly-file").hide();
            jc('.subtotal-block2').hide();
            jc('.verbafee').hide();
            jc('#verba_sub_amt').html('$0.00');
            jc('#verba_subamt').val('0.00');
            var selectedlang = jc('#srclang').val();
            jc('.timefee').hide();
            jc('#timcde_sub_amt').html('$0.00');
            jc('#timcde_sub_amt').val('0.00');
            if(( selectedlang in tirelanguage ) == true ) {

                jc('#trc_minorder_text').html('');
                jc('#trgt_minorder_text').html('');
                var language = jc('#srclang').val();
                var min = 0;
                var price = 0.99;
                var Transactionfee = '';
                var verbaitam = jc('#qtvercrmpay').is(":checked");
                var timecode = jc('#qttcodecrmpay').is(":checked");
                var native = jc('#nativecrmpay').is(":checked");
                var seltrslang = jc("#trslang option:selected").val();
                var notacrmpay = jc("#notacrmpay").is(":checked");
                var mailfilecrmpay = jc("#mailfilecrmpay").is(":checked");
                var trglang = jc("#trglang option:selected").val();
                var srclang = jc("#srclang option:selected").val();
                var srctier      = jc( "#srclang option:selected" ).data('tier');
                var trgtier      = jc( "#trglang option:selected" ).data('tier');
                var sourcefiletype = jc("#sourcefiletype option:selected").val();
                var mailcountry = jc("#mailcountry option:selected").val();
                var prfilelength = jc("#prfilelength").val();
                var pagecount = jc("#pagecount").val();
                var catetype     = jc( "#catetype option:selected" ).val();
                var minVal = jc("input[name='length[]']")
                    .map(function () {
                        return jc(this).val();
                    }).get();
                var serialId = jc("input[name='length[]']")
                    .map(function () {
                        return jc(this).data('serid');
                    }).get();
                var len = minVal.length;
                var i = 0;
                for (i = 0; i < len; i++) {
                    if (!isNaN(min) && !isNaN(minVal[i]) && minVal[i] != '') {
                        min = parseInt(min) + parseInt(minVal[i]);
                    }
                }
                if (isNaN(min)) {
                    min = 0;
                }
                jc('#duration_val').html(min);
                var totverbtemp = 0.00;
                var tottimetemp = 0.00;
                var totntvspeakertemp = 0.00;
                var i = 0;
                var m = 0;
                var trgt_cost = 0; //Transcription cost
                var trgt_total = 0;
                var cost = 0.00;
                //console.log(sourcefiletype);
                if(mailfilecrmpay){
                    if(mailcountry == "United States" || mailcountry == ""){
                        jc(".ord_sum").show();
                    }else{
                        jc(".ord_sum").hide();
                    }
                }
                var trgttierind=trgtier;
                var srctiercost = 0;
                var trgtiercost = 0;
                if (sourcefiletype == 'Document' && srctier !="Other" && trgtier != "Other") {


                    if (srclang == "English") {
                        trgttierind = trgtier;
                    }else if(trglang == "English"){
                        trgttierind = srctier;
                    }
                    price   = (trgttierind) ? tierarray[trgttierind]['tier_price'] : 0;

                    if(catetype == "General"){
                        price = price;
                        if((pagecount > 30) && (trglang == 'English' || srclang == 'English') && price == 25 ) {
                            price = 20.00;
                        }
                    }else if (catetype != "Handwritten" && price < 30){
                        price = 30.00;
                    }
                    if (trglang != 'English' && srclang != 'English') {
                        if(srctier == trgtier){
                            price = (price*2);
                        }else{
                            srctiercost   = (srctier) ? tierarray[srctier]['tier_price'] : 0;
                            trgtiercost   = (trgtier) ? tierarray[trgtier]['tier_price'] : 0;
                            srctiercost = (catetype != "General" && catetype != "Handwritten" && srctiercost < 30) ? 30 :srctiercost;
                            trgtiercost = (catetype != "General" && catetype != "Handwritten" && trgtiercost < 30) ? 30 :trgtiercost;
                            price = parseFloat(srctiercost) + parseFloat(trgtiercost);
                        }
                    }


                    cost = parseFloat(pagecount) * price;
                    total = parseFloat(total) + parseFloat(cost);
                    // if(serialId.length > 0){
                        paytc_showsubtotal();
                    // }

                } else {
                    if (language == "English" && native == "0") {
                        price = 0.99;
                    } else if (language == "English" && native == "1") {
                        price = 1.75;
                    } else if (language != "English") {
                        price = 5;
                    }
                    jc.each(serialId, function (index, value) {
                        m = index;
                        i = value;

                        if (price > 0) {
                            cost = minVal[m] * price;
                        }
                        jc('#coss').text('Cost');
                        jc('#costnew-' + i).html("$" + cost.toFixed(2));
                        jc('#costbox-' + i).val(cost.toFixed(2));
                        total = parseFloat(total) + parseFloat(cost);
                        //paytc_showsubtotal();
                    });
                }


                jc("#trgtunitcost_disp").html(price.toFixed(2));
                jc("#trgt_unitcost").val(price.toFixed(2));
                jc('#trgt_totamt').val(total.toFixed(2));
                jc('#trgt_tot').html('$' + total.toFixed(2));
                var notacost = 5.00;
                var notaprocesscost = 10.00;
                var mailfilecost = 20.00;
                if (sourcefiletype == 'Document') {
                    if (notacrmpay && total != "" && total != 0) {
                        total += parseFloat(notacost) + parseFloat(notaprocesscost);

                        jc('#nota_sub_amt').html('$' + notacost.toFixed(2));
                        jc('#nota_subamt').val(notacost.toFixed(2));
                        jc('#notapro_sub_amt').html('$' + notaprocesscost.toFixed(2));
                        jc('#notapro_subamt').val(notaprocesscost.toFixed(2));
                        jc('.notafee').show();
                    } else {
                        jc('.notafee').hide();
                        jc('#nota_sub_amt').html('$0.00');
                        jc('#nota_subamt').val('0.00');
                        jc('#notapro_sub_amt').html('$0.00');
                        jc('#notapro_subamt').val('0.00');
                    }
                    
                    if (mailfilecrmpay && total != "" && total != 0 && mailcountry == 'United States') {
                        total += parseFloat(mailfilecost);
                        jc('#mfile_sub_amt').html('$' + mailfilecost.toFixed(2));
                        jc('#mfile_subamt').val(mailfilecost.toFixed(2));
                        jc('.mfilefee').show();
                        
                    }
                    else {
                        
                        jc('.mfilefee').hide();
                        jc('#mfile_sub_amt').html('$0.00');
                        jc('#mfile_subamt').val('0.00');
                    }


                }else {
                    if ((verbaitam) && total != "" && total != 0) {
                        total = total + min * 0.25;
                        var vb_total_ind = (min * 0.25).toFixed(2);
                        if (isNaN(vb_total_ind)) {
                            vb_total_ind = 0;
                        }

                        jc('#verba_sub_amt').html('$' + vb_total_ind);
                        jc('#verba_subamt').val(vb_total_ind);
                        jc('.verbafee').show();
                    } else {
                        jc('.verbafee').hide();
                        jc('#verba_sub_amt').html('$0.00');
                        jc('#verba_subamt').val('0.00');

                    }
                    if ((timecode) && total != "" && total != 0) {
                        var timecodeprice = 0;
                        var spkrchangeyes = jc('#spkrchange').is(":checked");
                        if (spkrchangeyes) {
                            timecodeprice = 0.50;
                            jc(".nospeaker").hide();
                        }
                        else {
                            jc(".nospeaker").show();
                            var durtn = jc("#howoftn").val();
                            var durntype = jc("#oftnmtd option:selected").val();

                            if (durntype == "minutes") {
                                durtn = durtn * 60;
                            }

                            if (durtn >= 1 && durtn <= 10) {
                                timecodeprice = 1;
                            } else if (durtn > 10 && durtn <= 30) {
                                timecodeprice = 0.50;
                            } else if (durtn > 30) {
                                timecodeprice = 0.25;
                            }
                        }

                        total = total + (min * timecodeprice);
                        var tc_total_ind = (min * timecodeprice).toFixed(2);
                        if (isNaN(tc_total_ind)) {
                            tc_total_ind = 0;
                        }


                        jc('#timcde_sub_amt').html('$' + tc_total_ind);
                        jc('#timcde_subamt').val(tc_total_ind);
                        jc('.timefee').show();

                    } else {
                        jc('.timefee').hide();
                        jc('#timcde_sub_amt').html('$0.00');
                        jc('#timcde_sub_amt').val('0.00');
                    }
                }

                jc('#sub_min').html(min);
                jc('#sub_amt').html("$" + total.toFixed(2));
                jc('#subamttot').val(total.toFixed(2));
                Transactionfee = (total / 100) * 5;
                jc('#trans_rate').html("$" + Transactionfee.toFixed(2));
                jc('#trans_price').val(Transactionfee.toFixed(2));
                total = total + Transactionfee;



                var std_delivery_time = tatCalculation(srclang,trglang,srctier,trgtier,pagecount);


                if (min >= 900) {
                    std_delivery_time = "Our consultant will get in touch with you";
                }


                jc('#crm-lang').html(language);
                jc('#crm-srclang').html(srclang);
                jc('#crm-trglang').html(trglang);
                jc('#aprx-tat').html(std_delivery_time);
                var precedmin = pad(min, 2);
                var totallengthdisp = '';
                if (precedmin > 1) {
                    totallengthdisp = precedmin + " mins";
                } else {
                    totallengthdisp = precedmin + " min";
                }
                jc('#totalfilelength-disp').html(totallengthdisp);
                jc('#totalpageno-disp').html(pagecount);

                jc('#price_display').html("$" + total.toFixed(2));
                jc('#paymentamt').val(total.toFixed(2));
                jc('#totalfilelength').val(min);


                var uploadatt = jc('#uploadat').val();
                if (uploadatt == 'fileuploadpay') {
                    jc('#filelength').val(min);
                } else if (min > jc('#filelength').val() || min < 900) {
                    jc('#filelength').val(min);
                }

                jc('#amount').val(total.toFixed(2));
                if (min >= 900) {
                    jc("#time-exceed-msg").show();
                } else {
                    jc("#time-exceed-msg").hide();
                }
            }}
} else {
    jc('#price_div').hide();
    jc('#adv_div').show();
    paytc_clearCost();
    jc('#mode').val('');
    jc('#qsubmitcrm').html('Get A Quote');
//        jc('#total_rate').html('$'+total.toFixed(2));
}
}
function paytc_clearCost(){
    var minVal = jc("input[name='length[]']")
    .map(function () {
        return jc(this).val();
    }).get();
    var len = minVal.length;     
    var i = 0;
    for (i = 0; i < len; i++) {                                                                                                            
       jc('#costnew-'+i).html("");
       jc('#costbox-'+i).val("");
       
   } 
}
function  paytc_showsubtotal(){
    jc('#div_subtotal').show();
    jc("#isonly-file").show();
    jc('.subtotal-block2').show();
    jc('#time_rate').show();
    jc('#verb_rate').show(); 
    jc(".rate-show1").show();
    jc(".rate-show2").show();
    jc('#verb_rate').html('$0.00');
    jc('#time_rate').html('$0.00');
}
function tohour(durminutes){
    var hours = Math.floor( durminutes / 60);
    var minutes = (durminutes % 60).toFixed(0);
    hours = pad(hours, 2);
    minutes = pad(minutes, 2);
    return duhrs = parseFloat(hours+"."+minutes);
}
jc.ajax({   
    url: serverPath+'client.php',
    data: 'chennal='+channel_click+'&service=Translation&version=V1.0&sitename='+originPath,
    type: 'POST',
    success: function (data) {
        // alert(data);
    },
    error: function (data) {
        //alert(data);
    }
});
