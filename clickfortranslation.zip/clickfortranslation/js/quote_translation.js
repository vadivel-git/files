// JavaScript Document			
//Translation quote using JSON
//==============================================================
$('#toolname').hide();
$('#toolemail').hide();
$('#toolcountry').hide();
$('#toolarea').hide();
$('#toolphone').hide();
$('#toolsl').hide();
$('#tooltl').hide();



$('#qname,#qemail,#qcountrys,#qacode,#qphone,#qsource,#qtarget').focusout(function(){
$('#toolname').hide();
$('#toolemail').hide();
$('#toolcountry').hide();
$('#toolarea').hide();
$('#toolphone').hide();
$('#toolsl').hide();
$('#tooltl').hide();
});

$('#qsubmit').click(function(){
	var name=$('#qname').val();
	var email=$('#qemail').val();
	var country=$('#qcountrys').val();
	var acode=$('#qacode').val();
	var phone=$('#qphone').val();
	var source=$('#qsource').val();
	var target=$('#qtarget').val();	           
    var form_data = new FormData(); 
	var comment=$('#qcomment').val();
	var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
    var eaddress = email;
    var filena= new Array();
    var files='';
      
    var j=0;
	$('input[type=file]').each(function(){
		 // file_data.push($(this).prop('files')[0]);
		files=$(this).prop('files')[0];	
		form_data.append('file' + j, files);		
		// form_data.append('file' + j, files);
	    filena.push($(this).val()+'|');
	    // alert(filena);
	    j++;
	})
	var count =filena.length;
	// alert();	
	var copy='';
	if ($('#qcopy').is(":checked"))
	{
	  	copy='1';
	}
	else
	{
		copy='0';
	}
	
	


 	form_data.append('name', name);
    form_data.append('email', email);
    form_data.append('country', country);
    form_data.append('acode', acode);
    form_data.append('phone', phone);   
    form_data.append('source', source);
    form_data.append('target', target);
    form_data.append('filena', filena);
    form_data.append('count', count);
    form_data.append('copy', copy);
    form_data.append('comment', comment); 
    


if(name!='' && email!='' && reg.test(eaddress) != false && country!='' && acode!='' && phone!='' && source!='' && target!='' )
{   


	$('#qfmsg').css({'color':'#3573A6'});		
	$('#qfmsg').html('Processing...');	
	$.ajax({	
		url:'php/quote_translation.php',
	    dataType: 'json',  // what to expect back from the PHP script, if anything
        //cache: false,
        contentType: false,
        processData: false,
        data: form_data,                         
        type: 'POST',
	
	success: function(data){
		
		if(data.type == 'error')
		{
			output = data.text;
			//alert(output);
						 
		}
		else{
			$('#qfmsg').html('');
			output = data.text;
			//alert(output);
			if(output=='Your request has been sent successfully and you will receive an email from us shortly. Thank you!')
			{
				$('#qfmsg').html(output);
				$('#qfmsg').css({'color':'#333'});
				$('#qname').val('');
				$('#qemail').val('');
				$('#qcountrys').val('');
				$('#qacode').val('');
				$('#qphone').val('');				
				$('#qsource').val('');
				$('#qupfile').val('');
				$('#qtarget').val('');
				$('#qcomment').val('');
				$('#qcopy').attr('checked', false);
				$('.MultiFile-label').text('');
				
				window.setTimeout(function(){location.reload()},7000);
	    
			
				
				
			}
			else
			{
				$('#qfmsg').html(output);
				$('#qfmsg').css({'color':'#333'});

			}
						 
						
			}	
	},
	error : function (data) {
		//alert(data);		
	}		

	});

	}

	else{
	    if(name=='')
	    {
			/*$('#qfmsg').css({'color':'#F00'});	
			$('#qfmsg').html('Enter Name !');*/
			$('#toolname').show();
			$('#qname').focus();	
			$('#toolname').html('Enter Name !');	
		}
		else if(email=='')
		{
			/*$('#qfmsg').css({'color':'#F00'});	
			$('#qfmsg').html('Enter Email ID !');*/
			$('#toolemail').show();
			$('#qemail').focus();	
			$('#toolemail').html('Enter Email ID !');
		}
		else if(reg.test(eaddress) == false)
		{ 
	      	/*$('#qfmsg').css({'color':'#F00'});	
			$('#qfmsg').html('Enter Valid Email Address !');*/
			$('#toolemail').show();
			$('#qemail').focus();	
			$('#toolemail').html('Enter Valid Email Address !');
	      	return false;
        }
        else if(country=='')
        {
			/*$('#qfmsg').css({'color':'#F00'});	
			$('#qfmsg').html('Select Country !');*/
			$('#toolcountry').show();
			$('#qcountrys').focus();	
			$('#toolcountry').html('Select Country !');
		}
		else if(acode=='')
		{
			/*$('#qfmsg').css({'color':'#F00'});	
			$('#qfmsg').html('Enter Area Code !');*/
			$('#toolarea').show();
			$('#qacode').focus();	
			$('#toolarea').html('Enter Area Code !');
		}
		else if(phone=='')
		{
			/*$('#qfmsg').css({'color':'#F00'});	
			$('#qfmsg').html('Enter Phone Number !');*/
			$('#toolphone').show();
			$('#qphone').focus();	
			$('#toolphone').html('Enter Phone Number !');
		}
		else if(source=='')
		{
			/*$('#qfmsg').css({'color':'#F00'});	
			$('#qfmsg').html('Select Translate From !');*/
			$('#toolsl').show();
			$('#qsource').focus();	
			$('#toolsl').html('Select Translate From !');	
		}
		else if(target=='')
		{
			/*$('#qfmsg').css({'color':'#F00'});	
			$('#qfmsg').html('Select Translate To !');*/
			$('#tooltl').show();
			$('#qtarget').focus();	
			$('#tooltl').html('Select Translate To !');
		}
	}
});

