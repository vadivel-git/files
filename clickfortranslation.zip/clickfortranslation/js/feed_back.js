// Feedback form by R.Devipriya



$('#fsubmit').click(function(){



	var name=$('#fname').val();

	var email=$('#femail').val();

	var feedback=$('#fcomment').val();

	var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;

  	var address = email;







	if(name!='' && email!='' && reg.test(address) != false &&  feedback!='' ){



	$('#femsg').css({'color':'black'});		



	$('#femsg').html('Processing...');	



	$.ajax({



	url:'php/feed_back.php',



	data:"name="+encodeURIComponent(name)+"&email="+email+"&feedback="+encodeURIComponent(feedback),

	type:'post',



	success: function(data){



	$('#femsg').html(data);

	$('#femsg').css({'color':'black'});

	$('#fname').val('');

	$('#femail').val('');

	$('#fcomment').val('');	



	}



	});



	}

	else{	



		if(name==''){

			$('#femsg').css({'color':'red'});

			$('#femsg').html('Enter your Name !');	

		}



		else if(email==''){

			$('#femsg').css({'color':'red'});	

			$('#femsg').html('Enter your Email ID !');	

		}



		else if(reg.test(address) == false) {

			$('#femsg').css({'color':'red'});

			$('#femsg').html('Enter Valid Email Address !');

			return false;

		}

		

		else if(feedback==''){

			$('#femsg').css({'color':'red'});	

			$('#femsg').html('Enter Your Valuable Feedback !');	

		}



		}







});











