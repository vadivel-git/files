// JavaScript Document

			
//==============================================================
$('#submit').click(function(){
	
	var name=$('#name').val();
	var email=$('#email').val();
	var phone=$('#phone').val();
	var source_lang=$('#source_lang').val();
	var target_lang=$('#target_lang').val();
	var comment=$('#comment').val();
	
	var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
    var eaddress = email;

	if(name!='' && email!='' && reg.test(eaddress) != false  && phone!=''&& source_lang!='' && target_lang!='')
	{
	$('#fmsg').css({'color':'#F3A408'});		
	$('#fmsg').html('Request Sending...');	
	$.ajax({
	url:'php/quote_transcription.php',
	data:"name="+name+"&email="+email+"&phone="+phone+"&source_lang="+source_lang+"&target_lang="+target_lang+"&comment="+comment,
	success: function(data){
	
	$('#fmsg').html(data);
	$('#fmsg').css({'color':'#333'});	
	$('#name').val('');
	$('#email').val('');
	$('#phone').val('');
	$('#source_lang').val('');
	$('#target_lang').val('');
	$('#comment').val('');
	$('#fmsg').html('Message Has been Sent..');	
	}
	
	});

	}
	else{
		if(name==''){
		$('#fmsg').css({'color':'#333'});	
		$('#fmsg').html('Enter Name !');	
		}
		else if(email==''){
		$('#fmsg').css({'color':'#333'});	
		$('#fmsg').html('Enter Email ID !');	
		}
		else if(reg.test(eaddress) == false){ 
		$('.fmsg').css({'color':'#D6171C'});	
		$('.fmsg').html('Enter Valid Email Address !');
      	return false;
   		}
		else if(phone==''){
		$('#fmsg').css({'color':'#333'});	
		$('#fmsg').html('Enter Phone Number !');	
		}
		else if(source_lang==''){
		$('#fmsg').css({'color':'#333'});	
		$('#fmsg').html('Enter Source Language!');	
		
		}
		else if(target_lang==''){
		$('#fmsg').css({'color':'#333'});	
		$('#fmsg').html('Enter Target Language!');	
		
		}
					
		}

});