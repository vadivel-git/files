// JavaScript Document

$('#submit').click(function(){

	var name = $("#caname").val();
	var phone = $("#caphone").val();
	var cell = $("#cell").val();
	var email = $("#caemail").val();
	var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
    var eaddress = email;
    var sourcelang = $("#sourcelang").val();
	var targetlang = $("#targetlang").val();
	var rate = $("#rate").val();	
	var exp = $("#exp").val();							
	var experience = $("#experience").val();
	var trans = $("#trans").val();
	var hrcost = $("#hrcost").val();
	var weekdays = $("#weekdays").val();
	var city = $("#city").val();
	var state = $("#state").val();
	var country = $("#cacountry").val();
	var zip = $("#zip").val();
	var addr = $("#address").val();
	var comments = $("#comment").val();
	//alert(comments);							

	if(name!='' && cell!='' && phone!='' && email!='' && reg.test(eaddress)!= false && sourcelang!='' && targetlang!='' && rate!='' && exp!='' && experience!='' && weekdays!='')
	{
		$('#fmsg').css({'color':'#008000'});	
	    $('#fmsg').html('Processing...');
	   	$.ajax({
			url:'php/emp_store.php',
			data:"name="+encodeURIComponent(name)+"&phone="+encodeURIComponent(phone)+"&cell="+encodeURIComponent(cell)+"&email="+email+"&sourcelang="+encodeURIComponent(sourcelang)+"&targetlang="+encodeURIComponent(targetlang)+"&rate="+encodeURIComponent(rate)+"&exp="+encodeURIComponent(exp)+"&experience="+encodeURIComponent(experience)+"&trans="+encodeURIComponent(trans)+"&hrcost="+encodeURIComponent(hrcost)+"&weekdays="+weekdays+"&city="+encodeURIComponent(city)+"&state="+encodeURIComponent(state)+"&country="+encodeURIComponent(country)+"&zip="+encodeURIComponent(zip)+"&addr="+encodeURIComponent(addr)+"&comments="+encodeURIComponent(comments),

			success: function(data){
				$('#fmsg').html(data);
				$('#fmsg').css({'color':'#168add'});
				$('#caname').val('');
				$('#caphone').val('');
				$('#cell').val('');
				$('#caemail').val('');
				$('#sourcelang').val('');
				$('#targetlang').val('');
				$('#rate').val('');
				$('#exp').val('');
				$('#experience').val('');
				$('#trans').val('');
				$('#hrcost').val('');
				$('#weekdays').val('');
				$('#city').val('');
				$('#state').val('');
				$('#qcountry').val('');
				$('#zip').val('');
				$('#addr').val('');
				$('#comment').val('');
			}
		});
	}
	else
	{
		if(name=='')
		{
			$('#fmsg').css({'color':'#D6171C'});	
		    $('#fmsg').html('Enter Name !');	
		}
		else if(phone=='')
		{
			$('#fmsg').css({'color':'#D6171C'});
		    $('#fmsg').html('Enter Phone Number !');
		}
		else if(cell=='')
		{
			$('#fmsg').css({'color':'#D6171C'});
		    $('#fmsg').html('Enter Cell Number !');	
		}
		else if(email=='')
		{
			$('#fmsg').css({'color':'#D6171C'});
		    $('#fmsg').html('Enter Email ID !');	
		}
		else if(reg.test(eaddress) == false) 
		{ 
      	    $('#fmsg').css({'color':'#D6171C'});
		    $('#fmsg').html('Enter Valid Email Address !');
      	    return false;
   		}
		else if(sourcelang=='')
		{
			$('#fmsg').css({'color':'#D6171C'});	
		   	$('#fmsg').html('Select Source Language !');	
		}
		else if(targetlang=='')
		{
			$('#fmsg').css({'color':'#D6171C'});
		   	$('#fmsg').html('Select Target Language !');	
		}
		else if(rate=='')
		{
			$('#fmsg').css({'color':'#D6171C'});
		   	$('#fmsg').html('Enter Rate Per Word !');
		}
		else if(exp=='')
		{
			$('#fmsg').css({'color':'#D6171C'});
		   	$('#fmsg').html('Select Experienced !');
		}
		else if(experience=='')
		{
			$('#fmsg').css({'color':'#D6171C'});
		   	$('#fmsg').html('Enter How Many Years Experienced !');
		}
		else if(weekdays=='')
		{
			$('#fmsg').css({'color':'#D6171C'});
		   	$('#fmsg').html('Select Working Days !');
		}

	}

							
});