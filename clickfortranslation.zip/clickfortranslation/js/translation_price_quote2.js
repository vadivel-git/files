jc(document).ready(function() {
    var sourcefiletype = jc('#sourcefiletype').val();
    if(sourcefiletype != '' && sourcefiletype != null){
        jc('#sourcefiletype').trigger('change');
    }
    jc('#srclang,#trglang,.chozn-select').chosen();
    jc('#srclang').chosen().change(function () {
        notThislang();
    });


     // For updating page visit duration
    var startTime;
    var endTime;
    startTime  = new Date()
    window.onunload = function(){
    endTime = new Date();
    var elapsedSeconds = endTime.getTime() - startTime.getTime();
    var seconds = parseFloat(elapsedSeconds)/1000;
    var timespentrecordid  = $("#timespendingid").html();
        var ajxurl      = window.location.href;
        $.ajax({
              url: serverPath+'client.php',
              data: {'timeSpent': seconds,
                     'timespentrecordid': timespentrecordid,
                    'ajxurl' : ajxurl

              },
              async: false,
              type: 'POST',
              success: function (data) {

              }

          });
     }
});
jc(document).on('chosen:hiding_dropdown','#srclang,#trglang,#mailcountry', function (evt, params) {
    //mandvalidation(this);
    validatepay(this);
});

jc(document).on('change','input[name=rushopts]', function () {
    var expedited               = '';
    var rushview      = jc('#expedited-timeline').is(':visible') ? 1 : 0;
    var standaredview = jc('#delivery-timeline').is(':visible') ? 1 : 0;
    //var rushopts = '';
    var rushper = '';
    if(standaredview) {
        expedited = jc("#expedited").is(':checked') ? 'Yes' : 'No';
    }else if(rushview){
        var rushopts  = jc('input[name=rushopts]:checked', '#translationForm').val();
        expedited = (rushopts > 0)?'Yes':'No';

        if(rushopts == 3){
            rushper = '150%';
        }else if(rushopts == 2){
            rushper = '100%';
        }else if(rushopts == 1){
            rushper = '50%';
        }
    }

    if(rushopts > 0) {
        blurdataInfo             = {};
        blurdataInfo.comments    = 'Yes';
        blurdataInfo.fieldname   = 'expedited';
        blurdataInfo.expedited = 'Yes';
        paytc_updateFormInfo(blurdataInfo);
        
        blurdataInfo             = {};
        blurdataInfo.comments  = jc('#amount').val();
        blurdataInfo.fieldname = 'pricetotal';
        blurdataInfo.pricetotal = jc('#amount').val();
        paytc_updateFormInfo(blurdataInfo);


        setTimeout(function () {
            blurdataInfo             = {};
            blurdataInfo.comments   = rushper;
            blurdataInfo.fieldname  = 'rushper';
            blurdataInfo.rushper = rushper;
            paytc_updateFormInfo(blurdataInfo);
        }, 2000);
    }else{
        blurdataInfo             = {};
        blurdataInfo.comments    = '';
        blurdataInfo.fieldname   = 'expedited';
        blurdataInfo.expedited = '';
        paytc_updateFormInfo(blurdataInfo);

        setTimeout(function () {
            blurdataInfo             = {};
            blurdataInfo.comments   = '';
            blurdataInfo.fieldname  = 'rushper';
            blurdataInfo.rushper = '';
            paytc_updateFormInfo(blurdataInfo);
        }, 2000);
    }
});
function checktarget(){
    
    var srclang         = jc("#srclang option:selected").val();
    var trglang         = jc("#trglang option:selected").val();
    jc('.engfreecert').hide();
    if((srclang != '' && srclang == 90) || (trglang != '' && trglang == 90)){
        jc('.engfreecert').show();
    }else{
        jc('.engfreecert').hide();
    }
    if(trglang != '' && trglang != 90){
        jc('#trgtlng').html(language_list[trglang]);
        jc('.otrlang').show();
        jc('.englang').hide();        
    }else{
        jc('.englang').show();
        jc('.otrlang').hide();
    }
}
var lastselected = jc("#sourcefiletype").val();
/*show file length or page count based on file type */
jc( document ).on('change','#sourcefiletype', function() {
    var currentselected = jc("#sourcefiletype").val();
    if(uploadedFilesArr.length > 0){
        swal({
                title: "Are you sure?",
                text: "The file(s) you have uploaded do not support the file type you have chosen.",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#DD6B55",
                confirmButtonText: "Delete file(s)",
                cancelButtonText: "No",
                closeOnConfirm: true,
                closeOnCancel: true
            },
            function(isConfirm){
                if (!isConfirm) {
                    jc('#sourcefiletype').val(lastselected);
                    if (lastselected == 1){
                        jc('.mediafile').hide();
                        jc('.docfile').show();
                        var mailed = jc('#mailfilecrmpay').is('checked');
                        if(mailed){
                            jc('.mailedyes').show();
                        }else{
                            jc('.mailedyes').hide();
                        }
                        jc('.fname').removeClass('col-xs-4 col-sm-4 col-lg-4');
                        jc('.fname').addClass('col-xs-8 col-sm-8 col-lg-8');
                    }else{
                        jc('.fname').removeClass('col-xs-8 col-sm-8 col-lg-8');
                        jc('.fname').addClass('col-xs-4 col-sm-4 col-lg-4');

                        jc('.docfile').hide();
                        jc('.mediafile').show();
                    }
                    jc("#pagecount").trigger("keyup");
                    showpay();                    
                    return false;
                }
                
                remove_allfiles();
                lastselected = jc('#sourcefiletype').val();
            });
    }else{
        lastselected = jc('#sourcefiletype').val();
    }
    
    var sourcefiletype = jc(this).val();
    if(sourcefiletype != '') {
        jc('.uploadhere').show();
    }else{
        jc('.uploadhere').hide();
    }
    if (sourcefiletype == 1){
        jc('.mediafile').hide();
        jc('.docfile').show();
        var mailed = jc('#mailfilecrmpay').is('checked');
        if(mailed){
            jc('.mailedyes').show();
        }else{
            jc('.mailedyes').hide();
        }
        jc('.fname').removeClass('col-xs-4 col-sm-4 col-lg-4');
        jc('.fname').addClass('col-xs-8 col-sm-8 col-lg-8');
    }else{
        jc('.fname').removeClass('col-xs-8 col-sm-8 col-lg-8');
        jc('.fname').addClass('col-xs-4 col-sm-4 col-lg-4');

        jc('.docfile').hide();
        jc('.mediafile').show();
    }
});
/*--------- DELETE ALL UPLOADED FILES START ------------*/
function remove_allfiles() {
    jc('.up-close').each(function () {
        jc(this).trigger("click");
    });
}
/*--------- DELETE ALL UPLOADED END ------------*/
//Show hide U.S Native speaker
jc( document ).on('change','#sourcefiletype,#needtranscript,#srclang', function() {
    var needtranscript = jc('#needtranscript').is(':checked');
    var sourcefiletype = jc('#sourcefiletype option:selected').val();
    var srclang = jc('#srclang option:selected').val();
    if(needtranscript && srclang == 90 && sourcefiletype == 2){
        jc('.usnative-blk').show();
    }else{
        jc('.usnative-blk').hide();
    }
});
// Page count tooltip on focus
/*jc( document ).on('focus focusin','.tooltiptrigger', function() {
    jc(this).trigger("mouseenter");
});
jc( document ).on('mouseenter focusin','.tooltiptrigger', function() {
    jc(this).tooltip();
});
jc( document ).on('blur','.tooltiptrigger', function() {
    jc(this).tooltip('destroy');
}); */


/* TAT calculation start */
function tatCalculation(srclang,trglang,srctier,trgtier,pagecount,sourcefiletype, prfilelength){
    var std_delivery_time = '';
    var qcheck  = jc('#qcheck').is(':checked');
    var extendtat = 0;
    if(qcheck){
        extendtat = 1;
    }
    if(sourcefiletype == 1) {
        notThislang();
        var pagecount1        = 0;
        var srctiercost       = 0;
        var trgtiercost       = 0;
        var startday          = 0;
        var statictatpage     = 0;
        var tottaldays        = 0;
        var crosstier         = 0;
        var totatdiff         = 3;


        var trgttierind = trgtier;
        if (srclang == 90) {
            trgttierind = trgtier;
        } else if (trglang == 90) {
            trgttierind = srctier;
        } else {
            trgttierind = srctier;
        }

        srctiercost   = (trgttierind != 'undefined') ? tierarray[trgttierind]['tier_price'] : 0;
        trgtiercost   = (trgttierind != 'undefined') ? tierarray[trgttierind]['tier_price'] : 0;
        statictatpage = (trgttierind != 'undefined') ? tierarray[trgttierind]['statictatpage'] : 0;
        startday      = (trgttierind != 'undefined') ? tierarray[trgttierind]['statictatday'] : 0;
        totatdiff     = (trgttierind != 'undefined') ? tierarray[trgttierind]['durdiff'] : 0;
        crosstier     = (trgttierind != 'undefined') ? tierarray[trgttierind]['crosstier'] : 0;


        if (!qcheck && (pagecount <= statictatpage) && (srclang == 90 || trglang == 90)) {
            std_delivery_time = (trgttierind != '' && trgttierind != 'undefined' && pagecount != '') ? tierarray[trgttierind]['tat'][pagecount][0] : 0;
        } else {
            pagecount1   = pagecount - (statictatpage + 1);
            var reminder = Math.floor(pagecount1 / 10);
            tottaldays   = parseInt(startday) + parseFloat(reminder * totatdiff);
            if(qcheck){
                tottaldays = (trgttierind != '' && trgttierind != 'undefined' && pagecount != '') ? tierarray[trgttierind]['tat'][pagecount][1] : 0;
                if(tottaldays == 1){
                    std_delivery_time = parseInt(tottaldays+extendtat) + " business days";
                }else{
                    std_delivery_time = parseInt(tottaldays+extendtat) + ' to ' + (tottaldays+extendtat+totatdiff) + " business days";
                }

            }
            else if (srclang != 90 && trglang != 90) {
                if (pagecount <= statictatpage) {
                    tottaldays = (trgttierind != '' && trgttierind != 'undefined' && pagecount != '') ? tierarray[trgttierind]['tat'][pagecount][1] : 0;
                    totatdiff  = 1
                }
                tottaldays = (tottaldays * 2);
                if (srctier != trgtier) {
                    tottaldays += crosstier;
                }
                //totatdiff         = parseInt(crosstier);
                std_delivery_time = tottaldays + ' to ' + (tottaldays + totatdiff) + " business days";
            } else {
                if (srctier == "tr1") {
                    std_delivery_time = tottaldays + ' to ' + (tottaldays + totatdiff) + " days";
                } else {
                    std_delivery_time = tottaldays + ' to ' + (tottaldays + totatdiff) + " business days";
                }
            }
        }
    }
    else if(sourcefiletype == 2){
        if(prfilelength >= 1 && prfilelength<=30){
            std_delivery_time = "2 business days";
        }else if(prfilelength >= 31 && prfilelength<=60){
            std_delivery_time = "2 to 3 business days";
        }else if(prfilelength > 60){
            var std_delivery = prfilelength/60;
            var std_delivery_calc = parseInt(1)+Math.ceil(std_delivery);
            var to_deltime = parseInt(std_delivery_calc)+parseInt(1);
            std_delivery_time = parseInt(std_delivery_calc)+' to '+to_deltime+ " Business days";
        }
    }
    return std_delivery_time;
}
function showquote(){
    var sourcefiletype = jc('#sourcefiletype option:selected').val();
    jc('#uploadat').val('fileupload');
    jc('.order-summary').hide();
    jc('.pt').hide();
    jc('.u-email').show();
    jc('.qt_mailinfo').show();
    jc('.no-summary').show();
    if(!uploadProgress) {
        jc('.qt').show();
    }
    // showtimeline();
     if(sourcefiletype == 1) {
        jc('.pagecounthelp').show();
    }else{
        jc('.pagecounthelp').hide();
    }
}
function showpay(){
    jc('#uploadat').val('fileuploadpay');
    var sourcefiletype = jc('#sourcefiletype option:selected').val();
    jc('.no-summary').hide();
    jc('.qt').hide();
    jc('.qt_mailinfo').hide();
    jc('.order-summary').show();
    if(sourcefiletype == 1) {
        jc('.pagecounthelp').show();
    }else{
        jc('.pagecounthelp').hide();
    }

    jc('.u-email').show();
    if(!uploadProgress) {
        jc('.pt').show();
    }
    // showtimeline();
    blurdataInfo           = {};
    blurdataInfo.comments  = 'Yes';
    blurdataInfo.fieldname = 'priceviewed';
    blurdataInfo.priceviewed = 'Yes';
    paytc_updateFormInfo(blurdataInfo);
    
    
    setTimeout(function () {
        blurdataInfo             = {};
        blurdataInfo.comments  = jc('#amount').val();
        blurdataInfo.fieldname = 'pricetotal';
        blurdataInfo.pricetotal = jc('#amount').val();
        paytc_updateFormInfo(blurdataInfo);
    }, 2000);
    //jc('.capturedata').trigger('change');
}
function showerr(){
    var sourcefiletype  = jc("#sourcefiletype option:selected").val();
    jc('#uploadat').val('fileupload');
    jc('.order-summary').hide();
    jc('.pt').hide();
    jc('.u-email').hide();
    jc('.no-summary').show();
    jc('.qt').hide();
    jc('.hardcopytat').hide();
    jc("#delivery-timeline").hide();
    jc("#expedited-timeline").hide();
    jc('.expeditedblk').hide();
     if(sourcefiletype == 1) {
        jc('.pagecounthelp').show();
    }else{
        jc('.pagecounthelp').hide();
    }
}
function showtimeline(){
    var sourcefiletype  = jc("#sourcefiletype option:selected").val();
    var prfilelength    = (!isNaN(parseInt(jc('#prfilelength').val()))) ? parseInt(jc('#prfilelength').val()) : 0;
    var pagecount       = (!isNaN(parseInt(jc('#pagecount').val()))) ? parseInt(jc('#pagecount').val()) : 0;
    var srclang         = jc("#srclang option:selected").val();
    var srctier         = jc("#srclang option:selected").data('tier');
    var trglang         = jc("#trglang option:selected").val();
    var trgtier         = jc("#trglang option:selected").data('tier');
    var deliveryReq     = jc('input[name=deliveryReq]:checked', '#translationForm').val();
    var rushopts        = jc('input[name=rushopts]:checked', '#translationForm').val();
    var paytc_qemailcrm = jc("#paytc_qemailcrm").val();
    var mailfilecrmpay  = jc("#mailfilecrmpay").is(':checked') ? 1 : 0;
    var mailcountry     = jc("#mailcountry option:selected").val();
    var needtranscript  = jc("#needtranscript").is(':checked') ? 1 : 0;
    var deliverytime    = jc('#delivery-timeline').is(':visible');


    if(((sourcefiletype == 1) && (pagecount <= 20 && pagecount > 0))
        && ((language_list[srclang] in tirelanguage) == true)
        && ((language_list[trglang] in tirelanguage) == true)
        && (srclang == 90 || trglang ==90)
    ){
        if(((jc.inArray(srclang, trclang) == -1) && sourcefiletype == 2 && needtranscript)
            || (mailfilecrmpay && mailcountry != '' && mailcountry !=1)
        ){
            jc("#delivery-timeline").hide();
            jc("#expedited-timeline").hide();
            jc('.expeditedblk').hide();
            jc(".hardcopytat").hide();
        }else {
            if(mailfilecrmpay && (mailcountry == '' || mailcountry ==1)){
                jc(".hardcopytat").show();
            }else{
                jc(".hardcopytat").hide();
            }
            var std_delivery_time = tatCalculation(srclang, trglang, srctier, trgtier, pagecount, sourcefiletype, prfilelength);
            jc("#tat-val").html(std_delivery_time);
            expeditecalc(srclang, trglang, srctier, trgtier, sourcefiletype, pagecount, prfilelength);
        }
    }else{
        jc("#delivery-timeline").hide();
        jc("#expedited-timeline").hide();
        jc('.expeditedblk').hide();
        jc(".hardcopytat").hide();
    }

}
function reverseArr(input) {
    var ret = new Array;
    for(var i = input.length-1; i >= 0; i--) {
        ret.push(input[i]);
    }
    return ret;
}
function timeToSeconds(time) {
    time = time.split(/:/);
    return parseInt(time[0] * 3600 + time[1] * 60 + time[2]);
}
function expeditecalc(srclang,trglang,srctier,trgtier,sourcefiletype,pagecount,prfilelength) {
    var qcheck = jc('#qcheck').is(':checked');
    var doclength = '';
    var tierval   = '';

    if (srclang == 90) {
        tierval   = trgtier;
        doclength = pagecount;
    } else if (trglang == 90) {
        tierval   = srctier;
        doclength = pagecount;
    }
    var needtranscript = false;
    var languagebased  = true;
    if (sourcefiletype == 2) {
        tierval   = 'av';
        doclength = (prfilelength > 0 && prfilelength <= 15) ? 0 : '';
        doclength = (prfilelength > 15 && prfilelength <= 30) ? 1 : doclength;
        doclength = (prfilelength >= 31 && prfilelength <= 60) ? 2 : doclength;
        doclength = (prfilelength >= 61 && prfilelength <= 180) ? 3 : doclength;
        doclength = (prfilelength >= 181 && prfilelength <= 240) ? 4 : doclength;
        doclength = (prfilelength >= 241 && prfilelength <= 300) ? 5 : doclength;
        doclength = (prfilelength >= 301 && prfilelength <= 360) ? 6 : doclength;
        doclength = (prfilelength >= 361 && prfilelength <= 420) ? 7 : doclength;
        doclength = (prfilelength >= 421 && prfilelength <= 480) ? 8 : doclength;
        doclength = (prfilelength >= 481 && prfilelength <= 600) ? 9 : doclength;

        needtranscript = jc("#needtranscript").is(':checked') ? true : false;
        if (srclang != 90 && trglang != 90) {
            languagebased = false;
        }

    }
    var days    = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    var d       = new Date(todaydate);
    var dayName = days[d.getDay()];

    var fri_e_timee    = '17:30:00';
    var sun_s_timee    = '22:00:00';
    var cur_secs       = timeToSeconds(cur_timee);
    var friday_e_timee = timeToSeconds(fri_e_timee);
    var sunday_s_timee = timeToSeconds(sun_s_timee);
    var weekoff = false;
    if(dayName != 'Saturday'){
        if(dayName == 'Friday' && cur_secs > friday_e_timee){
            weekoff = true;
        }else if(dayName == 'Sunday' && cur_secs < sunday_s_timee ){
            weekoff = true;
        }else{
            weekoff = false;
        }
    }else {
        weekoff = true;
    }

    if(!qcheck && (tierval =='tr1' || tierval =='tr2' || tierval =='av') && doclength >= 0 && needtranscript != true && languagebased && weekoff != true) {
        var rushopts = jc('input[name=rushopts]:checked', '#translationForm').val();
        var opts     = expeditedarr[tierval][doclength];
        var optslist = '<div class="text-center tatdes">Turnaround time</div>';

        opts = reverseArr(opts);
        jc.each( opts, function(tiers,tats) {
            var checked  = '';
            var rushname = '';
            if(tiers == 3){
                rushname = ' (Express delivery)';
            }else if(tiers == 2){
                rushname = ' (Super rush delivery)';
            }else if(tiers == 1){
                rushname = ' (Rush delivery)';
            }else if(tiers == 0){
                rushname = ' (Standard delivery)';
                checked ='checked';
            }
            optslist += '<div class="col-xs-12 col-sm-10 col-md-8 col-lg-6 rush-padding">'
                +'<label>'
                +'<p class="pull-left fr_pull-left"> <input type="radio" id="rushopts'+tiers+'" onclick="paytc_pricequoteclac();" class="capturedata form-check-input" name="rushopts" value="'+tiers+'" '+checked+' > </p>'
                +'<p class="fr_pay-left"><span id="tat-val'+tiers+'">'+tats+rushname+'</span></p>'
                +'</label>'
                +'</div>';
        });


        var tataval0 = jc('#tat-val'+0).html();
        var tataval1 = jc('#tat-val'+1).html();
        var tataval2 = jc('#tat-val'+2).html();
        var tataval3 = jc('#tat-val'+3).html();

        var artataval0 = [];
        var artataval1 = [];
        var artataval2 = [];
        var artataval3 = [];

if(typeof tataval0 !== 'undefined'
    && typeof tataval1 !== 'undefined'
    && typeof tataval2 !== 'undefined'
    && typeof tataval3 !== 'undefined') {

    artataval0 = tataval0.split(' (');
    artataval1 = tataval1.split(' (');
    artataval2 = tataval2.split(' (');
    artataval3 = tataval3.split(' (');
}



        if(opts[0] == artataval0[0]
            && opts[1] == artataval1[0]
            && opts[2] == artataval2[0]
            && opts[3] == artataval3[0]) {
            jc('#rushopts'+rushopts).attr('checked', 'checked');
        }else{
            jc('#expedited-timeline').html("");
            jc('#expedited-timeline').html(optslist);
        }

        jc("#delivery-timeline").hide();
        jc("#expedited-timeline").show();
    }else{
         jc("#expedited-timeline").hide();
         jc("#delivery-timeline").show();
    }

    paytc_pricequoteclac();
}

function validatepay(elem){
    var thiselem = jc(elem).attr("id");
    jc('.del-time,#srclang_chosen,#trglang_chosen').removeClass('focusing');
    var sourcefiletype  = jc("#sourcefiletype option:selected").val();
    var prfilelength    = (!isNaN(parseInt(jc('#prfilelength').val()))) ? parseInt(jc('#prfilelength').val()) : 0;
    var pagecount       = (!isNaN(parseInt(jc('#pagecount').val()))) ? parseInt(jc('#pagecount').val()) : 0;
    var srclang         = jc("#srclang option:selected").val();
    var srctier         = jc("#srclang option:selected").data('tier');
    var trglang         = jc("#trglang option:selected").val();
    var trgtier         = jc("#trglang option:selected").data('tier');
    var deliveryReq     = jc('input[name=deliveryReq]:checked', '#translationForm').val();
    var rushopts        = jc('input[name=rushopts]:checked', '#translationForm').val();
    var paytc_qemailcrm = jc("#paytc_qemailcrm").val();
    var mailfilecrmpay  = jc("#mailfilecrmpay").is(':checked') ? 1 : 0;
    var mailcountry     = jc("#mailcountry option:selected").val();
    var mailingaddr    = jc("#paytc_mailaddress").val();
    var standaredview = jc('#delivery-timeline').is(':visible') ? 1 : 0;
    var fileupload_tat = jc("#fileupload_tat").val();
    var needtranscript  = jc("#needtranscript").is(':checked') ? 1 : 0;
    var deliverytime    = jc('#delivery-timeline').is(':visible');
    paytc_pricequoteclac();
    var focus_txt = (sourcefiletype == 1)?"to view the price.":"to get a price quote.";
    var msgs = '';
    if(sourcefiletype == '') {
        msgs = "Select <b class='text-highlight'>file type</b> "+focus_txt;
        jc('#sourcefiletype').addClass("errmsg");
    }else{
        jc('#sourcefiletype').removeClass("errmsg");
    }
    if((sourcefiletype == 1 || sourcefiletype == "" ) && (pagecount == 0 || pagecount == '')){
        if(msgs == '') {
            msgs = "Enter <b class='text-highlight'>page count</b> " + focus_txt;
        }
        showerr();
        if(thiselem == "sourcefiletype"){
            jc(".qt_msg").html(msgs);
            return false;
        }
        jc('#pagecount').addClass("errmsg");
        jc('#pagecount').closest('span').find('.fr_input-group-addon').addClass("errmsg");
    }else{
        jc('#pagecount').removeClass("errmsg");
        jc('#pagecount').closest('span').find('.fr_input-group-addon').removeClass("errmsg");
    }

    if(sourcefiletype == 2 && (prfilelength == 0 || prfilelength == '')){
        if(msgs == '') {
            msgs = "Enter <b class='text-highlight'>file length</b> " + focus_txt;
        }
        showerr();
        if(thiselem == "sourcefiletype"){ jc(".qt_msg").html(msgs); return false; }
        jc('#prfilelength').addClass("errmsg");
        jc('#prfilelength').closest('span').find('.fr_input-group-addon').addClass("errmsg");
    }else{
        jc('#prfilelength').removeClass("errmsg");
        jc('#prfilelength').closest('span').find('.fr_input-group-addon').removeClass("errmsg");
    }
    if(srclang == ''){
        if(msgs == '') {
            msgs = "Select <b class='text-highlight'>source language</b> " + focus_txt;
        }
        if(thiselem == "prfilelength" || thiselem == "pagecount"){ jc(".qt_msg").html(msgs); return false;}
        jc('#srclang_chosen .chosen-single').addClass("errmsg");
    }else{
        jc('#srclang_chosen .chosen-single').removeClass("errmsg");
    }
    if(trglang == ''){
        if(msgs == '') {
            msgs = "Select <b class='text-highlight'>target language</b> " + focus_txt;
        }
        if(thiselem == "srclang"){ jc(".qt_msg").html(msgs); return false;}
        jc('#trglang_chosen .chosen-single').addClass("errmsg");
    }else{
        jc('#trglang_chosen .chosen-single').removeClass("errmsg");
    }

    if(thiselem == "trglang"){ jc(".qt_msg").html(msgs); return false;}
    jc(".qt_msg").html(msgs);
}
jc( document ).on('blur change','.del-time', function() {
    //mandvalidation(this);
    validatepay(this);
    checktarget();
});
jc( document ).on('change keyup','.del-time', function() {
    deltime();
    checktarget();
});
function deltime(){
    var sourcefiletype  = jc("#sourcefiletype option:selected").val();
    var prfilelength    = (!isNaN(parseInt(jc('#prfilelength').val()))) ? parseInt(jc('#prfilelength').val()) : 0;
    var pagecount       = (!isNaN(parseInt(jc('#pagecount').val()))) ? parseInt(jc('#pagecount').val()) : 0;
    var srclang         = jc("#srclang option:selected").val();
    var srctier         = jc("#srclang option:selected").data('tier');
    var trglang         = jc("#trglang option:selected").val();
    var trgtier         = jc("#trglang option:selected").data('tier');
    var deliveryReq     = jc('input[name=deliveryReq]:checked', '#translationForm').val();
    var rushopts        = jc('input[name=rushopts]:checked', '#translationForm').val();
    var paytc_qemailcrm = jc("#paytc_qemailcrm").val();
    var mailfilecrmpay  = jc("#mailfilecrmpay").is(':checked') ? 1 : 0;
    var mailcountry     = jc("#mailcountry option:selected").val();
    var needtranscript  = jc("#needtranscript").is(':checked') ? 1 : 0;

    if(srclang != ""){
        jc(".needtrc-blk").show();
        jc("#needtrclang").html(language_list[srclang]);
    }else{
        jc(".needtrc-blk").hide();
    }

    if((sourcefiletype == 1 && pagecount >= 10) || (sourcefiletype == 2 && prfilelength >= 60)){
        jc(".freetrial").show();
    }else{
        jc(".freetrial").hide();
    }

    //jc('.qt_msg').html('Enter the details to view the price..');
    if(sourcefiletype == ''
        || ((sourcefiletype == 1 && pagecount == '') || (sourcefiletype == 2 && prfilelength == '' ))
        || srclang == ''
        || trglang == ''){
        jc('.u-email').hide();
        jc('.pt').hide();
        jc('.qt').hide();
        jc('.no-summary').show();
        jc('.order-summary').hide();
    }else {
        showtimeline();
        paytc_pricequoteclac();
        var deliverytime    = jc('#delivery-timeline').is(':visible');
        var expdtdtime = jc('#expedited-timeline').is(':visible');
        if (sourcefiletype == 2) {
            jc('.qt_msg').html('Customized rates apply for Audio/Video.');
            showquote();
            return false;
        }
        if((jc.inArray(srclang, trclang) == -1) && sourcefiletype == 2 && needtranscript){
            jc('.qt_msg').html('Customized rates apply for the languages you selected.');
            showquote();
            return false;
        }
        if(sourcefiletype == 1 && pagecount > 20){
            jc('.qt_msg').html('Customized rates apply for documents above 20 pages.');
            showquote();
            return false;
        }
        if((srclang != 90 && trglang != 90) ||((language_list[srclang] in tirelanguage) == false) || ((language_list[trglang] in tirelanguage) == false)){
            jc('.qt_msg').html('Customized rates apply for the languages you selected.');
            showquote();
            return false;
        }
        if(mailfilecrmpay && mailcountry != '' && mailcountry !=1){
            jc('.qt_msg').html('Customized rates apply for '+country_list[mailcountry]+'.');
            showquote();
            return false;
        }
        if(deliveryReq == 'option2' && deliverytime) {
            jc('.expeditedblk').show();
            jc('.qt_msg').html('Customized rates apply for expedited service.');
            showquote();
            return false;
        }
        // if((deliveryReq == 'option1') && deliverytime) {
         if((deliveryReq == 'option1')) {
            jc('.expeditedblk').hide();
            showpay();
            return false;
        }
         if(rushopts != '' && expdtdtime) {
        // if(rushopts != '') {
            jc('.expeditedblk').hide();
            showpay();
            return false;
        }
        //console.log(rushopts+"||"+expdtdtime);
        showquote();
    }
}
/* TAT calculation end */
function eligibility() {
    var mailcountry = jc('#mailcountry option:selected').val();
    var paytc_mailaddresspay = jc('#paytc_mailaddresspay').val();
    var mailfilecrmpay = jc('#mailfilecrmpay').is(':checked');
    
    if(mailcountry !='' && mailcountry != 'United States'){
        jc('#uploadat').val('fileupload');
    }else{
        jc('#uploadat').val('fileuploadpay');
    }
}
/*show mailing country start Quote*/
jc( document ).on('change','#mailfilecrm,#sourcefiletype', function() {
    var mailfilecrm = jc('#mailfilecrm').is(':checked');
    if (mailfilecrm){
        jc('.mail_country').show();
    }else{
        jc('#mailcountrycrm').prop('selectedIndex',0);
        jc('.mail_country').hide();
    }
});
/*show mailing country end Quote*/

/*show mailing country start*/
jc( document ).on('change','#mailfilecrmpay,#sourcefiletype', function() {
    var mailfilecrmpay = jc('#mailfilecrmpay').is(':checked');
    var sourcefiletype     = jc("#sourcefiletype option:selected" ).val();
    if (mailfilecrmpay && sourcefiletype){
        jc('.mailedyes').show();
    }else{
        jc('.mailedyes').hide();
    }
});
/*show mailing country end*/

function remove_allfiles(){
    jc('.up-close').each(function() {
        jc(this).trigger("click");
    });
}
function uncheckall(){
    jc('#qtvercrmpay,#qttcodecrmpay,#nativecrmpay').prop('checked', false);

}


function isNumberKeyq(evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode;
    if (charCode != 45 && charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
    return true;
}
function notThislang(){
    var selectedlang = jc( "#srclang option:selected" ).val();
    var selectedtrs = jc( "#trglang option:selected" ).val();
    var trsopt='<option value=""></option>';
    var seltrgtlang;
    jc.each( language_list, function(r,x) {
        seltrgtlang='';
        if(r != selectedlang || r == ""){
            if(selectedtrs == r){
                seltrgtlang ='selected="selected"';
            }
            var tgtiername = (tirelanguage[x]) ? tirelanguage[x] : "Other";
            trsopt += '<option data-tier="'+tgtiername+'" '+seltrgtlang+' value="'+r+'">'+x+'</option>';
        }
    });
    if(trsopt != '') {
        jc('#trglang')
            .find('option')
            .remove()
            .end()
            .append(trsopt);
    }
    jc('#trglang').trigger('chosen:updated');
    jc(".chosen-search-input").attr("placeholder", "Type here");
}

jc( document ).on('click','#qttcodecrmpay', function() {
    if(jc("#qttcodecrmpay").prop('checked') == true){
        jc(".timecodeneed").show();
    }else{
        jc("#howoftn").val("");
        jc("#spkrchange").prop('checked', false);
        jc(".timecodeneed").hide();
    }
});
window.onload = function() {
    notThislang();
    jc(".chosen-search-input").attr("placeholder", "Type here");
};

/* here js */
var source1;
var target;
var valFind;
jc(document).ready(function() {
	var bs_url = window.location;
    var base_urls = bs_url.protocol + "//" + bs_url.host;
    var isVisible = jc('#fileuploader').is(':visible');
	if(isVisible == false){
		jc.ajax({
			url:base_urls+'/logdetails.php',
			data : 'siteurl='+base_urls,                       
			type: 'POST',
			success: function(data){
			}
		});
	}
});




/* here qsubmit */
jc(document).on('click','.qsubmitcrm', function(e) {
    var reg        = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
    var buttonname = jc(this).attr('value');
    var sourcefiletype = jc("#sourcefiletype option:selected").val();
    var pagecount      = '';
    var prfilelength   = '';
    var qttcode        = '';
    var notacrmpay     = '';
    var mailfilecrmpay = '';
    var mailcountry    = '';
    var mailingaddr    = '';
    var deliveryReq    = '';
    var needtranscript = '';
    var nativespkr     = '';
    var qcheck         = '';
    var trgtunitcost   = 0.00;
    var trgttotamt     = 0.00;
    var nota_subamt    = 0.00;
    var notapro_subamt = 0.00;
    var mfile_subamt   = 0.00;
    var subamttot      = 0.00;
    var transactionfee = 0.00;
    var paymentamt     = 0.00;
    var trcunitcost_val = 0.00;
    var tottrl_subamt   = 0.00;
    var mini_subamt     = 0.00;
    var timecode_subamt = 0.00;
    var trc_totamt      = 0.00;
    var expd_subamt     = 0.00;
    var cert_subamt     = 0.00;
    var qcheck_subamt   = 0.00;

    var filena      = new Array();
    var files       = '';
    var UploadFlag  = uploadProgress;
    filena          = [];
    var uploadat    = jc("#uploadat").val();
    var certlang = '';
    deliveryReq = jc('#expedited').is(":checked")?1:0;
    if(jc("#notacrmpay").is(':visible')) {
        notacrmpay = jc("#notacrmpay").is(':checked') ? 1 : 0;
    }else{
        certlang = jc("#certlang").is(':checked') ? 1 : 0;
    }
    mailfilecrmpay = jc("#mailfilecrmpay").is(':checked') ? 1 : 0;
    qcheck         = jc("#qcheck").is(':checked') ? 1 : 0;
    mailcountry    = jc("#mailcountry option:selected").val();
    mailingaddr    = jc("#paytc_mailaddress").val();

    if (buttonname != "Get Quote") {
        trgtunitcost    = jc("#trgt_unitcost").val();
        trgttotamt      = jc("#trgt_totamt").val();
        if(notacrmpay == 1) {
            nota_subamt    = jc("#nota_subamt").val();
            notapro_subamt = jc("#notapro_subamt").val();
        }else if(certlang == 1) {
            cert_subamt    = jc("#cert_subamt").val();
        }
        if(qcheck) {
            qcheck_subamt = jc('#qcheck_subamt').val();
        }
        mfile_subamt    = jc("#mfile_subamt").val();
        subamttot       = jc("#subamttot").val();
        transactionfee  = jc("#trans_price").val();
        paymentamt      = jc("#paymentamt").val();
        trcunitcost_val = jc("#trcunitcost_val").val();
        tottrl_subamt   = jc("#tottrl_subamt").val();
        mini_subamt     = jc("#mini_subamt").val();
        timecode_subamt = jc("#timecode_subamt").val();
        trc_totamt     = jc("#trc_totamt").val();
    }
    if (sourcefiletype == 1){
        pagecount      = jc("#pagecount").val();
    }
    else if(sourcefiletype == 2){
        prfilelength   = jc("#prfilelength").val();
        qttcode        = jc('#qttcodecrm').is(":checked") ? 1 : 0;
        needtranscript = jc("#needtranscript").is(':checked') ? 1 : 0;
        nativespkr     = jc("#nativespkr").is(':checked') ? 1 : 0;
    }
    var srclang        = jc("#srclang").val();
    var trglang        = jc("#trglang").val();
    var aprxtat        = '';
    var rushopts       = '';
    var fileupload_tat = '';
    var rushview      = jc('#expedited-timeline').is(':visible') ? 1 : 0;
    var standaredview = jc('#delivery-timeline').is(':visible') ? 1 : 0;
    if (rushview) {
        rushopts      = jc('input[name=rushopts]:checked', '#translationForm').val();
        aprxtat       = jc("#tat-val" + rushopts).html();
        if(rushopts != 0) {
            deliveryReq = 1;
        }
        expd_subamt = jc('#expd_subamt').val();
    } else if (standaredview) {
        deliveryReq        = jc('#expedited').is(":checked") ? 1 : 0;
        if(deliveryReq) {
            fileupload_tat = jc("#fileupload_tat").val();
        }else {
            aprxtat = jc("#tat-val").html();
        }
    }

    var email          = jc('#paytc_qemailcrm').val();
    var agent_ref      = jc("#agent_ref").val();
    var form_data      = new FormData();
    var eaddress       = email;


    var recordkeyval = jc('#recordkey').val();
    var service      = jc('#service').val();
    var sitename     = jc("#site_namee").val();
    var camethrough  = jc("#camethrough").val();
    var cst_db       = jc("#cst_db").val();
    var source       = srclang;
    var target       = trglang;


    jc( ".fileNamepay" ).each(function( index ) {
        elemval = jc( this ).val().trim();
        filena.push(elemval);

    });
    var filesserid = jc("input[name='uploadFiles[]']")
        .map(function () {
            return jc(this).data('serid');
        }).get();

    var i               = 0;
    var fildetail       = [];
    var duratnval       = [];
    var tempfildetail   = '';
    var tempdur         = '';

    jc.each(filesserid, function (index, value) {
        i = value;
        tempfildetail = jc("#uploadFiles-"+i).val().trim();
        fildetail.push(tempfildetail);

        tempdur = jc("#durationnewpay-"+i).val().trim();
        duratnval.push(tempdur);

    });

    var count            = filena.length;
    var completedfilecnt = jc('.audioLengths:visible').length;
    var filecomments     = jc('#filecomments').val();
    var ofpct            = jc("#ofpct").html();
    var offerpct         = jc("#offerpct").val();
    var offerval         = jc("#offerval").val();
    var finalround       = jc("#finalround").val();
    if (offerpct <= 0 && offerval <= 0) {
        offerval   = 0;
        finalround = 0;
        ofpct      = '';
    }
    var siteprtcl        = jc('#siteprtcl').val();
    var frtrial          = jc('#frtrial').is(":checked")?1:0;

    form_data.append('completedfilecnt', completedfilecnt);
    form_data.append('count', count);
    form_data.append('fildetail', fildetail);
    form_data.append('duratnval', duratnval);
    form_data.append('filena', filena);
    form_data.append('uploadflag', UploadFlag);
    form_data.append('recordkey', recordkeyval);
    form_data.append('sourcefiletype',sourcefiletype);
    form_data.append('prfilelength',prfilelength);
    form_data.append('pagecount',pagecount);
    form_data.append('source', source);
    form_data.append('target', target);
    form_data.append('cst_db',cst_db);
    form_data.append('fileupload_tat', fileupload_tat);
    form_data.append('notacrmpay',notacrmpay);
    form_data.append('certlang',certlang);
    form_data.append('mailfilecrmpay',mailfilecrmpay);
    form_data.append('mailcountry',mailcountry);
    form_data.append('mailingaddr',mailingaddr);
    form_data.append('needtranscript',needtranscript);
    form_data.append('nativespkr',nativespkr);

    form_data.append('qttcode', qttcode);
    form_data.append('uploadat', uploadat);
    form_data.append('email', email);
    form_data.append('trgtunitcost',trgtunitcost);
    form_data.append('trgttotamt',trgttotamt);
    form_data.append('nota_subamt',nota_subamt);
    form_data.append('notapro_subamt',notapro_subamt);
    form_data.append('cert_subamt',cert_subamt);
    form_data.append('mfile_subamt',mfile_subamt);
    form_data.append('subamttot', subamttot);
    form_data.append('transactionfee', transactionfee);
    form_data.append('paymentamt', paymentamt);
    form_data.append('trc_totamt', trc_totamt);
    form_data.append('expd_subamt', expd_subamt);

    form_data.append('trcunitcost_val', trcunitcost_val);
    form_data.append('tottrl_subamt', tottrl_subamt);
    form_data.append('mini_subamt', mini_subamt);
    form_data.append('timecode_subamt', timecode_subamt);

    form_data.append('agent_ref', agent_ref);
    form_data.append('rushopts', rushopts);
    form_data.append('aprxtat', aprxtat);
    form_data.append('camethrough', camethrough);
    form_data.append('service', service);
    form_data.append('sitename', sitename);
    form_data.append('deliveryReq',deliveryReq);
    form_data.append('buttonname', buttonname);
    form_data.append('filecomments', filecomments);
    form_data.append('qcheck', qcheck);
    form_data.append('qcheck_subamt', qcheck_subamt);
    form_data.append('offerval', offerval);
    form_data.append('finalround', finalround);
    form_data.append('ofpct', ofpct);
    form_data.append('siteprtcl', siteprtcl);
    form_data.append('frtrial', frtrial);
    form_data.append('uploadedFileDetailsArr', uploadedFileDetailsArr);

    jc('#sourcefiletype').removeClass("errmsg");
    jc('#pagecount').removeClass("errmsg");
    jc('#pagecount').closest('span').find('.fr_input-group-addon').removeClass("errmsg");
    jc('#prfilelength').removeClass("errmsg");
    jc('#prfilelength').closest('span').find('.fr_input-group-addon').removeClass("errmsg");
    jc('#srclang_chosen .chosen-single').removeClass("errmsg");
    jc('#trglang_chosen .chosen-single').removeClass("errmsg");
    jc('#mailcountry_chosen .chosen-single').removeClass("errmsg");
    jc('#paytc_mailaddress').removeClass("errmsg");
    jc('#fileupload_tat').removeClass("errmsg");
    jc('input[id^="durationnewpay-"]').removeClass("errmsg");
    jc('#paytc_qemailcrm').removeClass("errmsg");


    if(sourcefiletype == ''){
        jc('#sourcefiletype').tooltip({title: "File type is required!"});
        jc('#sourcefiletype').focus();
        jc('#sourcefiletype').keypress(function () {
            jc('#sourcefiletype').tooltip('destroy');
        });
        return false;
    }
    if(sourcefiletype == 1 && (pagecount == '' || pagecount ==0)){
        jc('#pagecount').tooltip({title: "Page count is required!"});
        jc('#pagecount').focus();
        jc('#pagecount').keypress(function () {
            jc('#pagecount').tooltip('destroy');
        });
        return false;
    }
    if(sourcefiletype == 2 && (prfilelength == '' || prfilelength ==0)){
        jc('#prfilelength').tooltip({title: "File length is required!"});
        jc('#prfilelength').focus();
        jc('#prfilelength').keypress(function () {
            jc('#prfilelength').tooltip('destroy');
        });
        return false;
    }
    if(srclang ==''){
        jc('#srclang_chosen').tooltip({title: "Source language is required !"});
        jc('#srclang_chosen').trigger("mousedown");
        jc('#srclang').change(function() {
            jc('#srclang').tooltip('destroy');
        });
        return false;
    }
    if(trglang == ''){
        jc('#trglang_chosen').tooltip({title: "Target language is required !"});
        jc('#trglang_chosen').trigger("mousedown");
        jc('#trglang').change(function() {
            jc('#trglang').tooltip('destroy');
        });
        return false;
    }

    if(mailfilecrmpay && mailcountry =='') {
        jc('#mailcountry_chosen').tooltip({title: "Country is required!"});
        jc('#mailcountry_chosen').trigger("mousedown");
        //jc('#mailcountry_chosen .chosen-single').addClass("errmsg");
        jc('#mailcountry').change(function () {
            jc('#mailcountry').tooltip('destroy');
        });
        return false;
    }
    if(mailfilecrmpay && mailingaddr ==''){
        jc('#paytc_mailaddress').tooltip({title: "Physical address is required!"});
        jc('#paytc_mailaddress').focus();
        //jc('#paytc_mailaddress').addClass("errmsg");
        jc('#paytc_mailaddress').keypress(function () {
            jc('#paytc_mailaddress').tooltip('destroy');
        });
        return false;
    }
    if(standaredview && deliveryReq == 1 && fileupload_tat ==''){
        jc('#fileupload_tat').tooltip({title: "Turnaround time is required!"});
        jc('#fileupload_tat').focus();
        //jc('#fileupload_tat').addClass("errmsg");
        jc('#fileupload_tat').keypress(function () {
            jc('#fileupload_tat').tooltip('destroy');
        });
        return false;
    }
    var filelengthvalid = true;
    var invalidlength ='';
    if(sourcefiletype == 2) {
        jc(".length").each(function (i) {
            var thisid = jc(this).attr('id');
            var arr = thisid.split('-');
            i = arr[1];
            var dur = parseInt(jc("#durationnewpay-"+i).val());
            if (isNaN(dur) || dur == '' || dur < 1) {
                /*jc("#filetypespay" + i).show();
                jc("#filetypespay" + i).removeClass("hrdisplay").addClass("errlength");
                jc("#filetypespay" + i).html("Enter file length!");*/
                filelengthvalid = false;
                invalidlength = i;
            }
        });
    }
    if(!filelengthvalid){
        jc('#durationnewpay-'+ invalidlength).tooltip({title: "Enter file length!"});
        jc('#durationnewpay-'+ invalidlength).focus();
        //jc('#durationnewpay-'+ invalidlength).addClass("errmsg");
        jc('#durationnewpay-'+ invalidlength).keypress(function () {
            jc('#durationnewpay-'+ invalidlength).tooltip('destroy');
        });
        return false;
    }
    if(email ==''){
        jc('#paytc_qemailcrm').tooltip({title: "Email id is required!"});
        jc('#paytc_qemailcrm').focus();
        //jc('#paytc_qemailcrm').addClass("errmsg");
        jc('#paytc_qemailcrm').keypress(function () {
            jc('#paytc_qemailcrm').tooltip('destroy');
        });
        return false;
    }
    if(email !='' && (reg.test(email.trim()) == false)){
        jc('#paytc_qemailcrm').tooltip({title: "Email id is invalid!"});
        jc('#paytc_qemailcrm').focus();
        //jc('#paytc_qemailcrm').addClass("errmsg");
        jc('#paytc_qemailcrm').keypress(function () {
            jc('#paytc_qemailcrm').tooltip('destroy');
        });
        return false;
    }

    jc('.qt,.pt').html('Processing...');
    jc('.qt,.pt').hide();
    jc('.pr').show();
    jc.ajax({
        url:update_quote,
        dataType: 'json',  // what to expect back from the PHP script, if anything
        //cache: false,
        contentType: false,
        processData: false,
        data: form_data,
        type: 'POST',
        success: function(data){
            if (uploadat == "fileuploadpay" && buttonname == "Proceed to Payment") {
                jc('#item_number_1').val(data.ordsid);
                jc("#translationForm").submit();
                //jc('#qsubmitcrm').html('processing...');
                return false;
            }
            else{
                if(data.type == 'quote' && data.status == 1){
                    jc('#quoteflag').val(data.status);
                    quoteInfo = data.info;
                }
                if(data.type == 'error'){
                    output = data.text;
                }
                else{
                    jc('#qfmsgcrm').html('');
                    output = data.text;
                    if(output=='Your request has been sent successfully and you will receive an email from us shortly. Thank you!'){
                        if (successpath) {
                            var redurl = "http://"+successpath+"/additional-information.php?id="+data.param;
                            location.href = redurl;
                        }
                        else{
                            jc('#qfmsgcrm').html(output);
                            window.setTimeout(function () {
                                location.reload()
                            }, 7000);
                        }
                    }
                    else{
                        jc('#qfmsgcrm').html(output);
                        jc('#qfmsgcrm').css({'color':'#333'});
                    }
                }
            }
        },
        error : function (xhr, status, error) {
            jc("#qsubmitcrm").removeAttr('disabled');
        }
    });
});
function paytc_pricequoteclac() {
    var sourcefiletype = jc("#sourcefiletype option:selected").val();
    var srclang        = jc("#srclang option:selected").val();
    var trglang        = jc("#trglang option:selected").val();
    var pagecount      = jc("#pagecount").val();
    var prfilelength = (jc("#prfilelength").val() == '')? 0 : jc("#prfilelength").val();
    var deliveryReq    = jc('input[name=deliveryReq]:checked', '#translationForm').val();
    var rushopts       = jc('input[name=rushopts]:checked', '#translationForm').val();

    var minVal = jc("input[name='length[]']")
        .map(function () {
            return jc(this).val();
        }).get();

    var serialId = jc("input[name='uploadFiles[]']")
        .map(function () {
            return jc(this).data('serid');
        }).get();
    var len = minVal.length;
    var min = 0;
    var i = 0;
    for (i = 0; i < len; i++) {
        if (!isNaN(min) && !isNaN(minVal[i]) && minVal[i] != '') {
            min = parseInt(min) + parseInt(minVal[i]);
        }
    }
    if (isNaN(min)) {
        min = 0;
    }
    if(i > 0) {
        prfilelength = min;
        jc('#prfilelength').val(prfilelength);
    }
//        jc('.expeditedblk').hide();
        jc('.notary-pr,.mailed-pr').hide();
        var total = 0;
        var language = jc('#srclang').val();
        if((language_list[language] in tirelanguage ) == true ) {
            var min            = 0;
            var price          = 0;
            var cost           = 0;
            var Transactionfee = '';
            var srctier        = jc("#srclang option:selected").data('tier');
            var trgtier        = jc("#trglang option:selected").data('tier');

            var notacrmpay = false;
            var certlang = false;
            if(jc("#notacrmpay").is(":visible")) {
                notacrmpay = jc("#notacrmpay").is(":checked");
            }else if(jc("#certlang").is(":visible")) {
                certlang = jc("#certlang").is(":checked");
            }

            var mailfilecrmpay = jc("#mailfilecrmpay").is(":checked");
            var qcheck         = jc("#qcheck").is(":checked");
            var qttcodecrm     = jc("#qttcodecrm").is(":checked");
            var needtranscript = jc("#needtranscript").is(":checked");
            var nativespkr     = jc("#nativespkr").is(":checked");
            var mailcountry    = jc("#mailcountry option:selected").val();


            var trgttierind = trgtier;
            var srctiercost = 0;
            var trgtiercost = 0;

            /* PRICE CALCULATIONS FOR DOCUMENT START */
            jc('.discount-pr').hide();

            if (sourcefiletype == 1 && srctier != "Other" && trgtier != "Other") {
                if (srclang == 90) {
                    trgttierind = trgtier;
                } else if (trglang == 90) {
                    trgttierind = srctier;
                }

                price = (trgttierind) ? tierarray[trgttierind]['tier_price'] : 0;
                if((srclang != '' && srclang == 90 && (trgtier == 'tr1' || trgtier == 'tr2')) || (trglang != '' && trglang == 90 && (srctier == 'tr1' || srctier == 'tr2'))) {
                    price = 25.00;
                }

                if (trglang != 90 && srclang != 90) {
                    if (srctier == trgtier) {
                        jc('.trlhelp').show();
                        var trlhelptool = language_list[srclang]+" to "+language_list[90]+ ": $"+price+"/Page <br>"+
                                            language_list[90]+" to "+language_list[trglang]+ ": $"+price+"/Page";
                        jc('#trltooltip').attr('title',trlhelptool);
                        price = (price * 2);
                    } else {
                        srctiercost = (srctier) ? tierarray[srctier]['tier_price'] : 0;
                        trgtiercost = (trgtier) ? tierarray[trgtier]['tier_price'] : 0;
                        // srctiercost = (catetype != "General" && catetype != "Legal" && catetype != "Handwritten" && catetype != "Handwritten" && srctiercost < 30) ? 30 : srctiercost;
                        // trgtiercost = (catetype != "General" && catetype != "Legal" && catetype != "Handwritten" && catetype != "Handwritten" && trgtiercost < 30) ? 30 : trgtiercost;
                        price       = parseFloat(srctiercost) + parseFloat(trgtiercost);
                        jc('.trlhelp').show();
                        var trlhelptool = language_list[srclang]+" to "+language_list[90]+ ": $"+srctiercost+"/Page<br>"+
                            language_list[90]+" to "+language_list[trglang]+ ": $"+trgtiercost+"/Page"
                        jc('#trltooltip').attr('title',trlhelptool);

                    }
                }else{
                    jc('.trlhelp').hide();
                }

                cost  = parseFloat(pagecount) * price;

            }
            /* PRICE CALCULATIONS FOR DOCUMENT END */
            /* PRICE CALCULATIONS FOR AUDIO/VIDEO START */
            else{
                jc('.trlhelp').hide();
            }

            if((srclang == 90 || trglang == 90)&& (pagecount > 20)){
                price -= price* 0.2;
                cost -= cost*0.2;
                jc('.discount-pr').show();
            }

            total = parseFloat(total) + parseFloat(cost);
            paytc_showsubtotal();

            /* PRICE CALCULATIONS FOR AUDIO/VIDEO END */



            jc("#trgtunitcost_disp").html(price.toFixed(2));
            jc("#trgt_unitcost").val(price.toFixed(2));
            jc('#trgt_tot').html(total.toFixed(2));
            jc('#trgt_totamt').val(total.toFixed(2));
            var notacost        = 5.00;
            var notaprocesscost = 10.00;
            var certfee         = 10.00;
            var mailfilecost    = 20.00;
            var timecodecost    = 1.00;
            if (sourcefiletype) {
                if(needtranscript && sourcefiletype == 2 && ((srclang in trclang) == false)){
                    var trcprice = 0;
                    var trcpricetot = 0;
                    if(srclang == 90){
                        trcprice = (nativespkr)?1.75:0.99;
                    }else{
                        trcprice = 5.00;
                    }
                    trcpricetot =  parseFloat(trcprice)*parseFloat(prfilelength);
                    total += parseFloat(trcpricetot);
                    jc('#trc_tot').html(trcpricetot.toFixed(2));
                    jc('#trc_totamt').val(trcpricetot.toFixed(2));
                    jc('#trcunitcost_disp').html(trcprice.toFixed(2));
                    jc('#trcunitcost_val').val(trcprice.toFixed(2));
                    jc('.trc-pr').show();
                    //jc('.totaltrl-pr').show();
                }
                else{
                    jc('#trc_tot').html('0.00');
                    jc('#trc_totamt').val(0.00);
                    jc('#trcunitcost_disp').val(0.00);
                    jc('#trcunitcost_val').val(0.00);
                    jc('.trc-pr').hide();
                    //jc('.totaltrl-pr').hide();
                }
                if(qttcodecrm && sourcefiletype == 2){
                    var timecodetotal =  parseFloat(timecodecost)*parseFloat(prfilelength);
                    total += parseFloat(timecodetotal);
                    jc('#timecode_sub_amt').html(timecodetotal.toFixed(2));
                    jc('#timecode_subamt').val(timecodetotal.toFixed(2));
                    jc('.timecode-pr').show();
                }
                else{
                    jc('#timecode_sub_amt').html('0.00');
                    jc('#timecode_subamt').val(0.00);
                    jc('.timecode-pr').hide();
                }

                        jc('#tottrl_sub_amt').html(total.toFixed(2));
                        jc('#tottrl_subamt').val(total.toFixed(2));
                    var mini_ordcost = 50.00;
                    if (total < mini_ordcost && sourcefiletype == 2) {
                        jc('#tottrl_sub_amt').html(total.toFixed(2));
                        jc('#tottrl_subamt').val(total.toFixed(2));
                        total = mini_ordcost;
                        jc('#mini_sub_amt').html(mini_ordcost.toFixed(2));
                        jc('#mini_subamt').val(mini_ordcost.toFixed(2));
                        jc('.minimum-pr').show();
                    } else {
                        jc('.minimum-pr').hide();
                    }

                var rushview = jc('#expedited-timeline').is(':visible');
                
                if(!isNaN(parseInt(rushopts)) && rushview){
                    
                    var expd=0;
                    if(rushopts == 3){
                        expd = 1.5;
                    }else if(rushopts == 2){
                        expd =1;
                    }else if(rushopts == 1){
                        expd = 0.5;
                    }
                    jc("#expd_subamt").val(0);
                    if(expd > 0){
                        var expedited = total*expd;
                        total +=parseFloat(expedited);
                        var rushtat       = jc("#tat-val" + rushopts).html();
                        var rushperctge = expd*100
                        jc('#exptooltip').prop('title', rushperctge+'% Expedited service fee applies as you have chosen '+rushtat+' as the turnaround time.');
                        jc("#expd_sub_amt").html(expedited.toFixed(2));
                        jc("#expd_subamt").val(expedited.toFixed(2));
                        jc('.expd-pr').show();
                    }else{
                        jc('.expd-pr').hide();
                        jc("#expd_subamt").val(0);
                    }
                }else {
                    jc('.expd-pr').hide();
                }


                if (certlang && total != "" && total != 0) {
                    total += parseFloat(certfee);

                    jc('#cert_sub_amt').html(certfee.toFixed(2));
                    jc('#cert_subamt').val(certfee.toFixed(2));
                    jc('.cert-pr').show();
                }
                else {
                    jc('.cert-pr').hide();
                    jc('#cert_sub_amt').html('0.00');
                    jc('#cert_subamt').val('0.00');
                }

                if (notacrmpay && total != "" && total != 0) {
                    total += parseFloat(notacost) + parseFloat(notaprocesscost);

                    jc('#nota_sub_amt').html(notacost.toFixed(2));
                    jc('#nota_subamt').val(notacost.toFixed(2));
                    jc('#notapro_sub_amt').html(notaprocesscost.toFixed(2));
                    jc('#notapro_subamt').val(notaprocesscost.toFixed(2));
                    jc('.notary-pr').show();
                }
                else {
                    jc('.notafee').hide();
                    jc('#nota_sub_amt').html('0.00');
                    jc('#nota_subamt').val('0.00');
                    jc('#notapro_sub_amt').html('0.00');
                    jc('#notapro_subamt').val('0.00');
                }

                if (mailfilecrmpay && total != "" && total != 0 && (mailcountry == 1 || mailcountry == '')) {
                    total += parseFloat(mailfilecost);
                    jc('#mfile_sub_amt').html(mailfilecost.toFixed(2));
                    jc('#mfile_subamt').val(mailfilecost.toFixed(2));
                    jc('.mailed-pr').show();
                }
                else {
                    jc('.mfilefee').hide();
                    jc('#mfile_sub_amt').html('0.00');
                    jc('#mfile_subamt').val('0.00');
                }

                if (qcheck && sourcefiletype == 1) {
                    var trcqcheck =  parseFloat(5.00)*parseFloat(pagecount);
                    total += parseFloat(trcqcheck);
                    jc('#qcheck_sub_amt').html(trcqcheck.toFixed(2));
                    jc('#qcheck_subamt').val(trcqcheck.toFixed(2));
                    jc('.qcheck-pr').show();
                }else if(qcheck && sourcefiletype == 2){
                    var trcqcheck =  parseFloat(1.00)*parseFloat(prfilelength);
                    total += parseFloat(trcqcheck);
                    jc('#qcheck_sub_amt').html(trcqcheck.toFixed(2));
                    jc('#qcheck_subamt').val(trcqcheck.toFixed(2));
                    jc('.qcheck-pr').show();
                }else {
                    jc('.qcheck-pr').hide();
                    jc('#qcheck_sub_amt').html('0.00');
                    jc('#qcheck_subamt').val('0.00');
                }
            }



            jc('#sub_amt').html(total.toFixed(2));
            jc('#subamttot').val(total.toFixed(2));

            var offpct = jc("#offerpct").val();
            var offervalue = parseFloat(total * offpct);
            var sub_ttooll = (total - offervalue);

            if(offervalue > 0) {
                jc(".coupval-pr").slideDown();
            }else{
                jc(".coupval-pr").slideUp();
            }

            jc("#offerval_value").html(offervalue.toFixed(2));
            jc("#sub_total").html(sub_ttooll.toFixed(2));

            jc("#offerval").val(offervalue.toFixed(2));
            jc("#finalround").val(sub_ttooll.toFixed(2));
            total = sub_ttooll;
            Transactionfee = (total / 100) * 5;

            jc('#trans_rate').html(Transactionfee.toFixed(2));
            jc('#trans_price').val(Transactionfee.toFixed(2));
            total = total + Transactionfee;
            /*var std_delivery_time = tatCalculation(srclang, trglang, srctier, trgtier, pagecount, sourcefiletype, prfilelength);
            jc('#aprx-tat').html(std_delivery_time);*/
            jc('#paymentamt').val(total.toFixed(2));
            jc('#totalfilelength').val(min);
            jc('#price_display').html(total.toFixed(2));
            jc('#amount').val(total.toFixed(2));

        }
}

function  paytc_showsubtotal(){
    jc('#time_rate').show();
    jc('#verb_rate').show();
    jc(".rate-show1").show();
    jc(".rate-show2").show();
    jc('#verb_rate').html('$0.00');
    jc('#time_rate').html('$0.00');
}
function tohour(durminutes){
    var hours = Math.floor( durminutes / 60);
    var minutes = (durminutes % 60).toFixed(0);
    hours = pad(hours, 2);
    minutes = pad(minutes, 2);
    return duhrs = parseFloat(hours+"."+minutes);
}
function paytc_resetVariables() {
    sureUploadSize = 0, probableUplaodSize = 0;
    partsLeft = [];
    cancelFlag             = false
    fileuploadstatus       = [];
    uploadFilesArr         = [];
    uploadedFilesArr       = [];
    uploadedFileDetailsArr = [];
}
function pad(str, max) {
    str = str.toString();
    return str.length < max ? pad("0" + str, max) : str;
}
    function paytc_updateFormInfo(blurdataInfo) {
        var sourcefiletype          = jc("#sourcefiletype option:selected").val();
        //var expedited               = jc("#expedited").is(':checked') ? 'Yes' : 'No';
        
        var expedited               = '';
        var rushview      = jc('#expedited-timeline').is(':visible') ? 1 : 0;
        var standaredview = jc('#delivery-timeline').is(':visible') ? 1 : 0;
        //var rushopts = '';
        var rushper = '';
        if(standaredview) {
            expedited = jc("#expedited").is(':checked') ? 'Yes' : 'No';
        }else if(rushview){
            var rushopts  = jc('input[name=rushopts]:checked', '#translationForm').val();
            expedited = (rushopts > 0)?'Yes':'No';

            if(rushopts == 3){
                rushper = '150%';
            }else if(rushopts == 2){
                rushper = '100%';
            }else if(rushopts == 1){
                rushper = '50%';
            }
        }

        var frtrial          = jc('#frtrial').is(":checked") ? 1:0;
        blurdataInfo.qemail         = jc('#paytc_qemailcrm').val();
        blurdataInfo.entryval       = jc('#recordkey').val();
        blurdataInfo.service        = jc('#service').val();
        blurdataInfo.sourcefiletype = sourcefiletype;
        blurdataInfo.srclang        = jc("#srclang option:selected").val();
        blurdataInfo.trglang        = jc("#trglang option:selected").val();
        blurdataInfo.pagecount      = jc("#pagecount").val();
        blurdataInfo.prfilelength   = jc("#prfilelength").val();
        blurdataInfo.camethrough    = jc("#camethrough").val();
        blurdataInfo.fileupload_tat = jc("#fileupload_tat").val();
        blurdataInfo.filecomments   = jc("#filecomments").val();
        blurdataInfo.qcheck         = jc("#qcheck").is(':checked') ? 'Yes' : 'No';
        blurdataInfo.expedited      = expedited;
        blurdataInfo.rushper        = rushper;
        blurdataInfo.frtrial        = frtrial;
        blurdataInfo.notary      = jc("#notacrmpay").is(':checked') ? 'Yes' : 'No';
        blurdataInfo.mailed      = jc("#mailfilecrmpay").is(':checked') ? 'Yes' : 'No';
        blurdataInfo.mailaddress = jc("#paytc_mailaddress").val();
        blurdataInfo.mailcountry = jc("#mailcountry option:selected").val();

        if (sourcefiletype == 2) {
            blurdataInfo.qttcodecrm     = jc("#qttcodecrm").is(':checked') ? 'Yes' : 'No';
            blurdataInfo.needtranscript = jc("#needtranscript").is(':checked') ? 'Yes' : 'No';
            blurdataInfo.nativespkr     = jc("#nativespkr").is(':checked') ? 'Yes' : 'No';

        }
        blurdataInfo.filedetails = uploadedFileDetailsArr.toString();
        if (jc("#sourcefiletype").val() != "any") {
            $.ajax({
                url: update_quote,
                data: {
                    fieldinfocommand: 'updatefieldinfo',
                    sitename: sitename,
                    savedata: blurdataInfo,
                    async: false,
                },
                type: 'POST',
                success: function (data) {
                    jc('#recordkey').val(data);
                }
            });
        }
    }
    //on blur data capturing - end

jc(document).ready(function () {
    jc(".capturedata").change(function () {
        var email = jc('#paytc_qemailcrm').val();
        var reg   = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
        //if (reg.test(email) == true) {
            blurdataInfo           = {};
            blurdataInfo.comments  = jc(this).val();
            blurdataInfo.fieldname = jc(this).attr('id');
            paytc_updateFormInfo(blurdataInfo);
        //}
    });
});
var ajxurl  = window.location.href;
jc.ajax({   
    url: serverPath+'client.php',
    data: 'chennal='+channel_click+'&service=Translation&version=V1.0&sitename='+originPath+'&ajxurl='+ajxurl,
    type: 'POST',
    success: function (data) {
        jc('#timespendingid').html(data);
    },
    error: function (data) {
        //alert(data);
    }
});

jc("#pagecount,#prfilelength").keyup(function (e) {
    e.target.value = e.target.value.replace(/[^\d]/g, '');
    //return false;
});
jc( document ).on('click','#applycoupon', function(){
    var couponcode = jc("#couponcode").val();
    jc.ajax({
        url:update_quote,
        dataType: 'json',
        data: { coupon: couponcode },
        type: 'POST',
        success: function(data){
            if(data == 0){
                jc("#couponmsg").removeClass("text-success").addClass("text-danger").html("Invalid coupon code!");
            }else{
                jc("#couponmsg").removeClass("text-danger").addClass("text-success").html("Coupon code applied successfully");
                jc("#ofpct").html((data*100)+"%");
            }
            jc("#offerpct").val(data);
            paytc_pricequoteclac();
        }
    });
});
/*-------- FILE UPLOAD START ------------*/
var crmupload                      = true;
var sendBackData;
var partSize                       = 50 * 1024 * 1024; // constant
var totalSize;
var sureUploadSize                 = 0, probableUplaodSize = 0;
var numParts;
var partsLeft                      = [];
var file;
var cancelFlag                     = false;
var uploadFilesArr                 = [], uploadedFilesArr = [], uploadedFileDetailsArr = [], onblurdataarray = [];
var upItem                         = 0, j = 0, InitialVal = 0;
var checkUnprocessFlag             = false;
var checkUnprocessCompletePartFlag = false;
var checkUnprocesStartingPartFlag  = false;
var stageObj                       = {"/addfiles": 1, "/signin": 2, "/payment": 3, "booked": 4};
var currentStage                   = stageObj[window.location.pathname];
var awsUrl                         = 'https://s3-ap-southeast-1.amazonaws.com/';
var uploadProgress                 = false;
var filesUploadStatus              = [];
var HOSTNAME                       = 'http://' + window.location.host;
var COSTPERMIN                     = 1;
var VERBATIMCOST                   = 0.25;
var TIMESTAMPCOST                  = 0.25;
var serialno                       = 1;
var serverpath                     = crmRootpath + "lib/";
var uploadserver                   = serverpath + "server.php";
var vendorupload                   = false;

var awsUser = 'user';

function resetParam() {
    sendBackData;
    // partSize = 5 * 1024 * 1024; // constant
    totalSize;
    sureUploadSize = 0, probableUplaodSize = 0;
    numParts;
    partsLeft = [];
    file;
    cancelFlag = false;
}

function reorder() {
    var serialno = 1;
    jc('.serialno').each(function () {
        jc(this).text(serialno);
        serialno++;
    });
}

function addFiles() {
    jc('#file').val(null);
    var uploadfile = document.getElementById("file");
    uploadfile.click();  // here i can browse the file without clicking on file brows button
}

function updateInfo(Obj) {
    var lastserialno = jc(".serialno:last").text();
    if (lastserialno) {
        lastserialno++;
        var serialno = lastserialno;
    } else {
        var serialno = 1;
    }
    jc('#info').show();
    uploadFilename = Obj.name;
    addRow ='<div class="row striped row-'+upItem2+'">'+
        '<div class="col-xs-4 col-sm-4 col-lg-4 audioLengths ellipsisprgbar text-left text-size-ne" ><span data-file="'+Obj.name+'" data-modfy="'+Obj.modifyName+'" data-uploadid="" data-complete="0" id="removeFile-'+upItem2+'" class="up-close removeboth-'+upItem2+'" data-seerid="'+upItem2+'"  ><a href="javascript:void(0)"  data-placement="bottom" data-original-title="Remove file"> <i class="fa fa-trash-o" aria-hidden="true" style="font-weight:bold"></i></a></span>&nbsp;&nbsp;<span class="serialno">'+serialno+'</span>. '+Obj.name+'<input type="hidden" class="fileNamepay" value="'+Obj.modifyName+'#-#('+bytesToSize(Obj.size, 1).replace(".0", "") +')#-#'+Obj.type+'" id="uploadFiles-'+upItem2+'" data-durat="" name="uploadFiles[]" data-serid="'+upItem2+'" /></div>'+
        '<div class="col-xs-4 col-sm-4 col-lg-4 audioLengthpay text-size-ne text-center"><input data-ser="'+upItem2+'" type="text" maxlength="4" id="durationnewpay-'+upItem2+'" style="display:none;width:55px;text-align: center;" class="length onlynumbers text-center" placeholder="min" value="" onkeyup="paytc_pricequoteclac();paytc_paymentenable();"  name="length[]"> <span class="filetypes-'+upItem2+' hrdisplay" name="qfmsg" id="filetypespay'+upItem2+'" ></span></div> '+
        '<div class="col-xs-4 col-sm-4 col-lg-4 text-size-ne"> <span id="progpay-' + upItem2 + '" class="progress-upload ">'+
        '<input type="hidden" class="filePath" name="filePaths[]" value="" /><div class="awsupload-progress">'+
        '<div style="width:0%;" class="awsupload-progress-bar"></div>'+
        '<div class="awsupload-progress-text"></div>'+ '</div>'+
        '</span><div  class="audioLength text-center" id="inp-' + upItem2 + '" style="display:none;" >File Uploaded. </div></div>'+
        '<audio class="audio" id="audio-'+upItem2+'"></audio>'+
        '</div>';
    jc('#info').append(addRow);
    objectUrl = URL.createObjectURL(Obj);
    jc('#audio-' + upItem2).prop("src", objectUrl);

    var completedfilecnt = jc('.audioLength:visible').length;
    var totalfilecnt     = jc('.audioLength').length;
    jc('#completedfiletext').html("Uploaded " + completedfilecnt + "/" + totalfilecnt + " Files");
    serialno++;
}
function updateFinalInfo() {
    jc('#progpay-' + upItem).hide();
    jc('#inp-' + upItem).show();
    var srcfiletype = jc("#sourcefiletype option:selected").val();
    if(srcfiletype == 1){
        jc('#inp-' + upItem).show();
    }else if (srcfiletype == 2){
        //jc('#durationnewpay-' + upItem).show();
        if (jc('#formtype').val() == "payment") {
            if (jc('[id^=audio-' + upItem + ']').length > 0) {
                var vid     = document.getElementById('audio-' + upItem);
                var seconds = vid.duration;
                var minutes = seconds / 60;
                var result  = Math.ceil(minutes);
                jc('#durationnewpay-' + upItem).delay(1100).fadeIn();

                if (result > 0 && result != 'NaN') {
                    jc("#filetypespay" + upItem).show();
                    jc("#filetypespay" + upItem).removeClass("errlength").addClass("hrdisplay");
                    var durinhrs = hourconverter(result);
                    jc("#filetypespay" + upItem).html(durinhrs);
                    var precedres = pad(result, 2);
                    precedres = (precedres == 0)?'':precedres;
                    jc('#durationnewpay-' + upItem).val(precedres);
                    jc('#uploadFiles-' + upItem).data("durat", result);
                } else {
                    jc('#durationnewpay-' + upItem).val();
                    jc('#uploadFiles-' + upItem).data("durat", 0);
                    jc('.filetypes-' + upItem).delay(1100).fadeIn();
                    jc("#filetypespay" + upItem).removeClass("hrdisplay").addClass("errlength");
                    jc("#filetypespay" + upItem).html("Enter file length!");
                }
                //jc('#durationnew-'+upItem).val(result);
            }
        }
    }



    jc('#removeFile-' + upItem).data('complete', 1);
    jc('#removeFile-' + upItem).css('visibility', 'visible');
    var completedfilecnt = jc('.audioLength:visible').length;
    var totalfilecnt     = jc('.audioLength').length;
    jc('#completedfiletext').html("Uploaded " + completedfilecnt + "/" + totalfilecnt + " Files");

    if (jc('#quoteflag').val() == 1) {
        $.ajax({
            url: update_quote,
            data: {
                command: 'updatefilecount',
                uploadflag: uploadProgress,
                completedfilecnt: completedfilecnt,
                //uploadedFile :uploadedFileName,
                ticketid: ticketID,
                quoteflag: jc('#quoteflag').val(),
                totalfilecnt: totalfilecnt,
            },
            type: 'POST'
        });
    }
    paytc_pricequoteclac();
    deltime();
}
function updateUploadStatus() {
    var uploadFile       = filesUploadStatus[upItem]['file'];
    var uploadedFileName = uploadFile.modifyName;
    $.ajax({
        url: update_quote,
        data: {
            command: 'updateuploadstatus',
            uploadedFile: uploadedFileName,
        },
        type: 'POST'
    });
}

function updateProgressBar() {
    var progwidth = ((sureUploadSize + probableUplaodSize) / totalSize * 100).toFixed(1).replace(".0", "") + '%';
    var progtxt   = bytesToSize(sureUploadSize + probableUplaodSize, 1).replace(".0", "") + '/' + bytesToSize(totalSize, 1).replace(".0", "");
    /*jc('#prog-' + upItem + ' .awsupload-progress .awsupload-progress-bar').css('width', progwidth);
    jc('#prog-' + upItem + ' .awsupload-progress .awsupload-progress-text').html(progtxt + ' - (' + progwidth + ')');*/
    jc('#progpay-' + upItem + ' .awsupload-progress .awsupload-progress-bar').css('width', progwidth);
    jc('#progpay-' + upItem + ' .awsupload-progress .awsupload-progress-text').html(progtxt + ' - (' + progwidth + ')');

}
function resetProgressBar() {
    jc('#progress').attr('max', 0);
    jc('#progress').attr('value', 0);
}

function deletefile(filename, obj) {
    if (jc(obj).data('complete') == "0") {
        // console.log('Not uploaded');
        // upload file inprogress...
        if (jc(obj).data('uploadid') != "") {
            cancel();
            // console.log('upload inprogress file');
        }
        return;
    } else {
        $.ajax({
            url: uploadserver,
            data: {
                command: 'deletefile',
                Filename: filename
            }
        }).done(function (data) {
            //cancelFlag = true;
        });
    }
}

function completeMultipartUpload() {
    $.ajax({
        url: uploadserver,
        timeout: 5000,
        data: {
            command: 'CompleteMultipartUpload',
            sendBackData: sendBackData
        },
        beforeSend: function () {
            //console.log('before send');
        },
        error: function (event, request, settings, data) {
            var errorResponse = JSON.stringify(data);
            if (cancelFlag) {
                changeCancelFlag();
            } else {
                jc('#uploading_msg').hide();
                //jc('.upload_error, .upload_errmsg').show();
                jc('.upload_errmsg').show();
                showMessage('#my-welcome-message2');
                saveuploaderror(errorResponse);
                if (!checkUnprocessCompletePartFlag) {
                    checkUnprocessCompletePart();
                }
            }
        }, success: function () {
            if (checkUnprocessCompletePartFlag) {
                checkUnprocessCompletePartFlag = false;
                clearInterval(intervalfunc_complete);
                jc('.upload_error, .upload_errmsg ').hide();
                jc('#uploading_msg').show();
                if (jc('#quoteflagnew').val() == 0)
                    jc('#fvpp-blackout, #my-welcome-message2').hide();


            }
        }
    }).done(function (data, textStatus, jqXHR) {
        // console.log('==== CompleteMultipartUpload Final===='+ filesUploadStatus[upItem]['file'].name);
        resetProgressBar();
        resetParam();
        uploadedFilesArr.push(filesUploadStatus[upItem]['file'].name);

        var uploadFile = filesUploadStatus[upItem]['file'];
        uploadedFileDetailsArr.push(uploadFile.modifyName + '#-#(' + bytesToSize(uploadFile.size, 1).replace(".0", "") + ')#-#' + uploadFile.type);
        updateFinalInfo();
        if (jc('#quoteflag').val() == 1 || jc('#quoteflagnew').val() == 1) {
            updateUploadStatus();
        }
        blurdataInfo           = {};
        blurdataInfo.fieldname = "fileuploader";
        updateFormInfo(blurdataInfo);
        // Checking file exist or not to  upload
        if (++upItem in filesUploadStatus) {
            if (uploadFilesArr.length == uploadedFilesArr.length) {
                if (jc('#quoteflag').val() == 1 || jc('#quoteflagnew').val() == 1) {
                    //console.log("finalsubmit");
                    setTimeout(function () {
                        jc("#qsubmitcrm").trigger("click");
                    }, 5000);
                }
            }
            decideFileUpload();
        }
        else {
            uploadProgress = false;
            //Added by Rohini R on 20/12/2016 to disable submit in CRM File upload while upload in progress
            /*if (jc("#filesubmit").length) {
                jc("#filesubmit").removeAttr("disabled");
            }*/
            jc('#sourcefiletype').attr('disabled',false);
            jc(".up").hide();
            jc('#sourcefiletype').trigger('keyup');
            if(uploadedFilesArr != ''){
                jc('.filecomment').show();
            }


            if (jc('#quoteflag').val() == 1 || jc('#quoteflagnew').val() == 1) {
                setTimeout(function () {
                    jc("#qsubmitcrm").trigger("click");
                }, 5000);
            }
            //jc( "#qsubmitcrm" ).trigger( "click" );
            //}


            //quotesubmitbtn(uploadProgress);
            // console.log("************* ALL Files uploaded successfully*************");
        }
    });


}

function uploadPart(partNum) {
    //alert('upload part'+ partNum);
    if (cancelFlag) {
        cancelFlag = false;
        resetProgressBar();
        resetParam();
        decideFileUpload();
        return;
    }
    if (partNum > numParts) {
        completeMultipartUpload();
        filesUploadStatus[upItem]['status'].upload_status = 'complete';
        return;
    }
    var start = (partNum - 1) * partSize;
    var end   = start + partSize;
    if (end > totalSize)
        end = totalSize;
    var length = end - start;

    // var curBlobPart = processingFile.slice(start, end);

    if (typeof processingFile.slice === 'function') {
        var curBlobPart = processingFile.slice(start, end);
    } else if (typeof processingFile.webkitSlice === 'function') {
        var curBlobPart = processingFile.webkitSlice(start, end);
    } else {
        console.log('unable to slice processingFile (slice /webkitSlice) ');
    }

    $.ajax({
        url: uploadserver,
        timeout: 5000,
        data: {
            command: 'SignUploadPart',
            partNumber: partNum,
            contentLength: length,
            sendBackData: sendBackData
        }, error: function (data) {
            if (cancelFlag) {
                changeCancelFlag();
            } else {
                jc('#uploading_msg').hide();
                // jc('.upload_error, .upload_errmsg').show();
                jc('.upload_errmsg').show();
                showMessage('#my-welcome-message2');
                data.partNumber   = partNum;
                var errorResponse = JSON.stringify(data);
                saveuploaderror(errorResponse);
                if (!checkUnprocessFlag)
                    checkUnprocessData(partNum);
                return;
            }
        }, success: function () {
            if (checkUnprocessFlag) {
                checkUnprocessFlag = false;
                clearInterval(intervalfunc);
                jc('.upload_error, .upload_errmsg').hide();
                jc('#uploading_msg').show();
                if (jc('#quoteflagnew').val() == 0)
                    jc('#fvpp-blackout, #my-welcome-message2').hide();
            }
        }
    }).done(function (data, textStatus, jqXHR) {
        //console.log('==== SignUploadPart ====');
        var url = data['url'];
        // updating uploaded file path.
        jc('#prog-' + upItem + ' .filePath').val(getAwsLocation(url));
        var authHeader = data['authHeader'];
        var dateHeader = data['dateHeader'];
        var request    = new XMLHttpRequest();
        request.open('PUT', url, true);
        request.contentLength = length;

        request.onreadystatechange = function () {
            // console.log("++++++ onreadystatechange ++++++");
            // console.log(request.status);
            // console.log(request);

            if (request.readyState === 4) {
                if (request.status === 200) {
                    filesUploadStatus[upItem]['status'].upload_status = 'process';
                    if (checkUnprocessFlag) {

                        checkUnprocessFlag = false;
                        clearInterval(intervalfunc);
                        jc('#uploading_msg').show();
                        jc('.upload_error, .upload_errmsg').hide();
                        if (jc('#quoteflagnew').val() == 0)
                            jc('#fvpp-blackout, #my-welcome-message2').hide();
                    }
                    probableUplaodSize = 0;
                    sureUploadSize += request.contentLength;
                    updateProgressBar();
                    uploadPart(partNum + 1);
                } else {
                    if (cancelFlag) {
                        changeCancelFlag();
                    } else {
                        console.log('Request status Error');
                        jc('#uploading_msg').hide();
                        // jc('.upload_error, .upload_errmsg').show();
                        jc('.upload_errmsg').show();
                        showMessage('#my-welcome-message2');
                        var errorResponse = JSON.stringify(data);
                        saveuploaderror(errorResponse);

                        filesUploadStatus[upItem]['status'].upload_status = 'error';
                        if (!checkUnprocessFlag)
                            checkUnprocessData(partNum);
                        return;
                    }
                }
            }
        };
        request.upload.onprogress  = function (e) {
            //console.log("++++++ upload.onprogress ++++++" + request.status);
            if (e.lengthComputable) {
                probableUplaodSize = e.loaded;
                updateProgressBar();
            }
        };
        request.setRequestHeader("x-amz-date", dateHeader);
        request.setRequestHeader("Authorization", authHeader);
        //request.setRequestHeader("Content-Length", length);
        request.send(curBlobPart);

    });
}
function startPartitionAndUpload() {
    updateProgressBar();
    numParts = Math.ceil(totalSize / partSize);
    uploadPart(1);
}
function cancel() {
    $.ajax({
        url: uploadserver,
        data: {
            command: 'AbortMultipartUpload',
            sendBackData: sendBackData
        }
    }).done(function (data) {
        cancelFlag = true;
        console.log('upload cancelled');

    });
}

function upload() {
    var url = window.location.href;
    var re  = /\/upload\?type=delivery/g;
    if (re.test(url)) {
        var vendorupload = true;
    }

    if (window.File && window.FileReader && window.FileList && window.Blob && window.Blob.prototype.slice) {
        for (i = 0; i < jc('#file')[0].files.length; i++, InitialVal++) {
            fileObj = jc('#file')[0].files[i];

            //  console.log(i+"<=i######## step 1##########>InitialVal"+InitialVal);
            exist_file_name = jc('#exist_file_name').val();
            if (vendorupload && typeof exist_file_name !== 'undefined') {
                // variable is undefined
                var upd_file_name   = fileObj.name.substr(0, fileObj.name.lastIndexOf('.'));
                var exist_file_name = exist_file_name.substr(0, exist_file_name.lastIndexOf('.'));
                if (exist_file_name != upd_file_name) {
                    alert('Uploading filename should be same.');
                    location.reload();
                    jc('#uploadbuttoncls').hide();
                    InitialVal--;
                    continue;
                }
            }

            // already file in the list

            var filetype        = fileObj.type;
            var filtype         = filetype.split("/");
            var sourcefiletype3 = jc("#sourcefiletype option:selected").val();
            //console.log(filtype[0] + '-' + sourcefiletype3);
            if ((filtype[0] != "audio") && (filtype[0] != "video") && sourcefiletype3 == 2) {
                sweetAlert("Sorry...", "Please upload audio,video files only.", "error");
                InitialVal--;
                continue;
            } else if (((filtype[0] == "audio") || (filtype[0] == "video")) && (sourcefiletype3 == 1)) {
                sweetAlert("Sorry...", "Please upload documents only.", "error");
                InitialVal--;
                continue;
            } else if (uploadFilesArr.indexOf(fileObj.name) != -1) {
                alert('Already ' + fileObj.name + ' uploaded...');
                InitialVal--;
                continue;
            } else {

                //   console.log(i+"<=i######## step 2 else block ##########>InitialVal"+InitialVal);

                uploadFilesArr.push(fileObj.name);

                originalFile         = fileObj.name;
                var replacedFilename = originalFile.replace(/[^A-Za-z0-9\_\-\.]/g, '');
                if (replacedFilename.substring(0, replacedFilename.lastIndexOf('.')) == '') {
                    var ext          = replacedFilename.split('.').pop().toLowerCase();
                    replacedFilename = 'file_' + Math.floor(Math.random() * 90000) + '.' + ext;
                }
                if (jc("#bucketcode").length) {
                    var bucketcd  = jc('#bucketcode').val();
                    var bucketkey = bucketcd;
                } else {
                    var bucketkey = 'xx';
                }
                fileObj.modifyName                      = folderPath + makeid(6) + bucketkey + "_" + replacedFilename;
                //  console.log(i+"<=i######## step 3 before filesUploadStatus##########>InitialVal"+InitialVal);
                filesUploadStatus[InitialVal]           = {};
                filesUploadStatus[InitialVal]['file']   = fileObj;
                filesUploadStatus[InitialVal]['status'] = {
                    upload_status: 'start',
                    item_no: InitialVal,
                    file_name: fileObj.modifyName,
                    file_size: bytesToSize(fileObj.size, 1).replace(".0", ""),
                    file_type: fileObj.type
                };

                // console.log(i+"<=i######## step 3 after filesUploadStatus##########>InitialVal"+InitialVal);
                upItem2 = InitialVal;

                updateInfo(fileObj);
                if (uploadProgress == false) {
                    uploadProgress = true;
                    //Added by Rohini R on 20/12/2016 to disable submit in CRM File upload while upload in progress
                    /*if (jc("#filesubmit").length) {
                        jc('#filesubmit').attr('disabled', 'disabled');
                    }*/
                    jc('#sourcefiletype').attr('disabled',true);
                        jc(".up").show();
                        jc(".pt,.qt").hide();
                    if(uploadedFilesArr != ''){
                        jc('.filecomment').show();
                    }
                    // quotesubmitbtn(uploadProgress);
                    uploadFile(filesUploadStatus[upItem]['file']);
                }
            }

        }//for loop
    } else {
        alert('The File APIs are not fully supported in this browser.');
    }
    //jc('[data-toggle="tooltip"]').tooltip();

}
function uploadFile(uploadFile) {
    console.log('Upload file...');
    uploadProgress = true;
    //quotesubmitbtn(uploadProgress);
    processingFile = uploadFile;
    totalSize      = uploadFile.size;
    $.ajax({
        url: uploadserver,
        timeout: 5000,
        data: {
            command: 'CreateMultipartUpload',
            fileInfo: {
                name: uploadFile.modifyName,
                type: uploadFile.type,
                size: uploadFile.size,
                lastModifiedDate: uploadFile.lastModifiedDate
            },
            otherInfo: {
                user: awsUser,
                pass: 'pass'
            }
        }, beforeSend: function () {
            // console.log('before start ');
        }, error: function (data) {
            if (cancelFlag) {
                changeCancelFlag();
            } else {
                jc('#uploading_msg').hide();
                // jc('.upload_error, .upload_errmsg').show();
                jc('.upload_errmsg').show();
                showMessage('#my-welcome-message2');
                var errorResponse = JSON.stringify(data);
                saveuploaderror(errorResponse);
                if (!checkUnprocesStartingPartFlag) {
                    checkUnprocesStartingPart(uploadFile);
                }
            }
        }, success: function () {
            if (checkUnprocesStartingPartFlag) {
                checkUnprocesStartingPartFlag = false;
                clearInterval(intervalfunc_start);
                jc('.upload_error, .upload_errmsg').hide();
                jc('#uploading_msg').show();
                if (jc('#quoteflagnew').val() == 0)
                    jc('#fvpp-blackout, #my-welcome-message2').hide();
            }
        }
    }).done(function (data, textStatus, jqXHR) {
        // console.log('==== CreateMultipartUpload ===='+upItem+"==>"+data.uploadId);
        jc('#removeFile-' + upItem).data('uploadid', data.uploadId);
        sendBackData = data;
        startPartitionAndUpload();
    });
}
function decideFileUpload() {
    // console.log('decideFileUpload ====> ');
    for (i = upItem; i < filesUploadStatus.length; i++) {
        if (uploadFilesArr.indexOf(filesUploadStatus[upItem]['file']['name']) >= 0) {
            uploadFile(filesUploadStatus[upItem]['file']);
            return;
        }
        else upItem = upItem + 1;
    }

    uploadProgress = false;
    //Added by Rohini R on 20/12/2016 to disable submit in CRM File upload while upload in progress
   /* if (jc("#filesubmit").length) {
        jc("#filesubmit").removeAttr("disabled");
    }*/
    jc('#sourcefiletype').attr('disabled',false);
    jc(".up").hide();
    jc('#sourcefiletype').trigger('blur');
    if(uploadedFilesArr != ''){
        jc('.filecomment').show();
    }

    //quotesubmitbtn(uploadProgress);
    //console.log("************* ALL Files uploaded successfully*************");
}
function bytesToSize(bytes, precision) {
    var kilobyte = 1024;
    var megabyte = kilobyte * 1024;
    var gigabyte = megabyte * 1024;
    var terabyte = gigabyte * 1024;

    if ((bytes >= 0) && (bytes < kilobyte)) {
        return bytes + ' B';

    } else if ((bytes >= kilobyte) && (bytes < megabyte)) {
        return (bytes / kilobyte).toFixed(precision) + ' KB';
    } else if ((bytes >= megabyte) && (bytes < gigabyte)) {
        return (bytes / megabyte).toFixed(precision) + ' MB';

    } else if ((bytes >= gigabyte) && (bytes < terabyte)) {
        return (bytes / gigabyte).toFixed(precision) + ' GB';
    } else if (bytes >= terabyte) {
        return (bytes / terabyte).toFixed(precision) + ' TB';
    } else {
        return bytes + ' B';
    }
}

function getAwsLocation(href) {
    var l   = document.createElement("a");
    l.href  = href;
    var str = l.hostname;
    str.indexOf(".");
    var s3Bucket = str.substr(0, str.indexOf("."));
    return awsUrl + s3Bucket + l.pathname;
}
//on blur data capturing - start

function updateFormInfo(blurdataInfo) {
    var fieldname  = blurdataInfo.fieldname;
    var fieldlabel = jc('label[for="' + fieldname + '"]').text();
    var fieldlabel = fieldlabel.trim();
    var fieldvalue = jc('#' + fieldname).val();
    var fieldtype  = jc('#' + fieldname).attr('type');
    if (fieldtype == 'checkbox') {
        if (jc('#' + fieldname).is(':checked')) {
            fieldvalue = 'Yes';
        } else {
            fieldvalue = 'No';
        }
    }
    if (fieldlabel) {
        if ((fieldlabel == 'Translate To' || fieldlabel == 'Target Language' || fieldlabel == 'Language') && fieldvalue) {
            fieldvalue = fieldvalue.toString().replace(/,/g, '-');
        }
        if (fieldlabel == 'How Long is Your Video?' && fieldvalue) {
            fieldvalue = fieldvalue.toString().replace(/:/g, '-');
        }
        onblurdataarray.push(fieldlabel + ':' + fieldvalue);
    } else {
        if (fieldname == 'qmailmsgcrm')
            fieldname = 'mail comment';
        onblurdataarray.push(fieldname + ':' + fieldvalue);
    }
    if (jc('#qsourcecrm').val())
        onblurdataarray.push('Translate From' + ':' + jc('#qsourcecrm').val());
    else if (jc('#qsourcevoicecrm').val())
        onblurdataarray.push('Translate From' + ':' + jc('#qsourcevoicecrm').val());
    else if (jc('#language').val() && jc('#channel_id').val() == 7)
        onblurdataarray.push('language' + ':' + jc('#language').val());

    blurdataInfo.qname       = jc('#qnamecrm').val();
    blurdataInfo.qemail      = jc('#qemailcrm').val();
    blurdataInfo.qcountrys   = jc('#qcountryscrm').val();
    blurdataInfo.acode       = jc('#acodecrm').val();
    blurdataInfo.qphone      = jc('#qphonecrm').val();
    blurdataInfo.entryval    = jc('#recordkey').val();
    blurdataInfo.serviceid   = jc('#serviceid').val();
    blurdataInfo.channel_id  = jc('#channel_id').val();
    blurdataInfo.filedetails = uploadedFileDetailsArr.toString();
    blurdataInfo.fieldname1  = onblurdataarray.toString();
    if (jc('#recordkey').val()) {
        var id = '';
    } else {
        var id = new Date().getTime();
        jc('#recordkey').val(id);
    }
    blurdataInfo.id = id;
    if (jc('#qemailcrm').val()) {
        $.ajax({
            url: crmFormsavepath + 'save/crmformdata',
            data: {
                command: 'updatefieldinfo',
                sitename: sitename,
                savedata: blurdataInfo,
                async: false,
            },
            type: 'POST',
            success: function (data) {
                jc('#recordkey').val(data.trim());
            }
        });
    }
}
var etat = '';
//on blur data capturing - end
jc(document).ready(function () {
    getUploadPartSize();
    //on blur data capturing - start

    if (jc('#channel_id').val() == 7) {
        var formid = jc('#quick_servicetype').val();
    }
    else {
        var formid = jc('#formid').val();
    }
    jc('#' + formid + " :input").each(function () {
        var input = jc(this).attr("id"); // This is the jquery object of the input, do what you will

        if (input == 'qtargetcrm')
            var j = jc('#' + input);
        else if (input == 'expected_turnaround')
            var j = jc('.datetimepicker');
        else
            var j = jc('#' + input);

        j.on('change blur', function (e) {
            var email = jc('#qemailcrm').val();
            var reg   = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
            if (reg.test(email) == true) {
                blurdataInfo           = {};
                blurdataInfo.comments  = jc(this).val();
                blurdataInfo.fieldname = jc(this).attr('id');
                if (input == 'expected_turnaround')
                    setTimeout(function () {
                        var etat                         = jc('#expected_turnaround').val();
                        blurdataInfo.expected_turnaround = etat;
                        updateFormInfo(blurdataInfo);
                    }, 100);
                else if (input != 'file')
                    updateFormInfo(blurdataInfo);

            }

        });
    });

//    } else {
//            jc("#qemailcrm,#qcountryscrm,#acodecrm,#qphonecrm,#qnamecrm").blur(function () {
//                var email = jc('#qemailcrm').val();
//                var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
//                if (reg.test(email) == true)
//                {
//                    blurdataInfo = {};
//                    blurdataInfo.comments = jc(this).val();
//                    blurdataInfo.fieldname = jc(this).attr('id');
//                    updateFormInfo(blurdataInfo);
//                }
//            });
//        }
    //on blur data capturing - end
});

jc(document).on('click', '.up-close', function () {
    uploadId    = jc(this).data('uploadid');
    var remFile = jc(this).data('file');
    uploadFilesArr.splice(uploadFilesArr.indexOf(remFile), 1);
    uploadedFilesArr.splice(uploadedFilesArr.indexOf(remFile), 1);
    if (uploadedFileDetailsArr.length > 0) {
        for (i = 0; i < uploadedFileDetailsArr.length; i++) {
            var uploadedarrfilename  = uploadedFileDetailsArr[i].split("#-#");
            var uploadedarrfilename1 = uploadedarrfilename[0].substring(uploadedarrfilename[0].indexOf("_") + 1);
            if (uploadedarrfilename1 == remFile.replace(/[^A-Za-z0-9\_\-\.]/g, '')) {
                uploadedFileDetailsArr.splice(uploadedFileDetailsArr.indexOf(uploadedFileDetailsArr[i]), 1);
                blurdataInfo           = {};
                blurdataInfo.fieldname = "fileuploader";
                updateFormInfo(blurdataInfo);
            }
        }
    }

    jc(this).parent().parent().remove();
    if (!uploadFilesArr.length)
        jc('#info').hide();

    reorder();
    if(uploadedFilesArr == ''){
        jc('.filecomment').hide();
    }
});
function quotesubmitbtn(upProgress) {
    if (upProgress) {
        jc('.progressbtn').show();
        jc('.quotebtn').hide();
    } else {
        jc('.progressbtn').hide();
        jc('.quotebtn').show();
    }
    jc('#uploadprogress').val(upProgress);
}

function makeid(Strlen) {
    var text     = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    for (var i = 0; i < Strlen; i++)
        text += possible.charAt(Math.floor(Math.random() * possible.length));
    return text;
}

function checkUnprocessData(partNum) {
    console.log('checkUnprocessData : ' + partNum);
    checkUnprocessFlag = true;
    var counter        = 0;
    intervalfunc       = setInterval(function () {
        counter++;
        uploadPart(partNum);
        if (counter >= 20) {
            clearInterval(intervalfunc);
        }
    }, 10000);
}


function getUploadPartSize() {
    $.getJSON('//freegeoip.net/json/?callback=?', function (data) {
        var country_code = data.country_code;
        switch (country_code) {
            case "IN":
                partSize = 5 * 1024 * 1024;
                break;
            case "US":
                partSize = 50 * 1024 * 1024;
                break;
            case "GB":
            case "AU":
            case "UK":
                partSize = 20 * 1024 * 1024;
                break;
            default :
                partSize = 50 * 1024 * 1024;
                break;
        }
    });

}

function showMessage(id) {
    var $body   = jc('body');
    var $dialog = jc(id);
    $body.append('<div id="fvpp-blackout"></div>');
    $dialog.append('');
    $blackout = jc('#fvpp-blackout');
    var $blackout;
    $blackout.show();
    jc("#fvpp-close").css({'display': "none"});
    $dialog.show();
    jc(".DS-sidefixed-nav").css({'display': "none"});

}

function checkUnprocessCompletePart() {
    checkUnprocessCompletePartFlag = true;
    var counter                    = 0;
    intervalfunc_complete          = setInterval(function () {
        counter++;
        completeMultipartUpload();
        if (counter >= 20) {
            clearInterval(intervalfunc_complete);
        }
    }, 10000);
}

function checkUnprocesStartingPart(uploadFiles) {
    checkUnprocesStartingPartFlag = true;
    var counter                   = 0;
    intervalfunc_start            = setInterval(function () {
        counter++;
        uploadFile(uploadFiles);
        if (counter >= 20) {
            clearInterval(intervalfunc_start);
        }
    }, 10000);
}
function saveuploaderror(errorResponse) {
    dataInfo                 = {};
    var networkerrormailsent = 0;
    dataInfo.qname           = jc('#qnamecrm').val();
    if (jc('#qemailcrm').length) {
        dataInfo.qemail = jc('#qemailcrm').val();
    } else {
        dataInfo.qemail = jc('#sample_email').val();
    }
    //dataInfo.qcountrys = jc('#qcountryscrm').val();
    //dataInfo.acode = jc('#acodecrm').val();
    //dataInfo.qphone = jc('#qphonecrm').val();
    dataInfo.entryval            = jc('#recordkey').val();
    dataInfo.networkerrflag      = jc('#networkerrflag').val();
    dataInfo.serviceid           = jc('#serviceid').val();
    dataInfo.crmpage             = jc('#crmpage').val();
    dataInfo.filedetails         = JSON.stringify(uploadFilesArr);
    dataInfo.fileuploadstatus    = JSON.stringify(filesUploadStatus);
    dataInfo.uploadprogress      = uploadProgress;
    dataInfo.uploaderrorresponse = errorResponse;
    dataInfo.uploadedfiledetails = JSON.stringify(uploadedFileDetailsArr);
    if ((jc('#qemailcrm').val() || jc('#sample_email').val()) && jc('#networkerrflag').val() == 0) {
        $.ajax({
            url: crmFormsavepath + 'save/crmformdata',
            data: {
                command: 'networkerror',
                networkerrordata: dataInfo,
                sitename: sitename,
                async: false,
            },
            type: 'POST',
            success: function (data) {
                jc('#networkerrflag').val(data);
            }
        });
    }
}

function changeCancelFlag() {
    uploadProgress = false;
    resetProgressBar();
    resetParam();
    updateFinalInfo();
    decideFileUpload();
}

function hourconverter(durminutes) {
    var hours   = Math.floor(durminutes / 60);
    var minutes = durminutes % 60;
    hours       = pad(hours, 2);
    minutes     = pad(minutes, 2);
    return duhrs = "(" + hours + ":" + minutes + ")";
    //jc('.convertedHour').html(hours);
    //jc('.convertedMin').html(minutes);
}
function pad(str, max) {
    str = str.toString();
    return str.length < max ? pad("0" + str, max) : str;
}
function paytc_paymentenable() {
    var durationcheck = [];
    jc(".length").each(function (i) {
        var  i = jc(this).attr("data-ser");
        var dur = parseInt(jc('#durationnewpay-' + i).val());
        if (isNaN(dur) || dur == '' || dur < 1) {
            jc("#filetypespay" + i).show();
            jc("#filetypespay" + i).removeClass("hrdisplay").addClass("errlength");
            jc("#filetypespay" + i).html("Enter file length!");
            jc('#durationnewpay-' + i).val();
            dur = '00';
        } else {
            jc("#filetypespay" + i).show();
            jc("#filetypespay" + i).removeClass("errlength").addClass("hrdisplay");
            var durinhrs = hourconverter(dur);
            jc("#filetypespay" + i).html(durinhrs);
        }
        jc('#durationnew-' + i).val(dur);
        durationcheck.push(dur);
        paytc_pricequoteclac();
    });
}
/*-------- FILE UPLOAD END ------------*/
// For place holder hide and show onfocus
jc('input,textarea').focus(function(){
    jc(this).data('placeholder',jc(this).attr('placeholder'))
        .attr('placeholder','');
}).blur(function(){
    jc(this).attr('placeholder',jc(this).data('placeholder'));
});