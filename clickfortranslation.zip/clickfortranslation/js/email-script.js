$(document).ready(function() {
	"use strict";
// --------------Newsletter-----------------------

	$(".newsletter-signup").ajaxChimp({
		callback: mailchimpResponse,
		url: "//clickfortranslation.us11.list-manage.com/subscribe/post?u=3e35a4526e9878683f384cc34&amp;id=b207fdf956" // Replace your mailchimp post url inside double quote "".  
	});

	function mailchimpResponse(resp) {
		 if(resp.result === 'success') {
		 
			$('.alert-success').html(resp.msg).fadeIn();//.delay(3000).fadeOut();
            $('.alert-warning').html('').fadeOut();
			
		} else if(resp.result === 'error') {
            var msg=''; var ss = resp.msg; //alert(ss);
            if(resp.msg=='0 - Please enter a value')
                {
                    var msg='Please enter your email ID';
                }
            
            else if(resp.msg=='0 - An email address must contain a single @')
                {
                    var msg='Please enter valid email ID';
                }
                        
			$('.alert-warning').html(msg).fadeIn();//.delay(3000).fadeOut();
            $('.alert-success').html('').fadeOut();
		}  
	};
 });