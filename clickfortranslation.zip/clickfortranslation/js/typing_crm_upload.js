var sendBackData;
var partSize                       = 50 * 1024 * 1024; // constant
var totalSize;
var sureUploadSize                 = 0, probableUplaodSize = 0;
var numParts;
var partsLeft                      = [];
var file;
var cancelFlag                     = false;
var uploadFilesArr                 = [], uploadedFilesArr = [], uploadedFileDetailsArr = [];
var upItem                         = 0, j = 0, InitialVal = 0;
var checkUnprocessFlag             = false;
var checkUnprocessCompletePartFlag = false;
var checkUnprocesStartingPartFlag  = false;
var stageObj                       = {"/addfiles": 1, "/signin": 2, "/payment": 3, "booked": 4};
var currentStage                   = stageObj[window.location.pathname];
var awsUrl                         = 'https://s3-ap-southeast-1.amazonaws.com/';
var uploadProgress                 = false;
var filesUploadStatus              = [];
var HOSTNAME                       = 'http://' + window.location.host;
var COSTPERMIN                     = 1;
var VERBATIMCOST                   = 0.25;
var TIMESTAMPCOST                  = 0.25;
var serialno                       = 1;
var serverpath                     = crmRootpath + "lib/";
var uploadserver                   = serverpath + "server.php";
var vendorupload                   = false;
var fileinfoid                     = '';
var fileid                         = '';

var awsUser  = 'user';
var uploadat = jc('#uploadat').val();
function paytc_resetParam() {
    sendBackData;
    // partSize = 5 * 1024 * 1024; // constant
    totalSize;
    sureUploadSize = 0, probableUplaodSize = 0;
    numParts;
    partsLeft = [];
    file;
    cancelFlag = false;
}

function paytc_reorder() {
    var serialno    = 1;
    var serialnopay = 1;
    jc('.serialno').each(function () {
        jc(this).text(serialno);
        serialno++;
    });
    jc('.serialnopay').each(function () {
        jc(this).text(serialnopay);
        serialnopay++;
    });
}

function paytc_addFilespay(fileid) {
    jc('#' + fileid).val(null);
    var uploadfile = document.getElementById(fileid);
    uploadfile.click();  // here i can browse the file without clicking on file brows button
}
/*function addFilesPay() {
 jc('#filepay').val(null);
 var uploadfile = document.getElementById("filepay");
 uploadfile.click();  // here i can browse the file without clicking on file brows button
 }*/
function paytc_updateInfo(Obj, uploadid) {
    var lastserialno = jc(".serialno:last").text();
    if (lastserialno) {
        lastserialno++;
        var serialno = lastserialno;
    } else {
        var serialno = 1;
    }
    var lastserialnopay = jc(".serialnopay:last").text();
    if (lastserialnopay) {
        lastserialnopay++;
        var serialnopay = lastserialnopay;
    } else {
        var serialnopay = 1;
    }
    var uploadat = jc('#uploadat').val();
    if (uploadat == "fileupload") {
        fileinfoid = "info";
    } else {
        fileinfoid = "info_payment";
    }
    jc('#' + fileinfoid).show();
    jc('#skip-files').hide();
    jc('#skipfiles').prop('checked', false);
    uploadFilename = Obj.name;
    //if(uploadat == "fileupload"){
    addRow         = '<div class="row striped row-' + upItem2 + '">' +
        '<div class="col-xs-6 col-sm-8 col-lg-8 ellipsisprgbar "><span data-file="' + Obj.name + '" data-modfy="' + Obj.modifyName + '" data-objid="' + uploadid + '" data-uploadid="" data-complete="0" id="removeFile-' + upItem2 + '" class="up-close removeboth-' + upItem2 + '" data-seerid="' + upItem2 + '" ><a href="javascript:void(0)"  data-placement="bottom" data-original-title="Remove file"> <i class="fa fa-trash-o" aria-hidden="true"></i></a></span>&nbsp;&nbsp;<span class="serialno">' + serialno + '</span>. ' + Obj.name + '<input type="hidden" class="fileName" value="' + Obj.modifyName + '#-#(' + paytc_bytesToSize(Obj.size, 1).replace(".0", "") + ')#-#' + Obj.type + '" name="uploadFiles[]" /></div>' +
        '<div style="display: none;" class="col-xs-6 col-sm-4 col-lg-4 audioLength"><input type="text" maxlength="4" id="durationnew-' + upItem2 + '" data-serid="' + upItem2 + '"  style=" display:none;width:55px;text-align: center;" class="length onlynumbers" placeholder="min" value="" onkeyup="paytc_pricequoteclac();paytc_paymentenablexx();"  name="lengthxx[]"> <span class="filetypes-' + upItem2 + ' hrdisplay" name="qfmsg" id="filetypes' + upItem2 + '" ></span></div> ' +
        '<div class="col-xs-6 col-sm-4 col-lg-4"> <span id="prog-' + upItem2 + '" class="progress-upload ">' +
        ' <input type= "hidden" class="filePath" name="filePaths[]" value="" /><div class="awsupload-progress">' +
        '<div style="width:0%;" class="awsupload-progress-bar"></div>' +
        '<div class="awsupload-progress-text "></div>' +
        '</div>' +
        '</span><div  class="audioLength" id="inp-' + upItem2 + '" style=" display:none;" >File Uploaded. </div> </div>' +
        '</div>';
    jc('#info').append(addRow);
    //}else{
    addRow = '<div class="row striped row-' + upItem2 + '">' +
        '<div class="col-xs-6 col-sm-4 col-lg-8 ellipsisprgbar text-left" ><span data-file="' + Obj.name + '" data-modfy="' + Obj.modifyName + '" data-objid="' + uploadid + '" data-uploadid="" data-complete="0" id="removeFile-' + upItem2 + '" class="up-close removeboth-' + upItem2 + '" data-seerid="' + upItem2 + '"  ><a href="javascript:void(0)"  data-placement="bottom" data-original-title="Remove file"> <i class="fa fa-trash-o" aria-hidden="true" style="font-weight:bold"></i></a></span>&nbsp;&nbsp;<span class="serialnopay">' + serialnopay + '</span>. ' + Obj.name + '<input type="hidden" class="fileNamepay" value="' + Obj.modifyName + '#-#(' + paytc_bytesToSize(Obj.size, 1).replace(".0", "") + ')#-#' + Obj.type + '" id="uploadFiles-' + upItem2 + '" data-durat="" name="uploadFiles[]" /></div>' +
        '<div class="displaynone col-xs-6 col-sm-4 col-lg-4 audioLengthpay"><input type="text" maxlength="4" id="durationnewpay-' + upItem2 + '" data-serid="' + upItem2 + '"  style=" display:none;width:55px;text-align: center;" class="length onlynumbers" placeholder="min" value="" onkeyup="paytc_pricequoteclac();paytc_paymentenable();"  name="length[]"> <span class="filetypes-' + upItem2 + ' hrdisplay" name="qfmsg" id="filetypespay' + upItem2 + '" ></span></div> ' +
        '<div class="displaynone col-xs-2 col-sm-4 col-lg-4 text-right"><input id="costbox-' + upItem2 + '" type="hidden" value="0"><span style="display:none;" id="costnew-' + upItem2 + '">$0.00</span></div><div class="col-xs-6 col-sm-4 col-lg-4"> <span id="progpay-' + upItem2 + '" class="progress-upload ">' +
        ' <input type= "hidden" class="filePath" name="filePaths[]" value="" /><div class="awsupload-progress">' +
        '<div style="width:0%;" class="awsupload-progress-bar"></div>' +
        '<div class="awsupload-progress-text"></div>' + '</div>' +
        '</span><div  class="audioLengthpayno" id="inppay-' + upItem2 + '"  style=" display:none;" >File Uploaded. </div></div>' +
        //id="inppay-'+upItem2+'"  docfile
        '<audio class="audio" id="audio-' + upItem2 + '"></audio>' +
        '</div>';
    jc('#info_payment').append(addRow);
    objectUrl = URL.createObjectURL(Obj);
    jc('#audio-' + upItem2).prop("src", objectUrl);
    //  serialno++;
    //}


    if (uploadat == "fileupload") {
        var completedfilecnt = jc('#info .filecompleted').length;
        var totalfilecnt     = jc('.audioLength').length;
    } else {
        var completedfilecnt = jc('#info_payment .payfilecompleted').length;
        var totalfilecnt     = jc('.audioLengthpay').length;
    }
    jc('#completedfiletext').html("Uploaded " + completedfilecnt + "/" + totalfilecnt + " Files");
    serialno++;
    serialnopay++;
}
function paytc_updateFinalInfo() {
    jc('#prog-' + upItem).hide();
    jc('#prog-' + upItem).addClass("filecompleted");
    jc('#inp-' + upItem).show();
    jc('#progpay-' + upItem).hide();
    jc('#progpay-' + upItem).addClass("payfilecompleted");
    jc('#inppay-' + upItem).show();
    jc('#costnew-' + upItem).show();
    jc('#durationnew-' + upItem).show();
    jc('#durationnewpay-' + upItem).show();
    if (jc('#formtype').val() == "payment") {
        if (jc('[id^=audio-' + upItem + ']').length > 0) {
            var vid     = document.getElementById('audio-' + upItem);
            var seconds = vid.duration;
            var minutes = seconds / 60;
            //var result=Math.round(minutes*100)/100;
            var result  = Math.ceil(minutes);
            //jc('#inp-'+upItem).delay(1000).fadeOut();
            //jc('#inppay-'+upItem).delay(1000).fadeOut();
            jc('#durationnew-' + upItem).delay(1100).fadeIn();
            jc('#durationnewpay-' + upItem).delay(1100).fadeIn();


            if (result > 0 && result != 'NaN') {
                jc("#filetypes" + upItem).show();
                jc("#filetypespay" + upItem).show();
                jc("#filetypes" + upItem).removeClass("errlength").addClass("hrdisplay");
                jc("#filetypespay" + upItem).removeClass("errlength").addClass("hrdisplay");
                var durinhrs = hourconverter(result);
                jc("#filetypes" + upItem).html(durinhrs);
                jc("#filetypespay" + upItem).html(durinhrs);
                var precedres = pad(result, 2);
                jc('#durationnew-' + upItem).val(precedres);
                jc('#durationnewpay-' + upItem).val(precedres);
                jc('#uploadFiles-' + upItem).data("durat", result);
            } else {
                jc('#durationnew-' + upItem).val(00);
                jc('#durationnewpay-' + upItem).val(00);
                jc('#uploadFiles-' + upItem).data("durat", 0);
                jc('.filetypes-' + upItem).delay(1100).fadeIn();
                jc("#filetypes" + upItem).removeClass("hrdisplay").addClass("errlength");
                jc("#filetypes" + upItem).html("Enter file length!");
                jc("#filetypespay" + upItem).removeClass("hrdisplay").addClass("errlength");
                jc("#filetypespay" + upItem).html("Enter file length!");
                //jc('.qsubmitcrm').css('pointerEvents', 'none');

            }
            //jc('#durationnew-'+upItem).val(result);
        }
    }
    jc('#removeFile-' + upItem).data('complete', 1);
    jc('#removeFile-' + upItem).css('visibility', 'visible');
    if (uploadat == "fileupload") {
        var completedfilecnt = jc('#info .filecompleted').length;
        var totalfilecnt     = jc('.audioLength').length;
    } else {
        var completedfilecnt = jc('#info_payment .payfilecompleted').length;
        var totalfilecnt     = jc('.audioLengthpay').length;
    }
    jc('#completedfiletext').html("uploaded " + completedfilecnt + "/" + totalfilecnt + " Files");
    if (jc('#quoteflag').val() == 1) {
        $.ajax({
            url: crmRootpath + 'typing_pay_update_v1.0.php',
            data: {
                command: 'updatefilecount',
                uploadflag: uploadProgress,
                completedfilecnt: completedfilecnt,
                quoteinfo: quoteInfo,
                quoteflag: jc('#quoteflag').val(),
                totalfilecnt: totalfilecnt,
            },
            type: 'POST'
        });
    }

    paytc_pricequoteclac();
}


function paytc_updateProgressBar() {
    var progwidth = ((sureUploadSize + probableUplaodSize) / totalSize * 100).toFixed(1).replace(".0", "") + '%';
    var progtxt   = paytc_bytesToSize(sureUploadSize + probableUplaodSize, 1).replace(".0", "") + '/' + paytc_bytesToSize(totalSize, 1).replace(".0", "");
    jc('#prog-' + upItem + ' .awsupload-progress .awsupload-progress-bar').css('width', progwidth);
    jc('#prog-' + upItem + ' .awsupload-progress .awsupload-progress-text').html(progtxt + ' - (' + progwidth + ')');
    jc('#progpay-' + upItem + ' .awsupload-progress .awsupload-progress-bar').css('width', progwidth);
    jc('#progpay-' + upItem + ' .awsupload-progress .awsupload-progress-text').html(progtxt + ' - (' + progwidth + ')');

}
function paytc_resetProgressBar() {
    jc('#progress').attr('max', 0);
    jc('#progress').attr('value', 0);
}

function paytc_deletefile(filename, obj) {
    if (jc(obj).data('complete') == "0") {
        if (jc(obj).data('uploadid') != "") {
            paytc_cancel();
        }
        return;
    } else {
        $.ajax({
            url: uploadserver,
            data: {
                command: 'deletefile',
                Filename: filename
            }
        }).done(function (data) {
            if (jc(obj).data('objid') == "filepay") {
                paytc_paymentenable();
                paytc_pricequoteclac();
            }
            //cancelFlag = true;
        });
    }
}


function paytc_completeMultipartUpload() {
    $.ajax({
        url: uploadserver,
        timeout: 15000,
        data: {
            command: 'CompleteMultipartUpload',
            sendBackData: sendBackData
        },
        beforeSend: function () {
            //console.log('before send');
        },
        error: function (event, request, settings, data) {
            var errorResponse = JSON.stringify(data);
            if (cancelFlag) {
                paytc_changeCancelFlag();
            } else {
                jc('#uploading_msg').hide();
                //jc('.upload_error, .upload_errmsg').show();
                jc('.upload_errmsg').show();
                paytc_showMessage('#my-welcome-message2');
                paytc_saveuploaderror(errorResponse);
                if (!checkUnprocessCompletePartFlag) {
                    paytc_checkUnprocessCompletePart();
                }
            }
        }, success: function () {
            if (checkUnprocessCompletePartFlag) {
                checkUnprocessCompletePartFlag = false;
                clearInterval(intervalfunc_complete);
                jc('.upload_error, .upload_errmsg ').hide();
                jc('#uploading_msg').show();
                if (jc('#quoteflagnew').val() == 0)
                    jc('#fvpp-blackout, #my-welcome-message2').hide();


            }
        }
    }).done(function (data, textStatus, jqXHR) {
        // console.log('==== CompleteMultipartUpload Final===='+ filesUploadStatus[upItem]['file'].name);
        paytc_resetProgressBar();
        paytc_resetParam();
        uploadedFilesArr.push(filesUploadStatus[upItem][fileid].name);
        var uploadFile = filesUploadStatus[upItem][fileid];
        uploadedFileDetailsArr.push(uploadFile.modifyName + '#-#(' + paytc_bytesToSize(uploadFile.size, 1).replace(".0", "") + ')#-#' + uploadFile.type);
        if (fileid == "filepay") {
            paytc_updateFinalInfo();
        } else {
            jc('#prog-' + upItem).hide();
            jc('#prog-' + upItem).addClass("filecompleted");
            jc('#inp-' + upItem).show();
            jc('#progpay-' + upItem).hide();
            jc('#progpay-' + upItem).addClass("payfilecompleted");
            jc('#inppay-' + upItem).show();
        }

        blurdataInfo           = {};
        blurdataInfo.fieldname = "fileuploader";
        paytc_updateFormInfo(blurdataInfo);
        // Checking file exist or not to  upload
        if (++upItem in filesUploadStatus)
            paytc_decideFileUpload();
        else {
            uploadProgress = false;
            //Added by Rohini R on 20/12/2016 to disable submit in CRM File upload while upload in progress
            if (jc("#filesubmit").length) {
                jc("#filesubmit").removeAttr("disabled");
            }
            checkfiletype();
            jc("#contact-details").show();
            jc(".upload-loading").hide();
            if (jc('#quoteflag').val() == 1 || jc('#quoteflagnew').val() == 1) {
                jc("#qsubmitcrm").trigger("click");
            }
            //quotesubmitbtn(uploadProgress);
            // console.log("************* ALL Files uploaded successfully*************");
        }
    });
}

function paytc_uploadPart(partNum) {
    //alert('upload part'+ partNum);
    //alert("called paytc_upload");
    if (cancelFlag) {
        cancelFlag = false;
        paytc_resetProgressBar();
        paytc_resetParam();
        paytc_decideFileUpload();
        return;
    }
    if (partNum > numParts) {
        paytc_completeMultipartUpload();
        filesUploadStatus[upItem]['status'].upload_status = 'complete';
        return;
    }
    var start = (partNum - 1) * partSize;
    var end   = start + partSize;
    if (end > totalSize)
        end = totalSize;
    var length = end - start;

    // var curBlobPart = processingFile.slice(start, end);

    if (typeof processingFile.slice === 'function') {
        var curBlobPart = processingFile.slice(start, end);
    } else if (typeof processingFile.webkitSlice === 'function') {
        var curBlobPart = processingFile.webkitSlice(start, end);
    } else {
        console.log('unable to slice processingFile (slice /webkitSlice) ');
    }

    $.ajax({
        url: uploadserver,
        timeout: 15000,
        data: {
            command: 'SignUploadPart',
            partNumber: partNum,
            contentLength: length,
            sendBackData: sendBackData
        }, error: function (data) {
            if (cancelFlag) {
                paytc_changeCancelFlag();
            } else {
                jc('#uploading_msg').hide();
                // jc('.upload_error, .upload_errmsg').show();
                jc('.upload_errmsg').show();
                paytc_showMessage('#my-welcome-message2');
                data.partNumber   = partNum;
                var errorResponse = JSON.stringify(data);
                paytc_saveuploaderror(errorResponse);
                if (!checkUnprocessFlag)
                    paytc_checkUnprocessData(partNum);
                return;
            }
        }, success: function () {
            if (checkUnprocessFlag) {
                checkUnprocessFlag = false;
                clearInterval(intervalfunc);
                jc('.upload_error, .upload_errmsg').hide();
                jc('#uploading_msg').show();
                if (jc('#quoteflagnew').val() == 0)
                    jc('#fvpp-blackout, #my-welcome-message2').hide();
            }
        }
    }).done(function (data, textStatus, jqXHR) {
        //console.log('==== SignUploadPart ====');
        var url = data['url'];
        // updating uploaded file path.
        jc('#prog-' + upItem + ' .filePath').val(paytc_getAwsLocation(url));
        jc('#progpay-' + upItem + ' .filePath').val(paytc_getAwsLocation(url));
        var authHeader = data['authHeader'];
        var dateHeader = data['dateHeader'];
        var request    = new XMLHttpRequest();
        request.open('PUT', url, true);
        request.contentLength = length;

        request.onreadystatechange = function () {
            // console.log("++++++ onreadystatechange ++++++");
            // console.log(request.status);
            // console.log(request);

            if (request.readyState === 4) {
                if (request.status === 200) {
                    filesUploadStatus[upItem]['status'].upload_status = 'process';
                    if (checkUnprocessFlag) {

                        checkUnprocessFlag = false;
                        clearInterval(intervalfunc);
                        jc('#uploading_msg').show();
                        jc('.upload_error, .upload_errmsg').hide();
                        if (jc('#quoteflagnew').val() == 0)
                            jc('#fvpp-blackout, #my-welcome-message2').hide();
                    }
                    probableUplaodSize = 0;
                    sureUploadSize += request.contentLength;
                    paytc_updateProgressBar();
                    paytc_uploadPart(partNum + 1);
                } else {
                    if (cancelFlag) {
                        paytc_changeCancelFlag();
                    } else {
                        console.log('Request status Error');
                        jc('#uploading_msg').hide();
                        // jc('.upload_error, .upload_errmsg').show();
                        jc('.upload_errmsg').show();
                        paytc_showMessage('#my-welcome-message2');
                        var errorResponse = JSON.stringify(data);
                        paytc_saveuploaderror(errorResponse);

                        filesUploadStatus[upItem]['status'].upload_status = 'error';
                        if (!checkUnprocessFlag)
                            paytc_checkUnprocessData(partNum);
                        return;
                    }
                }
            }
        };
        request.upload.onprogress  = function (e) {
            //console.log("++++++ upload.onprogress ++++++" + request.status);
            if (e.lengthComputable) {
                probableUplaodSize = e.loaded;
                paytc_updateProgressBar();
            }
        };
        request.setRequestHeader("x-amz-date", dateHeader);
        request.setRequestHeader("Authorization", authHeader);
        //request.setRequestHeader("Content-Length", length);
        request.send(curBlobPart);

    });
}
function paytc_startPartitionAndUpload() {
    paytc_updateProgressBar();
    numParts = Math.ceil(totalSize / partSize);
    paytc_uploadPart(1);
}

function paytc_cancel() {
    $.ajax({
        url: uploadserver,
        data: {
            command: 'AbortMultipartUpload',
            sendBackData: sendBackData
        }
    }).done(function (data) {
        cancelFlag = true;
        console.log('upload cancelled');

    });
}

function paytc_upload(uploadid) {
    fileid  = uploadid;
    var url = window.location.href;
    var re  = /\/upload\?type=delivery/g;
    if (re.test(url)) {
        var vendorupload = true;
    }

    if (window.File && window.FileReader && window.FileList && window.Blob && window.Blob.prototype.slice) {
        for (i = 0; i < jc('#' + uploadid)[0].files.length; i++, InitialVal++) {
            fileObj = jc('#' + uploadid)[0].files[i];

            //  console.log(i+"<=i######## step 1##########>InitialVal"+InitialVal);
            exist_file_name = jc('#exist_file_name').val();
            if (vendorupload && typeof exist_file_name !== 'undefined') {
                // variable is undefined
                var upd_file_name   = fileObj.name.substr(0, fileObj.name.lastIndexOf('.'));
                var exist_file_name = exist_file_name.substr(0, exist_file_name.lastIndexOf('.'));
                if (exist_file_name != upd_file_name) {
                    sweetAlert('Uploading filename should be same.');
                    InitialVal--;
                    continue;
                }
            }

            // already file in the list

            var filetype = fileObj.type;
            var filtype = filetype.split("/");
            var sourcefiletype3 = jc("#sourcefiletype option:selected").val();

            if ((filtype[0] != "audio") && (filtype[0] != "video") && sourcefiletype3 == "Audio/Video") {
                sweetAlert("Sorry...", "Please upload audio,video files only.", "error");
                InitialVal--;
                continue;
            }else if (((filtype[0] == "audio") || (filtype[0] == "video")) && (sourcefiletype3 == "Document")) {
                sweetAlert("Sorry...", "Please upload documents only.", "error");
                InitialVal--;
                continue;
            }else if (uploadFilesArr.indexOf(fileObj.name) != -1) {
                sweetAlert('Already ' + fileObj.name + ' uploaded...');
                InitialVal--;
                continue;
            } else {

                //   console.log(i+"<=i######## step 2 else block ##########>InitialVal"+InitialVal);

                uploadFilesArr.push(fileObj.name);

                originalFile                            = fileObj.name;
                fileObj.modifyName                      = folderPath + paytc_makeid(6) + "xx_" + originalFile.replace(/[^A-Za-z0-9\_\-\.]/g, '');
                //  console.log(i+"<=i######## step 3 before filesUploadStatus##########>InitialVal"+InitialVal);
                filesUploadStatus[InitialVal]           = {};
                filesUploadStatus[InitialVal][uploadid] = fileObj;
                filesUploadStatus[InitialVal]['status'] = {
                    upload_status: 'start',
                    item_no: InitialVal,
                    file_name: fileObj.modifyName,
                    file_size: paytc_bytesToSize(fileObj.size, 1).replace(".0", ""),
                    file_type: fileObj.type
                };

                // console.log(i+"<=i######## step 3 after filesUploadStatus##########>InitialVal"+InitialVal);
                upItem2 = InitialVal;

                paytc_updateInfo(fileObj, uploadid);
                if (uploadProgress == false) {
                    uploadProgress = true;
                    //Added by Rohini R on 20/12/2016 to disable submit in CRM File upload while upload in progress
                    if (jc("#filesubmit").length) {
                        jc('#filesubmit').attr('disabled', 'disabled');
                    }
                    checkfiletype();
                    //jc(".DS-color-id").removeClass("chooserpay upcompleted").addClass("upgoing");
                    //jc("#upload-files").hide();
                    jc("#contact-details").hide();
                    jc(".upload-loading").show();
                    paytc_uploadFile(filesUploadStatus[upItem][uploadid]);
                }
            }

        }//for loop
    } else {
        alert('The File APIs are not fully supported in this browser.');
    }
    jc('[data-toggle="tooltip"]').tooltip();

}

function paytc_uploadFile(uploadFile) {
    console.log('Upload file...');
    uploadProgress = true;
    //quotesubmitbtn(uploadProgress);
    processingFile = uploadFile;
    totalSize      = uploadFile.size;
    $.ajax({
        url: uploadserver,
        timeout: 15000,
        data: {
            command: 'CreateMultipartUpload',
            fileInfo: {
                name: uploadFile.modifyName,
                type: uploadFile.type,
                size: uploadFile.size,
                lastModifiedDate: uploadFile.lastModifiedDate
            },
            otherInfo: {
                user: awsUser,
                pass: 'pass'
            }
        }, beforeSend: function () {
            // console.log('before start ');
        }, error: function (data) {

            if (cancelFlag) {
                paytc_changeCancelFlag();
            } else {
                jc('#uploading_msg').hide();
                // jc('.upload_error, .upload_errmsg').show();
                jc('.upload_errmsg').show();
                paytc_showMessage('#my-welcome-message2');
                var errorResponse = JSON.stringify(data);
                paytc_saveuploaderror(errorResponse);
                if (!checkUnprocesStartingPartFlag) {
                    paytc_checkUnprocesStartingPart(uploadFile);
                }
            }
        }, success: function () {
            if (checkUnprocesStartingPartFlag) {
                checkUnprocesStartingPartFlag = false;
                clearInterval(intervalfunc_start);
                jc('.upload_error, .upload_errmsg').hide();
                jc('#uploading_msg').show();
                if (jc('#quoteflagnew').val() == 0)
                    jc('#fvpp-blackout, #my-welcome-message2').hide();
            }
        }
    }).done(function (data, textStatus, jqXHR) {
        // console.log('==== CreateMultipartUpload ===='+upItem+"==>"+data.uploadId);
        jc('#removeFile-' + upItem).data('uploadid', data.uploadId);
        sendBackData = data;
        paytc_startPartitionAndUpload();
    });
}
function paytc_decideFileUpload() {
    // console.log('decideFileUpload ====> ');

    for (i = upItem; i < filesUploadStatus.length; i++) {
        if (uploadFilesArr.indexOf(filesUploadStatus[upItem][fileid]['name']) >= 0) {
            paytc_uploadFile(filesUploadStatus[upItem][fileid]);
            return;
        }
        else upItem = upItem + 1;
    }

    uploadProgress = false;
    //Added by Rohini R on 20/12/2016 to disable submit in CRM File upload while upload in progress
    if (jc("#filesubmit").length) {
        jc("#filesubmit").removeAttr("disabled");
    }
    checkfiletype();
    //jc(".DS-color-id").removeClass("chooserpay upgoing").addClass("upcompleted");
    //paytc_uploadagain('filepay');
    //jc("#upload-files").show();
    jc("#contact-details").show();
    jc(".upload-loading").hide();
    //console.log("************* ALL Files uploaded successfully*************");
}
function paytc_bytesToSize(bytes, precision) {
    var kilobyte = 1024;
    var megabyte = kilobyte * 1024;
    var gigabyte = megabyte * 1024;
    var terabyte = gigabyte * 1024;

    if ((bytes >= 0) && (bytes < kilobyte)) {
        return bytes + ' B';

    } else if ((bytes >= kilobyte) && (bytes < megabyte)) {
        return (bytes / kilobyte).toFixed(precision) + ' KB';
    } else if ((bytes >= megabyte) && (bytes < gigabyte)) {
        return (bytes / megabyte).toFixed(precision) + ' MB';

    } else if ((bytes >= gigabyte) && (bytes < terabyte)) {
        return (bytes / gigabyte).toFixed(precision) + ' GB';
    } else if (bytes >= terabyte) {
        return (bytes / terabyte).toFixed(precision) + ' TB';
    } else {
        return bytes + ' B';
    }
}

function paytc_getAwsLocation(href) {
    var l   = document.createElement("a");
    l.href  = href;
    var str = l.hostname;
    str.indexOf(".");
    var s3Bucket = str.substr(0, str.indexOf("."));
    return awsUrl + s3Bucket + l.pathname;
}
//on blur data capturing - start
function paytc_updateFormInfo(blurdataInfo) {
    blurdataInfo.qname       = jc('#paytc_qnamecrm').val();
    blurdataInfo.qemail      = jc('#paytc_qemailcrm').val();
    blurdataInfo.qcountrys   = jc('#paytc_qcountryscrm').val();
    blurdataInfo.acode       = jc('#paytc_acodecrm').val();
    blurdataInfo.qphone      = jc('#paytc_qphonecrm').val();
    blurdataInfo.qttime      = jc('#payt_tatcrm').val();
    blurdataInfo.qhfc        = jc('#paytc_hfc').val();
    blurdataInfo.agentid     = jc('#agent_ref').val();
    blurdataInfo.qcomment    = jc('#paytc_comment').val();
    blurdataInfo.entryval    = jc('#recordkey').val();
    blurdataInfo.service     = jc('#service').val();
    blurdataInfo.filedetails = uploadedFileDetailsArr.toString();
    $.ajax({
        //url:  crmRootpath+'crmquote_update_payment.php',
        url: crmRootpath + 'typing_pay_update_v1.0.php',
        data: {
            fieldinfocommand: 'updatefieldinfo',
            sitename: sitename,
            savedata: blurdataInfo,
            async: false,
        },
        type: 'POST',
        success: function (data) {
            jc('#recordkey').val(data);
        }
    });
}
//on blur data capturing - end

jc(document).ready(function () {
    paytc_getUploadPartSize();
    //on blur data capturing - start
    jc("#paytc_qemailcrm,#paytc_comment,#paytc_hfc,#agent_ref,#paytc_qcountryscrm,#paytc_acodecrm,#paytc_qphonecrm,#payt_tatcrm,#paytc_qnamecrm").blur(function () {
        var email = jc('#paytc_qemailcrm').val();
        var reg   = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
        if (reg.test(email) == true) {
            blurdataInfo           = {};
            blurdataInfo.comments  = jc(this).val();
            blurdataInfo.fieldname = jc(this).attr('id');
            paytc_updateFormInfo(blurdataInfo);
        }
    });
    //on blur data capturing - end
});

jc(document).on('click', '.up-close', function () {

    var sserid = jc(this).data('seerid');
    jc(".removeboth-" + sserid).each(function () {
        var modifyName = jc(this).data('modfy');
        paytc_deletefile(modifyName, this);
        uploadId    = jc(this).data('uploadid');
        var remFile = jc(this).data('file');
        if (uploadFilesArr.indexOf(remFile) !== -1) {
            uploadFilesArr.splice(uploadFilesArr.indexOf(remFile), 1);
        }
        uploadedFilesArr.splice(uploadedFilesArr.indexOf(remFile), 1);
        if (uploadedFileDetailsArr.length > 0) {

            for (i = 0; i < uploadedFileDetailsArr.length; i++) {
                var uploadedarrfilename  = uploadedFileDetailsArr[i].split("#-#");
                var uploadedarrfilename1 = uploadedarrfilename[0].substring(uploadedarrfilename[0].indexOf("_") + 1);
                if (uploadedarrfilename1 == remFile.replace(/[^A-Za-z0-9\_\-\.]/g, '')) {
                    uploadedFileDetailsArr.splice(uploadedFileDetailsArr.indexOf(uploadedFileDetailsArr[i]), 1);
                    blurdataInfo           = {};
                    blurdataInfo.fieldname = "fileuploader";
                    paytc_updateFormInfo(blurdataInfo);
                }
            }
        }

        jc(this).parent().parent().remove();
    });
    if (!uploadFilesArr.length) {
        jc('#' + fileinfoid).hide();
        jc('#skip-files').show();
        var totalfilecnt = jc('.audioLengthpay').length;
        if (totalfilecnt <= 0) {
            jc('.payment-nav-pills #tabid4').attr('href', '');
            jc('.payment-nav-pills #tabid4').parent('li').addClass('disabled');
        }
    }
    paytc_reorder();
    checkfiletype();
});
function paytc_quotesubmitbtn(upProgress) {
    if (upProgress) {
        jc('.progressbtn').show();
        jc('.quotebtn').hide();
    } else {
        jc('.progressbtn').hide();
        jc('.quotebtn').show();
    }
    jc('#uploadprogress').val(upProgress);
}

function paytc_makeid(Strlen) {
    var text     = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    for (var i = 0; i < Strlen; i++)
        text += possible.charAt(Math.floor(Math.random() * possible.length));
    return text;
}

function paytc_checkUnprocessData(partNum) {
    checkUnprocessFlag = true;
    var counter        = 0;
    intervalfunc       = setInterval(function () {
        counter++;
        paytc_uploadPart(partNum);
        if (counter >= 20) {
            clearInterval(intervalfunc);
        }
    }, 10000);
}


function paytc_getUploadPartSize() {
    $.getJSON('//freegeoip.net/json/?callback=?', function (data) {
        var country_code = data.country_code;
        switch (country_code) {
            case "IN":
                partSize = 5 * 1024 * 1024;
                break;
            case "US":
                partSize = 50 * 1024 * 1024;
                break;
            case "GB":
            case "AU":
            case "UK":
                partSize = 20 * 1024 * 1024;
                break;
            default :
                partSize = 50 * 1024 * 1024;
                break;
        }
    });

}

function paytc_showMessage(id) {
    var $body   = jc('body');
    var $dialog = jc(id);
    $body.append('<div id="fvpp-blackout"></div>');
    $dialog.append('');
    $blackout = jc('#fvpp-blackout');
    var $blackout;
    $blackout.show();
    jc("#fvpp-close").css({'display': "none"});
    $dialog.show();
    jc(".DS-sidefixed-nav").css({'display': "none"});

}

function paytc_checkUnprocessCompletePart() {
    checkUnprocessCompletePartFlag = true;
    var counter                    = 0;
    intervalfunc_complete          = setInterval(function () {
        counter++;
        paytc_completeMultipartUpload();
        if (counter >= 20) {
            clearInterval(intervalfunc_complete);
        }
    }, 10000);
}

function paytc_checkUnprocesStartingPart(uploadFiles) {
    checkUnprocesStartingPartFlag = true;
    var counter                   = 0;
    intervalfunc_start            = setInterval(function () {
        counter++;
        paytc_uploadFile(uploadFiles);
        if (counter >= 20) {
            clearInterval(intervalfunc_start);
        }
    }, 10000);
}
function paytc_saveuploaderror(errorResponse) {
    dataInfo                     = {};
    var networkerrormailsent     = 0;
    dataInfo.qname               = jc('#paytc_qnamecrm').val();
    dataInfo.qemail              = jc('#paytc_qemailcrm').val();
    dataInfo.qcountrys           = jc('#paytc_qcountryscrm').val();
    dataInfo.acode               = jc('#paytc_acodecrm').val();
    dataInfo.qphone              = jc('#paytc_qphonecrm').val();
    dataInfo.qttime              = jc('#payt_tatcrm').val();
    dataInfo.entryval            = jc('#recordkey').val();
    dataInfo.networkerrflag      = jc('#networkerrflag').val();
    dataInfo.service             = jc('#service').val();
    dataInfo.crmpage             = jc('#crmpage').val();
    dataInfo.filedetails         = JSON.stringify(uploadFilesArr);
    dataInfo.fileuploadstatus    = JSON.stringify(filesUploadStatus);
    dataInfo.uploadprogress      = uploadProgress;
    dataInfo.uploaderrorresponse = errorResponse;
    dataInfo.uploadedfiledetails = JSON.stringify(uploadedFileDetailsArr);
    if (jc('#paytc_qemailcrm').val() && jc('#networkerrflag').val() == 0) {
        $.ajax({
            url: crmRootpath + 'typing_pay_update_v1.0.php',
            data: {
                fieldinfocommand: 'mailnetworkerror',
                networkerrordata: dataInfo,
                sitename: sitename,
                async: false,
            },
            type: 'POST',
            success: function (data) {
                jc('#networkerrflag').val(data);
            }
        });
    }
}

function paytc_changeCancelFlag() {
    uploadProgress = false;
    paytc_resetProgressBar();
    paytc_resetParam();
    paytc_updateFinalInfo();
    paytc_decideFileUpload();
}
function paytc_paymentenable() {
    var durationcheck = [];
    jc(".length").each(function (i) {
        var dur = parseInt(jc('#durationnewpay-' + i).val());
        if (isNaN(dur) || dur == '' || dur < 1) {
            jc("#filetypespay" + i).show();
            jc("#filetypespay" + i).removeClass("hrdisplay").addClass("errlength");
            jc("#filetypespay" + i).html("Enter file length!");
            jc('#durationnewpay-' + i).val();
            dur = '00';
        } else {
            jc("#filetypespay" + i).show();
            jc("#filetypespay" + i).removeClass("errlength").addClass("hrdisplay");
            var durinhrs = hourconverter(dur);
            jc("#filetypespay" + i).html(durinhrs);
        }
        jc('#durationnew-' + i).val(dur);
        durationcheck.push(dur);
        paytc_pricequoteclac();
    });
    // if (jc.inArray('0', durationcheck)) {
    //     jc('.qsubmitcrm').css({'pointerEvents': 'auto'});
    // } else {
    //     jc('.qsubmitcrm').css({'pointerEvents': 'none'});
    // }
    //jc("#qsubmitcrm").load();
}
function paytc_paymentenablexx() {
    var durationcheckxx = [];
    jc(".length").each(function (i) {
        var dur = parseInt(jc('#durationnew-' + i).val());
        if (isNaN(dur) || dur == '' || dur < 1) {
            jc("#filetypes" + i).show();
            jc("#filetypes" + i).removeClass("hrdisplay").addClass("errlength");
            jc("#filetypes" + i).html("Enter file length!");
            jc('#durationnew-' + i).val();
            dur = '00';
        } else {
            jc("#filetypes" + i).show();
            jc("#filetypes" + i).removeClass("errlength").addClass("hrdisplay");
            var durinhrs = hourconverter(dur);
            jc("#filetypes" + i).html(durinhrs);
        }
        jc('#durationnewpay-' + i).val(dur);
        durationcheckxx.push(dur);
        paytc_pricequoteclac();
    });
    // if (jc.inArray('0', durationcheckxx)) {
    //     jc('.qsubmitcrm').css({'pointerEvents': 'auto'});
    // } else {
    //     jc('.qsubmitcrm').css({'pointerEvents': 'none'});
    // }
    //jc("#qsubmitcrm").load();
}
function hourconverter(durminutes) {
    var hours   = Math.floor(durminutes / 60);
    var minutes = durminutes % 60;
    hours       = pad(hours, 2);
    minutes     = pad(minutes, 2);
    return duhrs = "(" + hours + ":" + minutes + ")";

    //$('.convertedHour').html(hours);
    //$('.convertedMin').html(minutes);

}
function pad(str, max) {
    str = str.toString();
    return str.length < max ? pad("0" + str, max) : str;
}
function paytc_resetVariables() {
    sendBackData;
    totalSize;
    sureUploadSize = 0, probableUplaodSize = 0;
    numParts;
    partsLeft = [];
    file;
    cancelFlag             = false
    fileuploadstatus       = [];
    uploadFilesArr         = [];
    uploadedFilesArr       = [];
    uploadedFileDetailsArr = [];
}
function checkfiletype() {
    var filesser_id = jc("input[name='length[]']")
        .map(function () {
            return jc(this).data('serid');
        }).get();
    var i;
    var fildetails;
    var lastoccurance;
    var fileaudio = false;
    var filevidio = false;
    var quotetype = false;
    jc.each(filesser_id, function (index, value) {
        i             = value;
        fildetails    = jc("#uploadFiles-" + i).val().trim();
        fildetails    = fildetails.split("#-#");
        lastoccurance = fildetails[fildetails.length - 1]
        fileaudio     = lastoccurance.includes("audio");
        filevidio     = lastoccurance.includes("video");
        if (fileaudio || filevidio) {
            quotetype = true
        }
    });
    if(quotetype){
        jc('#uploadat').val('fileupload');
    }else{
        jc('#uploadat').val('fileuploadpay');
    }
    //console.log(fileaudio);
    //console.log(filevidio);
    
}