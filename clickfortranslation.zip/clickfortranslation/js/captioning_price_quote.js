jc(document).ready(function() {
    var sourcefiletype = jc('#sourcefiletype').val();
    if(sourcefiletype != '' && sourcefiletype != null){
        jc('#sourcefiletype').trigger('change');
    }

    jc('#srclang,#trglang,.chozn-select').chosen();
    jc('#srclang').chosen().change(function (evt, params) {
        //jc("#minutes").trigger("blur");
        showservice();
    });

    jc('#trglang').chosen().change(function (){
        //jc('#trglang').trigger('blur');
        showservice();
    });
    /*jc('#specification_pay').chosen().change(function (){
        jc('#specification_pay').trigger('blur');
    });*/
// For updating page visit duration
    var startTime;
    var endTime;
    startTime  = new Date()
    window.onunload = function(){
        endTime = new Date();
        var elapsedSeconds = endTime.getTime() - startTime.getTime();
        var seconds = parseFloat(elapsedSeconds)/1000;
        var timespentrecordid  = $("#timespendingid").html();
        var ajxurl      = window.location.href;
        $.ajax({
            url: serverPath+'client.php',
            data: {'timeSpent': seconds,
                'timespentrecordid': timespentrecordid,
                'ajxurl' : ajxurl
            },
            async: false,
            type: 'POST',
            success: function (data) {

            }

        });
    }
});

jc( document ).on('focus focusin','.tooltiptrigger', function() {
    jc(this).trigger("mouseenter");
});
jc( document ).on('mouseenter focusin','.tooltiptrigger', function() {
    jc(this).tooltip();
});
jc( document ).on('blur','.tooltiptrigger', function() {
    jc(this).tooltip('destroy');
});
function showservice(){
    var language          = jc("#srclang option:selected").val();
    var trgtlanguage      = jc("#trglang").val();
    var trgtlanguagelen = 0;
    if(trgtlanguage != '' && trgtlanguage != null) {
        trgtlanguagelen = trgtlanguage.length;
    }
    jc("#trchave").hide();
    jc("#trlhave").hide();
    jc("#needtrc").hide();
    jc(".trcl").hide();
    if(language != ''
        && language != null
        && trgtlanguage != ''
        && trgtlanguage != null
        && trgtlanguagelen == 1
    ){
        jc("#needtrc").slideDown();
        jc(".trcl").show();
        if(language == trgtlanguage){
            jc("#trchave").slideDown();
        }else{
            jc("#trlhave").slideDown();
        }
    }
}
/* TAT calculation start */
function tatCalculation(language, filelength){
    var adddate= 0;
        var havetrc = jc('#needtrc').is(':checked');
        if (!havetrc) {
            if (jc('#trchave').is(':visible')) {
                adddate = 1
            } else if (jc('#trlhave').is(':visible')) {
                adddate = 2
            }
        }
        if(filelength <= 30 && havetrc) {
            adddate = 0
        }else if(filelength <= 30 && !havetrc){
            adddate = 1
        }
        var std_delivery      = filelength / 60;
        var std_delivery_calc = Math.ceil(std_delivery);
        var std_delivery_time = '';
        if (std_delivery_calc <= 1 && language == 'English') {
            std_delivery_time = std_delivery_calc + " Business day";
        } else {
            std_delivery_calc = parseInt(std_delivery_calc)+parseInt(adddate);
            var to_deltime    = parseInt(std_delivery_calc) + parseInt(1);
            std_delivery_time = parseInt(std_delivery_calc) + ' - ' + to_deltime + " Business days";
        }
        jc("#tat-val").html(std_delivery_time);
return std_delivery_time;
}
function showerr(){
    jc('#uploadat').val('fileupload');
    jc('.order-summary').hide();
    jc('.pt').hide();
    jc('.u-email').hide();
    jc('.no-summary').show();
    jc('.qt').hide();
    jc('.hardcopytat').hide();
    jc("#expedited-timeline").hide();
    jc("#delivery-timeline").hide();
    jc('.expeditedblk').slideUp();
    jc('.offer-blk').hide();
}
function showquote(){
    jc('#uploadat').val('fileupload');
    jc('.order-summary').hide();
    jc('.pt').hide();
    jc('.u-email').show();
    jc('.qt_mailinfo').show();
    jc('.no-summary').show();
    if(!uploadProgress) {
        jc('.qt').show();
    }
   // jc(".hardcopytat").hide();   
}
function showpay(){
    jc('#uploadat').val('fileuploadpay');
    jc('.no-summary').hide();
    jc('.qt').hide();
    jc('.qt_mailinfo').hide();
    jc('.order-summary').show();
    jc('.u-email').show();
    if(!uploadProgress) {
        jc('.pt').show();
    }
    blurdataInfo           = {};
    blurdataInfo.comments  = 'Yes';
    blurdataInfo.fieldname = 'priceviewed';
    blurdataInfo.priceviewed = 'Yes';
    paytc_updateFormInfo(blurdataInfo);


    setTimeout(function() {
        blurdataInfo           = {};
        blurdataInfo.comments  = jc('#amount').val();
        blurdataInfo.fieldname = 'pricetotal';
        blurdataInfo.pricetotal = jc('#amount').val();
        paytc_updateFormInfo(blurdataInfo);
    }, 1000);
}
function validatepay(elem){
    var thisid = jc(elem).attr("id");
    var language          = jc("#srclang option:selected").val();
    var trgtlanguage      = jc("#trglang").val();
    var formats           = (jc('#formatting').val() === null) ? "" : jc('#formatting').val();

    var hours = parseInt(jc('#hours').val());
    var minutes = parseInt(jc('#minutes').val());
    hours = (!hours)?0:hours;
    minutes = (!minutes)?0:minutes;
    var filelength   = minutes + hours * 60;

    var errclass = 0;

    if (language == '') {
        jc('#srclang_chosen .chosen-single').addClass("errmsg");
        if(thisid == "srclang"){return false;}
    }else{
        jc('#srclang_chosen .chosen-single').removeClass('errmsg');
        errclass = jc("#captioningForm").parent().find('.errmsg').length;
        if(thisid == "srclang" && errclass <= 0){return false;}
    }
    if (trgtlanguage == '' || trgtlanguage == null) {
        jc("#trglang_chosen").addClass('errmsg');
        if(thisid == "srclang" || thisid == "trglang" ){return false;}
    }else{
        jc("#trglang_chosen").removeClass('errmsg');
        errclass = jc("#captioningForm").parent().find('.errmsg').length;
        if(thisid == "trglang" && errclass <= 0){return false;}
    }

    if (formats == '') {
        jc("#formatting").addClass('errmsg');
        if(thisid == "srclang" || thisid == "trglang" || thisid == "formatting" ){return false;}
    }else{
        jc("#formatting").removeClass('errmsg');
        errclass = jc("#captioningForm").parent().find('.errmsg').length;
        if(thisid == "formatting" && errclass <= 0){return false;}
    }
    if (filelength == '' || filelength == 0) {
        jc("#minutes").addClass('errmsg');
        if(thisid == "srclang" || thisid == "trglang" || thisid == "formatting" || thisid == "minutes" || thisid == "hours" ){return false;}
    }else{
        jc("#minutes").removeClass('errmsg');
        errclass = jc("#captioningForm").parent().find('.errmsg').length;
        if((thisid == "minutes" || thisid == "hours") && errclass <= 0){return false;}
    }

}
jc(document).on('chosen:hiding_dropdown','#srclang', function (evt, params) {
    jc("#srclang").trigger("blur");
});
jc(document).on('chosen:hiding_dropdown','#trglang', function (evt, params) {
    jc("#trglang").trigger("blur");
});
jc(document).on('chosen:hiding_dropdown','#specification_pay', function (evt, params) {
    jc("#specification_pay").trigger("blur");
});

jc(document).on('change blur keyup click','.del-time,.search-choice-close', function() {
    var language          = jc("#srclang option:selected").val();
    var trgtlanguage      = jc("#trglang").val();
    var formats           = (jc('#formatting').val() === null) ? "" : jc('#formatting').val();
    var needtrc           = jc('#needtrc').is(":checked") ? 1 : 0;
    var specification_pay = (jc('#specification_pay').val() === null) ? "" : jc('#specification_pay').val();
    var deliveryReq       = jc('input[name=deliveryReq]:checked', '#captioningForm').val();
    var min = 0;
    var minVal = jc("input[name='length[]']")
        .map(function () {
            return jc(this).val();
        }).get();

    var serialId = jc("input[name='uploadFiles[]']")
        .map(function () {
            return jc(this).data('serid');
        }).get();
    var len = minVal.length;
    min =(len > 0)?0:min;
    var i = 0;
    for (i = 0; i < len; i++) {
        if (!isNaN(min) && !isNaN(minVal[i]) && minVal[i] != '') {
            min = parseInt(min) + parseInt(minVal[i]);
        }
    }
    if (isNaN(min)) {
        min = 0;
    }
    if(i > 0) {
        filelength = min;
        var temphour = hourconverter(filelength);
        var res = temphour.replace("(", "").replace(")", "");
        var timear = res.split(':');

        jc('#hours').val(timear[0]);
        jc('#minutes').val(timear[1]);

    }
    var hours = parseInt(jc('#hours').val());
    var minutes = parseInt(jc('#minutes').val());
    hours = (!hours)?0:hours;
    minutes = (!minutes)?0:minutes;
    var filelength   = minutes + hours * 60;

    if(filelength >= 60){
        jc(".freetrial").slideDown("fast");
    }else{
        jc(".freetrial").slideUp("fast");
    }


    var trgtlanguagelen = 0;
    if(trgtlanguage != '' && trgtlanguage != null) {
        trgtlanguagelen = trgtlanguage.length;
    }
    validatepay(this);
    if(language == ''
        && (trgtlanguage == '' || trgtlanguage == null)
        && formats == ''
        && (filelength == '' || filelength == 0)
        && needtrc == 0
    ){
            jc('.u-email').hide();
            jc('.pt').hide();
            jc('.qt').hide();            
            jc('.no-summary').show();
            jc('.qt_mailinfo').hide();
            jc('.order-summary').hide();
            
    }else {


        if (language == '') {
            jc('.qt_msg').html('Select <b class="text-highlight">source language</b> to get the price quote for your project.');
            showerr();
        } else if (trgtlanguage == '' || trgtlanguage == null) {
            jc('.qt_msg').html('Select <b class="text-highlight">target language</b> to get the price quote for your project.');
            showerr();
        } else if (formats == '') {
            jc('.qt_msg').html('Select <b class="text-highlight">format</b> to get the price quote for your project.');
            showerr();
        } else if (filelength == '') {
            jc('.qt_msg').html('Enter <b class="text-highlight">file length</b> to get the price quote for your project');
            showerr();
        }else if (filelength > 600) {
            jc('.qt_msg').html('Customized discounts apply for file length above 600 minutes.');
            jc("#delivery-timeline").hide();
            showquote();
        } else if ((language != 90 && jc.inArray("90", trgtlanguage) == -1) && (jc.inArray(language, trclang) != -1 && language != trgtlanguage)) {
            jc('.qt_msg').html('Customized rates apply for the languages you selected.');
            jc("#delivery-timeline").hide();
            showquote();
        } else if (trgtlanguagelen > 1) {
            jc('.qt_msg').html('Customized rates apply for multiple target languages.');
            jc("#delivery-timeline").hide();
            showquote();
        }
        else if (jc.inArray(language, trclang) == -1 || jc.inArray((trgtlanguage == null) ? '' : trgtlanguage.toString(), trclang) == -1) {
            jc('.qt_msg').html('Customized rates apply for the languages you selected.');
            jc("#delivery-timeline").hide();
            showquote();
        }
        else if (formats == "Embedded" && language == 90 && trgtlanguage == 90) {
            jc('.qt_msg').html('Customized rates apply for embedded.');
            jc("#delivery-timeline").hide();
            showquote();
        }
        else if (jc.inArray("1", specification_pay) != -1 || jc.inArray("2", specification_pay) != -1 || jc.inArray("4", specification_pay) != -1 || jc.inArray("13", specification_pay) != -1) {
            jc('.qt_msg').html('Customized rates apply for the purpose <b>Broadcast television, DVD, Blue-ray and others</b>.');
            jc("#delivery-timeline").hide();
            showquote();
        }else{
        //else if(deliveryReq == 'option2') {
        jc('.expeditedblk').hide();
        paytc_pricequoteclac();
        var std_delivery_time = tatCalculation(language, filelength);
        jc("#tat-val").html(std_delivery_time);
        jc("#delivery-timeline").show();
        showpay();
        var deliverytime = jc('#delivery-timeline').is(':visible');
        if (deliverytime && deliveryReq == 'option2') {
            jc('.expeditedblk').show();
            jc('.qt_msg').html('Customized rates apply for expedited service.');
            jc("#delivery-timeline").show();
            showquote();
        }

        //}
    }
    }
});
/* TAT calculation end */
function eligibility() {
    var mailcountry = jc('#mailcountry option:selected').val();
    var paytc_mailaddresspay = jc('#paytc_mailaddresspay').val();
    var mailfilecrmpay = jc('#mailfilecrmpay').is(':checked');
    
    if(mailcountry !='' && mailcountry != 'United States'){
        jc('#uploadat').val('fileupload');
    }else{
        jc('#uploadat').val('fileuploadpay');
    }
}
function remove_allfiles(){
    jc('.up-close').each(function() {
        jc(this).trigger("click");
    });
}
function uncheckall(){
    //jc("#qtvercrmpay,#qttcodecrmpay,#nativecrmpay").trigger("click");
    jc('#qtvercrmpay,#qttcodecrmpay,#nativecrmpay').prop('checked', false);

}
function isNumberKeyq(evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode;
    //console.log(charCode);
    if (charCode != 45 && charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
    return true;
}
jc( document ).on('click','#view-chart', function() {
    var focusto = jc(".place_order2").is(":visible");
    jc("#pay_chart").slideToggle("slow");
    if(!focusto){
        jc('html, body').animate({'scrollTop' : jc("#pay_chart").position().top},'fast');
    }else{
        jc('html, body').animate({'scrollTop' : jc("#page-top").position().top},'fast');
    }
});
jc( document ).on('click','#qttcodecrmpay', function() {
    if(jc("#qttcodecrmpay").prop('checked') == true){
        jc(".timecodeneed").show();
    }else{
        jc("#howoftn").val("");
        jc("#spkrchange").prop('checked', false);
        jc(".timecodeneed").hide();
    }
});
jc(document).on('change', '#filepay', function() {
    paytc_upload('filepay');
});
//var formSubmitting = false;
//var setFormSubmitting = function() { formSubmitting = true; };
window.onload = function() {
    jc(".chosen-search-input").attr("placeholder", "Type here");
};
/* here js */
var source1;
var target;
var valFind;
jc(document).ready(function() {
    //jc(".select2").select2();
	var bs_url = window.location;
	//var base_urls = bs_url.protocol + "//" + bs_url.host + "/" + bs_url.pathname.split('/')[1];
    var base_urls = bs_url.protocol + "//" + bs_url.host;
    var isVisible = jc('#fileuploader').is(':visible');
	if(isVisible == false){
		jc.ajax({
			url:base_urls+'/logdetails.php',
			data : 'siteurl='+base_urls,                       
			type: 'POST',
			success: function(data){
				// alert(data);
			},
			error : function (data) {
				//alert(data);		
			}		
		});
	}
});
/* here submit */
jc(document).on('click','#filesubmit', function(e) {
    var name        = jc('#cont_qnamecrm').val();
    var country     = jc('#cont_qcountryscrm').val();
    var phone       = jc('#cont_qphonecrm').val();
    var payt_tatcrm = jc('#cont_tatcrm').val();
    var paytc_hfc   = jc("#cont_hfc").val();
    var expedited   = jc("#expedited").val();
    var service_name = jc("#service_name").val();
    var pid         = jc("#pid").val();
    var deliveryReq = jc('input[name=deliveryReq]:checked', '#captioningForm').val();


    var email    = $('#trans_email').val();
    var sitename = $('#sitename').val();
    var comment    = $('#upcomments').val();
    var filena     = new Array();
    var files      = '';
    var UploadFlag = uploadProgress;
    var ordId      = $('#ordId').val();
    filena         = [];
    $(".fileName").each(function (index) {
        elemval = $(this).val().trim();
        filena.push(elemval);
    });
    var count = filena.length;
    var completedfilecnt = $('.audioLength:visible').length;
    var recordkeyval = $('#recordkey').val();
    var form_data = new FormData();


    form_data.append('name', name);
    form_data.append('country', country);
    form_data.append('phone', phone);
    form_data.append('tatdate', payt_tatcrm);
    form_data.append('paytc_hfc', paytc_hfc);
    form_data.append('expedited', expedited);
    form_data.append('service_name', service_name);
    form_data.append('recordkey', recordkeyval);
    form_data.append('uploadFiles', filena);
    form_data.append('count', count);
    form_data.append('ordId', ordId);
    form_data.append('completedfilecnt', completedfilecnt);
    form_data.append('quoteflag', $('#quoteflag').val());
    form_data.append('uploadflag', UploadFlag);
    form_data.append('uptype', 1);
    form_data.append('upcomments', comment);
    form_data.append('email', email);
    form_data.append('sitename', sitename);
    form_data.append('pid', pid);
    form_data.append('uploadedFileDetailsArr', uploadedFileDetailsArr);
    $('#qfmsgcrm').css({'color': '#3573A6'});
    $('#qfmsgcrm').html('Processing...');
    $('#quoteflagnew').val(1);
    if ($('#quoteflag').val() == 0) {
        $('#fileuploader').prop('onclick', null);
        document.getElementById('fileuploader').style.removeProperty('cursor');
        $('span.up-close').hide();
        if (uploadProgress == true) {
            showMessage('#my-welcome-message2');
        }
    } else {
        form_data.append('quoteinfo', quoteInfo);
        form_data.append('ticketID', ticketID);
    }
    $('#filesubmit').hide();
    $('#processing').show();
    $.ajax({
        url: update_url,
        dataType: 'json',
        contentType: false,
        processData: false,
        data: form_data,
        type: 'POST',
        success: function (data) {
            if (data.type == 'quote' && data.status == 1) {
                $('#quoteflag').val(data.status);
                quoteInfo = data.info;
                ticketID = data.ticketid;
            }
            if (data.type == 'error') {
                output = data.text;
            }
            else {
                $('#qfmsgcrm').html('');
                output = data.text;
                if (output == 'Your request has been sent successfully and you will receive an email from us shortly. Thank you!') {
                    if (successpath) {
                        location.href = "http://" + successpath + "/success.php?crmpage=upload";
                    } else {
                        $('#qfmsgcrm').html(output);
                        window.setTimeout(function () {
                            location.reload()
                        }, 7000);
                    }
                }
                else {
                    $('#qfmsgcrm').html(output);
                    $('#qfmsgcrm').css({'color': '#333'});
                }
            }
        }
    });
});
/* here qsubmit */
jc(document).on('click','.qsubmitcrm', function(e) {
    var reg        = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
    var buttonname = jc(this).attr('value');
    var prfilelength   = '';
    var deliveryReq    = '';
    var catetype       = '';
    var trgtunitcost   = 0.00;
    var trgttotamt     = 0.00;
    var mfile_subamt   = 0.00;
    var subamttot      = 0.00;
    var transactionfee = 0.00;
    var paymentamt     = 0.00;
    // var mini_subamt    = 0.00;
    var script_cost    = 0.00;
    var tcode_cost    = 0.00;
    var formatting     = '';

    var filena      = new Array();
    var files       = '';
    var UploadFlag  = uploadProgress;
    filena          = [];

    deliveryReq    = jc('#expedited').is(":checked") ? 1 : 0;

    if (buttonname != "Get Quote") {
        trgtunitcost   = jc("#trgt_unitcost").val();
        trgttotamt     = jc("#trgt_totamt").val();
        mfile_subamt   = jc("#mfile_subamt").val();
        script_cost    = jc("#script_cost").val();
        tcode_cost    = jc("#tcode_cost").val();
        subamttot      = jc("#subamttot").val();
        transactionfee = jc("#trans_price").val();
        paymentamt     = jc("#paymentamt").val();
        // mini_subamt     = jc("#mini_subamt").val();
    }
    var needtrc             = jc('#needtrc').is(":checked") ? 1 : 0;
    var specification_pay   = jc("#specification_pay").val();
        formatting          = jc("#formatting").val();
    var hours    = parseInt(jc('#hours').val());
    var minutes  = parseInt(jc('#minutes').val());
    hours        = (!hours) ? 0 : hours;
    minutes      = (!minutes) ? 0 : minutes;
    prfilelength = minutes + hours * 60;

    var srclang        = jc("#srclang").val();
    var trglang        = jc("#trglang").val();
    var fileupload_tat        = "";
    var isVisibletatdate = jc('#delivery-timeline').is(':visible');
    if(isVisibletatdate == true && deliveryReq == 1){fileupload_tat = jc("#fileupload_tat").val();}
    var email          = jc('#paytc_qemailcrm').val();
    var agent_ref      = jc("#agent_ref").val();
    var form_data      = new FormData();
    var eaddress       = email;
    var uploadat       = jc("#uploadat").val();
    var aprxtat        = "";
    var isVisibletat = jc('#delivery-timeline').is(':visible');
    if(isVisibletat == true && deliveryReq == 0){aprxtat = jc("#tat-val").html();}
    var recordkeyval = jc('#recordkey').val();
    var service      = jc('#service').val();
    var sitename     = jc("#site_namee").val();
    var camethrough  = jc("#camethrough").val();
    var source       = srclang;
    var target       = trglang;

    jc( ".fileNamepay" ).each(function( index ) {
        elemval = jc( this ).val().trim();
        filena.push(elemval);

    });
    var filesserid = jc("input[name='uploadFiles[]']")
        .map(function () {
            return jc(this).data('serid');
        }).get();

    var i               = 0;
    var fildetail       = [];
    var duratnval       = [];
    var tempfildetail   = '';
    var tempdur         = '';

    jc.each(filesserid, function (index, value) {
        i = value;
        tempfildetail = jc("#uploadFiles-"+i).val().trim();
        fildetail.push(tempfildetail);

        tempdur = jc("#durationnewpay-"+i).val().trim();
        duratnval.push(tempdur);

    });

    var count            = filena.length;
    var completedfilecnt = jc('.audioLengths:visible').length;
    var filecomments     = jc('#filecomments').val();
    var cst_db  = jc("#cst_db").val();
    var ofpct            = jc("#ofpct").html();
    var offerpct         = jc("#offerpct").val();
    var offerval         = jc("#offerval").val();
    var finalround       = jc("#finalround").val();
    if (offerpct <= 0 && offerval <= 0) {
        offerval   = 0;
        finalround = 0;
        ofpct      = '';
    }
    var siteprtcl       = jc("#siteprtcl").val();
    var frtrial= '';
    if(jc(".freetrial").is(":visible")){
        var frtrial= jc('#frtrial').is(":checked")?1:0;
    }

    form_data.append('cst_db', cst_db);
    form_data.append('completedfilecnt', completedfilecnt);
    form_data.append('count', count);
    form_data.append('fildetail', fildetail);
    form_data.append('duratnval', duratnval);
    form_data.append('filena', filena);
    form_data.append('uploadflag', UploadFlag);

    form_data.append('recordkey', recordkeyval);
    form_data.append('prfilelength',prfilelength);
    form_data.append('source', source);
    form_data.append('target', target);
    form_data.append('specification_pay',specification_pay);
    form_data.append('formatting',formatting);
    form_data.append('fileupload_tat', fileupload_tat);
    form_data.append('needtrc', needtrc);
    form_data.append('uploadat', uploadat);
    form_data.append('email', email);
    form_data.append('trgtunitcost',trgtunitcost);
    form_data.append('trgttotamt',trgttotamt);
    form_data.append('script_cost',script_cost);
    form_data.append('tcode_cost',tcode_cost);
    form_data.append('mfile_subamt',mfile_subamt);
    form_data.append('subamttot', subamttot);
    form_data.append('transactionfee', transactionfee);
    form_data.append('paymentamt', paymentamt);
    // form_data.append('mini_subamt', mini_subamt);
    

    form_data.append('agent_ref', agent_ref);
    form_data.append('aprxtat', aprxtat);
    form_data.append('camethrough', camethrough);
    form_data.append('service', service);
    form_data.append('sitename', sitename);
    form_data.append('deliveryReq',deliveryReq);
    form_data.append('buttonname', buttonname);
    form_data.append('uploadedFileDetailsArr', uploadedFileDetailsArr);
    form_data.append('filecomments', filecomments);
    form_data.append('offerval', offerval);
    form_data.append('finalround', finalround);
    form_data.append('ofpct', ofpct);
    form_data.append('siteprtcl', siteprtcl);
    form_data.append('frtrial', frtrial);

   if(srclang ==''){
        jc('#srclang_chosen').tooltip({title: "Source language is required !"});
        jc('#srclang_chosen').trigger("mousedown");
        jc('#srclang').change(function() {
            jc('#srclang').tooltip('destroy');
        });
        return false;
    }
    if(trglang == ''){
        jc('#trglang_chosen').tooltip({title: "Target language is required !"});
        jc('#trglang_chosen').trigger("mousedown");
        jc('#trglang').change(function() {
            jc('#trglang').tooltip('destroy');
        });
        return false;
    }

    if(deliveryReq == 1 && fileupload_tat ==''){
        jc('#fileupload_tat').tooltip({title: "Turnaround time is required!"});
        jc('#fileupload_tat').focus();
        jc('#fileupload_tat').keypress(function () {
            jc('#fileupload_tat').tooltip('destroy');
        });
        return false;
    }
    var filelengthvalid = true;
    var invalidlength   = '';

    jc(".length").each(function (i) {
        var thisid = jc(this).attr('id');
        var arr    = thisid.split('-');
        i          = arr[1];
        var dur    = parseInt(jc("#durationnewpay-" + i).val());
        if (isNaN(dur) || dur == '' || dur < 1) {
            filelengthvalid = false;
            invalidlength   = i;
        }
    });

    if (!filelengthvalid) {
        jc('#durationnewpay-' + invalidlength).tooltip({title: "Enter file length!"});
        jc('#durationnewpay-' + invalidlength).focus();
        return false;
    }

    if(email ==''){
        jc('#paytc_qemailcrm').tooltip({title: "Email id is required!"});
        jc('#paytc_qemailcrm').focus();
        jc('#paytc_qemailcrm').keypress(function () {
            jc('#paytc_qemailcrm').tooltip('destroy');
        });
        return false;
    }
    if(email !='' && (reg.test(email) == false)){
        jc('#paytc_qemailcrm').tooltip({title: "Email id is invalid!"});
        jc('#paytc_qemailcrm').focus();
        jc('#paytc_qemailcrm').keypress(function () {
            jc('#paytc_qemailcrm').tooltip('destroy');
        });
        return false;
    }

   // jc('.qt,.pt').html('Processing...');
    jc('.qt,.pt').hide();
    jc('.pr').show();
    jc.ajax({
        url:update_quote,
        dataType: 'json',  // what to expect back from the PHP script, if anything
        //cache: false,
        contentType: false,
        processData: false,
        data: form_data,
        type: 'POST',
        success: function(data){
            console.log(data);
            if (uploadat == "fileuploadpay" && buttonname == "Proceed to Payment") {
                jc('#item_number_1').val(data.ordsid);
                jc("#captioningForm").submit();
                //jc('#qsubmitcrm').html('processing...');
                return false;
            }else{
                if(data.type == 'quote' && data.status == 1){
                    jc('#quoteflag').val(data.status);
                    quoteInfo = data.info;
                }
                if(data.type == 'error')
                {
                    output = data.text;

                }
                else{
                    jc('#qfmsgcrm').html('');
                    output = data.text;
                    //alert(output);
        if(output=='Your request has been sent successfully and you will receive an email from us shortly. Thank you!')
        {
            if (successpath) {
                //location.href = "http://" + successpath + "/success.php?crmpage=quote";
                var redurl = "http://"+successpath+"/additional-information.php?id="+data.param;
                location.href = redurl;
            } else {
                jc('#qfmsgcrm').html(output);
                window.setTimeout(function () {
                    location.reload()
                }, 7000);
            }

        }
        else
        {
                        jc('#qfmsgcrm').html(output);
                        jc('#qfmsgcrm').css({'color':'#333'});
        }
                }
            }
},
error : function (data) {
        jc("#qsubmitcrm").removeAttr('disabled');
        //alert(JSON.stringify(data));
}
});
});
function paytc_pricequoteclac() {
    var language          = jc("#srclang option:selected").val();
    var trgtlanguage      = jc("#trglang").val();
    if((trgtlanguage != '' && trgtlanguage != null)&&((language == 90 || jc.inArray("90",trgtlanguage) != -1)|| (jc.inArray(language, trclang) != -1 && language == trgtlanguage))) {
        var formats    = jc("#formatting").val();
        var hours      = parseInt(jc('#hours').val());
        var minutes    = parseInt(jc('#minutes').val());
        hours          = (!hours) ? 0 : hours;
        minutes        = (!minutes) ? 0 : minutes;
        var filelength = minutes + hours * 60;

        var needtrc           = jc('#needtrc').is(':checked')?"Yes":"No";
        var specification_pay = (jc('#specification_pay').val() === null) ? "" : jc('#specification_pay').val();
        var deliveryReq       = jc('input[name=deliveryReq]:checked', '#captioningForm').val();
        //jc('.expeditedblk').hide();
        jc('.notary-pr,.mailed-pr').hide();
        var total          = 0;
        var mini_ordcost   = 0;
        var price          = 0;
        var cost           = 0;
        var Transactionfee = '';
        var timecodecost   =0;
        //var trgttierind = trgtier;
        var srctiercost = 0;
        var trgtiercost = 0;
        var script_cost = 0;
        /* PRICE CALCULATIONS FOR DOCUMENT START */
        jc('.discount-pr').hide();
        price    = 1.00;
        var cost = 0.00;
        if (language == "90" && jc.inArray("90",trgtlanguage) != -1 && needtrc == "Yes") {
            price        = 1.00;
        }
        else if (language == "90" && jc.inArray("90",trgtlanguage) != -1 && needtrc == "No") {
            price        = 1.00;
            script_cost  = 0.99;
            jc('#needtr').html('Transcription');
        }
        else if (language == "90" && jc.inArray(trgtlanguage.toString(), trclang) != -1 && needtrc == "Yes") {
            price        = 7.00;
            timecodecost = 1.00;
        }
        else if (language == "90" && jc.inArray(trgtlanguage.toString(), trclang) != -1 && needtrc == "No") {
            price        = 7.00;
            script_cost  = 7.00;
            timecodecost = 1.00;
            jc('#needtr').html('Translation');
        }
        else if (jc.inArray(language, trclang) != -1 && jc.inArray("90",trgtlanguage) != -1 && needtrc == "Yes") {
            price        = 7.00;
            timecodecost = 1.00;

        }
        else if (jc.inArray(language, trclang) != -1 && jc.inArray("90",trgtlanguage) != -1 && needtrc == "No") {
            price        = 7.00;
            script_cost  = 7.00;
            timecodecost = 1.00;
            jc('#needtr').html('Translation');
        }else if ((jc.inArray(language, trclang) != -1 && language == trgtlanguage) && needtrc == "Yes") {
            price        = 7.00;
            timecodecost = 1.00;
        }else if ((jc.inArray(language, trclang) != -1 && language == trgtlanguage) && needtrc == "No") {
            price        = 7.00;
            script_cost  = 5.00;
            timecodecost = 1.00;
            jc('#needtr').html('Transcription');
        }

        cost        = parseFloat(filelength) * parseFloat(price);
        script_cost = parseFloat(filelength) * parseFloat(script_cost);
        total       = parseFloat(total) + parseFloat(cost);
        timecodecost = parseFloat(filelength) * parseFloat(timecodecost);
        jc("#trgtunitcost_disp").html(price.toFixed(2));
        jc('#trgt_tot').html(total.toFixed(2));
        jc('#trgt_totamt').val(total.toFixed(2));
        jc("#trgt_unitcost").val(price.toFixed(2));
        jc('.sub_amt-pr').show();
        if (script_cost > 0) {
            jc("#script_amount").html(script_cost.toFixed(2));
            jc("#script_cost").val(script_cost.toFixed(2));
            jc(".script_amount-pr").show();
            total = total + script_cost;
        }
        else {
            jc("#script_cost").val(0);
            jc(".script_amount-pr").hide();
        }
        if (timecodecost > 0) {
            jc("#tcode_amount").html(timecodecost.toFixed(2));
            jc("#tcode_cost").val(timecodecost.toFixed(2));
            jc(".tcode_amount-pr").show();
            total = total + timecodecost;
        }
        else {
            jc("#tcode_cost").val(0);
            jc(".tcode_amount-pr").hide();
        }
        var subtot = parseFloat(cost)+parseFloat(script_cost)+parseFloat(timecodecost);
        jc('#sub_amt').html(subtot.toFixed(2));
        /*if (total < mini_ordcost) {
            jc('#tottrl_sub_amt').html(total);
            total = mini_ordcost;
            jc('.mini_sub_amt').html(mini_ordcost.toFixed(2));
            jc('#mini_subamt').val(mini_ordcost.toFixed(2));
            jc('.minimum-pr').show();
        } else {
            jc('.minimum-pr').hide();

        }*/


        jc('#subamttot').val(subtot.toFixed(2));


        var offpct = jc("#offerpct").val();
        var offervalue = parseFloat(total * offpct);
        var sub_ttooll = (total - offervalue);

        if(offervalue > 0) {
            jc(".coupval-pr").slideDown();
        }else{
            jc(".coupval-pr").slideUp();
        }

        jc("#offerval_value").html(offervalue.toFixed(2));
        jc("#sub_total").html(sub_ttooll.toFixed(2));

        jc("#offerval").val(offervalue.toFixed(2));
        jc("#finalround").val(sub_ttooll.toFixed(2));
        total = sub_ttooll;


        Transactionfee = (total / 100) * 5;
        jc('#trans_rate').html(Transactionfee.toFixed(2));
        jc('#trans_price').val(Transactionfee.toFixed(2));
        total = total + Transactionfee;
        jc('#price_display').html(total.toFixed(2));

        jc('#amount').val(total.toFixed(2));
        jc('#paymentamt').val(total.toFixed(2));
    }

}
function  paytc_showsubtotal(){
    jc('#time_rate').show();
    jc('#verb_rate').show();
    jc(".rate-show1").show();
    jc(".rate-show2").show();
    jc('#verb_rate').html('$0.00');
    jc('#time_rate').html('$0.00');
}
function tohour(durminutes){
    var hours = Math.floor( durminutes / 60);
    var minutes = (durminutes % 60).toFixed(0);
    hours = pad(hours, 2);
    minutes = pad(minutes, 2);
    return duhrs = parseFloat(hours+"."+minutes);
}
function paytc_resetVariables() {
    sureUploadSize = 0, probableUplaodSize = 0;
    partsLeft = [];
    cancelFlag             = false
    fileuploadstatus       = [];
    uploadFilesArr         = [];
    uploadedFilesArr       = [];
    uploadedFileDetailsArr = [];
}
function pad(str, max) {
    str = str.toString();
    return str.length < max ? pad("0" + str, max) : str;
}
function paytc_updateFormInfo(blurdataInfo) {
    var hours = parseInt(jc('#hours').val());
    var minutes = parseInt(jc('#minutes').val());
    hours = (!hours)?0:hours;
    minutes = (!minutes)?0:minutes;
    var prfilelength   = minutes + hours * 60;
    var expedited                  = jc("#expedited").is(':checked') ? 'Yes' : 'No';
    blurdataInfo.qemail            = jc('#paytc_qemailcrm').val();
    blurdataInfo.entryval          = jc('#recordkey').val();
    blurdataInfo.service           = jc('#service').val();
    var purposes                   = jc("#specification_pay").val();
    blurdataInfo.specification_pay = (purposes != '' && purposes != null)?purposes.toString():'';
    blurdataInfo.formatting        = jc("#formatting option:selected").val();
    blurdataInfo.srclang           = jc("#srclang option:selected").val();
    var trgtlang                   = jc("#trglang").val();
    blurdataInfo.trglang           = (trgtlang != '' && trgtlang != null)?trgtlang.toString():'';
    blurdataInfo.needtrc           = jc("#needtrc").is(':checked')?"Yes":"No";
    blurdataInfo.frtrial           = jc("#frtrial").is(':checked')?"Yes":"No";
    blurdataInfo.prfilelength      = prfilelength;
    blurdataInfo.camethrough       = jc("#camethrough").val();
    blurdataInfo.fileupload_tat    = jc("#fileupload_tat").val();
    blurdataInfo.expedited         = expedited;
    blurdataInfo.filedetails = uploadedFileDetailsArr.toString();

    $.ajax({
        url: update_quote,
        data: {
            fieldinfocommand: 'updatefieldinfo',
            sitename: sitename,
            savedata: blurdataInfo,
            async: false,
        },
        type: 'POST',
        success: function (data) {
            jc('#recordkey').val(data);
        }
    });
}
    //on blur data capturing - end
jc(document).ready(function () {
    jc(".capturedata,#specification_pay,#trglang").blur(function () {
        blurdataInfo           = {};
        blurdataInfo.comments  = jc(this).val();
        blurdataInfo.fieldname = jc(this).attr('id');
        paytc_updateFormInfo(blurdataInfo);
    });
});
var ajxurl = window.location.href;
jc.ajax({   
    url: serverPath+'client.php',
    data: 'chennal='+channel_click+'&service=Captioning&version=V1.0&sitename='+originPath+'&ajxurl='+ajxurl,
    type: 'POST',
    success: function (data) {
        // alert(data);
        jc('#timespendingid').html(data);
    },
    error: function (data) {
        //alert(data);
    }
});
jc( document ).on('click','#applycoupon', function(){
    var couponcode = jc("#couponcode").val();
    jc.ajax({
        url:update_quote,
        dataType: 'json',
        data: { coupon: couponcode },
        type: 'POST',
        success: function(data){
            if(data == 0){
                jc("#couponmsg").removeClass("text-success").addClass("text-danger").html("Invalid coupon code!");
            }else{
                jc("#couponmsg").removeClass("text-danger").addClass("text-success").html("Coupon code applied successfully");
                jc("#ofpct").html((data*100)+"%");
            }
            jc("#offerpct").val(data);
            paytc_pricequoteclac();
        }
    });
});
/*-------- FILE UPLOAD START ------------*/
var crmupload                      = true;
var sendBackData;
var partSize                       = 50 * 1024 * 1024; // constant
var totalSize;
var sureUploadSize                 = 0, probableUplaodSize = 0;
var numParts;
var partsLeft                      = [];
var file;
var cancelFlag                     = false;
var uploadFilesArr                 = [], uploadedFilesArr = [], uploadedFileDetailsArr = [], onblurdataarray = [];
var upItem                         = 0, j = 0, InitialVal = 0;
var checkUnprocessFlag             = false;
var checkUnprocessCompletePartFlag = false;
var checkUnprocesStartingPartFlag  = false;
var stageObj                       = {"/addfiles": 1, "/signin": 2, "/payment": 3, "booked": 4};
var currentStage                   = stageObj[window.location.pathname];
var awsUrl                         = 'https://s3-ap-southeast-1.amazonaws.com/';
var uploadProgress                 = false;
var filesUploadStatus              = [];
var HOSTNAME                       = 'http://' + window.location.host;
var COSTPERMIN                     = 1;
var VERBATIMCOST                   = 0.25;
var TIMESTAMPCOST                  = 0.25;
var serialno                       = 1;
var serverpath                     = crmRootpath + "lib/";
var uploadserver                   = serverpath + "server.php";
var vendorupload                   = false;

var awsUser = 'user';

function resetParam() {
    sendBackData;
    // partSize = 5 * 1024 * 1024; // constant
    totalSize;
    sureUploadSize = 0, probableUplaodSize = 0;
    numParts;
    partsLeft = [];
    file;
    cancelFlag = false;
}
function reorder() {
    var serialno = 1;
    jc('.serialno').each(function () {
        jc(this).text(serialno);
        serialno++;
    });
}
function addFiles() {
    jc('#file').val(null);
    var uploadfile = document.getElementById("file");
    uploadfile.click();  // here i can browse the file without clicking on file brows button
}
function updateInfo(Obj) {
    var lastserialno = jc(".serialno:last").text();
    if (lastserialno) {
        lastserialno++;
        var serialno = lastserialno;
    } else {
        var serialno = 1;
    }
    jc('#info').show();
    uploadFilename = Obj.name;
    addRow ='<div class="row striped row-'+upItem2+'">'+
        '<div class="col-xs-4 col-sm-4 col-lg-4 audioLengths ellipsisprgbar text-left text-size-ne" ><span data-file="'+Obj.name+'" data-modfy="'+Obj.modifyName+'" data-uploadid="" data-complete="0" id="removeFile-'+upItem2+'" class="up-close removeboth-'+upItem2+'" data-seerid="'+upItem2+'"  ><a href="javascript:void(0)"  data-placement="bottom" data-original-title="Remove file"> <i class="fa fa-trash-o" aria-hidden="true" style="font-weight:bold"></i></a></span>&nbsp;&nbsp;<span class="serialno">'+serialno+'</span>. '+Obj.name+'<input type="hidden" class="fileNamepay" value="'+Obj.modifyName+'#-#('+bytesToSize(Obj.size, 1).replace(".0", "") +')#-#'+Obj.type+'" id="uploadFiles-'+upItem2+'" data-durat="" name="uploadFiles[]" data-serid="'+upItem2+'" /></div>'+
        '<div class="col-xs-4 col-sm-4 col-lg-4 audioLengthpay text-size-ne text-center"><input type="text" data-ser="'+upItem2+'" maxlength="4" id="durationnewpay-'+upItem2+'" style="display:none;width:55px;text-align: center;" class="length del-time onlynumbers text-center" placeholder="min" value="" onkeyup="paytc_pricequoteclac();paytc_paymentenable();"  name="length[]"> <span class="filetypes-'+upItem2+' hrdisplay" name="qfmsg" id="filetypespay'+upItem2+'" ></span></div> '+
        '<div class="col-xs-4 col-sm-4 col-lg-4 text-size-ne"> <span id="progpay-' + upItem2 + '" class="progress-upload ">'+
        '<input type="hidden" class="filePath" name="filePaths[]" value="" /><div class="awsupload-progress">'+
        '<div style="width:0%;" class="awsupload-progress-bar"></div>'+
        '<div class="awsupload-progress-text"></div>'+ '</div>'+
        '</span><div  class="audioLength text-center" id="inp-' + upItem2 + '" style="display:none;" >File Uploaded. </div></div>'+
        '<audio class="audio" id="audio-'+upItem2+'"></audio>'+
        '</div>';
    jc('#info').append(addRow);
    objectUrl = URL.createObjectURL(Obj);
    jc('#audio-' + upItem2).prop("src", objectUrl);

    var completedfilecnt = jc('.audioLength:visible').length;
    var totalfilecnt     = jc('.audioLength').length;
    jc('#completedfiletext').html("Uploaded " + completedfilecnt + "/" + totalfilecnt + " Files");
    serialno++;
}
function updateFinalInfo() {
    jc('#progpay-' + upItem).hide();
    jc('#inp-' + upItem).show();
    /*var srcfiletype = jc("#sourcefiletype option:selected").val();
     if(srcfiletype == 1){
     jc('#inp-' + upItem).show();
     }else if (srcfiletype == 2){*/
    //jc('#durationnewpay-' + upItem).show();
    if (jc('#formtype').val() == "payment") {
        if (jc('[id^=audio-' + upItem + ']').length > 0) {
            var vid     = document.getElementById('audio-' + upItem);
            var seconds = vid.duration;
            var minutes = seconds / 60;
            var result  = Math.ceil(minutes);
            jc('#durationnewpay-' + upItem).delay(1100).fadeIn();

            if (result > 0 && result != 'NaN') {
                jc("#filetypespay" + upItem).show();
                jc("#filetypespay" + upItem).removeClass("errlength").addClass("hrdisplay");
                var durinhrs = hourconverter(result);
                jc("#filetypespay" + upItem).html(durinhrs);
                var precedres = pad(result, 2);
                precedres = (precedres == 0)?'':precedres;
                jc('#durationnewpay-' + upItem).val(precedres);
                jc('#uploadFiles-' + upItem).data("durat", result);
            } else {
                jc('#durationnewpay-' + upItem).val();
                jc('#uploadFiles-' + upItem).data("durat", 0);
                jc('.filetypes-' + upItem).delay(1100).fadeIn();
                jc("#filetypespay" + upItem).removeClass("hrdisplay").addClass("errlength");
                jc("#filetypespay" + upItem).html("Enter file length!");
            }
            //jc('#durationnew-'+upItem).val(result);
        }
    }
    //}



    jc('#removeFile-' + upItem).data('complete', 1);
    jc('#removeFile-' + upItem).css('visibility', 'visible');
    var completedfilecnt = jc('.audioLength:visible').length;
    var totalfilecnt     = jc('.audioLength').length;
    jc('#completedfiletext').html("Uploaded " + completedfilecnt + "/" + totalfilecnt + " Files");

    if (jc('#quoteflag').val() == 1) {
        $.ajax({
            url: update_quote,
            data: {
                command: 'updatefilecount',
                uploadflag: uploadProgress,
                completedfilecnt: completedfilecnt,
                //uploadedFile :uploadedFileName,
                ticketid: ticketID,
                quoteflag: jc('#quoteflag').val(),
                totalfilecnt: totalfilecnt,
            },
            type: 'POST'
        });
    }
    paytc_pricequoteclac();
    jc('#minutes').trigger('blur');
    if(uploadedFilesArr != ''){
        jc('.filecomment').show();
    }
}
function updateUploadStatus() {
    var uploadFile       = filesUploadStatus[upItem]['file'];
    var uploadedFileName = uploadFile.modifyName;
    $.ajax({
        url: update_quote,
        data: {
            command: 'updateuploadstatus',
            uploadedFile: uploadedFileName,
        },
        type: 'POST'
    });
}
function updateProgressBar() {
    var progwidth = ((sureUploadSize + probableUplaodSize) / totalSize * 100).toFixed(1).replace(".0", "") + '%';
    var progtxt   = bytesToSize(sureUploadSize + probableUplaodSize, 1).replace(".0", "") + '/' + bytesToSize(totalSize, 1).replace(".0", "");
    /*jc('#prog-' + upItem + ' .awsupload-progress .awsupload-progress-bar').css('width', progwidth);
     jc('#prog-' + upItem + ' .awsupload-progress .awsupload-progress-text').html(progtxt + ' - (' + progwidth + ')');*/
    jc('#progpay-' + upItem + ' .awsupload-progress .awsupload-progress-bar').css('width', progwidth);
    jc('#progpay-' + upItem + ' .awsupload-progress .awsupload-progress-text').html(progtxt + ' - (' + progwidth + ')');

}
function resetProgressBar() {
    jc('#progress').attr('max', 0);
    jc('#progress').attr('value', 0);
}
function deletefile(filename, obj) {
    if (jc(obj).data('complete') == "0") {
        // console.log('Not uploaded');
        // upload file inprogress...
        if (jc(obj).data('uploadid') != "") {
            cancel();
            // console.log('upload inprogress file');
        }
        return;
    } else {
        $.ajax({
            url: uploadserver,
            data: {
                command: 'deletefile',
                Filename: filename
            }
        }).done(function (data) {
            //cancelFlag = true;
        });
    }
}
function completeMultipartUpload() {
    $.ajax({
        url: uploadserver,
        timeout: 5000,
        data: {
            command: 'CompleteMultipartUpload',
            sendBackData: sendBackData
        },
        beforeSend: function () {
            //console.log('before send');
        },
        error: function (event, request, settings, data) {
            var errorResponse = JSON.stringify(data);
            if (cancelFlag) {
                changeCancelFlag();
            } else {
                jc('#uploading_msg').hide();
                //jc('.upload_error, .upload_errmsg').show();
                jc('.upload_errmsg').show();
                showMessage('#my-welcome-message2');
                saveuploaderror(errorResponse);
                if (!checkUnprocessCompletePartFlag) {
                    checkUnprocessCompletePart();
                }
            }
        }, success: function () {
            if (checkUnprocessCompletePartFlag) {
                checkUnprocessCompletePartFlag = false;
                clearInterval(intervalfunc_complete);
                jc('.upload_error, .upload_errmsg ').hide();
                jc('#uploading_msg').show();
                if (jc('#quoteflagnew').val() == 0)
                    jc('#fvpp-blackout, #my-welcome-message2').hide();


            }
        }
    }).done(function (data, textStatus, jqXHR) {
        // console.log('==== CompleteMultipartUpload Final===='+ filesUploadStatus[upItem]['file'].name);
        resetProgressBar();
        resetParam();
        uploadedFilesArr.push(filesUploadStatus[upItem]['file'].name);

        var uploadFile = filesUploadStatus[upItem]['file'];
        uploadedFileDetailsArr.push(uploadFile.modifyName + '#-#(' + bytesToSize(uploadFile.size, 1).replace(".0", "") + ')#-#' + uploadFile.type);
        updateFinalInfo();
        if (jc('#quoteflag').val() == 1 || jc('#quoteflagnew').val() == 1) {
            updateUploadStatus();
        }
        blurdataInfo           = {};
        blurdataInfo.fieldname = "fileuploader";
        updateFormInfo(blurdataInfo);
        // Checking file exist or not to  upload
        if (++upItem in filesUploadStatus) {
            if (uploadFilesArr.length == uploadedFilesArr.length) {
                if (jc('#quoteflag').val() == 1 || jc('#quoteflagnew').val() == 1) {
                    //console.log("finalsubmit");
                    setTimeout(function () {
                        jc("#qsubmitcrm").trigger("click");
                    }, 5000);
                }
            }
            decideFileUpload();
        }
        else {
            uploadProgress = false;
            //Added by Rohini R on 20/12/2016 to disable submit in CRM File upload while upload in progress
            /*if (jc("#filesubmit").length) {
             jc("#filesubmit").removeAttr("disabled");
             }*/

            jc(".up").hide();
            jc('#minutes').trigger('change');
            if(uploadedFilesArr != ''){
                jc('.filecomment').show();
            }


            if (jc('#quoteflag').val() == 1 || jc('#quoteflagnew').val() == 1) {
                setTimeout(function () {
                    jc("#qsubmitcrm").trigger("click");
                }, 5000);
            }
            //jc( "#qsubmitcrm" ).trigger( "click" );
            //}


            //quotesubmitbtn(uploadProgress);
            // console.log("************* ALL Files uploaded successfully*************");
        }
    });


}
function uploadPart(partNum) {
    //alert('upload part'+ partNum);
    if (cancelFlag) {
        cancelFlag = false;
        resetProgressBar();
        resetParam();
        decideFileUpload();
        return;
    }
    if (partNum > numParts) {
        completeMultipartUpload();
        filesUploadStatus[upItem]['status'].upload_status = 'complete';
        return;
    }
    var start = (partNum - 1) * partSize;
    var end   = start + partSize;
    if (end > totalSize)
        end = totalSize;
    var length = end - start;

    // var curBlobPart = processingFile.slice(start, end);

    if (typeof processingFile.slice === 'function') {
        var curBlobPart = processingFile.slice(start, end);
    } else if (typeof processingFile.webkitSlice === 'function') {
        var curBlobPart = processingFile.webkitSlice(start, end);
    } else {
        console.log('unable to slice processingFile (slice /webkitSlice) ');
    }

    $.ajax({
        url: uploadserver,
        timeout: 5000,
        data: {
            command: 'SignUploadPart',
            partNumber: partNum,
            contentLength: length,
            sendBackData: sendBackData
        }, error: function (data) {
            if (cancelFlag) {
                changeCancelFlag();
            } else {
                jc('#uploading_msg').hide();
                // jc('.upload_error, .upload_errmsg').show();
                jc('.upload_errmsg').show();
                showMessage('#my-welcome-message2');
                data.partNumber   = partNum;
                var errorResponse = JSON.stringify(data);
                saveuploaderror(errorResponse);
                if (!checkUnprocessFlag)
                    checkUnprocessData(partNum);
                return;
            }
        }, success: function () {
            if (checkUnprocessFlag) {
                checkUnprocessFlag = false;
                clearInterval(intervalfunc);
                jc('.upload_error, .upload_errmsg').hide();
                jc('#uploading_msg').show();
                if (jc('#quoteflagnew').val() == 0)
                    jc('#fvpp-blackout, #my-welcome-message2').hide();
            }
        }
    }).done(function (data, textStatus, jqXHR) {
        //console.log('==== SignUploadPart ====');
        var url = data['url'];

        // updating uploaded file path.
        jc('#prog-' + upItem + ' .filePath').val(getAwsLocation(url));
        var authHeader = data['authHeader'];
        var dateHeader = data['dateHeader'];
        var request    = new XMLHttpRequest();
        request.open('PUT', url, true);
        request.contentLength = length;

        request.onreadystatechange = function () {
            // console.log("++++++ onreadystatechange ++++++");
            // console.log(request.status);
            // console.log(request);

            if (request.readyState === 4) {
                if (request.status === 200) {
                    filesUploadStatus[upItem]['status'].upload_status = 'process';
                    if (checkUnprocessFlag) {

                        checkUnprocessFlag = false;
                        clearInterval(intervalfunc);
                        jc('#uploading_msg').show();
                        jc('.upload_error, .upload_errmsg').hide();
                        if (jc('#quoteflagnew').val() == 0)
                            jc('#fvpp-blackout, #my-welcome-message2').hide();
                    }
                    probableUplaodSize = 0;
                    sureUploadSize += request.contentLength;
                    updateProgressBar();
                    uploadPart(partNum + 1);
                } else {
                    if (cancelFlag) {
                        changeCancelFlag();
                    } else {
                        console.log('Request status Error');
                        jc('#uploading_msg').hide();
                        // jc('.upload_error, .upload_errmsg').show();
                        jc('.upload_errmsg').show();
                        showMessage('#my-welcome-message2');
                        var errorResponse = JSON.stringify(data);
                        saveuploaderror(errorResponse);

                        filesUploadStatus[upItem]['status'].upload_status = 'error';
                        if (!checkUnprocessFlag)
                            checkUnprocessData(partNum);
                        return;
                    }
                }
            }
        };
        request.upload.onprogress  = function (e) {
            //console.log("++++++ upload.onprogress ++++++" + request.status);
            if (e.lengthComputable) {
                probableUplaodSize = e.loaded;
                updateProgressBar();
            }
        };
        request.setRequestHeader("x-amz-date", dateHeader);
        request.setRequestHeader("Authorization", authHeader);
        //request.setRequestHeader("Content-Length", length);
        request.send(curBlobPart);

    });
}
function startPartitionAndUpload() {
    updateProgressBar();
    numParts = Math.ceil(totalSize / partSize);
    uploadPart(1);
}
function cancel() {
    $.ajax({
        url: uploadserver,
        data: {
            command: 'AbortMultipartUpload',
            sendBackData: sendBackData
        }
    }).done(function (data) {
        cancelFlag = true;
        console.log('upload cancelled');

    });
}
function upload() {
    var url = window.location.href;
    var re  = /\/upload\?type=delivery/g;
    if (re.test(url)) {
        var vendorupload = true;
    }

    if (window.File && window.FileReader && window.FileList && window.Blob && window.Blob.prototype.slice) {
        for (i = 0; i < jc('#file')[0].files.length; i++, InitialVal++) {
            fileObj = jc('#file')[0].files[i];

            //  console.log(i+"<=i######## step 1##########>InitialVal"+InitialVal);
            exist_file_name = jc('#exist_file_name').val();
            if (vendorupload && typeof exist_file_name !== 'undefined') {
                // variable is undefined
                var upd_file_name   = fileObj.name.substr(0, fileObj.name.lastIndexOf('.'));
                var exist_file_name = exist_file_name.substr(0, exist_file_name.lastIndexOf('.'));
                if (exist_file_name != upd_file_name) {
                    alert('Uploading filename should be same.');
                    location.reload();
                    jc('#uploadbuttoncls').hide();
                    InitialVal--;
                    continue;
                }
            }

            // already file in the list

            var filetype        = fileObj.type;
            var filtype         = filetype.split("/");
            //var sourcefiletype3 = jc("#sourcefiletype option:selected").val();
            //console.log(filtype[0] + '-' + sourcefiletype3);
            if ((filtype[0] != "audio") && (filtype[0] != "video"))
            {
                sweetAlert("Sorry...", "Please upload audio,video files only.", "error");
                InitialVal--;
                continue;
            }else if (uploadFilesArr.indexOf(fileObj.name) != -1)
            {
                alert('Already ' + fileObj.name + ' uploaded...');
                InitialVal--;
                continue;
            } else {

                //   console.log(i+"<=i######## step 2 else block ##########>InitialVal"+InitialVal);

                uploadFilesArr.push(fileObj.name);

                originalFile         = fileObj.name;
                var replacedFilename = originalFile.replace(/[^A-Za-z0-9\_\-\.]/g, '');
                if (replacedFilename.substring(0, replacedFilename.lastIndexOf('.')) == '') {
                    var ext          = replacedFilename.split('.').pop().toLowerCase();
                    replacedFilename = 'file_' + Math.floor(Math.random() * 90000) + '.' + ext;
                }
                if (jc("#bucketcode").length) {
                    var bucketcd  = jc('#bucketcode').val();
                    var bucketkey = bucketcd;
                } else {
                    var bucketkey = 'xx';
                }
                fileObj.modifyName                      = folderPath + makeid(6) + bucketkey + "_" + replacedFilename;
                //  console.log(i+"<=i######## step 3 before filesUploadStatus##########>InitialVal"+InitialVal);
                filesUploadStatus[InitialVal]           = {};
                filesUploadStatus[InitialVal]['file']   = fileObj;
                filesUploadStatus[InitialVal]['status'] = {
                    upload_status: 'start',
                    item_no: InitialVal,
                    file_name: fileObj.modifyName,
                    file_size: bytesToSize(fileObj.size, 1).replace(".0", ""),
                    file_type: fileObj.type
                };

                // console.log(i+"<=i######## step 3 after filesUploadStatus##########>InitialVal"+InitialVal);
                upItem2 = InitialVal;

                updateInfo(fileObj);
                if (uploadProgress == false) {
                    uploadProgress = true;
                    //Added by Rohini R on 20/12/2016 to disable submit in CRM File upload while upload in progress
                    /*if (jc("#filesubmit").length) {
                     jc('#filesubmit').attr('disabled', 'disabled');
                     }*/

                    jc(".up").show();
                    jc(".pt,.qt").hide();
                    // quotesubmitbtn(uploadProgress);
                    uploadFile(filesUploadStatus[upItem]['file']);
                }
            }

        }//for loop
    } else {
        alert('The File APIs are not fully supported in this browser.');
    }
    //jc('[data-toggle="tooltip"]').tooltip();

}
function uploadFile(uploadFile) {
    console.log('Upload file...');
    uploadProgress = true;
    //quotesubmitbtn(uploadProgress);
    processingFile = uploadFile;
    totalSize      = uploadFile.size;
    $.ajax({
        url: uploadserver,
        timeout: 5000,
        data: {
            command: 'CreateMultipartUpload',
            fileInfo: {
                name: uploadFile.modifyName,
                type: uploadFile.type,
                size: uploadFile.size,
                lastModifiedDate: uploadFile.lastModifiedDate
            },
            otherInfo: {
                user: awsUser,
                pass: 'pass'
            }
        }, beforeSend: function () {
            // console.log('before start ');
        }, error: function (data) {
            if (cancelFlag) {
                changeCancelFlag();
            } else {
                jc('#uploading_msg').hide();
                // jc('.upload_error, .upload_errmsg').show();
                jc('.upload_errmsg').show();
                showMessage('#my-welcome-message2');
                var errorResponse = JSON.stringify(data);
                saveuploaderror(errorResponse);
                if (!checkUnprocesStartingPartFlag) {
                    checkUnprocesStartingPart(uploadFile);
                }
            }
        }, success: function () {
            if (checkUnprocesStartingPartFlag) {
                checkUnprocesStartingPartFlag = false;
                clearInterval(intervalfunc_start);
                jc('.upload_error, .upload_errmsg').hide();
                jc('#uploading_msg').show();
                if (jc('#quoteflagnew').val() == 0)
                    jc('#fvpp-blackout, #my-welcome-message2').hide();
            }
        }
    }).done(function (data, textStatus, jqXHR) {
        // console.log('==== CreateMultipartUpload ===='+upItem+"==>"+data.uploadId);
        jc('#removeFile-' + upItem).data('uploadid', data.uploadId);
        sendBackData = data;
        startPartitionAndUpload();
    });
}
function decideFileUpload() {
    // console.log('decideFileUpload ====> ');
    for (i = upItem; i < filesUploadStatus.length; i++) {
        if (uploadFilesArr.indexOf(filesUploadStatus[upItem]['file']['name']) >= 0) {
            uploadFile(filesUploadStatus[upItem]['file']);
            return;
        }
        else upItem = upItem + 1;
    }

    uploadProgress = false;
    //Added by Rohini R on 20/12/2016 to disable submit in CRM File upload while upload in progress
    /* if (jc("#filesubmit").length) {
     jc("#filesubmit").removeAttr("disabled");
     }*/

    jc(".up").hide();
    jc('#minutes').trigger('change');
    if(uploadedFilesArr != ''){
        jc('.filecomment').show();
    }
    //quotesubmitbtn(uploadProgress);
    //console.log("************* ALL Files uploaded successfully*************");
}
function bytesToSize(bytes, precision) {
    var kilobyte = 1024;
    var megabyte = kilobyte * 1024;
    var gigabyte = megabyte * 1024;
    var terabyte = gigabyte * 1024;

    if ((bytes >= 0) && (bytes < kilobyte)) {
        return bytes + ' B';

    } else if ((bytes >= kilobyte) && (bytes < megabyte)) {
        return (bytes / kilobyte).toFixed(precision) + ' KB';
    } else if ((bytes >= megabyte) && (bytes < gigabyte)) {
        return (bytes / megabyte).toFixed(precision) + ' MB';

    } else if ((bytes >= gigabyte) && (bytes < terabyte)) {
        return (bytes / gigabyte).toFixed(precision) + ' GB';
    } else if (bytes >= terabyte) {
        return (bytes / terabyte).toFixed(precision) + ' TB';
    } else {
        return bytes + ' B';
    }
}
function getAwsLocation(href) {
    var l   = document.createElement("a");
    l.href  = href;
    var str = l.hostname;
    str.indexOf(".");
    var s3Bucket = str.substr(0, str.indexOf("."));
    return awsUrl + s3Bucket + l.pathname;
}
//on blur data capturing - start
function updateFormInfo(blurdataInfo) {
    var fieldname  = blurdataInfo.fieldname;
    var fieldlabel = jc('label[for="' + fieldname + '"]').text();
    var fieldlabel = fieldlabel.trim();
    var fieldvalue = jc('#' + fieldname).val();
    var fieldtype  = jc('#' + fieldname).attr('type');
    if (fieldtype == 'checkbox') {
        if (jc('#' + fieldname).is(':checked')) {
            fieldvalue = 'Yes';
        } else {
            fieldvalue = 'No';
        }
    }
    if (fieldlabel) {
        if ((fieldlabel == 'Translate To' || fieldlabel == 'Target Language' || fieldlabel == 'Language') && fieldvalue) {
            fieldvalue = fieldvalue.toString().replace(/,/g, '-');
        }
        if (fieldlabel == 'How Long is Your Video?' && fieldvalue) {
            fieldvalue = fieldvalue.toString().replace(/:/g, '-');
        }
        onblurdataarray.push(fieldlabel + ':' + fieldvalue);
    } else {
        if (fieldname == 'qmailmsgcrm')
            fieldname = 'mail comment';
        onblurdataarray.push(fieldname + ':' + fieldvalue);
    }
    if (jc('#qsourcecrm').val())
        onblurdataarray.push('Translate From' + ':' + jc('#qsourcecrm').val());
    else if (jc('#qsourcevoicecrm').val())
        onblurdataarray.push('Translate From' + ':' + jc('#qsourcevoicecrm').val());
    else if (jc('#language').val() && jc('#channel_id').val() == 7)
        onblurdataarray.push('language' + ':' + jc('#language').val());

    blurdataInfo.qname       = jc('#qnamecrm').val();
    blurdataInfo.qemail      = jc('#qemailcrm').val();
    blurdataInfo.qcountrys   = jc('#qcountryscrm').val();
    blurdataInfo.acode       = jc('#acodecrm').val();
    blurdataInfo.qphone      = jc('#qphonecrm').val();
    blurdataInfo.entryval    = jc('#recordkey').val();
    blurdataInfo.serviceid   = jc('#serviceid').val();
    blurdataInfo.channel_id  = jc('#channel_id').val();
    blurdataInfo.filedetails = uploadedFileDetailsArr.toString();
    blurdataInfo.fieldname1  = onblurdataarray.toString();
    if (jc('#recordkey').val()) {
        var id = '';
    } else {
        var id = new Date().getTime();
        jc('#recordkey').val(id);
    }
    blurdataInfo.id = id;
    if (jc('#qemailcrm').val()) {
        $.ajax({
            url: crmFormsavepath + 'save/crmformdata',
            data: {
                command: 'updatefieldinfo',
                sitename: sitename,
                savedata: blurdataInfo,
                async: false,
            },
            type: 'POST',
            success: function (data) {
                jc('#recordkey').val(data.trim());
            }
        });
    }
}
var etat = '';
//on blur data capturing - end
jc(document).ready(function () {
    getUploadPartSize();
    //on blur data capturing - start

    if (jc('#channel_id').val() == 7) {
        var formid = jc('#quick_servicetype').val();
    }
    else {
        var formid = jc('#formid').val();
    }
    jc('#' + formid + " :input").each(function () {
        var input = jc(this).attr("id"); // This is the jquery object of the input, do what you will

        if (input == 'qtargetcrm')
            var j = jc('#' + input);
        else if (input == 'expected_turnaround')
            var j = jc('.datetimepicker');
        else
            var j = jc('#' + input);

        j.on('change blur', function (e) {
            var email = jc('#qemailcrm').val();
            var reg   = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
            if (reg.test(email) == true) {
                blurdataInfo           = {};
                blurdataInfo.comments  = jc(this).val();
                blurdataInfo.fieldname = jc(this).attr('id');
                if (input == 'expected_turnaround')
                    setTimeout(function () {
                        var etat                         = jc('#expected_turnaround').val();
                        blurdataInfo.expected_turnaround = etat;
                        updateFormInfo(blurdataInfo);
                    }, 100);
                else if (input != 'file')
                    updateFormInfo(blurdataInfo);

            }

        });
    });

//    } else {
//            jc("#qemailcrm,#qcountryscrm,#acodecrm,#qphonecrm,#qnamecrm").blur(function () {
//                var email = jc('#qemailcrm').val();
//                var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
//                if (reg.test(email) == true)
//                {
//                    blurdataInfo = {};
//                    blurdataInfo.comments = jc(this).val();
//                    blurdataInfo.fieldname = jc(this).attr('id');
//                    updateFormInfo(blurdataInfo);
//                }
//            });
//        }
    //on blur data capturing - end
});
jc(document).on('click', '.up-close', function () {
    uploadId    = jc(this).data('uploadid');
    var remFile = jc(this).data('file');
    deletefile(remFile,this);
    uploadFilesArr.splice(uploadFilesArr.indexOf(remFile), 1);
    uploadedFilesArr.splice(uploadedFilesArr.indexOf(remFile), 1);
    if (uploadedFileDetailsArr.length > 0) {
        for (i = 0; i < uploadedFileDetailsArr.length; i++) {
            var uploadedarrfilename  = uploadedFileDetailsArr[i].split("#-#");
            var uploadedarrfilename1 = uploadedarrfilename[0].substring(uploadedarrfilename[0].indexOf("_") + 1);
            if (uploadedarrfilename1 == remFile.replace(/[^A-Za-z0-9\_\-\.]/g, '')) {
                uploadedFileDetailsArr.splice(uploadedFileDetailsArr.indexOf(uploadedFileDetailsArr[i]), 1);
                blurdataInfo           = {};
                blurdataInfo.fieldname = "fileuploader";
                updateFormInfo(blurdataInfo);
            }
        }
    }

    jc(this).parent().parent().remove();
    if (!uploadFilesArr.length)
        jc('#info').hide();
    reorder();
    if(uploadedFilesArr == ''){
        jc('.filecomment').hide();
    }
});
function quotesubmitbtn(upProgress) {
    if (upProgress) {
        jc('.progressbtn').show();
        jc('.quotebtn').hide();
    } else {
        jc('.progressbtn').hide();
        jc('.quotebtn').show();
    }
    jc('#uploadprogress').val(upProgress);
}
function makeid(Strlen) {
    var text     = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    for (var i = 0; i < Strlen; i++)
        text += possible.charAt(Math.floor(Math.random() * possible.length));
    return text;
}
function checkUnprocessData(partNum) {
    console.log('checkUnprocessData : ' + partNum);
    checkUnprocessFlag = true;
    var counter        = 0;
    intervalfunc       = setInterval(function () {
        counter++;
        uploadPart(partNum);
        if (counter >= 20) {
            clearInterval(intervalfunc);
        }
    }, 10000);
}
function getUploadPartSize() {
    $.getJSON('//freegeoip.net/json/?callback=?', function (data) {
        var country_code = data.country_code;
        switch (country_code) {
            case "IN":
                partSize = 5 * 1024 * 1024;
                break;
            case "US":
                partSize = 50 * 1024 * 1024;
                break;
            case "GB":
            case "AU":
            case "UK":
                partSize = 20 * 1024 * 1024;
                break;
            default :
                partSize = 50 * 1024 * 1024;
                break;
        }
    });

}
function showMessage(id) {
    var $body   = jc('body');
    var $dialog = jc(id);
    $body.append('<div id="fvpp-blackout"></div>');
    $dialog.append('');
    $blackout = jc('#fvpp-blackout');
    var $blackout;
    $blackout.show();
    jc("#fvpp-close").css({'display': "none"});
    $dialog.show();
    jc(".DS-sidefixed-nav").css({'display': "none"});

}
function checkUnprocessCompletePart() {
    checkUnprocessCompletePartFlag = true;
    var counter                    = 0;
    intervalfunc_complete          = setInterval(function () {
        counter++;
        completeMultipartUpload();
        if (counter >= 20) {
            clearInterval(intervalfunc_complete);
        }
    }, 10000);
}
function checkUnprocesStartingPart(uploadFiles) {
    checkUnprocesStartingPartFlag = true;
    var counter                   = 0;
    intervalfunc_start            = setInterval(function () {
        counter++;
        uploadFile(uploadFiles);
        if (counter >= 20) {
            clearInterval(intervalfunc_start);
        }
    }, 10000);
}
function saveuploaderror(errorResponse) {
    dataInfo                 = {};
    var networkerrormailsent = 0;
    dataInfo.qname           = jc('#qnamecrm').val();
    if (jc('#qemailcrm').length) {
        dataInfo.qemail = jc('#qemailcrm').val();
    } else {
        dataInfo.qemail = jc('#sample_email').val();
    }
    dataInfo.entryval            = jc('#recordkey').val();
    dataInfo.networkerrflag      = jc('#networkerrflag').val();
    dataInfo.serviceid           = jc('#serviceid').val();
    dataInfo.crmpage             = jc('#crmpage').val();
    dataInfo.filedetails         = JSON.stringify(uploadFilesArr);
    dataInfo.fileuploadstatus    = JSON.stringify(filesUploadStatus);
    dataInfo.uploadprogress      = uploadProgress;
    dataInfo.uploaderrorresponse = errorResponse;
    dataInfo.uploadedfiledetails = JSON.stringify(uploadedFileDetailsArr);
    if ((jc('#qemailcrm').val() || jc('#sample_email').val()) && jc('#networkerrflag').val() == 0) {
        $.ajax({
            url: crmFormsavepath + 'save/crmformdata',
            data: {
                command: 'networkerror',
                networkerrordata: dataInfo,
                sitename: sitename,
                async: false,
            },
            type: 'POST',
            success: function (data) {
                jc('#networkerrflag').val(data);
            }
        });
    }
}
function changeCancelFlag() {
    uploadProgress = false;
    resetProgressBar();
    resetParam();
    updateFinalInfo();
    decideFileUpload();
}
function hourconverter(durminutes) {
    var hours   = Math.floor(durminutes / 60);
    var minutes = durminutes % 60;
    hours       = pad(hours, 2);
    minutes     = pad(minutes, 2);
    return duhrs = "(" + hours + ":" + minutes + ")";
    //jc('.convertedHour').html(hours);
    //jc('.convertedMin').html(minutes);
}
function pad(str, max) {
    str = str.toString();
    return str.length < max ? pad("0" + str, max) : str;
}
function paytc_paymentenable() {
    var durationcheck = [];
    jc(".length").each(function () {
        var  i = jc(this).attr("data-ser");
        var dur = parseInt(jc('#durationnewpay-' + i).val());
        if (isNaN(dur) || dur == '' || dur < 1) {
            jc("#filetypespay" + i).show();
            jc("#filetypespay" + i).removeClass("hrdisplay").addClass("errlength");
            jc("#filetypespay" + i).html("Enter file length!");
            jc('#durationnewpay-' + i).val();
            dur = '00';
        } else {
            jc("#filetypespay" + i).show();
            jc("#filetypespay" + i).removeClass("errlength").addClass("hrdisplay");
            var durinhrs = hourconverter(dur);
            jc("#filetypespay" + i).html(durinhrs);
        }
        jc('#durationnew-' + i).val(dur);
        durationcheck.push(dur);
        paytc_pricequoteclac();
    });
}
/*-------- FILE UPLOAD END ------------*/
// For place holder hide and show onfocus
jc('input,textarea').focus(function(){
    jc(this).data('placeholder',jc(this).attr('placeholder'))
        .attr('placeholder','');
}).blur(function(){
    jc(this).attr('placeholder',jc(this).data('placeholder'));
});