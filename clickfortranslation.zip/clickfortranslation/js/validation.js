                  var namevalid = function(){
                      var name = $('#qname').val();
                      if(name==''){
                        $('#qname').tooltip({title: "Enter Name !"}); 
                        $('#qname').focus();
                        $("#qname").css({"border-color": "red"});
                        $('#qname').keypress(function() {
                            $('#qname').tooltip('destroy');
                        }); 
                      }else{
                        $("#qname").css({"border-color": "green"});
                        return true;
                        
                      }
                  };
                  var emailvalid = function(){
                      var email = $('#qemail').val();
                      var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
                      var eaddress = email;
                      if(email==''){
                        $("#qemail").css({"border-color": "red"});
                        $("#qemail").css({"border-color": "red"});
                        $('#qemail').tooltip({title: "Enter Email ID !"}); 
                        $('#qemail').focus();
                        $('#qemail').keypress(function() {
                            $('#qemail').tooltip('destroy');
                        });
                      }else if(reg.test(eaddress) == false){
                        $("#qemail").css({"border-color": "red"});
                        $("#qemail").css({"border-color": "red"});
                        $('#qemail').tooltip({title: "Enter Valid Email ID !"}); 
                        $('#qemail').focus();
                        $('#qemail').keypress(function() {
                            $('#qemail').tooltip('destroy');
                        });
                      }
                      else{
                        $("#qemail").css({"border-color": "green"});
                        return true;
                      }
                    };
                  /*var countryvalid = function(){
                      var country = $('#qcountrys').val();
                      if(country==''){
                        $("#qcountrys").css({"border-color": "red"});
                        $('#qcountrys').tooltip({title: "Select Country !"}); 
                        $('#qcountrys').focus();
                        
                      }else{
                        $("#qcountrys").css({"border-color": "green"});
                            $('#qcountrys').tooltip('destroy');
                        return true;
                      }
                    };*/
                    
                  /*var areavalid = function(){
                      var areacode = $('#qacode').val();
                      if(areacode==''){
                        $("#qacode").css({"border-color": "red"});
                        $('#qacode').tooltip({title: "Enter Area Code !"}); 
                        $('#qacode').focus();
                        $('#qacode').keypress(function() {
                            $('#qacode').tooltip('destroy');
                        });                        
                      }else{
                        $("#qacode").css({"border-color": "green"});
                        return true;
                      }
                    };*/
                  /*var phonevalid = function(){
                      var phone = $('#qphone').val();
                      if(phone==''){
                        $("#qphone").css({"border-color": "red"});
                        $('#qphone').tooltip({title: "Enter Phone Number !"}); 
                        $('#qphone').focus();
                        $('#qphone').keypress(function() {
                            $('#qphone').tooltip('destroy');
                        });
                      }else{
                        $("#qphone").css({"border-color": "green"});
                        return true;
                      }
                    };*/
                    var sourcevalid = function(){
                      var source = $('#qsource').val();
                      if(source==''){
                        $("#qsource").css({"border-color": "red"});
                        $('#qsource').tooltip({title: "Select Source Language !"}); 
                        $('#qsource').focus();
                        $('#qsource').change(function() {
                            $('#qsource').tooltip('destroy');
                        }); 
                      }else{
                        $("#qsource").css({"border-color": "green"});
                        return true;
                      }
                    };  
                    var targetvalid = function(){
                      var options1 = $('#qtarget > option:selected');
                        if(options1.length == 0){
                          $("#drop").css({"border-color": "red"});
                          $('#drop').tooltip({title: "Select Target Language !"}); 
                          $('#drop').focus();
                          $('#drop').keypress(function() {
                              $('#drop').tooltip('destroy');
                          });
                        }else{
                          $("#drop").css({"border-color": "green"});
                        }
                    };  
                    $('#qname').on('focus keyup',function(){
                      var name = $('#qname').val();
                      if(name==''){
                        $("#qname").css({"border-color": "red"});
                        $('#qname').tooltip({title: "Enter Name !"}); 
                        $('#qname').focus();
                        $('#qname').keypress(function() {
                            $('#qname').tooltip('destroy');
                        }); 
                      }else{
                        $("#qname").css({"border-color": "green"});
                        
                      }
                    });
                    $('#qemail').on('focus keyup',function(){
                      if(namevalid()){
                        var email = $('#qemail').val();
                        var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
                        var eaddress = email;
                        if(email==''){
                          $("#qemail").css({"border-color": "red"});
                          $('#qemail').tooltip({title: "Enter Email ID !"}); 
                          $('#qemail').focus();
                          $('#qemail').keypress(function() {
                              $('#qemail').tooltip('destroy');
                          });
                        }else if(reg.test(eaddress) == false){
                          $("#qemail").css({"border-color": "red"});
                          $('#qemail').tooltip({title: "Enter Valid Email ID !"}); 
                          $('#qemail').focus();
                          $('#qemail').keypress(function() {
                              $('#qemail').tooltip('destroy');
                          });
                        }
                        else{
                          $("#qemail").css({"border-color": "green"});
                         
                        }
                      }else{
                        namevalid();
                      }
                    });
                    /*$('#qcountrys').on('focus change',function(){
                      if(namevalid() && emailvalid()){
                      var country = $('#qcountrys').val();
                      if(country==''){
                        $("#qcountrys").css({"border-color": "red"});
                        $('#qcountrys').tooltip({title: "Select Country !"}); 
                        $('#qcountrys').focus();
                        
                        
                      }else{
                        $("#qcountrys").css({"border-color": "green"});
                            $('#qcountrys').tooltip('destroy');
                        
                      }
                    }else{
                      emailvalid();
                      namevalid();
                      var country = $('#qcountrys').val();
                      if(country==''){
                        $("#qcountrys").css({"border-color": "red"});
                        $('#qcountrys').tooltip({title: "Select Country !"}); 
                        $('#qcountrys').focus();
                        
                        
                      }else{
                        $("#qcountrys").css({"border-color": "green"});
                            $('#qcountrys').tooltip('destroy');
                        
                      }
                    }
                    });*/
                    $('#qacode').on('focus keyup',function(){
                     
                        namevalid();
                        emailvalid();
                    });
                    $('#qphone').on('focus keyup', function(){
                      
                      namevalid();
                      emailvalid();
                      
                      
                    });
                    $('#qsource').on('focus change', function(){
                      
                     
                      var source = $('#qsource').val();
                      if(source==''){
                        $("#qsource").css({"border-color": "red"});
                        $('#qsource').tooltip({title: "Select Source Language !"}); 
                        $('#qsource').focus();
                        
                        
                      }else{
                        $("#qsource").css({"border-color": "green"});
                            $('#qsource').tooltip('destroy');
                      }
                    
                    });
                    $('#qtarget,#drop').on('focus change', function(){
                     
                      $('.multiselect-selected-text').html($('#qtarget > option:selected').val());
                        var options1 = $('#qtarget > option:selected');
                        if(options1.length == 0){
                          $("#drop").css({"border-color": "red"});
                          $('#drop').tooltip({title: "Select Target Language !"}); 
                          $('#drop').focus();
                        }else{
                          $("#drop").css({"border-color": "green"});
                        }
                     
                      
                    });
                    $('#qpurpose,#qtat,#qcomment').on('focus keyup', function(){
                        targetvalid();
                        sourcevalid();
                        emailvalid();
                        namevalid();
                    });  
                    
