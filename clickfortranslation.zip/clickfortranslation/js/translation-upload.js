var crmupload                      = true;
var sendBackData;
var partSize                       = 50 * 1024 * 1024; // constant
var totalSize;
var sureUploadSize                 = 0, probableUplaodSize = 0;
var numParts;
var partsLeft                      = [];
var file;
var cancelFlag                     = false;
var uploadFilesArr                 = [], uploadedFilesArr = [], uploadedFileDetailsArr = [], onblurdataarray = [];
var upItem                         = 0, j = 0, InitialVal = 0;
var checkUnprocessFlag             = false;
var checkUnprocessCompletePartFlag = false;
var checkUnprocesStartingPartFlag  = false;
var stageObj                       = {"/addfiles": 1, "/signin": 2, "/payment": 3, "booked": 4};
var currentStage                   = stageObj[window.location.pathname];
var awsUrl                         = 'https://s3-ap-southeast-1.amazonaws.com/';
var uploadProgress                 = false;
var filesUploadStatus              = [];
var HOSTNAME                       = 'http://' + window.location.host;
var COSTPERMIN                     = 1;
var VERBATIMCOST                   = 0.25;
var TIMESTAMPCOST                  = 0.25;
var serialno                       = 1;
var serverpath                     = crmRootpath + "lib/";
var uploadserver                   = serverpath + "server.php";
var vendorupload                   = false;

var awsUser = 'user';

function resetParam() {
    sendBackData;
    // partSize = 5 * 1024 * 1024; // constant
    totalSize;
    sureUploadSize = 0, probableUplaodSize = 0;
    numParts;
    partsLeft = [];
    file;
    cancelFlag = false;
}

function reorder() {
    var serialno = 1;
    $('.serialno').each(function () {
        $(this).text(serialno);
        serialno++;
    });
}

function addFiles() {
    $('#file').val(null);
    var uploadfile = document.getElementById("file");
    uploadfile.click();  // here i can browse the file without clicking on file brows button
}

function updateInfo(Obj) {
    var lastserialno = $(".serialno:last").text();
    if (lastserialno) {
        lastserialno++;
        var serialno = lastserialno;
    } else {
        var serialno = 1;
    }
    $('#info').show();
    uploadFilename = Obj.name;
    addRow         = '<div class="row striped row-' + upItem2 + '">' +
        '<div class="col-xs-6 col-sm-8 col-lg-8 ellipsisprgbar "><span data-file="' + Obj.name + '" data-uploadid="" data-complete="0" id="removeFile-' + upItem2 + '" class="up-close" onclick="deletefile(\'' + Obj.modifyName + '\',this)" ><a href="javascript:void(0)"  data-placement="bottom" data-original-title="Remove file"> <i class="fa fa-trash-o" aria-hidden="true"></i></a></span>&nbsp;&nbsp;<span class="serialno">' + serialno + '</span>. ' + Obj.name + '<input type="hidden" class="fileName" value="' + Obj.modifyName + '#-#(' + bytesToSize(Obj.size, 1).replace(".0", "") + ')#-#' + Obj.type + '" name="uploadFiles[]" /></div>' +
        '<div class="col-xs-6 col-sm-4 col-lg-4"> <span id="prog-' + upItem2 + '" class="progress-upload ">' +
        ' <input type= "hidden" class="filePath" name="filePaths[]" value="" /><div class="awsupload-progress">' +
        '<div style="width:0%;" class="awsupload-progress-bar"></div>' +
        '<div class="awsupload-progress-text"></div>' +
        '</div>' +
        '</span><div  class="audioLength" id="inp-' + upItem2 + '" style=" display:none;" >File Uploaded. </div> </div>' +
        '</div>';
    $('#info').append(addRow);
    var completedfilecnt = $('.audioLength:visible').length;
    var totalfilecnt     = $('.audioLength').length;
    $('#completedfiletext').html("Uploaded " + completedfilecnt + "/" + totalfilecnt + " Files");
    serialno++;
}
function updateFinalInfo() {
    // var uploadFile = filesUploadStatus[upItem]['file'];
    // var uploadedFileName = uploadFile.modifyName;

    $('#prog-' + upItem).hide();
    $('#inp-' + upItem).show();
    $('#removeFile-' + upItem).data('complete', 1);
    $('#removeFile-' + upItem).css('visibility', 'visible');
    var completedfilecnt = $('.audioLength:visible').length;
    var totalfilecnt     = $('.audioLength').length;
    $('#completedfiletext').html("Uploaded " + completedfilecnt + "/" + totalfilecnt + " Files");

    if ($('#quoteflag').val() == 1) {
        $.ajax({
            url: crmFormsavepath + 'save/crmformdata',
            data: {
                command: 'updatefilecount',
                uploadflag: uploadProgress,
                completedfilecnt: completedfilecnt,
                //uploadedFile :uploadedFileName,
                ticketid: ticketID,
                quoteflag: $('#quoteflag').val(),
                totalfilecnt: totalfilecnt,
            },
            type: 'POST'
        });
    }
}
function updateUploadStatus() {
    var uploadFile       = filesUploadStatus[upItem]['file'];
    var uploadedFileName = uploadFile.modifyName;
    $.ajax({
        url: crmFormsavepath + 'save/crmformdata',
        data: {
            command: 'updateuploadstatus',
            uploadedFile: uploadedFileName,
        },
        type: 'POST'
    });
}

function updateProgressBar() {
    var progwidth = ((sureUploadSize + probableUplaodSize) / totalSize * 100).toFixed(1).replace(".0", "") + '%';
    var progtxt   = bytesToSize(sureUploadSize + probableUplaodSize, 1).replace(".0", "") + '/' + bytesToSize(totalSize, 1).replace(".0", "");
    $('#prog-' + upItem + ' .awsupload-progress .awsupload-progress-bar').css('width', progwidth);
    $('#prog-' + upItem + ' .awsupload-progress .awsupload-progress-text').html(progtxt + ' - (' + progwidth + ')');

}
function resetProgressBar() {
    $('#progress').attr('max', 0);
    $('#progress').attr('value', 0);
}

function deletefile(filename, obj) {
    if ($(obj).data('complete') == "0") {
        // console.log('Not uploaded');
        // upload file inprogress...
        if ($(obj).data('uploadid') != "") {
            cancel();
            // console.log('upload inprogress file');
        }
        return;
    } else {
        $.ajax({
            url: uploadserver,
            data: {
                command: 'deletefile',
                Filename: filename
            }
        }).done(function (data) {
            //cancelFlag = true;
        });
    }
}

function completeMultipartUpload() {
    $.ajax({
        url: uploadserver,
        timeout: 5000,
        data: {
            command: 'CompleteMultipartUpload',
            sendBackData: sendBackData
        },
        beforeSend: function () {
            //console.log('before send');
        },
        error: function (event, request, settings, data) {
            var errorResponse = JSON.stringify(data);
            if (cancelFlag) {
                changeCancelFlag();
            } else {
                $('#uploading_msg').hide();
                //$('.upload_error, .upload_errmsg').show();
                $('.upload_errmsg').show();
                showMessage('#my-welcome-message2');
                saveuploaderror(errorResponse);
                if (!checkUnprocessCompletePartFlag) {
                    checkUnprocessCompletePart();
                }
            }
        }, success: function () {
            if (checkUnprocessCompletePartFlag) {
                checkUnprocessCompletePartFlag = false;
                clearInterval(intervalfunc_complete);
                $('.upload_error, .upload_errmsg ').hide();
                $('#uploading_msg').show();
                if ($('#quoteflagnew').val() == 0)
                    $('#fvpp-blackout, #my-welcome-message2').hide();


            }
        }
    }).done(function (data, textStatus, jqXHR) {
        // console.log('==== CompleteMultipartUpload Final===='+ filesUploadStatus[upItem]['file'].name);
        resetProgressBar();
        resetParam();
        uploadedFilesArr.push(filesUploadStatus[upItem]['file'].name);

        var uploadFile = filesUploadStatus[upItem]['file'];
        uploadedFileDetailsArr.push(uploadFile.modifyName + '#-#(' + bytesToSize(uploadFile.size, 1).replace(".0", "") + ')#-#' + uploadFile.type);
        updateFinalInfo();
        if ($('#quoteflag').val() == 1 || $('#quoteflagnew').val() == 1) {
            updateUploadStatus();
        }
        blurdataInfo           = {};
        blurdataInfo.fieldname = "fileuploader";
        updateFormInfo(blurdataInfo);
        // Checking file exist or not to  upload
        if (++upItem in filesUploadStatus) {
            if (uploadFilesArr.length == uploadedFilesArr.length) {
                if ($('#quoteflag').val() == 1 || $('#quoteflagnew').val() == 1) {
                    //console.log("finalsubmit");
                    setTimeout(function () {
                        $("#qsubmitcrm").trigger("click");
                    }, 5000);
                }
            }
            decideFileUpload();
        }
        else {
            uploadProgress = false;
            //Added by Rohini R on 20/12/2016 to disable submit in CRM File upload while upload in progress
            if ($("#filesubmit").length) {
                $("#filesubmit").removeAttr("disabled");
            }
            if ($('#quoteflag').val() == 1 || $('#quoteflagnew').val() == 1) {
                setTimeout(function () {
                    $("#qsubmitcrm").trigger("click");
                }, 5000);
            }
            //$( "#qsubmitcrm" ).trigger( "click" );
            //}


            //quotesubmitbtn(uploadProgress);
            // console.log("************* ALL Files uploaded successfully*************");
        }
    });


}

function uploadPart(partNum) {
    //alert('upload part'+ partNum);
    if (cancelFlag) {
        cancelFlag = false;
        resetProgressBar();
        resetParam();
        decideFileUpload();
        return;
    }
    if (partNum > numParts) {
        completeMultipartUpload();
        filesUploadStatus[upItem]['status'].upload_status = 'complete';
        return;
    }
    var start = (partNum - 1) * partSize;
    var end   = start + partSize;
    if (end > totalSize)
        end = totalSize;
    var length = end - start;

    // var curBlobPart = processingFile.slice(start, end);

    if (typeof processingFile.slice === 'function') {
        var curBlobPart = processingFile.slice(start, end);
    } else if (typeof processingFile.webkitSlice === 'function') {
        var curBlobPart = processingFile.webkitSlice(start, end);
    } else {
        console.log('unable to slice processingFile (slice /webkitSlice) ');
    }

    $.ajax({
        url: uploadserver,
        timeout: 5000,
        data: {
            command: 'SignUploadPart',
            partNumber: partNum,
            contentLength: length,
            sendBackData: sendBackData
        }, error: function (data) {
            if (cancelFlag) {
                changeCancelFlag();
            } else {
                $('#uploading_msg').hide();
                // $('.upload_error, .upload_errmsg').show();
                $('.upload_errmsg').show();
                showMessage('#my-welcome-message2');
                data.partNumber   = partNum;
                var errorResponse = JSON.stringify(data);
                saveuploaderror(errorResponse);
                if (!checkUnprocessFlag)
                    checkUnprocessData(partNum);
                return;
            }
        }, success: function () {
            if (checkUnprocessFlag) {
                checkUnprocessFlag = false;
                clearInterval(intervalfunc);
                $('.upload_error, .upload_errmsg').hide();
                $('#uploading_msg').show();
                if ($('#quoteflagnew').val() == 0)
                    $('#fvpp-blackout, #my-welcome-message2').hide();
            }
        }
    }).done(function (data, textStatus, jqXHR) {
        //console.log('==== SignUploadPart ====');
        var url = data['url'];
        // updating uploaded file path.
        $('#prog-' + upItem + ' .filePath').val(getAwsLocation(url));
        var authHeader = data['authHeader'];
        var dateHeader = data['dateHeader'];
        var request    = new XMLHttpRequest();
        request.open('PUT', url, true);
        request.contentLength = length;

        request.onreadystatechange = function () {
            // console.log("++++++ onreadystatechange ++++++");
            // console.log(request.status);
            // console.log(request);

            if (request.readyState === 4) {
                if (request.status === 200) {
                    filesUploadStatus[upItem]['status'].upload_status = 'process';
                    if (checkUnprocessFlag) {

                        checkUnprocessFlag = false;
                        clearInterval(intervalfunc);
                        $('#uploading_msg').show();
                        $('.upload_error, .upload_errmsg').hide();
                        if ($('#quoteflagnew').val() == 0)
                            $('#fvpp-blackout, #my-welcome-message2').hide();
                    }
                    probableUplaodSize = 0;
                    sureUploadSize += request.contentLength;
                    updateProgressBar();
                    uploadPart(partNum + 1);
                } else {
                    if (cancelFlag) {
                        changeCancelFlag();
                    } else {
                        console.log('Request status Error');
                        $('#uploading_msg').hide();
                        // $('.upload_error, .upload_errmsg').show();
                        $('.upload_errmsg').show();
                        showMessage('#my-welcome-message2');
                        var errorResponse = JSON.stringify(data);
                        saveuploaderror(errorResponse);

                        filesUploadStatus[upItem]['status'].upload_status = 'error';
                        if (!checkUnprocessFlag)
                            checkUnprocessData(partNum);
                        return;
                    }
                }
            }
        };
        request.upload.onprogress  = function (e) {
            //console.log("++++++ upload.onprogress ++++++" + request.status);
            if (e.lengthComputable) {
                probableUplaodSize = e.loaded;
                updateProgressBar();
            }
        };
        request.setRequestHeader("x-amz-date", dateHeader);
        request.setRequestHeader("Authorization", authHeader);
        //request.setRequestHeader("Content-Length", length);
        request.send(curBlobPart);

    });
}
function startPartitionAndUpload() {
    updateProgressBar();
    numParts = Math.ceil(totalSize / partSize);
    uploadPart(1);
}
function cancel() {
    $.ajax({
        url: uploadserver,
        data: {
            command: 'AbortMultipartUpload',
            sendBackData: sendBackData
        }
    }).done(function (data) {
        cancelFlag = true;
        console.log('upload cancelled');

    });
}

function upload() {
    var url = window.location.href;
    var re  = /\/upload\?type=delivery/g;
    if (re.test(url)) {
        var vendorupload = true;
    }

    if (window.File && window.FileReader && window.FileList && window.Blob && window.Blob.prototype.slice) {
        for (i = 0; i < $('#file')[0].files.length; i++, InitialVal++) {
            fileObj = $('#file')[0].files[i];

            //  console.log(i+"<=i######## step 1##########>InitialVal"+InitialVal);
            exist_file_name = $('#exist_file_name').val();
            if (vendorupload && typeof exist_file_name !== 'undefined') {
                // variable is undefined
                var upd_file_name   = fileObj.name.substr(0, fileObj.name.lastIndexOf('.'));
                var exist_file_name = exist_file_name.substr(0, exist_file_name.lastIndexOf('.'));
                if (exist_file_name != upd_file_name) {
                    alert('Uploading filename should be same.');
                    location.reload();
                    $('#uploadbuttoncls').hide();
                    InitialVal--;
                    continue;
                }
            }

            // already file in the list

            if (uploadFilesArr.indexOf(fileObj.name) != -1) {
                alert('Already ' + fileObj.name + ' uploaded...');
                InitialVal--;
                continue;
            } else {

                //   console.log(i+"<=i######## step 2 else block ##########>InitialVal"+InitialVal);

                uploadFilesArr.push(fileObj.name);

                originalFile         = fileObj.name;
                var replacedFilename = originalFile.replace(/[^A-Za-z0-9\_\-\.]/g, '');
                if (replacedFilename.substring(0, replacedFilename.lastIndexOf('.')) == '') {
                    var ext          = replacedFilename.split('.').pop().toLowerCase();
                    replacedFilename = 'file_' + Math.floor(Math.random() * 90000) + '.' + ext;
                }
                if ($("#bucketcode").length) {
                    var bucketcd  = $('#bucketcode').val();
                    var bucketkey = bucketcd;
                } else {
                    var bucketkey = 'xx';
                }
                fileObj.modifyName                      = folderPath + makeid(6) + bucketkey + "_" + replacedFilename;
                //  console.log(i+"<=i######## step 3 before filesUploadStatus##########>InitialVal"+InitialVal);
                filesUploadStatus[InitialVal]           = {};
                filesUploadStatus[InitialVal]['file']   = fileObj;
                filesUploadStatus[InitialVal]['status'] = {
                    upload_status: 'start',
                    item_no: InitialVal,
                    file_name: fileObj.modifyName,
                    file_size: bytesToSize(fileObj.size, 1).replace(".0", ""),
                    file_type: fileObj.type
                };

                // console.log(i+"<=i######## step 3 after filesUploadStatus##########>InitialVal"+InitialVal);
                upItem2 = InitialVal;

                updateInfo(fileObj);
                if (uploadProgress == false) {
                    uploadProgress = true;
                    //Added by Rohini R on 20/12/2016 to disable submit in CRM File upload while upload in progress
                    if ($("#filesubmit").length) {
                        $('#filesubmit').attr('disabled', 'disabled');
                    }
                    // quotesubmitbtn(uploadProgress);
                    uploadFile(filesUploadStatus[upItem]['file']);
                }
            }

        }//for loop
    } else {
        alert('The File APIs are not fully supported in this browser.');
    }
    $('[data-toggle="tooltip"]').tooltip();

}
function uploadFile(uploadFile) {
    console.log('Upload file...');
    uploadProgress = true;
    //quotesubmitbtn(uploadProgress);
    processingFile = uploadFile;
    totalSize      = uploadFile.size;
    $.ajax({
        url: uploadserver,
        timeout: 5000,
        data: {
            command: 'CreateMultipartUpload',
            fileInfo: {
                name: uploadFile.modifyName,
                type: uploadFile.type,
                size: uploadFile.size,
                lastModifiedDate: uploadFile.lastModifiedDate
            },
            otherInfo: {
                user: awsUser,
                pass: 'pass'
            }
        }, beforeSend: function () {
            // console.log('before start ');
        }, error: function (data) {
            if (cancelFlag) {
                changeCancelFlag();
            } else {
                $('#uploading_msg').hide();
                // $('.upload_error, .upload_errmsg').show();
                $('.upload_errmsg').show();
                showMessage('#my-welcome-message2');
                var errorResponse = JSON.stringify(data);
                saveuploaderror(errorResponse);
                if (!checkUnprocesStartingPartFlag) {
                    checkUnprocesStartingPart(uploadFile);
                }
            }
        }, success: function () {
            if (checkUnprocesStartingPartFlag) {
                checkUnprocesStartingPartFlag = false;
                clearInterval(intervalfunc_start);
                $('.upload_error, .upload_errmsg').hide();
                $('#uploading_msg').show();
                if ($('#quoteflagnew').val() == 0)
                    $('#fvpp-blackout, #my-welcome-message2').hide();
            }
        }
    }).done(function (data, textStatus, jqXHR) {
        // console.log('==== CreateMultipartUpload ===='+upItem+"==>"+data.uploadId);
        $('#removeFile-' + upItem).data('uploadid', data.uploadId);
        sendBackData = data;
        startPartitionAndUpload();
    });
}
function decideFileUpload() {
    // console.log('decideFileUpload ====> ');
    for (i = upItem; i < filesUploadStatus.length; i++) {
        if (uploadFilesArr.indexOf(filesUploadStatus[upItem]['file']['name']) >= 0) {
            uploadFile(filesUploadStatus[upItem]['file']);
            return;
        }
        else upItem = upItem + 1;
    }

    uploadProgress = false;
    //Added by Rohini R on 20/12/2016 to disable submit in CRM File upload while upload in progress
    if ($("#filesubmit").length) {
        $("#filesubmit").removeAttr("disabled");
    }
    //quotesubmitbtn(uploadProgress);
    //console.log("************* ALL Files uploaded successfully*************");
}
function bytesToSize(bytes, precision) {
    var kilobyte = 1024;
    var megabyte = kilobyte * 1024;
    var gigabyte = megabyte * 1024;
    var terabyte = gigabyte * 1024;

    if ((bytes >= 0) && (bytes < kilobyte)) {
        return bytes + ' B';

    } else if ((bytes >= kilobyte) && (bytes < megabyte)) {
        return (bytes / kilobyte).toFixed(precision) + ' KB';
    } else if ((bytes >= megabyte) && (bytes < gigabyte)) {
        return (bytes / megabyte).toFixed(precision) + ' MB';

    } else if ((bytes >= gigabyte) && (bytes < terabyte)) {
        return (bytes / gigabyte).toFixed(precision) + ' GB';
    } else if (bytes >= terabyte) {
        return (bytes / terabyte).toFixed(precision) + ' TB';
    } else {
        return bytes + ' B';
    }
}

function getAwsLocation(href) {
    var l   = document.createElement("a");
    l.href  = href;
    var str = l.hostname;
    str.indexOf(".");
    var s3Bucket = str.substr(0, str.indexOf("."));
    return awsUrl + s3Bucket + l.pathname;
}
//on blur data capturing - start

function updateFormInfo(blurdataInfo) {
    var fieldname  = blurdataInfo.fieldname;
    var fieldlabel = $('label[for="' + fieldname + '"]').text();
    var fieldlabel = fieldlabel.trim();
    var fieldvalue = $('#' + fieldname).val();
    var fieldtype  = $('#' + fieldname).attr('type');
    if (fieldtype == 'checkbox') {
        if ($('#' + fieldname).is(':checked')) {
            fieldvalue = 'Yes';
        } else {
            fieldvalue = 'No';
        }
    }
    if (fieldlabel) {
        if ((fieldlabel == 'Translate To' || fieldlabel == 'Target Language' || fieldlabel == 'Language') && fieldvalue) {
            fieldvalue = fieldvalue.toString().replace(/,/g, '-');
        }
        if (fieldlabel == 'How Long is Your Video?' && fieldvalue) {
            fieldvalue = fieldvalue.toString().replace(/:/g, '-');
        }
        onblurdataarray.push(fieldlabel + ':' + fieldvalue);
    } else {
        if (fieldname == 'qmailmsgcrm')
            fieldname = 'mail comment';
        onblurdataarray.push(fieldname + ':' + fieldvalue);
    }
    if ($('#qsourcecrm').val())
        onblurdataarray.push('Translate From' + ':' + $('#qsourcecrm').val());
    else if ($('#qsourcevoicecrm').val())
        onblurdataarray.push('Translate From' + ':' + $('#qsourcevoicecrm').val());
    else if ($('#language').val() && $('#channel_id').val() == 7)
        onblurdataarray.push('language' + ':' + $('#language').val());

    blurdataInfo.qname       = $('#qnamecrm').val();
    blurdataInfo.qemail      = $('#qemailcrm').val();
    blurdataInfo.qcountrys   = $('#qcountryscrm').val();
    blurdataInfo.acode       = $('#acodecrm').val();
    blurdataInfo.qphone      = $('#qphonecrm').val();
    blurdataInfo.entryval    = $('#recordkey').val();
    blurdataInfo.serviceid   = $('#serviceid').val();
    blurdataInfo.channel_id  = $('#channel_id').val();
    blurdataInfo.filedetails = uploadedFileDetailsArr.toString();
    blurdataInfo.fieldname1  = onblurdataarray.toString();
    if ($('#recordkey').val()) {
        var id = '';
    } else {
        var id = new Date().getTime();
        $('#recordkey').val(id);
    }
    blurdataInfo.id = id;
    if ($('#qemailcrm').val()) {
        $.ajax({
            url: crmFormsavepath + 'save/crmformdata',
            data: {
                command: 'updatefieldinfo',
                sitename: sitename,
                savedata: blurdataInfo,
                async: false,
            },
            type: 'POST',
            success: function (data) {
                $('#recordkey').val(data.trim());
            }
        });
    }
}
var etat = '';
//on blur data capturing - end
$(document).ready(function () {
    getUploadPartSize();
    //on blur data capturing - start

    if ($('#channel_id').val() == 7) {
        var formid = $('#quick_servicetype').val();
    }
    else {
        var formid = $('#formid').val();
    }
    $('#' + formid + " :input").each(function () {
        var input = $(this).attr("id"); // This is the jquery object of the input, do what you will

        if (input == 'qtargetcrm')
            var j = jc('#' + input);
        else if (input == 'expected_turnaround')
            var j = $('.datetimepicker');
        else
            var j = $('#' + input);

        j.on('change blur', function (e) {
            var email = $('#qemailcrm').val();
            var reg   = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
            if (reg.test(email) == true) {
                blurdataInfo           = {};
                blurdataInfo.comments  = $(this).val();
                blurdataInfo.fieldname = $(this).attr('id');
                if (input == 'expected_turnaround')
                    setTimeout(function () {
                        var etat                         = $('#expected_turnaround').val();
                        blurdataInfo.expected_turnaround = etat;
                        updateFormInfo(blurdataInfo);
                    }, 100);
                else if (input != 'file')
                    updateFormInfo(blurdataInfo);

            }

        });
    });

//    } else {
//            $("#qemailcrm,#qcountryscrm,#acodecrm,#qphonecrm,#qnamecrm").blur(function () {
//                var email = $('#qemailcrm').val();
//                var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
//                if (reg.test(email) == true)
//                {
//                    blurdataInfo = {};
//                    blurdataInfo.comments = $(this).val();
//                    blurdataInfo.fieldname = $(this).attr('id');
//                    updateFormInfo(blurdataInfo);
//                }
//            });
//        }
    //on blur data capturing - end
});

$(document).on('click', '.up-close', function () {
    uploadId    = $(this).data('uploadid');
    var remFile = $(this).data('file');
    uploadFilesArr.splice(uploadFilesArr.indexOf(remFile), 1);
    uploadedFilesArr.splice(uploadedFilesArr.indexOf(remFile), 1);
    if (uploadedFileDetailsArr.length > 0) {
        for (i = 0; i < uploadedFileDetailsArr.length; i++) {
            var uploadedarrfilename  = uploadedFileDetailsArr[i].split("#-#");
            var uploadedarrfilename1 = uploadedarrfilename[0].substring(uploadedarrfilename[0].indexOf("_") + 1);
            if (uploadedarrfilename1 == remFile.replace(/[^A-Za-z0-9\_\-\.]/g, '')) {
                uploadedFileDetailsArr.splice(uploadedFileDetailsArr.indexOf(uploadedFileDetailsArr[i]), 1);
                blurdataInfo           = {};
                blurdataInfo.fieldname = "fileuploader";
                updateFormInfo(blurdataInfo);
            }
        }
    }

    $(this).parent().parent().remove();

    if (!uploadFilesArr.length)
        $('#info').hide();

    reorder();
});
function quotesubmitbtn(upProgress) {
    if (upProgress) {
        $('.progressbtn').show();
        $('.quotebtn').hide();
    } else {
        $('.progressbtn').hide();
        $('.quotebtn').show();
    }
    $('#uploadprogress').val(upProgress);
}

function makeid(Strlen) {
    var text     = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    for (var i = 0; i < Strlen; i++)
        text += possible.charAt(Math.floor(Math.random() * possible.length));
    return text;
}

function checkUnprocessData(partNum) {
    console.log('checkUnprocessData : ' + partNum);
    checkUnprocessFlag = true;
    var counter        = 0;
    intervalfunc       = setInterval(function () {
        counter++;
        uploadPart(partNum);
        if (counter >= 20) {
            clearInterval(intervalfunc);
        }
    }, 10000);
}


function getUploadPartSize() {
    $.getJSON('//freegeoip.net/json/?callback=?', function (data) {
        var country_code = data.country_code;
        switch (country_code) {
            case "IN":
                partSize = 5 * 1024 * 1024;
                break;
            case "US":
                partSize = 50 * 1024 * 1024;
                break;
            case "GB":
            case "AU":
            case "UK":
                partSize = 20 * 1024 * 1024;
                break;
            default :
                partSize = 50 * 1024 * 1024;
                break;
        }
    });

}

function showMessage(id) {
    var $body   = $('body');
    var $dialog = $(id);
    $body.append('<div id="fvpp-blackout"></div>');
    $dialog.append('');
    $blackout = $('#fvpp-blackout');
    var $blackout;
    $blackout.show();
    $("#fvpp-close").css({'display': "none"});
    $dialog.show();
    $(".DS-sidefixed-nav").css({'display': "none"});

}

function checkUnprocessCompletePart() {
    checkUnprocessCompletePartFlag = true;
    var counter                    = 0;
    intervalfunc_complete          = setInterval(function () {
        counter++;
        completeMultipartUpload();
        if (counter >= 20) {
            clearInterval(intervalfunc_complete);
        }
    }, 10000);
}

function checkUnprocesStartingPart(uploadFiles) {
    checkUnprocesStartingPartFlag = true;
    var counter                   = 0;
    intervalfunc_start            = setInterval(function () {
        counter++;
        uploadFile(uploadFiles);
        if (counter >= 20) {
            clearInterval(intervalfunc_start);
        }
    }, 10000);
}
function saveuploaderror(errorResponse) {
    dataInfo                 = {};
    var networkerrormailsent = 0;
    dataInfo.qname           = $('#qnamecrm').val();
    if ($('#qemailcrm').length) {
        dataInfo.qemail = $('#qemailcrm').val();
    } else {
        dataInfo.qemail = $('#sample_email').val();
    }
    //dataInfo.qcountrys = $('#qcountryscrm').val();
    //dataInfo.acode = $('#acodecrm').val();
    //dataInfo.qphone = $('#qphonecrm').val();
    dataInfo.entryval            = $('#recordkey').val();
    dataInfo.networkerrflag      = $('#networkerrflag').val();
    dataInfo.serviceid           = $('#serviceid').val();
    dataInfo.crmpage             = $('#crmpage').val();
    dataInfo.filedetails         = JSON.stringify(uploadFilesArr);
    dataInfo.fileuploadstatus    = JSON.stringify(filesUploadStatus);
    dataInfo.uploadprogress      = uploadProgress;
    dataInfo.uploaderrorresponse = errorResponse;
    dataInfo.uploadedfiledetails = JSON.stringify(uploadedFileDetailsArr);
    if (($('#qemailcrm').val() || $('#sample_email').val()) && $('#networkerrflag').val() == 0) {
        $.ajax({
            url: crmFormsavepath + 'save/crmformdata',
            data: {
                command: 'networkerror',
                networkerrordata: dataInfo,
                sitename: sitename,
                async: false,
            },
            type: 'POST',
            success: function (data) {
                $('#networkerrflag').val(data);
            }
        });
    }
}

function changeCancelFlag() {
    uploadProgress = false;
    resetProgressBar();
    resetParam();
    updateFinalInfo();
    decideFileUpload();
}

