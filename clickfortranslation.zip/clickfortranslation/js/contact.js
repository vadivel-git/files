
$('#csubmit').click(function(){
	
	var name=$('#cname').val();
	var email=$('#cemail').val();
	var country=$('#ccountry').val();
	var areacode=$('#careacode').val();	
	var phone=$('#cphone').val();
	var comment=$('#ccomment').val();
	
	
	var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
    var eaddress = email;
	
	if(name!=''  && email!='' && reg.test(eaddress) != false && country!='' && areacode!='' && phone!='' && comment!='')
	{
	$('#cfmsg').css({'color':'#0033ff'});		
	$('#cfmsg').html('Request Sending...');	

	$.ajax({
	url:'php/contact.php',
	data:"name="+encodeURIComponent(name)+"&email="+encodeURIComponent(email)+"&country="+encodeURIComponent(country)+"&areacode="+encodeURIComponent(areacode)+"&phone="+encodeURIComponent(phone)+"&comment="+encodeURIComponent(comment),
	type:'post',
	success: function(data){
		// alert(data);
	
	$('#cfmsg').html(data);
	$('#cfmsg').css({'color':'#333'});
	
	$('#cname').val('');
	$('#cemail').val('');
	$('#ccountry').val('');
	$('#careacode').val('');	
	$('#cphone').val('');
	$('#ccomment').val('');
	}
	
	});

	}
	else{
		if(name==''){
		$('#cfmsg').css({'color':'#F00'});	
		$('#cfmsg').html('Enter Name !');	
		}
		
		else if(email==''){
		$('#cfmsg').css({'color':'#F00'});	
		$('#cfmsg').html('Enter Email ID !');	
		}
		else if(reg.test(eaddress) == false) 
		 { 
      	 $('#cfmsg').css({'color':'#F00'});	
		 $('#cfmsg').html('Enter Valid Email Address !');
      	 return false;
   		 }
   		 else if(country==''){
		$('#cfmsg').css({'color':'#F00'});	
		$('#cfmsg').html('Select Country !');	
		}
		else if(areacode==''){
		$('#cfmsg').css({'color':'#F00'});	
		$('#cfmsg').html('Enter Area Code !');	
		}
		else if(phone==''){
		$('#cfmsg').css({'color':'#F00'});	
		$('#cfmsg').html('Enter Phone Number !');
		}
		else if(comment==''){
		$('#cfmsg').css({'color':'#F00'});	
		$('#cfmsg').html('Enter Comment !');	
		
		}
			
		}

});

