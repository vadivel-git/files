<?php include 'vip/doctype.php';
$FILEUPLOADMSG = 0;
?>
<link rel="canonical" href="http://clickfortranslation.com/Translation-Payment.php" >
<title>Get free translation quote ($25/page)</title>
<meta name="keywords" content="Free online translation quote"/>
<meta name="description" content="click for translation – Free online translation quote ($25/page)."/>
<?php include 'vip/site_verification.php'; ?>
<?php include 'vip/All-links.php'; ?>
<link rel="stylesheet" href="css/bootstrap-datetimepicker.min.css">
<link rel="stylesheet" href="css/bootstrap-multiselect.css">
<body>     <!-- side-nav --> <?php include 'vip/inner-sidefixed-nav-block.php'; ?>
<div class="DS-wrapper">      <!-- header-Block --> <?php include 'vip/header-block.php'; ?> <!-- baner-block -->
    <section class="DS-all-services">
        <div class="DS-res-clear-25"></div>
        <div class="DS-clrar-50 DS-space-reduce-320"></div>
        <div class="container">
            <div class="row"><h1 class="DS-h-head1"> Check your project price for free </h1>
                <div class="DS-h-slogen">we’ll get back to you within a couple of minutes or less</div>
            </div>
        </div>
        <div class="DS-res-clear-25"></div>
        <div class="DS-clrar-50 DS-space-reduce-320"></div>
    </section>      <!-- inner-msg-box -->
    <section>
        <div class="DS-clrar-50"></div>
        <div class="container DS-container-width">
            <div class="row">            <!-- left-side-block -->           <!-- to languages -->
                <?php if (isset($_GET["language"])) {
                    $lang = $_GET["language"];
                    if ($lang != '') {
                        $lang = $_GET["language"];
                    } else {
                        $lang = '';
                    }
                } else {
                    $lang = '';
                }
                echo '<input type="hidden" id="tolanguage" value="' . $lang . '" />';
                //include'vip/quote-form1.php';
                error_reporting(0);
                $post = http_build_query(
                    array(
                        'service_type' => 'quick_transcription',
                        'page' => 'upload',
                        'servervariable' => $_SERVER,
                        'cookievariable' => $_COOKIE,
                        'requestvariable' => $_REQUEST,
                        'version' => '__CRMCENTFORM-V-1.0__'
                    )
                );
                $ch = curl_init('http://localhost/projects/clickfortranslation/translation_payment_contact_v1.0.php');
                //$ch = curl_init('http://protect-dt.com/staging/dtcrm/get-quote-form.php');
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
                curl_setopt($ch, CURLOPT_HEADER, 0);
                $response = curl_exec($ch);
                if ($response) {
                    curl_close($ch);
                    echo $response;
                } else {
                    $ch = curl_init('http://protect-dt.com/dtcrm/get-quote-form.php');
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
                    curl_setopt($ch, CURLOPT_HEADER, 0);
                    $response = curl_exec($ch);
                    curl_close($ch);
                    echo $response;
                }
                $CRMFORM = "1";
                ?><!-- to languages -->               <!--  </form> -->                <!-- form-end -->
                <!-- inner-area-block-end -->
                <!-- right-side-block --> <?php //include 'vip/inner-rightside-box-quote.php'; ?>          </div>
        </div>
        <div class="DS-clrar-50"></div>
    </section>      <!-- conversion-button --> <?php include 'vip/footer-conversion-block.php'; ?>
    <!-- contact-number --> <?php include 'vip/contact-number-block.php'; ?>
    <!-- conversion-button --> <?php include 'vip/footer-block.php'; ?>
    <script>var val = location.href.match('http://clickfortranslation.com/Translation-Quote.php'); // get params from URL$("input:text:visible:first").focus();</script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <!-- Common javascript plgins -->
    <script src="js/validation.js?<?php echo $RANDOMNO ?>"></script>
    <script src="js/quote_translation1.js?<?php echo $RANDOMNO ?>"></script>
    <script src="js/bootstrap-datetimepicker.min.js?<?php echo $RANDOMNO ?>"></script>
    <script src="js/bootstrap-multiselect.js?<?php echo $RANDOMNO ?>"></script>
    <script src="js/jquery.MultiFile.js?<?php echo $RANDOMNO ?>"></script>